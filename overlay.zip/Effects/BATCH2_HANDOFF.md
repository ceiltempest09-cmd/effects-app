# Batch 2 continuation handoff

## Current source
This is the `overlay.zip` project tree. Keep the `Effects/` folder as the archive root.
`Effects.zip` is a supporting reference archive; it is not the upload target.

## Native GLES baseline restored and verified
The following native test infrastructure was restored from the matching Effects source archive:
- `tests/native/run.sh`
- `tests/native/build_gl.sh`
- `docs/NATIVE_SHADERS.md`

The host suite was run against this source tree on Mesa llvmpipe:
- Render graph: 183 checks passed.
- Native shader: 105 checks passed.
- SPIR-V reflection: 22 checks passed.
- GLSL wrapper: 22 checks passed.
- History signature: 16 checks passed.
- Color pipeline: 114 checks passed.
- Real GLES / desktop GL backend: 1,227 checks passed, 0 failed, 1 skipped.
- The skipped check requires a SPIR-V compiler and Vulkan device unavailable in this host test build.

## Batch 2 status — NOT COMPLETE
This verification covers the standalone native render-graph backend. It does not establish that the Android app uses it as its primary renderer.

Still Skia-backed:
- `shared/cpp/engine.cpp` frame lifecycle and scene composition.
- `shared/cpp/scene.h` / `scene.cpp` scene and path model.
- Drawing, shapes, styles, text, and preview integration.
- Video-frame integration still adapts native YUV output back into a Skia image.
- The native GL graph bridge is implemented for the Graphite/Vulkan path; the Ganesh/OpenGL path explicitly refuses native sharing.

## Next engineering task
Implement a safe engine-owned GPU bridge for the Ganesh/OpenGL engine (same EGL context, AHardwareBuffer-backed shared surfaces, correct flush/synchronization and lifetime), then connect the frame lifecycle to the native graph. Do not create an unrelated second GL context for Ganesh. Do not remove Skia build dependencies until scene, drawing, text, video, and preview paths have real replacements and Android/device validation passes.

Android Gradle/NDK build and physical-device validation have not been run in this step.


## Batch 2 continuation — video GL state isolation (2026-11-22)

Hardened `shared/cpp/gl_yuv.cpp` in the native YUV-to-RGBA texture path:
- Added an RAII GL state guard around conversion.
- Restores the caller's framebuffer, viewport, current program, active texture unit, 2D/external texture bindings, VAO, array buffer, color write mask, and blend/scissor/depth/stencil/cull enable states.
- Removed the unconditional framebuffer reset to framebuffer 0; the exact previous framebuffer is restored instead.
- This prevents video-frame conversion from corrupting the editor renderer's GL state when both use the same EGL context.

Validation:
- `tests/native/run.sh`: 183 render-graph, 105 native-shader, 22 SPIR-V reflection, 22 GLSL wrapper, 16 history-signature, and 114 color-pipeline checks passed.
- GLES/desktop GL backend: 1,227 passed, 0 failed, 1 skipped.
- The YUV converter itself is Android-only and is not compiled by the host test runner. Android NDK build/device validation remains required.

Batch 2 is still not complete. The main scene/drawing/text renderer and the Skia-backed video-to-image adapter still require replacement and integration.


## Batch 2 continuation — Ganesh/OpenGL native graph bridge

The engine GPU bridge now has a Ganesh/OpenGL path in addition to the existing Graphite/Vulkan path:

- `GraphGpuBridge` exposes whether the native backend must adopt the engine's current EGL context and a stable context identity.
- The GLES render-graph backend adopts the engine EGL context for Ganesh instead of creating an unrelated second context.
- Ganesh wraps graph AHardwareBuffers with `SkSurfaces::WrapAndroidHardwareBuffer`; wrappers are cached and invalidated by `forgetBuffer`.
- Ganesh hand-off submits and waits on the same GL queue. Native writes invalidate Ganesh's cached GL state with `resetContext()`.
- The adopted GL backend is released by the engine before EGL teardown, after effect graphs are dropped.

Validation: the native host suite passes (183 render-graph, 105 shader, 22 SPIR-V reflection, 22 GLSL wrapper, 16 history-signature, 114 color-pipeline, and 1,227 GLES/desktop GL checks; one SPIR-V/Vulkan check skipped). These tests do not compile the Android-only `engine.cpp` or validate Ganesh AHardwareBuffer wrapping on a device. Android Gradle/NDK build and physical-device verification are still required. Scene, drawing, text, preview, and the video SkImage adapter remain Skia-backed.


## Batch 2 continuation — isolate native YUV converter vertex/framebuffer state (2026-11-22)

Hardened the Android GLES YUV converter's state isolation in `shared/cpp/gl_yuv.cpp`:

- Saves and restores draw and read framebuffer bindings independently (rather than collapsing both to `GL_FRAMEBUFFER`).
- Saves/restores the sampler binding on texture unit 0.
- Uses a converter-owned VAO instead of mutating VAO 0 and its vertex attribute state.
- Checks allocation of the converter's GL objects and fails setup explicitly if one cannot be created.

Validation:
- Re-ran `tests/native/run.sh`: 183 render-graph, 105 native-shader, 22 SPIR-V reflection, 22 GLSL wrapper, 16 history-signature, 114 color-pipeline checks passed; GLES/desktop GL backend: 1,227 passed, 0 failed, 1 skipped.
- The YUV converter is Android-only and is not compiled by this host suite. Android NDK/Gradle build and physical-device validation remain required.

This is a grouped video-path correctness improvement, not a replacement of the Skia `SkImage` adapter. `EngineImpl::setVideoFrame()` still stores imported frames as `SkImage`; the native texture path is not yet the app's end-to-end video frame representation.


## Batch 2 continuation — grouped source audit (2026-11-22)

Re-opened the latest `overlay.zip` and `Effects.zip`; `overlay.zip` remains the main project source and `Effects.zip` remains supporting reference material. No Skia-dependent production files were overwritten from the supporting archive.

Added `tools/audit_skia_migration.py` to make the remaining migration measurable. It inventories production C++ Skia API use by subsystem and has a `--strict` mode that exits non-zero until the Skia dependencies are actually removed.

Audit result on this source:
- Engine/frame lifecycle: 160 matching lines in `engine.cpp`.
- Scene/path model: 194 matching lines across camera, depth, model and scene files.
- Drawing/shapes/styles/text/preview: 798 matching lines across 10 files.
- Video/image adapter: 8 direct matches in `gl_yuv.cpp/.h`; the engine still stores video frames as `SkImage`, so the true video dependency also appears in `engine.cpp`.
- Other Skia-dependent production C++ (effects, interpolation and supporting geometry): 363 matching lines.
- Total: 1,523 matching lines across 26 production C++ files.

Re-ran `tests/native/run.sh` from this exact source:
- Render graph: 183 passed.
- Native shader: 105 passed.
- SPIR-V reflection: 22 passed.
- GLSL wrapper: 22 passed.
- History signature: 16 passed.
- Color pipeline: 114 passed.
- GLES/desktop GL backend: 1,227 passed, 0 failed, 1 skipped.
- The one skip is SPIR-V/Vulkan execution because the host test environment has no SPIR-V compiler/Vulkan device.

This is a grouped audit and validation improvement, NOT a claim that the four application-renderer migration areas are converted. The app still uses Skia for the frame lifecycle, scene/path representation, drawing/shapes/styles/text/preview, and the video `SkImage` adapter. The Android Gradle/NDK build and physical-device validation have not been run. Keep Batch 2 open.

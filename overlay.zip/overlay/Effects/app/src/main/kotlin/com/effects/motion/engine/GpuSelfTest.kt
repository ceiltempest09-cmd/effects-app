package com.effects.motion.engine

object GpuSelfTest {
    @JvmStatic private external fun nativeRun(cacheDir: String): String

    fun run(cacheDir: String): String {
        System.loadLibrary("amengine")
        return nativeRun(cacheDir)
    }
}

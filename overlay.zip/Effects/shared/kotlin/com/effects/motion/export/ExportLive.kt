package com.effects.motion.export

/**
 * What the video encoder is really doing right now, for the export progress dialog.
 * Everything here is written by the export loop (VideoExport.kt) after each frame is handed to the encoder;
 * nothing is estimated or invented. The dialog only reads it.
 */
object ExportLive {
    class Preview(val rgba: ByteArray, val width: Int, val height: Int, val frame: Int)

    @Volatile var frame = 0
    @Volatile var frames = 0
    @Volatile var width = 0
    @Volatile var height = 0
    @Volatile var bitrate = 0
    @Volatile var preview: Preview? = null
    /** True while an earlier identical export is being copied instead of rendered (see ExportReuse). */
    @Volatile var reusing = false
    /** Smart Export: frames copied from an earlier export without rendering them. [frames] then counts only the frames that are drawn. */
    @Volatile var reusedFrames = 0
    /** Smart Export: the frame of the timeline being drawn (1-based); [frame] counts drawn frames. 0 when it is the same as [frame]. */
    @Volatile var position = 0
    /** Frames of the whole video, also when [frames] only counts the drawn ones. */
    @Volatile var timelineFrames = 0

    fun begin(frames: Int, width: Int, height: Int, bitrate: Int) {
        this.frames = frames
        timelineFrames = frames
        this.width = width
        this.height = height
        this.bitrate = bitrate
        frame = 0
        preview = null
        reusing = false
        reusedFrames = 0
        position = 0
    }

    fun clear() {
        frame = 0
        frames = 0
        preview = null
        reusing = false
        reusedFrames = 0
        position = 0
        timelineFrames = 0
    }
}

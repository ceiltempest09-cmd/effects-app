#!/bin/bash
# Builds and runs the REAL-GPU tests: the GL backend + render graph executor on whatever EGL driver the machine has
# (Mesa llvmpipe on a CPU-only host; any GLES 3 / GL 3.3 driver on a workstation). Needs libEGL + a GLES3 or GL driver at run time,
# no GL headers at build time. Exit code 1 on any failed check; skipped checks are listed and not counted as passes.
set -e
cd "$(dirname "$0")/../.."
CXX=${CXX:-g++}
OUT=${OUT:-/tmp/em-native-tests}; mkdir -p "$OUT"
$CXX -std=c++20 -fno-exceptions -fno-rtti -Wall -Wextra -O1 -I shared/cpp tests/native/gl_backend_test.cpp shared/cpp/gl_backend.cpp \
  shared/cpp/render_graph.cpp shared/cpp/render_graph_xml.cpp shared/cpp/xml.cpp shared/cpp/shader_info.cpp shared/cpp/shader_diag.cpp \
  shared/cpp/shader_cache.cpp shared/cpp/spirv_util.cpp -lexpat -ldl -lpthread -o "$OUT/gl_backend_test"
stdbuf -o0 "$OUT/gl_backend_test" || { echo "gl_backend_test FAILED"; exit 1; }

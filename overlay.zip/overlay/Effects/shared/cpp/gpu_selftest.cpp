// gpu_selftest.cpp - on-device checks for the native GL backend (+ a Vulkan capability probe).
// Everything marked PASS/FAIL below was produced by the phone's own GPU driver in this run. Nothing is simulated.
#include "gpu_selftest.h"

#include "gl_backend.h"

#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <sys/stat.h>

#if __has_include(<vulkan/vulkan.h>)
#include <vulkan/vulkan.h>
#define AM_HAVE_VULKAN 1
#endif

namespace am {
using namespace rg;

namespace {
struct Report {
    std::string text; int pass = 0, fail = 0, skip = 0;
    void line(const std::string& s) { text += s + "\n"; }
    void ok(const std::string& s) { pass++; line("PASS  " + s); }
    void bad(const std::string& s) { fail++; line("FAIL  " + s); }
    void skp(const std::string& s) { skip++; line("SKIP  " + s); }
    void check(bool c, const std::string& s) { if (c) ok(s); else bad(s); }
};

std::string Num(double v) { char b[64]; std::snprintf(b, sizeof b, "%.5g", v); return b; }

const char* kHeader = "#version 300 es\nprecision highp float;\n";
// Pass A: horizontal ramp (red), constant green, constant blue (> 1 = HDR, only checked on float formats).
const char* kPassA =
    "uniform vec2 size;\nuniform float hdr;\nout vec4 o;\n"
    "void main() { o = vec4((gl_FragCoord.x) / size.x, 0.25, hdr, 1.0); }\n";
// Pass B: reads A, scales channels. Proves a second pass can sample the first pass's GPU texture.
const char* kPassB =
    "uniform sampler2D src;\nuniform vec2 size;\nout vec4 o;\n"
    "void main() { vec4 s = texture(src, gl_FragCoord.xy / size); o = s * vec4(0.5, 2.0, 1.0, 1.0); }\n";

PassDesc Make(const char* id, const char* body) {
    PassDesc p; p.id = id; p.name = id; p.lang = Lang::GLSLES; p.file = "selftest"; p.line = 1;
    p.source = std::string(kHeader) + body; return p;
}

bool Run(GlBackend& be, const PassDesc& p, Target* out, Target* in, int w, int h, std::string* err, const char* inName = "src") {
    static std::string name; name = inName;
    PassRun r; r.pass = &p; r.output = out; r.areaWidth = w; r.areaHeight = h; r.clear = true;
    if (in) { BoundInput b; b.name = &name; b.target = in; b.filter = Filter::Nearest; b.wrap = Wrap::Clamp; r.inputs.push_back(b); }
    return be.run(r, err);
}

void RenderTest(Report& R, GlBackend& be, Format f) {
    const std::string tag = std::string("two-pass render ") + FormatText(f);
    if (!be.supports(f)) { R.skp(tag + ": format not renderable on this GPU"); return; }
    const int W = 64, H = 8;
    const bool hdr = f != Format::RGBA8;
    Target* a = be.create(W, H, f); Target* b = be.create(W, H, f);
    if (!a || !b) { R.bad(tag + ": could not allocate targets"); if (a) be.destroy(a); if (b) be.destroy(b); return; }
    PassDesc pa = Make("A", kPassA), pb = Make("B", kPassB);
    pa.constants.push_back({"hdr", {hdr ? 2.5f : 0.75f}});
    std::string err;
    if (!Run(be, pa, a, nullptr, W, H, &err)) { R.bad(tag + ": pass A failed: " + err); be.destroy(a); be.destroy(b); return; }
    if (!Run(be, pb, b, a, W, H, &err)) { R.bad(tag + ": pass B failed: " + err); be.destroy(a); be.destroy(b); return; }
    std::vector<float> px;
    if (!be.readback(b, &px)) { R.bad(tag + ": readback failed"); be.destroy(a); be.destroy(b); return; }
    double worst = 0;
    for (int y = 0; y < H; y++) for (int x = 0; x < W; x++) {
        const float* p = &px[((size_t)y * W + x) * 4];
        const double er = 0.5 * ((x + 0.5) / W), eg = 2.0 * 0.25, eb = hdr ? 2.5 : 0.75;
        worst = std::fmax(worst, std::fabs(p[0] - er)); worst = std::fmax(worst, std::fabs(p[1] - eg));
        worst = std::fmax(worst, std::fabs(p[2] - eb) / (hdr ? 2.5 : 1.0));
    }
    const double tol = f == Format::RGBA8 ? 3.0 / 255 : f == Format::RGBA16F ? 2e-3 : 1e-4;
    R.check(worst <= tol, tag + ": GPU output vs CPU expectation, max error " + Num(worst) + " (limit " + Num(tol) + ")");
    be.destroy(a); be.destroy(b);
}

void GlTests(Report& R, const std::string& cacheDir) {
    R.line("== OpenGL ES (native GLSL ES, driver-compiled) ==");
    std::string err;
    std::unique_ptr<GlContext> ctx = GlContext::Create(GlContext::Api::ES, &err);
    if (!ctx) { R.bad("could not create an OpenGL ES context: " + err); return; }
    GlOptions opt; opt.cacheDirectory = cacheDir; opt.profile = true;
    std::string cacheSub = cacheDir;
    if (!cacheSub.empty()) { mkdir(cacheSub.c_str(), 0700); }
    {
        GlBackend be(*ctx, opt);
        if (!be.ok()) { R.bad("GL backend unusable: " + be.error()); return; }
        const GlDeviceCaps& c = be.caps();
        R.line(c.describe());
        R.ok("GLSL ES context " + std::to_string(c.major) + "." + std::to_string(c.minor) + " on " + c.renderer);

        PassDesc bad = Make("broken", "out vec4 o;\nvoid main() { o = vec4(1.0) + undefined_symbol; }\n");
        std::string log; const int prog = be.compileProgramForTest(bad, &log);
        R.check(prog == 0 && !log.empty(), "driver rejects a broken shader and reports a message");
        if (!log.empty()) R.line("      driver message: " + log.substr(0, 160));

        RenderTest(R, be, Format::RGBA8);
        RenderTest(R, be, Format::RGBA16F);
        RenderTest(R, be, Format::RGBA32F);

        const GlStats& s = be.stats();
        R.line("stats: passes " + std::to_string(s.passesRun) + ", compiles " + std::to_string(s.shaderCompiles) +
               ", disk stores " + std::to_string(s.programDiskStores) + ", peak GPU bytes " + std::to_string(s.peakBytes));
        R.check(s.liveTargets == 0, "no GPU targets leaked after the tests");
        be.dropPrograms();
        R.check(be.programCount() == 0, "programs freed on memory pressure (dropPrograms)");
        R.check(!be.contextLost(), "context not reported lost");
    }
    if (!cacheDir.empty()) {
        GlBackend be2(*ctx, opt);
        if (be2.ok()) {
            if (!be2.caps().programBinary) R.skp("shader disk cache: driver has no program binary support");
            else {
                PassDesc pa = Make("A", kPassA); pa.constants.push_back({"hdr", {0.75f}});
                Target* t = be2.create(16, 4, Format::RGBA8); std::string e2;
                const bool ran = t && Run(be2, pa, t, nullptr, 16, 4, &e2);
                R.check(ran && be2.stats().programDiskHits >= 1 && be2.stats().shaderCompiles == 0,
                        "second run loads the compiled shader from the disk cache (hits " + std::to_string(be2.stats().programDiskHits) + ")");
                if (t) be2.destroy(t);
            }
        }
    }
}

void VulkanProbe(Report& R) {
    R.line("");
    R.line("== Vulkan (capability probe only) ==");
#ifdef AM_HAVE_VULKAN
    VkApplicationInfo ai = {VK_STRUCTURE_TYPE_APPLICATION_INFO};
    ai.apiVersion = VK_API_VERSION_1_1;
    VkInstanceCreateInfo ici = {VK_STRUCTURE_TYPE_INSTANCE_CREATE_INFO};
    ici.pApplicationInfo = &ai;
    VkInstance inst = VK_NULL_HANDLE;
    if (vkCreateInstance(&ici, nullptr, &inst) != VK_SUCCESS) { R.bad("vkCreateInstance failed: Vulkan 1.1 unavailable"); return; }
    uint32_t n = 0; vkEnumeratePhysicalDevices(inst, &n, nullptr);
    if (n == 0) { R.bad("no Vulkan physical device"); vkDestroyInstance(inst, nullptr); return; }
    std::vector<VkPhysicalDevice> devs(n); vkEnumeratePhysicalDevices(inst, &n, devs.data());
    for (VkPhysicalDevice d : devs) {
        VkPhysicalDeviceProperties pr; vkGetPhysicalDeviceProperties(d, &pr);
        R.ok(std::string("Vulkan device: ") + pr.deviceName + ", API " + std::to_string(VK_VERSION_MAJOR(pr.apiVersion)) + "." +
             std::to_string(VK_VERSION_MINOR(pr.apiVersion)) + "." + std::to_string(VK_VERSION_PATCH(pr.apiVersion)) +
             ", max image " + std::to_string(pr.limits.maxImageDimension2D));
        const struct { VkFormat f; const char* n; } fm[] = {{VK_FORMAT_R8G8B8A8_UNORM, "RGBA8"}, {VK_FORMAT_R16G16B16A16_SFLOAT, "RGBA16F"}, {VK_FORMAT_R32G32B32A32_SFLOAT, "RGBA32F"}};
        for (auto& x : fm) {
            VkFormatProperties p; vkGetPhysicalDeviceFormatProperties(d, x.f, &p);
            const VkFormatFeatureFlags t = p.optimalTilingFeatures;
            const bool att = t & VK_FORMAT_FEATURE_COLOR_ATTACHMENT_BIT, bl = t & VK_FORMAT_FEATURE_COLOR_ATTACHMENT_BLEND_BIT;
            const bool smp = t & VK_FORMAT_FEATURE_SAMPLED_IMAGE_BIT, lin = t & VK_FORMAT_FEATURE_SAMPLED_IMAGE_FILTER_LINEAR_BIT;
            R.line(std::string("      ") + x.n + ": render " + (att ? "yes" : "NO") + ", blend " + (bl ? "yes" : "NO") + ", sample " + (smp ? "yes" : "NO") +
                   ", linear filter " + (lin ? "yes" : "NO"));
        }
    }
    vkDestroyInstance(inst, nullptr);
#else
    R.skp("this build has no Vulkan headers");
#endif
    R.line("NOT IMPLEMENTED in this build: Vulkan GLSL compilation, SPIR-V execution, Skia texture sharing.");
}
}  // namespace

std::string RunGpuSelfTest(const std::string& cacheDirectory) {
    Report R;
    R.line("Effects native GPU self-test");
    GlTests(R, cacheDirectory);
    VulkanProbe(R);
    R.line("");
    R.line("RESULT: " + std::to_string(R.pass) + " passed, " + std::to_string(R.fail) + " failed, " + std::to_string(R.skip) + " skipped");
    return R.text;
}
}  // namespace am

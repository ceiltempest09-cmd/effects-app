// What the GPU fences between Skia (Vulkan) and the native GL backend actually did, process wide. Reports and tests read these, so a report
// shows what ran on the hardware (a real GPU-side wait, or the CPU fallback). No dependencies on purpose.
#pragma once
#include <atomic>
#include <cstdint>

namespace am::rg {
struct FenceCounts {
    // Skia side (engine.cpp submitAndSignal)
    std::atomic<int64_t> exported{0};       // hand-offs that produced a sync fd
    std::atomic<int64_t> alreadyDone{0};    // the driver reported the work finished already (no fd needed)
    std::atomic<int64_t> cpuFallback{0};    // nothing to fence, or the device cannot export: the CPU waited
    // GL side (GlBackend::waitForeign)
    std::atomic<int64_t> gpuWaits{0};       // the GL queue waits for the fence, the CPU does not
    std::atomic<int64_t> cpuWaits{0};       // the thread waited on the fence itself
    // GL -> Skia direction (the native backend hands a buffer to Skia)
    std::atomic<int64_t> glExported{0};     // GL made a native fence fd instead of glFinish
    std::atomic<int64_t> glExportFallback{0}; // GL could not make one (no extension, or nothing pending): glFinish was used
    std::atomic<int64_t> skiaGpuWaits{0};   // Skia queued the fd as a wait semaphore on its next submit (the CPU does not block)
    std::atomic<int64_t> skiaCpuWaits{0};   // Skia could not import it: the thread waited on the fd itself
};
inline FenceCounts& FenceCounters() { static FenceCounts counts; return counts; }
}  // namespace am::rg

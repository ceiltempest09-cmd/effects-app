#include "bridge_selftest.h"
#include "engine.h"
#include "fence_stats.h"

#include <android/hardware_buffer.h>
#include <android/log.h>

#include <algorithm>
#include <cmath>
#include <functional>
#include <cstdio>
#include <chrono>
#include <cstring>
#include <thread>
#include <unistd.h>
#include <vector>

namespace am {
void SetNativeShaders(bool on);   // effects_graph.cpp
bool NativeShadersEnabled();
void SetNativeFences(bool on);
bool NativeFencesEnabled();

namespace {
constexpr int kSize = 256;

const char* kSksl =
    "<effect id=\"fx.bridge_sksl\" graph=\"2\" output=\"out\" seek=\"reset\">\n"
    " <buffer id=\"m\" format=\"rgba16f\"/><buffer id=\"n\" format=\"rgba16f\"/>\n"
    " <pass id=\"a\" lang=\"sksl\" output=\"m\"><input name=\"image\" ref=\"source\"/><source><![CDATA[\n"
    "uniform shader image;\nhalf4 main(float2 p) { return image.eval(p) * 0.8; }\n]]></source></pass>\n"
    " <pass id=\"b\" lang=\"sksl\" output=\"n\"><input name=\"image\" ref=\"buffer:m\"/><source><![CDATA[\n"
    "uniform shader image;\nhalf4 main(float2 p) { return image.eval(p) * 0.5; }\n]]></source></pass>\n"
    " <pass id=\"c\" lang=\"sksl\" output=\"out\"><input name=\"image\" ref=\"buffer:n\"/><source><![CDATA[\n"
    "uniform shader image;\nhalf4 main(float2 p) { return image.eval(p); }\n]]></source></pass>\n"
    "</effect>\n";

const char* kNative =
    "<effect id=\"fx.bridge_native\" graph=\"2\" output=\"out\" seek=\"reset\">\n"
    " <buffer id=\"m\" format=\"rgba16f\"/><buffer id=\"n\" format=\"rgba16f\"/>\n"
    " <pass id=\"a\" lang=\"sksl\" output=\"m\"><input name=\"image\" ref=\"source\"/><source><![CDATA[\n"
    "uniform shader image;\nhalf4 main(float2 p) { return image.eval(p) * 0.8; }\n]]></source></pass>\n"
    " <pass id=\"b\" lang=\"glsl-es\" output=\"n\"><input name=\"src\" ref=\"buffer:m\"/><source><![CDATA[#version 300 es\n"
    "precision highp float;\nuniform sampler2D src;\nuniform vec2 size;\nout vec4 o;\n"
    "void main() { o = texture(src, gl_FragCoord.xy / size) * 0.5; }\n]]></source></pass>\n"
    " <pass id=\"c\" lang=\"sksl\" output=\"out\"><input name=\"image\" ref=\"buffer:n\"/><source><![CDATA[\n"
    "uniform shader image;\nhalf4 main(float2 p) { return image.eval(p); }\n]]></source></pass>\n"
    "</effect>\n";

// Control: SkSL -> (SkSL | GLSL ES) with a control `gain` -> SkSL. The scene sets gain per render.
std::string GainEffect(const char* id, bool native) {
    std::string x = std::string("<effect id=\"") + id + "\" graph=\"2\" output=\"out\" seek=\"reset\">\n"
        " <param name=\"gain\" value=\"0.5\"/>\n"
        " <buffer id=\"m\" format=\"rgba16f\"/><buffer id=\"n\" format=\"rgba16f\"/>\n"
        " <pass id=\"a\" lang=\"sksl\" output=\"m\"><input name=\"image\" ref=\"source\"/><source><![CDATA[\n"
        "uniform shader image;\nhalf4 main(float2 p) { return image.eval(p) * 0.8; }\n]]></source></pass>\n";
    if (native)
        x += " <pass id=\"b\" lang=\"glsl-es\" output=\"n\"><input name=\"src\" ref=\"buffer:m\"/><source><![CDATA[#version 300 es\n"
             "precision highp float;\nuniform sampler2D src;\nuniform vec2 size;\nuniform float gain;\nout vec4 o;\n"
             "void main() { o = texture(src, gl_FragCoord.xy / size) * gain; }\n]]></source></pass>\n";
    else
        x += " <pass id=\"b\" lang=\"sksl\" output=\"n\"><input name=\"image\" ref=\"buffer:m\"/><source><![CDATA[\n"
             "uniform shader image;\nuniform float gain;\nhalf4 main(float2 p) { return image.eval(p) * half(gain); }\n]]></source></pass>\n";
    x += " <pass id=\"c\" lang=\"sksl\" output=\"out\"><input name=\"image\" ref=\"buffer:n\"/><source><![CDATA[\n"
         "uniform shader image;\nhalf4 main(float2 p) { return image.eval(p); }\n]]></source></pass>\n</effect>\n";
    return x;
}

// Colour control: the effect declares `tint` with type="color" (the format that marks a colour for native passes). A native GLSL ES pass gets
// R, G, B, A in a vec4 and must match SkSL's `layout(color) uniform half4`.
std::string TintEffect(const char* id, bool native) {
    std::string x = std::string("<effect id=\"") + id + "\" graph=\"2\" output=\"out\" seek=\"reset\">\n"
        " <param name=\"tint\" value=\"#ffffffff\" type=\"color\"/>\n"
        " <buffer id=\"m\" format=\"rgba16f\"/>\n";
    if (native)
        x += " <pass id=\"a\" lang=\"glsl-es\" output=\"m\"><input name=\"src\" ref=\"source\"/><source><![CDATA[#version 300 es\n"
             "precision highp float;\nuniform sampler2D src;\nuniform vec2 size;\nuniform vec4 tint;\nout vec4 o;\n"
             "void main() { o = texture(src, gl_FragCoord.xy / size) * tint; }\n]]></source></pass>\n";
    else
        x += " <pass id=\"a\" lang=\"sksl\" output=\"m\"><input name=\"image\" ref=\"source\"/><source><![CDATA[\n"
             "uniform shader image;\nlayout(color) uniform half4 tint;\nhalf4 main(float2 p) { return image.eval(p) * tint; }\n]]></source></pass>\n";
    x += " <pass id=\"c\" lang=\"sksl\" output=\"out\"><input name=\"image\" ref=\"buffer:m\"/><source><![CDATA[\n"
         "uniform shader image;\nhalf4 main(float2 p) { return image.eval(p); }\n]]></source></pass>\n</effect>\n";
    return x;
}

// History: acc = 0.5 * source + 0.5 * acc[previous frame]; the layer moves, so every frame differs and the trail is visible.
std::string TrailEffect(const char* id, bool native) {
    std::string x = std::string("<effect id=\"") + id + "\" graph=\"2\" output=\"out\" seek=\"reset\">\n"
        " <buffer id=\"acc\" format=\"rgba16f\" history=\"1\"/>\n";
    if (native)
        x += " <pass id=\"mix\" lang=\"glsl-es\" output=\"acc\"><input name=\"image\" ref=\"source\"/><input name=\"prev\" ref=\"buffer:acc@1\"/><source><![CDATA[#version 300 es\n"
             "precision highp float;\nuniform sampler2D image;\nuniform sampler2D prev;\nuniform vec2 size;\nout vec4 o;\n"
             "void main() { vec2 uv = gl_FragCoord.xy / size; o = texture(image, uv) * 0.5 + texture(prev, uv) * 0.5; }\n]]></source></pass>\n";
    else
        x += " <pass id=\"mix\" lang=\"sksl\" output=\"acc\"><input name=\"image\" ref=\"source\"/><input name=\"prev\" ref=\"buffer:acc@1\"/><source><![CDATA[\n"
             "uniform shader image;\nuniform shader prev;\nhalf4 main(float2 p) { return image.eval(p) * 0.5 + prev.eval(p) * 0.5; }\n]]></source></pass>\n";
    x += " <pass id=\"fin\" lang=\"sksl\" output=\"out\"><input name=\"image\" ref=\"buffer:acc\"/><source><![CDATA[\n"
         "uniform shader image;\nhalf4 main(float2 p) { return image.eval(p); }\n]]></source></pass>\n</effect>\n";
    return x;
}

// `props` = extra <property .../> lines inside the layer's <effect>; `moving` = the circle travels right over time.
std::string Scene(const std::string& effect, int size = kSize, const std::string& props = "", bool moving = false) {
    const std::string c = std::to_string(size / 2) + ".0," + std::to_string(size / 2) + ".0,0.0";
    const std::string dim = std::to_string(size);
    std::string xf = "    <transform><location value=\"" + c + "\"/><scale value=\"" + std::to_string(1.6 * size / kSize) + "," + std::to_string(1.6 * size / kSize) + "\"/></transform>\n";
    if (moving) {   // keyframe times run 0..1 over the layer's life (0..999 ms): at 30 fps the circle moves about 4% of the way per frame
        xf = "    <transform><location>\n"
             "      <kf t=\"0.0\" v=\"" + std::to_string(size / 4) + ".0," + std::to_string(size / 2) + ".0,0.0\"/>\n"
             "      <kf t=\"1.0\" v=\"" + std::to_string(size * 3 / 4) + ".0," + std::to_string(size / 2) + ".0,0.0\"/>\n"
             "    </location><scale value=\"1.0,1.0\"/></transform>\n";
    }
    return std::string("<?xml version='1.0' encoding='UTF-8' ?>\n<scene title=\"bridge\" width=\"") + dim + "\" height=\"" + dim + "\" exportWidth=\"" + dim + "\" exportHeight=\"" + dim + "\" "
        "bgcolor=\"#ff000000\" totalTime=\"999\" fps=\"30\">\n"
        "  <shape id=\"1\" label=\"Circle\" startTime=\"0\" endTime=\"999\" fillType=\"color\" s=\".circle\">\n" + xf +
        "    <fillColor value=\"#fff24949\"/>\n    <property name=\"size\" type=\"vec2\" value=\"" + std::to_string(size * 100 / kSize) + ".0," + std::to_string(size * 100 / kSize) + ".0\"/>\n" +
        (effect.empty() ? "" : "    <effect id=\"" + effect + "\">\n" + props + "    </effect>\n") + "  </shape>\n</scene>\n";
}

struct Shot { std::vector<uint8_t> rgba; double msPerFrame = 0; int frames = 0; };

// Renders `frames` consecutive frames (frame i at i * 1000 / 30 ms) and keeps the last one; `warmup` frames are not timed.
bool RenderFrames(Engine& engine, const std::string& scene, int size, int frames, Shot* out, std::string* why) {
    std::string error;
    if (!engine.setScene(scene, &error)) { *why = "setScene: " + error; return false; }
    AHardwareBuffer_Desc d = {};
    d.width = size; d.height = size; d.layers = 1; d.format = AHARDWAREBUFFER_FORMAT_R8G8B8A8_UNORM;
    d.usage = AHARDWAREBUFFER_USAGE_GPU_FRAMEBUFFER | AHARDWAREBUFFER_USAGE_GPU_SAMPLED_IMAGE | AHARDWAREBUFFER_USAGE_CPU_READ_OFTEN;
    AHardwareBuffer* buffer = nullptr;
    if (AHardwareBuffer_allocate(&d, &buffer) != 0 || !buffer) { *why = "cannot allocate the output buffer"; return false; }
    bool ok = true;
    int code = 0;
    std::chrono::steady_clock::time_point t0;
    for (int i = 0; i < frames && ok; i++) {
        if (i == 1) t0 = std::chrono::steady_clock::now();   // frame 0 pays for shader compilation and target creation
        code = engine.renderBuffer(buffer, i * 1000.0 / 30.0, 0xff000000);
        if (code != 0) { ok = false; *why = "renderBuffer returned " + std::to_string(code) + " at frame " + std::to_string(i); }
    }
    if (ok && frames > 1) {
        out->msPerFrame = std::chrono::duration<double, std::milli>(std::chrono::steady_clock::now() - t0).count() / (frames - 1);
        out->frames = frames - 1;
    }
    if (ok) {
        AHardwareBuffer_Desc info = {};
        AHardwareBuffer_describe(buffer, &info);
        void* mem = nullptr;
        if (AHardwareBuffer_lock(buffer, AHARDWAREBUFFER_USAGE_CPU_READ_OFTEN, -1, nullptr, &mem) != 0 || !mem) { *why = "cannot lock the output buffer"; ok = false; }
        else {
            out->rgba.assign((size_t)size * size * 4, 0);
            for (int y = 0; y < size; y++) std::memcpy(&out->rgba[(size_t)y * size * 4], static_cast<uint8_t*>(mem) + (size_t)y * info.stride * 4, (size_t)size * 4);
            AHardwareBuffer_unlock(buffer, nullptr);
        }
    }
    AHardwareBuffer_release(buffer);
    return ok;
}

bool Render(Engine& engine, const std::string& effect, std::vector<uint8_t>* rgba, std::string* why) {
    Shot s;
    if (!RenderFrames(engine, Scene(effect), kSize, 2, &s, why)) return false;   // twice: the second frame reuses every pooled target
    *rgba = std::move(s.rgba);
    return true;
}

int MaxDiff(const std::vector<uint8_t>& a, const std::vector<uint8_t>& b) {
    int m = 0;
    if (a.size() != b.size()) return 255;
    for (size_t i = 0; i < a.size(); i++) m = std::max(m, std::abs((int)a[i] - (int)b[i]));
    return m;
}
}  // namespace

void RunBridgeSelfTest(std::string* text, int* pass, int* fail, const std::string& cacheDir) {
    auto line = [&](const std::string& s) { *text += s + "\n"; __android_log_print(ANDROID_LOG_INFO, "BridgeSelfTest", "%s", s.c_str()); };   // logcat keeps partial results if a later test crashes
    auto ok = [&](const std::string& s) { (*pass)++; line("PASS  " + s); };
    auto bad = [&](const std::string& s) { (*fail)++; line("FAIL  " + s); };
    const std::string crumb = cacheDir + "/bridge-selftest.stage", skipFile = cacheDir + "/bridge-selftest.skip";
    auto readFile = [](const std::string& path) { std::string r; if (FILE* f = std::fopen(path.c_str(), "rb")) { char c[256]; size_t n; while ((n = std::fread(c, 1, sizeof c, f)) > 0) r.append(c, n); std::fclose(f); } return r; };
    auto writeFile = [](const std::string& path, const std::string& v) { if (FILE* f = std::fopen(path.c_str(), "wb")) { std::fwrite(v.data(), 1, v.size(), f); std::fflush(f); fsync(fileno(f)); std::fclose(f); } };
    std::string skip = readFile(skipFile);
    { const std::string died = readFile(crumb);
      if (!died.empty()) { skip += died + "\n"; line("CRASH  the previous run died inside stage '" + died + "'; that stage is skipped in this run (it is tried again on the run after)"); (*fail)++; writeFile(skipFile, died + "\n"); }
      else std::remove(skipFile.c_str()); }
    std::remove(crumb.c_str());
    // Runs one stage with a marker on disk; a stage named in the skip list is not run.
    auto stage = [&](const std::string& name, const std::function<void()>& body, bool heavy = false) {
        // Heavy stages (large targets, several engines at once) can take the whole phone down, so they only run when the file
        // <cacheDir>/bridge-selftest.allow-<name> exists.
        if (heavy && !std::fopen((cacheDir + "/bridge-selftest.allow-" + name).c_str(), "rb")) { line("SKIP  stage '" + name + "' (heavy: off by default after it rebooted a phone; not run)"); return; }
        if (skip.find(name + "\n") != std::string::npos) { line("SKIP  stage '" + name + "' (it crashed the app last time)"); return; }
        writeFile(crumb, name);
        body();
        std::remove(crumb.c_str());
    };
    line("== Skia <-> native GL bridge (real engine, Graphite on Vulkan) ==");
    const bool before = NativeShadersEnabled();
    SetNativeShaders(true);
    std::string error;
    std::unique_ptr<Engine> engine = Engine::Make(Backend::kGraphite, &error);
    if (!engine || engine->failed()) { bad("engine did not start: " + error); SetNativeShaders(before); return; }
    ok("engine started: " + engine->info().substr(0, 120));
    std::string a = engine->loadEffect(kSksl), b = engine->loadEffect(kNative);
    if (a != "ok") bad("all-SkSL reference effect did not load: " + a); else ok("all-SkSL reference effect loads");
    if (b != "ok") bad("SkSL -> GLSL ES -> SkSL effect did not load: " + b); else ok("SkSL -> GLSL ES -> SkSL effect loads (GLSL ES kept as GLSL ES)");
    if (a == "ok" && b == "ok") {
        std::vector<uint8_t> none, sksl, native;
        std::string why;
        if (!Render(*engine, "", &none, &why)) bad("render without effect: " + why);
        else if (!Render(*engine, "fx.bridge_sksl", &sksl, &why)) bad("render with the all-SkSL effect: " + why);
        else if (!Render(*engine, "fx.bridge_native", &native, &why)) bad("render with the native effect: " + why);
        else {
            const int engaged = MaxDiff(none, sksl);
            if (engaged > 40) ok("the reference effect changed the picture (max change " + std::to_string(engaged) + "/255)");
            else bad("the reference effect did not change the picture (max change " + std::to_string(engaged) + "); the comparison below proves nothing");
            const int d = MaxDiff(sksl, native);
            const std::string msg = "native GLSL ES pass between two SkSL passes matches the all-SkSL result, max difference " + std::to_string(d) + "/255 (limit 4)";
            if (d <= 4 && engaged > 40) ok(msg); else bad(msg);
        }
    }

    // ---------------------------------------------------------------- step 3: harder cases
    if (a == "ok" && b == "ok") {
        auto f1 = [](double v) { char t[32]; std::snprintf(t, sizeof t, "%.2f", v); return std::string(t); };
        const std::string gs = engine->loadEffect(GainEffect("fx.s3_gain_sksl", false)), gn = engine->loadEffect(GainEffect("fx.s3_gain_native", true));
        const std::string ts = engine->loadEffect(TrailEffect("fx.s3_trail_sksl", false)), tn = engine->loadEffect(TrailEffect("fx.s3_trail_native", true));
        if (gs != "ok" || gn != "ok" || ts != "ok" || tn != "ok") bad("step 3 effects did not load: " + gs + " | " + gn + " | " + ts + " | " + tn);
        else {
            ok("step 3 effects load (control and history, each as SkSL and with a native GLSL ES pass)");
            std::string why;
            const std::string g25 = "      <property name=\"gain\" type=\"float\" value=\"0.25\"/>\n";
            stage("control", [&] {   // a control that reaches the native pass by name
            Shot refDefault, refSet, natSet;
            if (!RenderFrames(*engine, Scene("fx.s3_gain_sksl", kSize), kSize, 2, &refDefault, &why)) bad("control: SkSL render with the default value: " + why);
            else if (!RenderFrames(*engine, Scene("fx.s3_gain_sksl", kSize, g25), kSize, 2, &refSet, &why)) bad("control: SkSL render with gain 0.25: " + why);
            else if (!RenderFrames(*engine, Scene("fx.s3_gain_native", kSize, g25), kSize, 2, &natSet, &why)) bad("control: native render with gain 0.25: " + why);
            else {
                const int moved = MaxDiff(refDefault.rgba, refSet.rgba);
                if (moved > 20) ok("control: changing gain 0.5 -> 0.25 changes the SkSL picture (max change " + std::to_string(moved) + "/255)");
                else bad("control: changing gain did not change the SkSL picture (" + std::to_string(moved) + "); the native comparison proves nothing");
                const int d = MaxDiff(refSet.rgba, natSet.rgba);
                const std::string msg = "control: native pass with `uniform float gain` set to 0.25 by the scene matches SkSL, max difference " + std::to_string(d) + "/255 (limit 4)";
                if (d <= 4 && moved > 20) ok(msg); else bad(msg);
                Shot natDefault;
                if (RenderFrames(*engine, Scene("fx.s3_gain_native", kSize), kSize, 2, &natDefault, &why)) {
                    const int dd = MaxDiff(refDefault.rgba, natDefault.rgba);
                    const std::string m2 = "control: native pass with the effect's default gain (0.5) matches SkSL, max difference " + std::to_string(dd) + "/255 (limit 4)";
                    if (dd <= 4) ok(m2); else bad(m2);
                } else bad("control: native render with the default value: " + why);
            }
            });
            stage("color", [&] {   // a type="color" control reaches a native vec4 as R, G, B, A
            const std::string cs = engine->loadEffect(TintEffect("fx.s4_tint_sksl", false)), cn = engine->loadEffect(TintEffect("fx.s4_tint_native", true));
            if (cs != "ok" || cn != "ok") { bad("color: effects did not load: " + cs + " | " + cn); return; }
            const std::string tint = "      <property name=\"tint\" type=\"color\" value=\"#ff40a0e0\"/>\n";   // R 0.25, G 0.63, B 0.88: any channel swap shows
            Shot plain, refSet, natSet, natDefault;
            if (!RenderFrames(*engine, Scene("fx.s4_tint_sksl", kSize), kSize, 2, &plain, &why)) bad("color: SkSL render with the default (white): " + why);
            else if (!RenderFrames(*engine, Scene("fx.s4_tint_sksl", kSize, tint), kSize, 2, &refSet, &why)) bad("color: SkSL render with the tint: " + why);
            else if (!RenderFrames(*engine, Scene("fx.s4_tint_native", kSize, tint), kSize, 2, &natSet, &why)) bad("color: native render with the tint: " + why);
            else {
                const int moved = MaxDiff(plain.rgba, refSet.rgba);
                if (moved > 20) ok("color: the tint changes the SkSL picture (max change " + std::to_string(moved) + "/255)");
                else bad("color: the tint did not change the SkSL picture (" + std::to_string(moved) + "); the native comparison proves nothing");
                const int d = MaxDiff(refSet.rgba, natSet.rgba);
                const std::string msg = "color: native `uniform vec4 tint` (type=\"color\") set by the scene matches SkSL layout(color), max difference " + std::to_string(d) + "/255 (limit 4)";
                if (d <= 4 && moved > 20) ok(msg); else bad(msg);
                if (RenderFrames(*engine, Scene("fx.s4_tint_native"), kSize, 2, &natDefault, &why)) {
                    const int dd = MaxDiff(plain.rgba, natDefault.rgba);
                    const std::string m2 = "color: native pass with the effect's default colour (white) matches SkSL, max difference " + std::to_string(dd) + "/255 (limit 4)";
                    if (dd <= 4) ok(m2); else bad(m2);
                } else bad("color: native render with the default value: " + why);
            }
            });
            stage("history", [&] {   // history across frames (6 consecutive frames, the layer moves)
            const int kFrames = 6;
            Shot plain, trailSksl, trailNative;
            if (!RenderFrames(*engine, Scene("", kSize, "", true), kSize, kFrames, &plain, &why)) bad("history: moving layer without effect: " + why);
            else if (!RenderFrames(*engine, Scene("fx.s3_trail_sksl", kSize, "", true), kSize, kFrames, &trailSksl, &why)) bad("history: SkSL feedback render: " + why);
            else if (!RenderFrames(*engine, Scene("fx.s3_trail_native", kSize, "", true), kSize, kFrames, &trailNative, &why)) bad("history: native feedback render: " + why);
            else {
                const int trail = MaxDiff(plain.rgba, trailSksl.rgba);
                if (trail > 20) ok("history: the SkSL feedback effect leaves a trail behind the moving layer (max change " + std::to_string(trail) + "/255)");
                else bad("history: the SkSL feedback effect left no trail (" + std::to_string(trail) + "); the native comparison proves nothing");
                const int d = MaxDiff(trailSksl.rgba, trailNative.rgba);
                const std::string msg = "history: native pass reading its own previous frame (buffer:acc@1) matches SkSL after " + std::to_string(kFrames) + " frames, max difference " + std::to_string(d) + "/255 (limit 4)";
                if (d <= 4 && trail > 20) ok(msg); else bad(msg);
                if (trailSksl.frames > 0 && trailNative.frames > 0)
                    line("INFO  history timing at " + std::to_string(kSize) + "x" + std::to_string(kSize) + ": SkSL " + f1(trailSksl.msPerFrame) + " ms/frame, native " + f1(trailNative.msPerFrame) + " ms/frame (wall clock per renderBuffer, includes the GPU waits of the bridge)");
            }
            });
            stage("fences", [&] {   // GPU fences instead of CPU waits: the same native effects must give the same pictures
            const bool fencesBefore = NativeFencesEnabled();
            SetNativeFences(true);
            rg::FenceCounts& fs = rg::FenceCounters();
            rg::FenceCounts& gs2 = fs;
            const int64_t exp0 = fs.exported.load(), done0 = fs.alreadyDone.load(), cpu0 = fs.cpuFallback.load(), gpuW0 = gs2.gpuWaits.load(), cpuW0 = gs2.cpuWaits.load();
            Shot refSet, natSet, trailRef, trailNat;
            const int kFences = 6;
            if (!RenderFrames(*engine, Scene("fx.s3_gain_sksl", kSize, g25), kSize, 2, &refSet, &why)) bad("fences: SkSL render: " + why);
            else if (!RenderFrames(*engine, Scene("fx.s3_gain_native", kSize, g25), kSize, 2, &natSet, &why)) bad("fences: native render with fences on: " + why);
            else {
                const int d = MaxDiff(refSet.rgba, natSet.rgba);
                const std::string msg = "fences on: native pass with a control matches SkSL, max difference " + std::to_string(d) + "/255 (limit 4)";
                if (d <= 4) ok(msg); else bad(msg);
            }
            if (!RenderFrames(*engine, Scene("fx.s3_trail_sksl", kSize, "", true), kSize, kFences, &trailRef, &why)) bad("fences: SkSL feedback render: " + why);
            else if (!RenderFrames(*engine, Scene("fx.s3_trail_native", kSize, "", true), kSize, kFences, &trailNat, &why)) bad("fences: native feedback render with fences on: " + why);
            else {
                const int d = MaxDiff(trailRef.rgba, trailNat.rgba);
                const std::string msg = "fences on: native pass reading its own previous frame matches SkSL after " + std::to_string(kFences) + " frames, max difference " + std::to_string(d) + "/255 (limit 4)";
                if (d <= 4) ok(msg); else bad(msg);
            }
            const int64_t exported = fs.exported.load() - exp0, already = fs.alreadyDone.load() - done0, cpuFb = fs.cpuFallback.load() - cpu0;
            const int64_t gpuWaits = gs2.gpuWaits.load() - gpuW0, cpuWaits = gs2.cpuWaits.load() - cpuW0;
            SetNativeFences(fencesBefore);
            line("INFO  fence hand-offs in this stage: Skia exported " + std::to_string(exported) + " sync fds, " + std::to_string(already) + " were already finished, " + std::to_string(cpuFb) +
                 " used the CPU wait (no fence possible); the GL side queued " + std::to_string(gpuWaits) + " GPU-side waits and waited " + std::to_string(cpuWaits) + " times on the CPU");
            if (exported + already + cpuFb == 0) bad("fences: no hand-off went through the fenced path, so the comparison above proves nothing about fences");
            else if (exported > 0 && gpuWaits > 0) ok("fences: real GPU-side fences were used (" + std::to_string(exported) + " exported by Vulkan, " + std::to_string(gpuWaits) + " waited for by the GL queue)");
            else if (exported > 0) line("NOTE  fences: Vulkan exported fences but EGL could not wait for them on the GPU (" + std::to_string(cpuWaits) + " CPU waits): this device has no EGL native-fence wait; results are still correct");
            else line("NOTE  fences: this device cannot export a Vulkan semaphore as a sync fd (or there was nothing to fence): every hand-off used the CPU wait, results are still correct; no GPU fence ran");
            });
            for (const int k4 : {2048, 3840}) stage("size" + std::to_string(k4), [&, k4] {   // large targets: 2048 first so a memory limit shows where it starts
            Shot big, bigRef;
            if (!RenderFrames(*engine, Scene("fx.s3_gain_sksl", k4, g25), k4, 4, &bigRef, &why)) bad("size " + std::to_string(k4) + ": SkSL render: " + why);
            else if (!RenderFrames(*engine, Scene("fx.s3_gain_native", k4, g25), k4, 4, &big, &why)) bad("size " + std::to_string(k4) + ": native render: " + why);
            else {
                const int d = MaxDiff(bigRef.rgba, big.rgba);
                const std::string msg = "large target " + std::to_string(k4) + "x" + std::to_string(k4) + " (RGBA16F buffers shared between Skia and GL): native matches SkSL, max difference " + std::to_string(d) + "/255 (limit 4)";
                if (d <= 4) ok(msg); else bad(msg);
                line("INFO  size " + std::to_string(k4) + " timing: SkSL " + f1(bigRef.msPerFrame) + " ms/frame, native " + f1(big.msPerFrame) + " ms/frame");
            }
            }, true);
        }
    }

    // ---------------------------------------------------------------- threads (last: a crash here would lose the printed report, logcat tag BridgeSelfTest keeps the lines)
    if (a == "ok" && b == "ok") {
        const std::string g25 = "      <property name=\"gain\" type=\"float\" value=\"0.25\"/>\n";
        struct Job { Shot native, sksl; std::string why; bool started = false, done = false; };
        auto work = [&](Job* j) {
            std::string e;
            std::unique_ptr<Engine> own = Engine::Make(Backend::kGraphite, &e);
            if (!own || own->failed()) { j->why = "engine did not start: " + e; return; }
            j->started = true;
            if (own->loadEffect(GainEffect("fx.s3_gain_sksl", false)) != "ok" || own->loadEffect(GainEffect("fx.s3_gain_native", true)) != "ok") { j->why = "effects did not load"; return; }
            if (!RenderFrames(*own, Scene("fx.s3_gain_sksl", kSize, g25), kSize, 3, &j->sksl, &j->why)) return;
            if (!RenderFrames(*own, Scene("fx.s3_gain_native", kSize, g25), kSize, 3, &j->native, &j->why)) return;
            j->done = true;
        };
        Job one;
        stage("thread-worker", [&] {
        std::thread([&] { work(&one); }).join();
        if (!one.done) bad("worker thread: an engine created and used only on another thread could not render a native effect: " + one.why);
        else {
            const int d = MaxDiff(one.sksl.rgba, one.native.rgba);
            const std::string msg = "worker thread: an engine created and used only on a thread other than the caller renders the native effect like SkSL, max difference " + std::to_string(d) + "/255 (limit 4)";
            if (d <= 4) ok(msg); else bad(msg);
        }
        }, true);
        Job x, y;   // two engines at the same time, each with its own thread, as a preview and an export would
        stage("thread-pair", [&] {
        std::thread t1([&] { work(&x); }), t2([&] { work(&y); });
        t1.join(); t2.join();
        if (!x.done || !y.done) bad("two threads at once, one engine each: " + (x.done ? y.why : x.why));
        else {
            const int d1 = MaxDiff(x.sksl.rgba, x.native.rgba), d2 = MaxDiff(y.sksl.rgba, y.native.rgba), d3 = MaxDiff(x.native.rgba, y.native.rgba);
            const std::string msg = "two threads at once, one engine each: native matches SkSL on both (max difference " + std::to_string(d1) + " and " + std::to_string(d2) + "/255) and the two native results agree (" + std::to_string(d3) + "/255), limit 4";
            if (d1 <= 4 && d2 <= 4 && d3 <= 4) ok(msg); else bad(msg);
        }
        }, true);
        line("NOT TESTED  one Engine shared by a preview thread and an export thread, and a native graph that moves to another thread after it started (the code refuses that with an error; nothing here proves the refusal is clean on the real engine)");
    }
    engine.reset();
    SetNativeShaders(before);
}
}  // namespace am

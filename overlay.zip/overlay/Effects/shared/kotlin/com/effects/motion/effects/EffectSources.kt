package com.effects.motion.effects

import com.effects.motion.engine.bitdepth.BitDepth
import com.effects.motion.platform.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap

/**
 * Where an effect is stored. Effects Motion = the app's own library; After Effects and Alight Motion are the two built-in imported libraries;
 * any number of custom libraries (see [CustomLibraries]) follow them. The After Effects library is kept, but After Effects plug-in files
 * (.aex and friends) can no longer be imported.
 */
object EffectSources {
    const val Native = "em"
    const val AfterEffects = "ae"
    const val AlightMotion = "am"
    val all: List<Pair<String, String>> = listOf(
        Native to "Effects Motion", AfterEffects to "After Effects", AlightMotion to "Alight Motion",
    )

    fun label(source: String): String = all.firstOrNull { it.first == source }?.second ?: CustomLibraries.name(source) ?: source

    /** Every library an effect can be stored in (the "Library effect" choice of the import dialog): built-in ones, then the custom ones. */
    fun choices(context: Context): List<Pair<String, String>> = listOf(Native to "Effects Motion") + CustomLibraries.list(context)

    /** The libraries shown as buttons under the Effects Library header, in sliding order: After Effects, Alight Motion, then the custom ones. */
    fun libraries(context: Context): List<Pair<String, String>> = CustomLibraries.list(context)

    /** True for a folder the user made in the import dialog (Custom...). */
    fun isCustom(source: String): Boolean = source.startsWith("cx_")
}

/** Custom effect libraries the user named in the import dialog. They sit next to the Alight Motion library; only the name list is stored here. */
object CustomLibraries {
    private const val Prefs = "effects"
    private const val Key = "custom_libraries"
    private val names = ConcurrentHashMap<String, String>()

    fun name(key: String): String? = names[key]

    fun list(context: Context): List<Pair<String, String>> {
        val raw = context.getSharedPreferences(Prefs, Context.MODE_PRIVATE).getString(Key, null) ?: return emptyList()
        val out = runCatching {
            val array = JSONArray(raw)
            List(array.length()) { i -> array.getJSONObject(i).let { it.getString("key") to it.getString("name") } }
        }.getOrDefault(emptyList())
        out.forEach { (key, name) -> names[key] = name }
        return out
    }

    /** The library a typed name stands for: a built-in or an existing custom library with the same name, otherwise a new key (not stored until [save]). */
    fun resolve(context: Context, typed: String): Pair<String, String> {
        val name = typed.trim().replace(Regex("\\s+"), " ").take(30)
        val known = EffectSources.choices(context)
        known.firstOrNull { it.second.equals(name, ignoreCase = true) }?.let { return it }
        val slug = name.lowercase(Locale.ROOT).replace(Regex("[^a-z0-9]+"), "_").trim('_').ifBlank { "library" }
        var key = "cx_$slug"
        var n = 2
        while (known.any { it.first == key }) key = "cx_${slug}_${n++}"
        return key to name
    }

    /** Remembers a custom library (does nothing for a built-in one or one that is already stored). */
    fun save(context: Context, key: String, name: String) {
        if (!key.startsWith("cx_")) return
        val current = list(context)
        if (current.any { it.first == key }) return
        val array = JSONArray()
        (current + (key to name)).forEach { (k, v) -> array.put(JSONObject().put("key", k).put("name", v)) }
        context.getSharedPreferences(Prefs, Context.MODE_PRIVATE).edit().putString(Key, array.toString()).apply()
        names[key] = name
    }
}

/**
 * The shader language chosen on import. It changes how the effect is built, not only its name:
 * GLSL keeps the shader as a native OpenGL ES pass, which runs in the float pipeline at the depth chosen (8 / 16 / 32 bit) and gives the better picture;
 * SkSL converts it for Skia only, the lower quality 8-bit path. Re-import an effect as GLSL to get the better quality.
 */
enum class ShaderLang(val label: String, val hint: String) {
    GLSL("GLSL", "Native, higher quality"),
    GLSL_ES("GLSL ES", "OpenGL ES, kept as written"),
    SPIRV("SPIR-V", "Vulkan: spirv / glsl-vk passes"),
    SKSL("SkSL", "Skia only, lower quality");

    companion object {
        fun named(name: String?): ShaderLang = values().firstOrNull { it.name == name } ?: GLSL
    }
}

/** Quality the user picks on import. Each tier is stored in the matching pack of the Default menu. */
enum class ImportTier(val pack: String, val depth: BitDepth, val label: String, val bits: String, val tierName: String) {
    RAYTRACED(EffectPacks.RayTraced, BitDepth.BIT32, "Heavy effects [32]", "32 bit", "Heavy effects"),
    VIBRANT(EffectPacks.Vibrant, BitDepth.BIT16, "Balance [16]", "16 bit", "Balance"),
    DEFAULT(EffectPacks.Default, BitDepth.BIT8, "Performance [8]", "8 bit", "Performance");

    companion object {
        fun named(name: String?): ImportTier = values().firstOrNull { it.name == name } ?: DEFAULT
    }
}

/** Categories of the After Effects library (your own list, edit freely). */
val AeCategories: Map<String, String> = linkedMapOf(
    "ae_blur" to "Blur & Sharpen", "ae_color" to "Color Correction", "ae_distort" to "Distort",
    "ae_generate" to "Generate", "ae_keying" to "Keying", "ae_noise" to "Noise & Grain",
    "ae_perspective" to "Perspective", "ae_stylize" to "Stylize", "ae_time" to "Time",
    "ae_transition" to "Transition", "ae_utility" to "Utility", "ae_other" to "Imported",
)

/** The Alight Motion library: the layout of the category picture (Color & Light ... Text). PNKJ and Custom are not part of it. */
val AlightMotionCategories: Map<String, String> = linkedMapOf(
    "colorlight" to "Color & Light", "drawedge" to "Drawing & Edge", "blur" to "Blur", "warp" to "Distortion/Warp",
    "procedural" to "Procedural", "3d" to "3D", "transform" to "Move/Transform", "repeat" to "Repeat",
    "matte" to "Matte/Mask/Key", "opacity" to "Opacity/Visibility", "text" to "Text",
)

/** Puts an Alight Motion file's own category name into one of the library's cards (tools/fxconvert.py does the same for the bundled files). */
fun amCardFor(category: String): String {
    val c = category.trim().lowercase(Locale.ROOT)
    if (c in AlightMotionCategories) return c
    return when (c) {
        "color", "light", "lighting", "glow" -> "colorlight"
        "drawing", "drawing/edge", "stylize" -> "drawedge"
        "distort", "distortion", "warp", "glitch" -> "warp"
        "generate", "generative" -> "procedural"
        "move", "move/transform" -> "transform"
        "mask", "key" -> "matte"
        "transition" -> "opacity"
        else -> "procedural"
    }
}

fun importedCategoryLabel(key: String): String =
    AeCategories[key] ?: AlightMotionCategories[key] ?: EffectCatalog.Categories[key]
        ?: key.replace('_', ' ').replaceFirstChar { it.titlecase(Locale.ROOT) }

/** Puts a category name into the category list of an Effects Motion pack, so an effect stored in the app's own library can be shown there. */
fun nativeCategoryFor(category: String, pack: String): String {
    val c = category.trim().lowercase(Locale.ROOT)
    val valid = EffectCatalog.categoriesOf(pack)
    if (c in valid) return c
    val mapped = when (pack) {
        EffectPacks.RayTraced -> amCardFor(c)
        EffectPacks.Vibrant -> when (c) {
            "colorlight", "color", "light", "lighting", "glow" -> "glow"
            "warp", "distort", "distortion", "blur" -> "liquid"
            "glitch" -> "glitch"
            "3d" -> "depth"
            "beat" -> "beat"
            "text" -> "text"
            else -> "other"
        }
        else -> when (c) {
            "colorlight", "light", "lighting", "glow" -> "color"
            "drawedge", "drawing", "drawing/edge" -> "stylize"
            "warp", "distortion", "glitch" -> "distort"
            "procedural", "generate", "generative" -> "noise"
            "transform", "move/transform" -> "move"
            "matte", "mask" -> "key"
            else -> "other"
        }
    }
    return if (mapped in valid) mapped else "other"
}

/** Maps an Alight Motion category name to an After Effects library category. */
fun aeCategoryFor(amCategory: String): String = when (amCategory.lowercase()) {
    "blur" -> "ae_blur"
    "color" -> "ae_color"
    "distort" -> "ae_distort"
    "stylize" -> "ae_stylize"
    "noise" -> "ae_noise"
    "key" -> "ae_keying"
    "3d" -> "ae_perspective"
    "move", "repeat" -> "ae_distort"
    else -> "ae_other"
}

/**
 * The ten-plus-text categories of the Effects Library (Color & Light ... Text). Every effect of every pack and library is shown in one of them.
 * Glow goes to Drawing & Edge, shakes / beat to Move/Transform, echo to Repeat, keys and anything that deletes pixels to Matte/Mask/Key.
 */
fun unifiedCategoryFor(category: String): String {
    val c = category.trim().lowercase(Locale.ROOT)
    if (c in AlightMotionCategories) return c
    return when (c) {
        "color", "light", "lighting", "leaks", "neon", "ae_color" -> "colorlight"
        "glow", "stylize", "drawing", "drawing/edge", "ae_stylize" -> "drawedge"
        "ae_blur" -> "blur"
        "distort", "distortion", "warp", "liquid", "glitch", "ae_distort" -> "warp"
        "depth", "ae_perspective" -> "3d"
        "move", "move/transform", "beat", "ae_time" -> "transform"
        "key", "mask", "matte", "ae_keying" -> "matte"
        "transition", "ae_transition" -> "opacity"
        else -> "procedural"
    }
}

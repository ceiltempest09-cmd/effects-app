// effects_graph.h — Skia (SkSL) execution of a render graph (render_graph.h).
//
// Every pass is an SkRuntimeEffect drawn into its own offscreen SkSurface that comes from the SAME canvas, hence the same
// Ganesh (GL/Vulkan) or Graphite context the editor already owns: no second Vulkan device, no second EGL context, no CPU readback.
// Skia orders the GPU work and the layout transitions between a pass that renders a surface and the next pass that samples it.
#pragma once

#include "render_graph.h"
#include "xml.h"
#include "include/core/SkCanvas.h"
#include "include/core/SkImage.h"
#include "include/effects/SkRuntimeEffect.h"

#include <functional>
#include <memory>
#include <set>
#include <string>

namespace am {

struct GraphProgram {
    std::shared_ptr<const rg::Plan> plan;
    std::vector<sk_sp<SkRuntimeEffect>> effects;   // per plan->desc.passes index; null for culled passes
    bool timed = false;                            // reads time/frame or history: the result changes without the controls changing
    bool temporal = false;
};

// Reads an <effect graph="2"> element. Returns "ok" or "shader error: ..." (the same convention as EffectRuntime::load), with every
// problem carrying effect id, pass, backend and source line. `controls` are the effect's control names (uniforms bind by name).
std::string CompileGraph(const XmlNode& root, const std::set<std::string>& controls, std::shared_ptr<const GraphProgram>* out);

struct GraphFrame {
    int64_t frame = 0;                // quantised frame index for temporal graphs, otherwise a running count
    float seconds = 0;                // value of the `time` uniform
    int width = 0, height = 0;        // effect area in pixels
    uint64_t signature = 0;           // changes when anything that defines earlier frames changes (controls, area)
    // Fills the float values of a control uniform; false = unknown name.
    std::function<bool(const SkRuntimeEffect::Uniform&, float*)> control;
};

// One per (layer, effect) instance: owns the pooled render targets and the history of temporal graphs.
class GraphRunner {
public:
    explicit GraphRunner(std::shared_ptr<const GraphProgram> program);
    ~GraphRunner();

    // Runs all passes for one frame. `canvas` supplies the GPU context and colour space, `source` is the layer image for this frame.
    // On success `*result` is the final buffer (premultiplied, same colour space, same size as the area).
    bool render(SkCanvas* canvas, const sk_sp<SkImage>& source, const GraphFrame& frame, const std::function<sk_sp<SkImage>(const sk_sp<SkImage>&)>& upload,
                sk_sp<SkImage>* result, std::string* error);

    void drop();                      // device loss, context recreation, low memory
    void trim();
    std::string report() const;       // JSON: pass timings of the last frame and pool statistics
    const GraphProgram& program() const { return *fProgram; }

private:
    class SkiaBackend;
    std::shared_ptr<const GraphProgram> fProgram;
    std::unique_ptr<SkiaBackend> fBackend;
    std::unique_ptr<rg::Executor> fExecutor;
    rg::FrameResult fLast;
    std::string fLastError;
};

}  // namespace am

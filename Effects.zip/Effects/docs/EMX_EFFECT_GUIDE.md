# EMX effect guide (RayTraced VFX)

Paste this whole file to ChatGPT, then say:
"Write the EMX effect <name>: <what it should look like>. Follow this format exactly. Reply with one .emx file only."

## What you get
One text file `emx/<id>.emx`. You only describe the 3D scene. The build adds the camera, ray marching, soft shadows, ambient occlusion, reflections, lighting and blending with the layer.

## Header
Same as GLSL files:
```
// @id mything                      lowercase letters and digits only
// @name My Thing
// @category 3d                     colorlight drawedge blur warp procedural 3d transform repeat matte opacity text pnkj
// @description One sentence.
// @param <id> <type> <default> [min=] [max=] [step=] [pixels=1] [percent=1] [unit=] label="Label"
```
Param types: `float`, `angle`, `switch`, `point 0.5,0.5`, `color #rrggbb`, `choice 0 options="A|B"`.
Every @param needs `uniform` with the same id (`float`, `vec2` for point, `vec4` for color).

## You write exactly these two functions
```
float map(vec3 p)
```
Signed distance to the scene at point p. Y is up. The camera looks at 0,0,0. Union = `min`, smooth shapes with `length`, `max` etc.
```
vec3 material(vec3 p, vec3 n, vec2 uv, out float refl)
```
Surface color (rgb) at hit point p with normal n. Set `refl` from 0 (matte) to 1 (mirror).

## Ready to use (do not declare them)
- Uniforms: `size`, `time`, `image` (the layer, `sampler2D`).
- `vec3 layerOnPlane(vec2 xy)`: the layer as a flat picture; scene height 1 = y from -0.5 to 0.5. Use `fract()` to tile it.
- `texture2D(image, uv)` with uv 0..1, y top to bottom.
- Built-in params, shown in the app: camera distance/yaw/pitch, light direction, shadows, occlusion, reflections, exposure, opacity. Do not redeclare them.

## Rules
Same as GLSL: no `#if`, no function macros, constant loop bounds, no recursion. Keep `map` cheap; it is called about 150 times per pixel.

## Example 1 (`emx/rtorbs.emx`)
```glsl
// @id rtorbs
// @name Ray Traced Orbs
// @category 3d
// @description Three mirror orbs circle above a floor that tiles your layer. Soft shadows, occlusion and reflections.
// @param orbit float 0.5 min=0 max=3 step=0.01 label="Orbit Speed"
// @param orbRadius float 0.45 min=0.1 max=0.9 step=0.01 label="Orb Size"
// @param orbColor color #ffb454 label="Orb Tint"
uniform float orbit;
uniform float orbRadius;
uniform vec4 orbColor;

float map(vec3 p) {
    float d = p.y + 0.9;
    for (int i = 0; i < 3; i++) {
        float a = time * orbit + float(i) * 2.0943951;
        vec3 c = vec3(cos(a), -0.4 + 0.15 * sin(a * 2.0 + float(i)), sin(a) + 0.2);
        d = min(d, length(p - c) - orbRadius);
    }
    return d;
}

vec3 material(vec3 p, vec3 n, vec2 uv, out float refl) {
    if (p.y < -0.88) {
        refl = 0.2;
        return layerOnPlane(fract(p.xz * 0.25 + 0.5) - 0.5);
    }
    refl = 0.9;
    return orbColor.rgb;
}
```

## Example 2 (`emx/rtplanet.emx`)
```glsl
// @id rtplanet
// @name Ray Traced Planet
// @category 3d
// @description Your layer wrapped around a rotating planet, lit and shadowed, over the original picture.
// @param spin float 0.25 min=-2 max=2 step=0.01 label="Spin Speed"
// @param radius float 1.0 min=0.3 max=1.6 step=0.01 label="Planet Size"
// @param rim color #7fc4ff label="Rim Light"
uniform float spin;
uniform float radius;
uniform vec4 rim;

float map(vec3 p) {
    return length(p) - radius;
}

vec3 material(vec3 p, vec3 n, vec2 uv, out float refl) {
    float a = time * spin * 6.2831853;
    float c = cos(a);
    float s = sin(a);
    vec3 q = normalize(vec3(p.x * c + p.z * s, p.y, -p.x * s + p.z * c));
    vec2 su = vec2(atan(q.z, q.x) / 6.2831853 + 0.5, 0.5 - asin(clamp(q.y, -1.0, 1.0)) / 3.14159265);
    vec3 tex = texture2D(image, su).rgb;
    refl = 0.12;
    return tex + rim.rgb * pow(1.0 - clamp(n.z * -1.0, 0.0, 1.0), 3.0) * 0.4;
}
```

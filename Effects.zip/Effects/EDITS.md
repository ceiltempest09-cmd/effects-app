# Edits to EXISTING files (6 small ones)

New files: copy the folder `shared/` into your repo (same paths).

## 1. EffectDefinition.kt
Find (in the data class, last parameter):
    val pack: String = EffectPacks.Default,
Add AFTER it:
    val source: String = EffectSources.Native,

## 2. EffectCatalog.kt  (4 changes)
a) In `data class EffectCatalog(`, find the last parameter
    val pack: String = EffectPacks.Default,
   Add AFTER it:
    val source: String = EffectSources.Native,

b) Find:
    fun find(id: String): EffectDefinition? = definitions.firstOrNull { it.id == id }
   Add ABOVE it:
    fun forSource(source: String): EffectCatalog = copy(source = source, definitions = definitions.filter { it.source == source })

c) Find:
    val categories: List<Pair<String, String>> get() =
   Replace with these 3 lines (the old next line stays as it is):
    val categories: List<Pair<String, String>> get() =
        if (source != EffectSources.Native) definitions.map { it.category }.distinct().map { it to (categoryNames[it] ?: importedCategoryLabel(it)) }
        else nativeCategories
    private val nativeCategories: List<Pair<String, String>> get() =

d) Find:
    .let { if (it.message != null) it.copy(message = context.getString(R.string.effects_not_loaded)) else it }
   Add on a NEW line AFTER it:
    .let { it.copy(definitions = it.definitions + ImportedEffects.load(context)) }

## 3. app/.../engine/EngineThread.kt
Find:
    suspend fun effectCheck(directory: File) {
Add ABOVE it:
    fun reloadEffects(context: Context): Job = mediaScope.launch {
        effectJob?.join()
        val catalog = EffectCatalog.read(context.applicationContext)
        effectCatalog.value = withContext(dispatcher) {
            if (closed) catalog else catalog.loadInto { runCatching { engine().loadEffect(it) }.getOrElse { e -> "shader error: ${e.message}" } }
        }
        withContext(dispatcher) { renderNow() }
    }

## 4. ui/editor/effects/EffectBrowser.kt  (4 changes)
a) Find: import com.effects.motion.effects.EffectPacks
   Add AFTER it: import com.effects.motion.effects.EffectSources

b) Find:
    val catalog = remember(fullCatalog, pack) { fullCatalog.forPack(pack) }
   Replace with:
    var source by remember { mutableStateOf(EffectSources.Native) }
    var importing by remember { mutableStateOf(false) }
    val catalog = remember(fullCatalog, pack, source) { fullCatalog.forPack(pack).forSource(source) }

c) The line  `if (!stepping && !audio && !searching) PackPicker(pack) {...}`  appears TWICE.
   Take the SECOND one (inside `else Row(Modifier.fillMaxWidth().height(44.dp)`).
   Add AFTER it:
            if (!stepping && !audio && !searching) ImportChip { importing = true }

d) Find:
        Swap(page, Modifier.fillMaxSize().effectSwipe(
   Add ABOVE it (2 lines):
        EffectImportFlow(state, importing, { importing = false }) { s, p -> source = s; pack = p; category = null; history.edit().putString("pack", p).apply() }
        if (!stepping && !audio && !searching && category == null && detail == null) SourceBar(source, catalog.definitions.isEmpty()) { source = it; category = null }

## 5. ui/editor/StructureUi.kt  (3D model check, temporary)
Find:
    withContext(Dispatchers.Main) { state.addModel(uri, names[main]); added = true }
Replace with:
    withContext(Dispatchers.Main) {
        state.addModel(uri, names[main]); added = true
        android.widget.Toast.makeText(context, "3D model added: $count triangles, ${state.scene.layers.size} layers", android.widget.Toast.LENGTH_LONG).show()
    }

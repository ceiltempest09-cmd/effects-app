#!/bin/bash
# engblur/englight graphs on a real GL driver. Needs python3 (JSON -> runtime XML) and libEGL; no GL headers.
set -e
cd "$(dirname "$0")/../.."
OUT=${OUT:-/tmp/em-native-tests}; mkdir -p "$OUT"
for n in engblur englight; do python3 tools/graph_json_to_xml.py shared/assets/effects/$n.json "$OUT/$n.xml"; done
python3 - "$OUT" <<'PY'
import re,sys
s=open("shared/kotlin/com/effects/motion/effects/LutEffect.kt").read()
m=re.search(r'Shader = """\n(.*?)"""',s,re.S)
open(sys.argv[1]+"/lut_shader.glsl","w").write(m.group(1))
PY
g++ -std=c++20 -fno-exceptions -fno-rtti -Wall -Wextra -O1 -I shared/cpp tests/native/engine_graphs_test.cpp shared/cpp/gl_backend.cpp shared/cpp/render_graph.cpp \
  shared/cpp/render_graph_xml.cpp shared/cpp/xml.cpp shared/cpp/shader_info.cpp shared/cpp/shader_diag.cpp shared/cpp/shader_cache.cpp shared/cpp/spirv_util.cpp \
  -lexpat -ldl -lpthread -o "$OUT/engine_graphs_test"
stdbuf -o0 "$OUT/engine_graphs_test" "$OUT"

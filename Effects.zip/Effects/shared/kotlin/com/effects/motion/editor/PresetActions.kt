package com.effects.motion.editor

import com.effects.motion.model.finiteFloat
import com.effects.motion.audio.AUDIO_FX_TAG
import com.effects.motion.library.PresetStore
import com.effects.motion.library.SavedPreset
import com.effects.motion.model.Layer
import com.effects.motion.model.MotionSlot
import com.effects.motion.model.effects
import com.effects.motion.model.motion
import com.effects.motion.model.Scene
import com.effects.motion.model.VideoTiming
import com.effects.motion.model.XmlNode
import com.effects.motion.model.isKeyframed
import com.effects.motion.model.keyframes
import com.effects.motion.model.withKeyframes
import com.effects.motion.model.withVideoSpeedMap
import com.effects.motion.R
import com.effects.motion.i18n.AppText
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

private val STYLED = setOf("shape", "text", "drawing", "embedScene")
private val STROKED = setOf("shape", "text")
private val MOVING = listOf("scale", "location", "rotation", "tilt", "skew", "pivot")

fun canSavePreset(layer: Layer): Boolean {
    val n = layer.node
    val transform = n.child("transform")
    fun XmlNode?.plain(one: Float) = this == null || (!isKeyframed && this["value"]?.finiteFloat().let { it == null || it == one })
    return n.children.any { it.name in setOf("path-stroke", "border", "shadow", "effect") } || n.child(AUDIO_FX_TAG)?.children?.isNotEmpty() == true ||
        (n["blending"] ?: "normal") != "normal" || !transform?.child("opacity").plain(1f) ||
        MOVING.any { transform?.child(it)?.isKeyframed == true } ||
        !n.child("gain").plain(1f) || !n.child("speedMap").plain(1f) || (n["speed"]?.finiteFloat() ?: 1f) != 1f ||
        (n["font"] ?: "") != "" || (n["size"]?.finiteFloat() ?: 18f) != 18f || (n["align"] ?: "left") != "left"
}

fun presetTitle(layer: Layer, taken: Collection<String>, numbered: (Int) -> String = { AppText.get(R.string.preset_numbered, "$it") }): String =
    layer.label.takeIf { it.isNotBlank() } ?: (1..1000).map(numbered).firstOrNull { it !in taken } ?: numbered(1)

fun presetScene(scene: Scene, layer: Layer, title: String): Scene {
    val parent = layer.node["parent"]?.toLongOrNull()
    val flat = if (parent == null) layer else scene.unparentChildrenOf(setOf(parent)).layer(layer.id) ?: layer
    val base = Scene.create(title, scene.width, scene.height, 30, 0)
    return Scene(base.node.with("type", "preset").with("ffver", "107")).add(flat.withHidden(false))
}

suspend fun EditorState.savePreset(store: PresetStore): SavedPreset? {
    val layer = selected?.takeIf { canSavePreset(it) } ?: return null
    val scene = scene
    return withContext(Dispatchers.IO) { store.load(store.save(presetScene(scene, layer, presetTitle(layer, store.list().map { it.title })))) }
}

fun EditorState.applyPreset(preset: SavedPreset) {
    val id = selectedId ?: return
    val from = preset.layer ?: return
    edit { s -> s.update(id) { applyPreset(it, from, preset.id) } }
}

internal fun Scene.applyPresetToLayers(ids: Set<Long>, preset: Layer, presetId: String? = null): Scene =
    layers.filter { it.id in ids }.fold(this) { scene, layer -> scene.update(layer.id) { applyPreset(it, preset, presetId) } }

fun applyPreset(target: Layer, preset: Layer, presetId: String? = null): Layer {
    val retimed = target.withPresetSpeed(preset)
    val p = preset.node
    var n = retimed.node
    if (retimed.kind in STYLED) {
        n = n.replaced(setOf("border", "shadow") + if (retimed.kind in STROKED && preset.kind in STROKED) setOf("path-stroke") else emptySet(), p)
            .with("blending", p["blending"]).withTransformPart("opacity", p.child("transform")?.child("opacity"))
    }
    if (retimed.kind != "audio") {
        for (name in MOVING) p.child("transform")?.child(name)?.takeIf { it.isKeyframed }?.let { n = n.withTransformPart(name, it) }
        n = n.replaced(setOf("effect"), p)
    }
    if (retimed.kind == "text" && preset.kind == "text") for (a in listOf("size", "align", "font")) n = n.with(a, p[a])
    if ((retimed.kind == "audio" || retimed.mediaFill?.video == true) && (preset.kind == "audio" || preset.mediaFill?.video == true)) n = n.replaced(setOf("gain", AUDIO_FX_TAG), p)
    var applied = retimed.copy(node = n.with("presetId", presetId ?: n["presetId"]))
    for (slot in MotionSlot.entries) if (applied.motion(slot) != null && !applied.hasMotionParts(slot)) applied = applied.copy(node = applied.node.with(slot.attr, null))
    return applied
}

private fun Layer.hasMotionParts(slot: MotionSlot): Boolean = effects.any { it["gen"] == slot.xml } ||
    node.child("transform")?.children.orEmpty().any { part -> part.keyframes.any { it.gen == slot.xml } }

private fun XmlNode.replaced(names: Set<String>, from: XmlNode): XmlNode {
    val at = children.indexOfFirst { it.name in names }.takeIf { it >= 0 } ?: children.size
    val kept = children.filter { it.name !in names }
    return copy(children = kept.take(at) + from.children.filter { it.name in names } + kept.drop(at))
}

private fun XmlNode.withTransformPart(name: String, part: XmlNode?): XmlNode {
    val next = (child("transform") ?: XmlNode("transform")).withChild(name, part)
    return withChild("transform", next.takeIf { it.children.isNotEmpty() || it.attrs.isNotEmpty() })
}

private fun Layer.withPresetSpeed(preset: Layer): Layer {
    fun domain(layer: Layer) = if (layer.kind == "audio" || layer.mediaFill?.video == true) "media" else layer.kind
    if (domain(this) != domain(preset)) return this
    fun speedOf(l: Layer) = l.node.child("speedMap") ?: XmlNode("speedMap", mapOf("value" to (l.node["speed"] ?: "1")))
    val map = speedOf(preset)
    if (kind == "embedScene" && map.isKeyframed) return this
    val own = speedOf(this)
    if (!map.isKeyframed && !own.isKeyframed && own["value"]?.finiteFloat() == map["value"]?.finiteFloat()) return this
    fun range(l: Layer) = VideoTiming(l).let { it.mediaMs(0.0) to it.mediaMs((l.endTime - l.startTime).toDouble()) }
    val (from, to) = range(preset)
    val (start, end) = range(this)
    val stretch = (end - start) / (to - from).coerceAtLeast(1e-6)
    return withVideoSpeedMap(if (map.isKeyframed) map.withKeyframes(map.keyframes.map { it.copy(t = ((start + (it.t / 1e6 - from) * stretch) * 1e6).toFloat()) }) else map)
}

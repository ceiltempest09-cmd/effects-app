package com.effects.motion.effects.graph

/**
 * GLSL ES -> SkSL for ONE pass, for a clearly defined subset. Token based (after [GlslPreprocessor]), never regex on raw text.
 *
 * Supported: precision/qualifier removal, vecN/matN/ivecN types, `uniform` scalars/vectors/arrays/int/bool, `uniform sampler2D x` bound to a
 * declared input, texture()/texture2D()/textureSize() on those inputs, `in vec2 v_uv`-style varyings (= pixel position / area size),
 * `out vec4 c` or gl_FragColor, gl_FragCoord.xy, helper functions, structs, `for` loops, `return;` in main.
 * Rejected with a line number: discard, switch, while/do, uint/uvec, bit operators and %, sampler3D/Cube/Array, derivatives, textureLod/Grad/
 * Proj, texelFetch, layout() other than output locations, #include, `texture()` with a bias, uniform blocks.
 *
 * Colour: GLSL passes were written for straight alpha. Reads un-premultiply, the result is premultiplied (same rule as the one-pass converter).
 * Coordinates: texture(x, uv) samples at uv * size, `size` being the effect area in pixels, so it works at any buffer resolution.
 */
object GlslToSksl {
    /** `headerLines`: lines added before the translated body; SkSL line N is source line N - headerLines. */
    /** A control that the shader may use without declaring it: `sksl` is the declaration, `bool` marks a switch (declared float, used as bool). */
    class Implicit(val name: String, val sksl: String, val bool: Boolean = false)

    class Result(val sksl: String, val issues: List<Issue>, val headerLines: Int)

    private val tokenRe = Regex("""\s+|[A-Za-z_]\w*|0[xX][0-9a-fA-F]+[uU]?|\d+\.?\d*(?:[eE][+-]?\d+)?[uUfF]?|\.\d+(?:[eE][+-]?\d+)?[fF]?|<<=|>>=|<<|>>|<=|>=|==|!=|&&|\|\||\+\+|--|\+=|-=|\*=|/=|%=|&=|\|=|\^=|.""", RegexOption.DOT_MATCHES_ALL)

    private class Tok(val t: String, val line: Int) {
        val ws get() = t.isBlank()
    }

    private val Qualifiers = setOf("lowp", "mediump", "highp")
    private val Banned = mapOf(
        "discard" to "discard is not supported", "switch" to "switch is not supported", "while" to "while loops are not supported (use a for loop with constant bounds)",
        "do" to "do/while loops are not supported", "uint" to "unsigned integers are not supported", "uvec2" to "unsigned integers are not supported",
        "uvec3" to "unsigned integers are not supported", "uvec4" to "unsigned integers are not supported", "sampler3D" to "3D samplers are not supported",
        "samplerCube" to "cube samplers are not supported", "sampler2DArray" to "array samplers are not supported", "dFdx" to "derivatives are not supported",
        "dFdy" to "derivatives are not supported", "fwidth" to "derivatives are not supported", "textureLod" to "textureLod is not supported",
        "textureGrad" to "textureGrad is not supported", "textureProj" to "textureProj is not supported", "texelFetch" to "texelFetch is not supported (use texture())",
        "layout" to "layout() is only accepted on an output declaration", "buffer" to "buffer blocks are not supported", "shared" to "shared is not supported",
    )
    private val Bans = setOf("<<", ">>", "<<=", ">>=", "&", "|", "^", "~", "%", "%=", "&=", "|=", "^=")

    private fun mapType(t: String): String? = when (t) {
        "float", "int", "bool", "void" -> t
        "vec2" -> "float2"; "vec3" -> "float3"; "vec4" -> "float4"
        "ivec2" -> "int2"; "ivec3" -> "int3"; "ivec4" -> "int4"
        "bvec2" -> "bool2"; "bvec3" -> "bool3"; "bvec4" -> "bool4"
        "mat2" -> "float2x2"; "mat3" -> "float3x3"; "mat4" -> "float4x4"
        else -> null
    }

    fun convert(
        glsl: String, inputs: List<String>, colorUniforms: Set<String> = emptySet(), effect: String = "", pass: String? = null,
        file: String? = null, firstLine: Int = 1, defines: Map<String, String> = emptyMap(),
        implicit: List<Implicit> = emptyList(),
    ): Result {
        val pre = GlslPreprocessor.run(glsl, defines, effect, pass, file, firstLine)
        val issues = pre.issues.toMutableList()
        fun bad(line: Int, msg: String, kind: IssueKind = IssueKind.UNSUPPORTED) {
            issues += Issue(kind, msg, true, effect, pass, -1, "sksl", file, firstLine + line - 1)
        }
        if (!pre.ok) return Result("", issues, 0)

        val toks = ArrayList<Tok>()
        var line = 1
        for (m in tokenRe.findAll(pre.text)) { toks += Tok(m.value, line); line += m.value.count { it == '\n' } }

        // ---- split into top-level chunks
        val chunks = ArrayList<List<Tok>>()
        var cur = ArrayList<Tok>()
        var depth = 0
        for ((i, t) in toks.withIndex()) {
            cur += t
            when (t.t) {
                "{", "(" -> if (t.t == "{") depth++
                "}" -> {
                    depth--
                    if (depth == 0) {
                        val head = cur.firstOrNull { !it.ws }?.t
                        if (head != "struct" && toks.drop(i + 1).firstOrNull { !it.ws }?.t != ";") { chunks += cur; cur = ArrayList() }
                    }
                }
                ";" -> if (depth == 0) { chunks += cur; cur = ArrayList() }
            }
        }
        if (cur.any { !it.ws }) chunks += cur
        if (depth != 0) bad(line, "unbalanced braces", IssueKind.MALFORMED)

        val samplers = inputs.toSet()
        val decls = StringBuilder()
        val helpers = StringBuilder()
        val body = StringBuilder()
        val swap = hashMapOf<String, String>()
        val varyings = ArrayList<Pair<String, Int>>()
        var outName: String? = null
        var sawMain = false
        var usesPx = hashSetOf<String>()
        var mainText = ""

        fun words(c: List<Tok>) = c.filter { !it.ws }

        fun translate(ts: List<Tok>, inMain: Boolean): String {
            val sb = StringBuilder()
            var i = 0
            while (i < ts.size) {
                val t = ts[i]
                if (t.ws) { sb.append(t.t); i++; continue }
                val x = t.t
                if (x in Bans) { bad(t.line, "operator '$x' is not supported by SkSL (ES2). Use mod() or arithmetic."); sb.append(x); i++; continue }
                Banned[x]?.let { bad(t.line, it) }
                when {
                    x in Qualifiers -> {}
                    x == "texture" || x == "texture2D" || x == "textureSize" -> {
                        val rest = ts.drop(i + 1).filter { !it.ws }
                        val name = rest.getOrNull(1)?.t
                        if (rest.getOrNull(0)?.t != "(" || name == null || (name !in samplers)) {
                            bad(t.line, "$x(${name ?: "?"}, ...) does not read a declared input" + (name?.let { ". Add <input name=\"$it\" ref=...> to the pass." } ?: ""), IssueKind.TRANSLATION)
                            sb.append(x); i++
                        } else if (x == "textureSize") {
                            usesPx += name
                            sb.append("int2(").append(name).append("_px)")
                            // skip: ( name , lod )
                            var k = i + 1; var lvl = 0
                            while (k < ts.size) { if (ts[k].t == "(") lvl++; if (ts[k].t == ")") { lvl--; if (lvl == 0) break }; k++ }
                            i = k
                        } else {
                            val comma = ts.indexOfFirst2(i) { it.t == "," }
                            // a third argument (bias) is not supported
                            var k = comma; var lvl = 0; var commas = 0
                            while (k < ts.size) { val s = ts[k].t; if (s == "(") lvl++; if (s == ")") { if (lvl == 0) break; lvl-- }; if (s == "," && lvl == 0) commas++; k++ }
                            if (commas > 1) bad(t.line, "texture() with a bias argument is not supported")
                            sb.append("_tex_").append(name).append('(')
                            i = comma
                            while (i + 1 < ts.size && ts[i + 1].ws) i++        // drop the space after the removed comma
                        }
                    }
                    x == "gl_FragColor" || (outName != null && x == outName) -> { sb.append("_out"); }
                    x == "gl_FragCoord" -> { if (!inMain) bad(t.line, "gl_FragCoord is used outside main()"); sb.append("float4(_fc, 0.0, 1.0)") }
                    x == "acTime" -> sb.append("time")
                    x == "acScreenSize" -> sb.append("size")
                    x == "acLayerSize" -> sb.append("layer")
                    x == "acLayerCenter" -> sb.append("(layer * 0.5)")
                    x == "acScreenNorm" -> { if (!inMain) bad(t.line, "acScreenNorm is used outside main()"); sb.append("(_fc / size)") }
                    x == "return" && inMain && words(ts.drop(i + 1)).firstOrNull()?.t == ";" -> sb.append("return half4(float4(_out.rgb * _out.a, _out.a))")
                    x in swap && (i == 0 || ts.subList(0, i).lastOrNull { !it.ws }?.t != ".") -> sb.append(swap.getValue(x))
                    else -> sb.append(mapType(x)?.takeIf { it != x } ?: x)
                }
                i++
            }
            return sb.toString()
        }

        val declared = chunks.flatMap { c -> val w = words(c); if (w.firstOrNull()?.t == "uniform") w.map { it.t } else emptyList() }.toSet()
        val mentioned = toks.filter { !it.ws }.map { it.t }.toSet()
        for (im in implicit) {
            if (im.name in declared || im.name !in mentioned || im.name in samplers) continue
            decls.append(im.sksl).append('\n')
            if (im.bool) swap[im.name] = "(${im.name} > 0.5)"
        }
        for (c in chunks) {
            val w = words(c)
            if (w.isEmpty()) continue
            val first = w[0].t
            when {
                first == "precision" -> body.append(blankLines(c))
                first == "uniform" -> {
                    val parts = w.drop(1).filter { it.t !in Qualifiers }
                    val type = parts.getOrNull(0)?.t
                    val name = parts.getOrNull(1)?.t
                    if (type == null || name == null || parts.getOrNull(2)?.t == "{") { bad(w[0].line, "uniform blocks are not supported"); continue }
                    val array = parts.drop(2).takeWhile { it.t != ";" }.joinToString("") { it.t }
                    if (type == "sampler2D") {
                        if (name !in samplers) bad(w[0].line, "sampler '$name' has no <input name=\"$name\" ref=...> on this pass", IssueKind.TRANSLATION)
                    } else if (name in samplers) bad(w[0].line, "'$name' is both an input and a uniform", IssueKind.TRANSLATION)
                    else if (type == "bool") { decls.append("uniform float $name$array;\n"); swap[name] = "($name > 0.5)" }
                    else {
                        val t = mapType(type)
                        if (t == null || t == "void") bad(w[0].line, "uniform type '$type' is not supported")
                        else if (type == "vec4" && name in colorUniforms) decls.append("layout(color) uniform half4 $name$array;\n")
                        else decls.append("uniform $t $name$array;\n")
                    }
                    body.append(blankLines(c))
                }
                first == "in" || first == "varying" || (first == "layout" && w.any { it.t == "in" }) -> {
                    val ps = w.filter { it.t != "layout" && it.t != "in" && it.t != "varying" && it.t !in Qualifiers && it.t != ";" }
                    val type = ps.firstOrNull()?.t
                    val name = ps.getOrNull(1)?.t
                    if (type == "vec2" && name != null) varyings += name to w[0].line
                    else bad(w[0].line, "only 'in vec2 <name>;' varyings are supported (the pixel position / area size)")
                    body.append(blankLines(c))
                }
                first == "out" || (first == "layout" && w.any { it.t == "out" }) -> {
                    val ps = w.filter { it.t != "out" && it.t !in Qualifiers && it.t != ";" }.dropWhile { it.t == "layout" }
                        .let { l -> val close = l.indexOfFirst { it.t == ")" }; if (l.firstOrNull()?.t == "(") l.drop(close + 1) else l }
                    if (ps.getOrNull(0)?.t == "vec4" && ps.getOrNull(1) != null) {
                        if (outName != null) bad(w[0].line, "only one fragment output is supported")
                        outName = ps[1].t
                    } else bad(w[0].line, "only 'out vec4 <name>;' is supported as the fragment output")
                    body.append(blankLines(c))
                }
                w.size > 2 && first == "void" && w[1].t == "main" -> {
                    if (sawMain) bad(w[0].line, "two main() functions", IssueKind.MALFORMED)
                    sawMain = true
                    mainText = c.joinToString("") { it.t }
                    val open = c.indexOfFirst { it.t == "{" }
                    val close = c.indexOfLast { it.t == "}" }
                    if (open < 0 || close < open) { bad(w[0].line, "main() has no body", IssueKind.MALFORMED); continue }
                    val inner = c.subList(open + 1, close)
                    val head = blankLines(c.subList(0, open + 1))
                    val vary = varyings.joinToString("") { "float2 ${it.first} = _fc / size; " }
                    body.append("half4 main(float2 _fc) {").append(head).append(" float4 _out = float4(0.0); ").append(vary)
                        .append(translate(inner, true)).append(" return half4(float4(_out.rgb * _out.a, _out.a)); }").append(blankLines(c.subList(close + 1, c.size)))
                }
                else -> body.append(translate(c, false))
            }
        }
        if (!sawMain) bad(1, "the pass has no void main()", IssueKind.MALFORMED)
        if (outName == null && !toks.any { it.t == "gl_FragColor" }) bad(1, "the pass never writes a colour (declare 'out vec4 c;' or use gl_FragColor)", IssueKind.TRANSLATION)

        var header = 0
        val sksl = buildString {
            for (n in inputs) append("uniform shader ").append(n).append(";\n")
            append("uniform float2 size;\n")
            for (n in usesPx) append("uniform float2 ").append(n).append("_px;\n")
            append(decls)
            for (n in inputs) {
                append("float4 _tex_").append(n).append("(float2 uv) {\n  half4 c = ").append(n).append(".eval(uv * size);\n  float a = float(c.a);\n")
                append("  return float4(a > 0.0 ? float3(c.rgb) / a : float3(c.rgb), a);\n}\n")
            }
            header = count { it == '\n' }
            append(helpers).append(body)
        }
        return Result(sksl, issues, header)
    }

    private fun blankLines(ts: List<Tok>): String = "\n".repeat(ts.sumOf { t -> t.t.count { it == '\n' } })

    private fun List<Tok>.indexOfFirst2(from: Int, pred: (Tok) -> Boolean): Int { for (i in from until size) if (pred(this[i])) return i; return size - 1 }
}

#include "vulkan_backend.h"

#include "fence_stats.h"
#include "glsl_compile.h"
#include "glsl_wrap.h"
#include "shader_info.h"
#include "spirv_reflect.h"
#include "spirv_util.h"

#include <algorithm>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <map>
#include <memory>
#include <mutex>
#include <set>
#include <unistd.h>

#if defined(__ANDROID__) && __has_include(<vulkan/vulkan.h>)
#ifndef VK_USE_PLATFORM_ANDROID_KHR
#define VK_USE_PLATFORM_ANDROID_KHR 1
#endif
#include <vulkan/vulkan.h>
#include <android/hardware_buffer.h>
#include <android/log.h>
#define AM_VK_BACKEND 1
#define LOGV(...) __android_log_print(ANDROID_LOG_WARN, "AMVulkan", __VA_ARGS__)
#endif

namespace am::rg {

#ifndef AM_VK_BACKEND

Backend* SharedVulkanBackend(std::string* why) { *why = "this build has no Vulkan headers (or is not an Android build)"; return nullptr; }
void VulkanBackendSetFences(Backend*, bool) {}
std::string VulkanBackendDescribe() { return std::string(); }

#else

namespace {

uint64_t Fnv(const std::string& s, uint64_t h = 1469598103934665603ull) {
    for (unsigned char c : s) { h ^= c; h *= 1099511628211ull; }
    return h;
}

// "#define K V" lines right after the #version line (the shader text itself is not touched).
std::string InsertDefines(const std::string& source, const std::map<std::string, std::string>& defines) {
    if (defines.empty()) return source;
    size_t pos = 0;
    while (pos < source.size()) {
        size_t eol = source.find('\n', pos);
        const size_t end = eol == std::string::npos ? source.size() : eol;
        size_t k = pos;
        while (k < end && (source[k] == ' ' || source[k] == '\t')) k++;
        if (source.compare(k, 8, "#version") == 0) {
            std::string out = source.substr(0, end);
            out += "\n";
            for (const auto& d : defines) out += "#define " + d.first + " " + d.second + "\n";
            if (eol != std::string::npos) out += source.substr(eol + 1);
            return out;
        }
        if (eol == std::string::npos) break;
        pos = eol + 1;
    }
    return source;
}

VkFormat VkFormatOf(Format f) {
    switch (f) {
        case Format::RGBA16F: return VK_FORMAT_R16G16B16A16_SFLOAT;
        case Format::RGBA32F: return VK_FORMAT_R32G32B32A32_SFLOAT;
        default: return VK_FORMAT_R8G8B8A8_UNORM;
    }
}

const char* kVertexSource =
    "#version 450\n"
    "void main() { vec2 p = vec2(float((gl_VertexIndex << 1) & 2), float(gl_VertexIndex & 2)); gl_Position = vec4(p * 2.0 - 1.0, 0.0, 1.0); }\n";

constexpr uint32_t kSlotUboBytes = 64 * 1024;
constexpr size_t kMaxSlots = 8;
constexpr size_t kMaxViews = 24;

}  // namespace

class VkBackend : public Backend {
public:
    struct VkTarget : Target {
        VkImage image = VK_NULL_HANDLE;
        VkDeviceMemory memory = VK_NULL_HANDLE;
        VkImageView view = VK_NULL_HANDLE;
        VkFramebuffer fb = VK_NULL_HANDLE;
        VkFormat vkFormat = VK_FORMAT_UNDEFINED;
        AHardwareBuffer* ahb = nullptr;      // one reference owned by this object (allocated here, or acquired for an import)
        bool imported = false;               // a view of a buffer another backend owns
        bool needsAcquire = true;            // another API may have written it since this queue last used it
        bool layoutInit = false;
        int users = 0;
        uint64_t used = 0;
        AHardwareBuffer* hardwareBuffer() const override { return ahb; }
    };

    struct Program {
        bool ok = false;
        std::string error;
        VkShaderModule frag = VK_NULL_HANDLE;
        std::string entry = "main";
        SpirvReflection refl;
        VkDescriptorSetLayout dsl = VK_NULL_HANDLE;
        VkPipelineLayout layout = VK_NULL_HANDLE;
        std::map<uint64_t, VkPipeline> pipelines;
    };

    struct Slot {
        VkFence fence = VK_NULL_HANDLE;
        VkCommandBuffer cmd = VK_NULL_HANDLE;
        VkDescriptorPool pool = VK_NULL_HANDLE;
        VkBuffer ubo = VK_NULL_HANDLE;
        VkDeviceMemory uboMemory = VK_NULL_HANDLE;
        uint8_t* uboMap = nullptr;
        bool busy = false;
        std::vector<VkSemaphore> semaphores;   // destroyed once the fence is signalled
    };

    static VkBackend* Create(std::string* why) {
        std::unique_ptr<VkBackend> b(new VkBackend());
        if (!b->init(why)) return nullptr;
        return b.release();
    }

    ~VkBackend() override { shutdown(); }

    // ------------------------------------------------------------ rg::Backend
    const char* name() const override { return "vulkan"; }
    bool supports(Lang l) const override { return fOk && (l == Lang::GLSL || l == Lang::VulkanGLSL || l == Lang::SPIRV); }
    bool supports(Format f) const override { return fOk && caps(f).render; }
    Format workingFormat() const override { return caps(Format::RGBA16F).render && caps(Format::RGBA16F).linear && caps(Format::RGBA16F).blend ? Format::RGBA16F : Format::RGBA8; }
    int maxTextureSize() const override { return (int)fProps.limits.maxImageDimension2D; }

    bool canShare(Format f) const override { return fOk && fAhb && f != Format::RGBA32F && f != Format::Inherit && caps(f).render; }

    Target* create(int w, int h, Format f) override { return createShared(w, h, f); }

    Target* createShared(int w, int h, Format f) override {
        std::lock_guard<std::recursive_mutex> lock(fLock);
        if (f == Format::Inherit) f = Format::RGBA8;
        std::string error;
        VkTarget* t = makeTarget(w, h, f, nullptr, fAhb && f != Format::RGBA32F, &error);
        if (!t) LOGV("vulkan target %dx%d %s: %s", w, h, ToString(f), error.c_str());
        return t;
    }

    void destroy(Target* t) override {
        std::lock_guard<std::recursive_mutex> lock(fLock);
        destroyTarget(static_cast<VkTarget*>(t));
    }

    Target* texture(const TextureDesc& td) override {
        std::lock_guard<std::recursive_mutex> lock(fLock);
        const std::string key = td.id + ":" + td.source + ":" + std::to_string(td.width) + "x" + std::to_string(td.height) + ":" + std::to_string(td.seed);
        auto it = fTextures.find(key);
        if (it != fTextures.end()) return it->second;
        std::vector<uint8_t> px((size_t)td.width * td.height * 4);
        if (td.source == "builtin:noise") px = NoisePixels(td.width, td.height, td.seed);
        else for (int y = 0; y < td.height; y++) for (int x = 0; x < td.width; x++) {
            const uint8_t v = (uint8_t)std::lround(255.0 * (td.source == "builtin:ramp-x" ? (x + 0.5) / td.width : (y + 0.5) / td.height));
            uint8_t* p = &px[((size_t)y * td.width + x) * 4];
            p[0] = p[1] = p[2] = v; p[3] = 255;
        }
        std::string error;
        VkTarget* t = makeTarget(td.width, td.height, Format::RGBA8, nullptr, false, &error);
        if (!t || !upload(t, px.data(), px.size(), &error)) { if (t) destroyTarget(t); LOGV("vulkan texture '%s': %s", td.id.c_str(), error.c_str()); return nullptr; }
        fTextures[key] = t;
        return t;
    }

    Target* blank(int w, int h, Format f) override {
        std::lock_guard<std::recursive_mutex> lock(fLock);
        if (f == Format::Inherit) f = Format::RGBA8;
        const std::string key = std::to_string(w) + "x" + std::to_string(h) + ":" + ToString(f);
        auto it = fBlanks.find(key);
        if (it != fBlanks.end()) return it->second;
        std::string error;
        VkTarget* t = makeTarget(w, h, f, nullptr, false, &error);
        if (!t || !clearImage(t, &error)) { if (t) destroyTarget(t); LOGV("vulkan blank %dx%d: %s", w, h, error.c_str()); return nullptr; }
        fBlanks[key] = t;
        return t;
    }

    bool accepts(const PassDesc& pass, Diag* why) override {
        std::lock_guard<std::recursive_mutex> lock(fLock);
        if (!supports(pass.lang)) { why->message = std::string("the Vulkan backend does not run ") + ToString(pass.lang); return false; }
        std::string error;
        Program* p = program(pass, &error);
        if (!p) { why->message = error; return false; }
        return true;
    }

    int64_t gpuNanos() override { return -1; }

    bool run(const PassRun& r, std::string* error) override;

    // ------------------------------------------------------------ hand-off with another backend
    bool release(Target* t, Backend& to, std::string* error) override;
    Target* acquire(Backend& from, Target* t, bool forWrite, std::string* error) override;
    void relinquish(Target* view) override {
        std::lock_guard<std::recursive_mutex> lock(fLock);
        VkTarget* vt = live(view);
        if (vt && vt->users > 0) vt->users--;
    }
    void reclaim(Target* t, Backend& user) override {
        (void)user;
        std::lock_guard<std::recursive_mutex> lock(fLock);
        if (VkTarget* vt = live(t)) vt->needsAcquire = true;
    }
    bool waitForeign(int fd, std::string* error) override;

    void setFences(bool on) { std::lock_guard<std::recursive_mutex> lock(fLock); fFences = on; }

    std::string describe() const {
        std::string s = std::string("device ") + fProps.deviceName + ", Vulkan " + std::to_string(VK_API_VERSION_MAJOR(fProps.apiVersion)) + "." + std::to_string(VK_API_VERSION_MINOR(fProps.apiVersion)) + "\n";
        s += std::string("AHardwareBuffer import: ") + (fAhb ? "yes" : "NO") + ", sync-fd semaphores export: " + (fCanExport ? "yes" : "NO") + ", import: " + (fCanImport ? "yes" : "NO") + "\n";
        for (Format f : {Format::RGBA8, Format::RGBA16F, Format::RGBA32F}) {
            const FormatCaps& c = caps(f);
            s += std::string(ToString(f)) + ": render " + (c.render ? "yes" : "no") + ", blend " + (c.blend ? "yes" : "NO") + ", linear " + (c.linear ? "yes" : "no") + "\n";
        }
        s += std::string("pipeline cache: ") + (fCache ? "yes" : "NO") + ", validation layer: " + (fValidation ? "on" : "off") + ", device lost: " + (fLost ? "YES" : "no") + "\n";
        return s;
    }

private:
    struct FormatCaps { bool render = false, blend = false, linear = false; };
    const FormatCaps& caps(Format f) const { return f == Format::RGBA32F ? fCaps[2] : f == Format::RGBA16F ? fCaps[1] : fCaps[0]; }

    VkBackend() = default;

    bool init(std::string* why);
    void shutdown();

    VkTarget* live(Target* t) { VkTarget* v = static_cast<VkTarget*>(t); return v && fLive.count(v) ? v : nullptr; }
    bool findMemory(uint32_t bits, VkMemoryPropertyFlags want, uint32_t* index) const {
        for (uint32_t i = 0; i < fMem.memoryTypeCount; i++)
            if ((bits & (1u << i)) && (fMem.memoryTypes[i].propertyFlags & want) == want) { *index = i; return true; }
        return false;
    }

    VkTarget* makeTarget(int w, int h, Format f, AHardwareBuffer* importFrom, bool wantShared, std::string* error);
    bool importAhb(AHardwareBuffer* buffer, VkTarget* t, std::string* error);
    void destroyTarget(VkTarget* t);
    VkRenderPass renderPass(VkFormat f, bool clear, std::string* error);
    VkFramebuffer framebuffer(VkTarget* t, std::string* error);
    VkSampler sampler(Filter f, Wrap w, std::string* error);
    Program* program(const PassDesc& pass, std::string* error);
    void freeProgram(Program* p);
    VkPipeline pipeline(Program* p, VkTarget* out, Blend blend, std::string* error);
    Slot* acquireSlot(std::string* error);
    void reap();
    void drain();
    bool beginSlot(Slot* s, std::string* error);
    bool submit(Slot* s, VkSemaphore signal, bool useWaits, std::string* error);
    VkSemaphore makeSemaphore(bool exportable);
    bool upload(VkTarget* t, const uint8_t* bytes, size_t size, std::string* error);
    bool clearImage(VkTarget* t, std::string* error);
    void trimViews();

    // ---- state
    std::recursive_mutex fLock;
    bool fValidation = false;
    bool fOk = false, fAhb = false, fCanExport = false, fCanImport = false, fFences = false, fLost = false;
    VkInstance fInst = VK_NULL_HANDLE;
    VkPhysicalDevice fPhys = VK_NULL_HANDLE;
    VkDevice fDev = VK_NULL_HANDLE;
    VkQueue fQueue = VK_NULL_HANDLE;
    uint32_t fFamily = 0, fForeign = VK_QUEUE_FAMILY_FOREIGN_EXT;
    VkPhysicalDeviceProperties fProps = {};
    VkPhysicalDeviceMemoryProperties fMem = {};
    FormatCaps fCaps[3];
    VkCommandPool fPool = VK_NULL_HANDLE;
    VkPipelineCache fCache = VK_NULL_HANDLE;   // one cache for every pipeline of this process (cheaper rebuilds per format / blend)
    std::string fDeviceName;
    VkShaderModule fVertex = VK_NULL_HANDLE;
    PFN_vkGetAndroidHardwareBufferPropertiesANDROID fGetAhbProps = nullptr;
    PFN_vkGetSemaphoreFdKHR fGetSemaphoreFd = nullptr;
    PFN_vkImportSemaphoreFdKHR fImportSemaphoreFd = nullptr;
    std::set<VkTarget*> fLive;
    std::map<std::string, VkTarget*> fTextures, fBlanks;
    std::map<AHardwareBuffer*, VkTarget*> fViews;
    uint64_t fClock = 0;
    std::map<VkFormat, std::pair<VkRenderPass, VkRenderPass>> fPasses;   // clear, load
    std::map<int, VkSampler> fSamplers;
    std::map<uint64_t, std::unique_ptr<Program>> fPrograms;
    std::vector<std::unique_ptr<Slot>> fSlots;
    std::vector<VkSemaphore> fPending;       // imported fences of other APIs: the next submit waits for them
};

// ================================================================== setup
bool VkBackend::init(std::string* why) {
    if (!GlslangAvailable()) { *why = "this build has no glslang, so GLSL cannot be compiled to SPIR-V"; return false; }
    VkApplicationInfo ai = {VK_STRUCTURE_TYPE_APPLICATION_INFO};
    ai.pApplicationName = "Effects"; ai.apiVersion = VK_API_VERSION_1_1;
    VkInstanceCreateInfo ici = {VK_STRUCTURE_TYPE_INSTANCE_CREATE_INFO};
    ici.pApplicationInfo = &ai;
#ifdef AM_VK_VALIDATION
    // Development builds only. Needs libVkLayer_khronos_validation.so packaged in the APK; its messages go to logcat. Silently skipped when absent.
    const char* kValidation = "VK_LAYER_KHRONOS_validation";
    uint32_t layerCount = 0;
    vkEnumerateInstanceLayerProperties(&layerCount, nullptr);
    std::vector<VkLayerProperties> layers(layerCount);
    if (layerCount) vkEnumerateInstanceLayerProperties(&layerCount, layers.data());
    for (const auto& l : layers) if (std::strcmp(l.layerName, kValidation) == 0) { ici.enabledLayerCount = 1; ici.ppEnabledLayerNames = &kValidation; fValidation = true; break; }
#endif
    VkResult r = vkCreateInstance(&ici, nullptr, &fInst);
    if (r != VK_SUCCESS) { *why = "vkCreateInstance failed (" + std::to_string((int)r) + ")"; return false; }
    uint32_t n = 0;
    vkEnumeratePhysicalDevices(fInst, &n, nullptr);
    std::vector<VkPhysicalDevice> devs(n);
    if (n) vkEnumeratePhysicalDevices(fInst, &n, devs.data());
    // Pick the best device that can do the work: Vulkan >= 1.1, a graphics queue, a colour-renderable RGBA8. Discrete > integrated > the rest.
    int bestScore = -1;
    for (VkPhysicalDevice p : devs) {
        VkPhysicalDeviceProperties dp;
        vkGetPhysicalDeviceProperties(p, &dp);
        if (dp.apiVersion < VK_API_VERSION_1_1) continue;
        VkFormatProperties rgba8;
        vkGetPhysicalDeviceFormatProperties(p, VK_FORMAT_R8G8B8A8_UNORM, &rgba8);
        const VkFormatFeatureFlags need = VK_FORMAT_FEATURE_COLOR_ATTACHMENT_BIT | VK_FORMAT_FEATURE_SAMPLED_IMAGE_BIT;
        if ((rgba8.optimalTilingFeatures & need) != need) continue;
        uint32_t qn = 0;
        vkGetPhysicalDeviceQueueFamilyProperties(p, &qn, nullptr);
        std::vector<VkQueueFamilyProperties> qf(qn);
        if (qn) vkGetPhysicalDeviceQueueFamilyProperties(p, &qn, qf.data());
        int family = -1;
        for (uint32_t i = 0; i < qn; i++) if ((qf[i].queueFlags & VK_QUEUE_GRAPHICS_BIT) && qf[i].queueCount > 0) { family = (int)i; break; }
        if (family < 0) continue;
        const int score = dp.deviceType == VK_PHYSICAL_DEVICE_TYPE_DISCRETE_GPU ? 3 : dp.deviceType == VK_PHYSICAL_DEVICE_TYPE_INTEGRATED_GPU ? 2 : dp.deviceType == VK_PHYSICAL_DEVICE_TYPE_VIRTUAL_GPU ? 1 : 0;
        if (score > bestScore) { bestScore = score; fPhys = p; fFamily = (uint32_t)family; }
    }
    if (!fPhys) { *why = "no Vulkan 1.1 device with a graphics queue and a renderable RGBA8 format"; return false; }
    vkGetPhysicalDeviceProperties(fPhys, &fProps);
    fDeviceName = fProps.deviceName;
    vkGetPhysicalDeviceMemoryProperties(fPhys, &fMem);
    if (fProps.apiVersion < VK_API_VERSION_1_1) { *why = "the Vulkan driver is older than 1.1"; return false; }

    uint32_t en = 0;
    vkEnumerateDeviceExtensionProperties(fPhys, nullptr, &en, nullptr);
    std::vector<VkExtensionProperties> have(en);
    if (en) vkEnumerateDeviceExtensionProperties(fPhys, nullptr, &en, have.data());
    auto has = [&](const char* name) { for (const auto& e : have) if (std::strcmp(e.extensionName, name) == 0) return true; return false; };
    std::vector<const char*> enable;
    // Everything the AHardwareBuffer extension depends on, when the driver lists it (all of these are core in Vulkan 1.1; harmless to enable).
    for (const char* name : {"VK_KHR_sampler_ycbcr_conversion", "VK_KHR_external_memory", "VK_KHR_dedicated_allocation", "VK_KHR_get_memory_requirements2",
                             "VK_KHR_maintenance1", "VK_KHR_bind_memory2", "VK_KHR_external_semaphore"})
        if (has(name)) enable.push_back(name);
    const bool foreignExt = has("VK_EXT_queue_family_foreign");
    fAhb = has("VK_ANDROID_external_memory_android_hardware_buffer") && foreignExt;
    if (fAhb) { enable.push_back("VK_ANDROID_external_memory_android_hardware_buffer"); enable.push_back("VK_EXT_queue_family_foreign"); }
    else if (foreignExt) enable.push_back("VK_EXT_queue_family_foreign");
    const bool semFd = has("VK_KHR_external_semaphore_fd");
    if (semFd) enable.push_back("VK_KHR_external_semaphore_fd");
    fForeign = foreignExt ? VK_QUEUE_FAMILY_FOREIGN_EXT : VK_QUEUE_FAMILY_EXTERNAL;

    float priority = 1.0f;
    VkDeviceQueueCreateInfo qi = {VK_STRUCTURE_TYPE_DEVICE_QUEUE_CREATE_INFO};
    qi.queueFamilyIndex = fFamily; qi.queueCount = 1; qi.pQueuePriorities = &priority;
    VkDeviceCreateInfo dci = {VK_STRUCTURE_TYPE_DEVICE_CREATE_INFO};
    dci.queueCreateInfoCount = 1; dci.pQueueCreateInfos = &qi;
    dci.enabledExtensionCount = (uint32_t)enable.size(); dci.ppEnabledExtensionNames = enable.data();
    r = vkCreateDevice(fPhys, &dci, nullptr, &fDev);
    if (r != VK_SUCCESS) { *why = "vkCreateDevice failed (" + std::to_string((int)r) + ")"; return false; }
    vkGetDeviceQueue(fDev, fFamily, 0, &fQueue);
    fGetAhbProps = (PFN_vkGetAndroidHardwareBufferPropertiesANDROID)vkGetDeviceProcAddr(fDev, "vkGetAndroidHardwareBufferPropertiesANDROID");
    if (fAhb && !fGetAhbProps) fAhb = false;
    if (semFd) {
        fGetSemaphoreFd = (PFN_vkGetSemaphoreFdKHR)vkGetDeviceProcAddr(fDev, "vkGetSemaphoreFdKHR");
        fImportSemaphoreFd = (PFN_vkImportSemaphoreFdKHR)vkGetDeviceProcAddr(fDev, "vkImportSemaphoreFdKHR");
        VkPhysicalDeviceExternalSemaphoreInfo info = {VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_EXTERNAL_SEMAPHORE_INFO};
        info.handleType = VK_EXTERNAL_SEMAPHORE_HANDLE_TYPE_SYNC_FD_BIT;
        VkExternalSemaphoreProperties props = {VK_STRUCTURE_TYPE_EXTERNAL_SEMAPHORE_PROPERTIES};
        vkGetPhysicalDeviceExternalSemaphoreProperties(fPhys, &info, &props);
        fCanExport = fGetSemaphoreFd && (props.externalSemaphoreFeatures & VK_EXTERNAL_SEMAPHORE_FEATURE_EXPORTABLE_BIT);
        fCanImport = fImportSemaphoreFd && (props.externalSemaphoreFeatures & VK_EXTERNAL_SEMAPHORE_FEATURE_IMPORTABLE_BIT);
    }
    for (int i = 0; i < 3; i++) {
        VkFormatProperties fp;
        vkGetPhysicalDeviceFormatProperties(fPhys, VkFormatOf(i == 0 ? Format::RGBA8 : i == 1 ? Format::RGBA16F : Format::RGBA32F), &fp);
        const VkFormatFeatureFlags f = fp.optimalTilingFeatures;
        fCaps[i].render = (f & VK_FORMAT_FEATURE_COLOR_ATTACHMENT_BIT) && (f & VK_FORMAT_FEATURE_SAMPLED_IMAGE_BIT);
        fCaps[i].blend = (f & VK_FORMAT_FEATURE_COLOR_ATTACHMENT_BLEND_BIT) != 0;
        fCaps[i].linear = (f & VK_FORMAT_FEATURE_SAMPLED_IMAGE_FILTER_LINEAR_BIT) != 0;
    }
    if (!fCaps[0].render) { *why = "RGBA8 is not renderable and sampleable on this Vulkan device"; return false; }
    VkPipelineCacheCreateInfo pci = {VK_STRUCTURE_TYPE_PIPELINE_CACHE_CREATE_INFO};
    if (vkCreatePipelineCache(fDev, &pci, nullptr, &fCache) != VK_SUCCESS) fCache = VK_NULL_HANDLE;   // not fatal: pipelines are just built without a cache
    VkCommandPoolCreateInfo pi = {VK_STRUCTURE_TYPE_COMMAND_POOL_CREATE_INFO};
    pi.queueFamilyIndex = fFamily; pi.flags = VK_COMMAND_POOL_CREATE_RESET_COMMAND_BUFFER_BIT;
    r = vkCreateCommandPool(fDev, &pi, nullptr, &fPool);
    if (r != VK_SUCCESS) { *why = "vkCreateCommandPool failed"; return false; }

    GlslCompileResult cv = CompileGlslToSpirv(kVertexSource, GlslDialect::Vulkan, GlslStage::Vertex);
    if (!cv.ok) { *why = "the full-screen vertex shader did not compile: " + cv.log; return false; }
    VkShaderModuleCreateInfo si = {VK_STRUCTURE_TYPE_SHADER_MODULE_CREATE_INFO};
    si.codeSize = cv.words.size() * 4; si.pCode = cv.words.data();
    if (vkCreateShaderModule(fDev, &si, nullptr, &fVertex) != VK_SUCCESS) { *why = "vkCreateShaderModule (vertex) failed"; return false; }
    fOk = true;
    return true;
}

void VkBackend::shutdown() {
    if (!fDev) { if (fInst) vkDestroyInstance(fInst, nullptr); return; }
    vkDeviceWaitIdle(fDev);
    for (auto& s : fSlots) {
        for (VkSemaphore sem : s->semaphores) vkDestroySemaphore(fDev, sem, nullptr);
        if (s->uboMap) vkUnmapMemory(fDev, s->uboMemory);
        if (s->ubo) vkDestroyBuffer(fDev, s->ubo, nullptr);
        if (s->uboMemory) vkFreeMemory(fDev, s->uboMemory, nullptr);
        if (s->pool) vkDestroyDescriptorPool(fDev, s->pool, nullptr);
        if (s->fence) vkDestroyFence(fDev, s->fence, nullptr);
    }
    fSlots.clear();
    for (VkSemaphore sem : fPending) vkDestroySemaphore(fDev, sem, nullptr);
    fPending.clear();
    std::vector<VkTarget*> all(fLive.begin(), fLive.end());
    for (VkTarget* t : all) destroyTarget(t);
    for (auto& p : fPrograms) freeProgram(p.second.get());
    fPrograms.clear();
    for (auto& s : fSamplers) vkDestroySampler(fDev, s.second, nullptr);
    for (auto& p : fPasses) { vkDestroyRenderPass(fDev, p.second.first, nullptr); vkDestroyRenderPass(fDev, p.second.second, nullptr); }
    if (fVertex) vkDestroyShaderModule(fDev, fVertex, nullptr);
    if (fPool) vkDestroyCommandPool(fDev, fPool, nullptr);
    if (fCache) vkDestroyPipelineCache(fDev, fCache, nullptr);
    vkDestroyDevice(fDev, nullptr);
    fDev = VK_NULL_HANDLE;
    if (fInst) vkDestroyInstance(fInst, nullptr);
    fInst = VK_NULL_HANDLE;
}

// ================================================================== targets
bool VkBackend::importAhb(AHardwareBuffer* buffer, VkTarget* t, std::string* error) {
    VkAndroidHardwareBufferFormatPropertiesANDROID fp = {VK_STRUCTURE_TYPE_ANDROID_HARDWARE_BUFFER_FORMAT_PROPERTIES_ANDROID};
    VkAndroidHardwareBufferPropertiesANDROID props = {VK_STRUCTURE_TYPE_ANDROID_HARDWARE_BUFFER_PROPERTIES_ANDROID};
    props.pNext = &fp;
    VkResult r = fGetAhbProps(fDev, buffer, &props);
    if (r != VK_SUCCESS) { *error = "vkGetAndroidHardwareBufferPropertiesANDROID failed (" + std::to_string((int)r) + ")"; return false; }
    if (fp.format != VK_FORMAT_R8G8B8A8_UNORM && fp.format != VK_FORMAT_R16G16B16A16_SFLOAT) {
        *error = "the hardware buffer has Vulkan format " + std::to_string((int)fp.format) + " (an external or unsupported format): only RGBA8 and RGBA16F buffers are shared";
        return false;
    }
    AHardwareBuffer_Desc desc = {};
    AHardwareBuffer_describe(buffer, &desc);
    t->vkFormat = fp.format;
    t->width = (int)desc.width; t->height = (int)desc.height;
    t->format = fp.format == VK_FORMAT_R16G16B16A16_SFLOAT ? Format::RGBA16F : Format::RGBA8;

    VkExternalMemoryImageCreateInfo ext = {VK_STRUCTURE_TYPE_EXTERNAL_MEMORY_IMAGE_CREATE_INFO};
    ext.handleTypes = VK_EXTERNAL_MEMORY_HANDLE_TYPE_ANDROID_HARDWARE_BUFFER_BIT_ANDROID;
    VkImageCreateInfo ic = {VK_STRUCTURE_TYPE_IMAGE_CREATE_INFO};
    ic.pNext = &ext;
    ic.imageType = VK_IMAGE_TYPE_2D; ic.format = fp.format; ic.extent = {desc.width, desc.height, 1};
    ic.mipLevels = 1; ic.arrayLayers = 1; ic.samples = VK_SAMPLE_COUNT_1_BIT; ic.tiling = VK_IMAGE_TILING_OPTIMAL;
    ic.usage = VK_IMAGE_USAGE_COLOR_ATTACHMENT_BIT | VK_IMAGE_USAGE_SAMPLED_BIT;
    ic.sharingMode = VK_SHARING_MODE_EXCLUSIVE; ic.initialLayout = VK_IMAGE_LAYOUT_UNDEFINED;
    r = vkCreateImage(fDev, &ic, nullptr, &t->image);
    if (r != VK_SUCCESS) { *error = "vkCreateImage (hardware buffer) failed (" + std::to_string((int)r) + ")"; return false; }
    VkMemoryRequirements mr;
    vkGetImageMemoryRequirements(fDev, t->image, &mr);
    VkImportAndroidHardwareBufferInfoANDROID imp = {VK_STRUCTURE_TYPE_IMPORT_ANDROID_HARDWARE_BUFFER_INFO_ANDROID};
    imp.buffer = buffer;
    VkMemoryDedicatedAllocateInfo dedicated = {VK_STRUCTURE_TYPE_MEMORY_DEDICATED_ALLOCATE_INFO};
    dedicated.pNext = &imp; dedicated.image = t->image;
    VkMemoryAllocateInfo ai = {VK_STRUCTURE_TYPE_MEMORY_ALLOCATE_INFO};
    ai.pNext = &dedicated; ai.allocationSize = props.allocationSize;
    const uint32_t bits = props.memoryTypeBits & mr.memoryTypeBits;
    uint32_t index = 0;
    while (index < 32 && !(bits & (1u << index))) index++;
    if (index >= 32) { *error = "no memory type fits the hardware buffer"; return false; }
    ai.memoryTypeIndex = index;
    r = vkAllocateMemory(fDev, &ai, nullptr, &t->memory);
    if (r != VK_SUCCESS) { *error = "vkAllocateMemory (hardware buffer import) failed (" + std::to_string((int)r) + ")"; return false; }
    r = vkBindImageMemory(fDev, t->image, t->memory, 0);
    if (r != VK_SUCCESS) { *error = "vkBindImageMemory failed"; return false; }
    return true;
}

VkBackend::VkTarget* VkBackend::makeTarget(int w, int h, Format f, AHardwareBuffer* importFrom, bool wantShared, std::string* error) {
    if (!fOk || fLost) { *error = "the Vulkan backend is not usable"; return nullptr; }
    if (w <= 0 || h <= 0 || w > maxTextureSize() || h > maxTextureSize()) { *error = "size " + std::to_string(w) + "x" + std::to_string(h) + " is outside what this device allows"; return nullptr; }
    if (!caps(f).render) { *error = std::string(ToString(f)) + " is not renderable on this device"; return nullptr; }
    std::unique_ptr<VkTarget> t(new VkTarget());
    t->width = w; t->height = h; t->format = f; t->vkFormat = VkFormatOf(f);
    fLive.insert(t.get());
    auto fail = [&]() { VkTarget* raw = t.release(); destroyTarget(raw); return (VkTarget*)nullptr; };
    if (importFrom) {
        AHardwareBuffer_acquire(importFrom);
        t->ahb = importFrom;
        t->imported = true;
        if (!importAhb(importFrom, t.get(), error)) return fail();
    } else if (wantShared) {
        AHardwareBuffer_Desc d = {};
        d.width = (uint32_t)w; d.height = (uint32_t)h; d.layers = 1;
        d.format = f == Format::RGBA16F ? AHARDWAREBUFFER_FORMAT_R16G16B16A16_FLOAT : AHARDWAREBUFFER_FORMAT_R8G8B8A8_UNORM;
        d.usage = AHARDWAREBUFFER_USAGE_GPU_FRAMEBUFFER | AHARDWAREBUFFER_USAGE_GPU_SAMPLED_IMAGE;
        AHardwareBuffer* b = nullptr;
        if (AHardwareBuffer_allocate(&d, &b) != 0 || !b) { *error = "AHardwareBuffer_allocate failed"; return fail(); }
        t->ahb = b;
        if (!importAhb(b, t.get(), error)) return fail();
    } else {
        VkImageCreateInfo ic = {VK_STRUCTURE_TYPE_IMAGE_CREATE_INFO};
        ic.imageType = VK_IMAGE_TYPE_2D; ic.format = t->vkFormat; ic.extent = {(uint32_t)w, (uint32_t)h, 1};
        ic.mipLevels = 1; ic.arrayLayers = 1; ic.samples = VK_SAMPLE_COUNT_1_BIT; ic.tiling = VK_IMAGE_TILING_OPTIMAL;
        ic.usage = VK_IMAGE_USAGE_COLOR_ATTACHMENT_BIT | VK_IMAGE_USAGE_SAMPLED_BIT | VK_IMAGE_USAGE_TRANSFER_DST_BIT;
        ic.sharingMode = VK_SHARING_MODE_EXCLUSIVE; ic.initialLayout = VK_IMAGE_LAYOUT_UNDEFINED;
        VkResult r = vkCreateImage(fDev, &ic, nullptr, &t->image);
        if (r != VK_SUCCESS) { *error = "vkCreateImage failed (" + std::to_string((int)r) + ")"; return fail(); }
        VkMemoryRequirements mr;
        vkGetImageMemoryRequirements(fDev, t->image, &mr);
        VkMemoryAllocateInfo ai = {VK_STRUCTURE_TYPE_MEMORY_ALLOCATE_INFO};
        ai.allocationSize = mr.size;
        if (!findMemory(mr.memoryTypeBits, VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT, &ai.memoryTypeIndex) && !findMemory(mr.memoryTypeBits, 0, &ai.memoryTypeIndex)) { *error = "no memory type for the image"; return fail(); }
        r = vkAllocateMemory(fDev, &ai, nullptr, &t->memory);
        if (r != VK_SUCCESS) { *error = "vkAllocateMemory failed (" + std::to_string((int)r) + ")"; return fail(); }
        if (vkBindImageMemory(fDev, t->image, t->memory, 0) != VK_SUCCESS) { *error = "vkBindImageMemory failed"; return fail(); }
    }
    VkImageViewCreateInfo vi = {VK_STRUCTURE_TYPE_IMAGE_VIEW_CREATE_INFO};
    vi.image = t->image; vi.viewType = VK_IMAGE_VIEW_TYPE_2D; vi.format = t->vkFormat;
    vi.subresourceRange.aspectMask = VK_IMAGE_ASPECT_COLOR_BIT; vi.subresourceRange.levelCount = 1; vi.subresourceRange.layerCount = 1;
    if (vkCreateImageView(fDev, &vi, nullptr, &t->view) != VK_SUCCESS) { *error = "vkCreateImageView failed"; return fail(); }
    return t.release();
}

void VkBackend::destroyTarget(VkTarget* t) {
    if (!t) return;
    if (fDev) {
        drain();      // the GPU may still read it
        if (t->fb) vkDestroyFramebuffer(fDev, t->fb, nullptr);
        if (t->view) vkDestroyImageView(fDev, t->view, nullptr);
        if (t->image) vkDestroyImage(fDev, t->image, nullptr);
        if (t->memory) vkFreeMemory(fDev, t->memory, nullptr);
    }
    if (t->ahb) AHardwareBuffer_release(t->ahb);
    fLive.erase(t);
    for (auto it = fTextures.begin(); it != fTextures.end();) { if (it->second == t) it = fTextures.erase(it); else ++it; }
    for (auto it = fBlanks.begin(); it != fBlanks.end();) { if (it->second == t) it = fBlanks.erase(it); else ++it; }
    for (auto it = fViews.begin(); it != fViews.end();) { if (it->second == t) it = fViews.erase(it); else ++it; }
    delete t;
}

void VkBackend::trimViews() {
    while (fViews.size() > kMaxViews) {
        auto oldest = fViews.end();
        for (auto it = fViews.begin(); it != fViews.end(); ++it)
            if (it->second->users == 0 && (oldest == fViews.end() || it->second->used < oldest->second->used)) oldest = it;
        if (oldest == fViews.end()) return;     // all in use
        destroyTarget(oldest->second);
    }
}

VkRenderPass VkBackend::renderPass(VkFormat f, bool clear, std::string* error) {
    auto it = fPasses.find(f);
    if (it == fPasses.end()) {
        VkRenderPass made[2] = {VK_NULL_HANDLE, VK_NULL_HANDLE};
        for (int k = 0; k < 2; k++) {
            VkAttachmentDescription at = {};
            at.format = f; at.samples = VK_SAMPLE_COUNT_1_BIT;
            at.loadOp = k == 0 ? VK_ATTACHMENT_LOAD_OP_CLEAR : VK_ATTACHMENT_LOAD_OP_LOAD;
            at.storeOp = VK_ATTACHMENT_STORE_OP_STORE;
            at.stencilLoadOp = VK_ATTACHMENT_LOAD_OP_DONT_CARE; at.stencilStoreOp = VK_ATTACHMENT_STORE_OP_DONT_CARE;
            at.initialLayout = VK_IMAGE_LAYOUT_GENERAL; at.finalLayout = VK_IMAGE_LAYOUT_GENERAL;
            VkAttachmentReference ref = {0, VK_IMAGE_LAYOUT_GENERAL};
            VkSubpassDescription sp = {};
            sp.pipelineBindPoint = VK_PIPELINE_BIND_POINT_GRAPHICS; sp.colorAttachmentCount = 1; sp.pColorAttachments = &ref;
            VkRenderPassCreateInfo rp = {VK_STRUCTURE_TYPE_RENDER_PASS_CREATE_INFO};
            rp.attachmentCount = 1; rp.pAttachments = &at; rp.subpassCount = 1; rp.pSubpasses = &sp;
            if (vkCreateRenderPass(fDev, &rp, nullptr, &made[k]) != VK_SUCCESS) {
                if (k == 1) vkDestroyRenderPass(fDev, made[0], nullptr);
                *error = "vkCreateRenderPass failed";
                return VK_NULL_HANDLE;
            }
        }
        it = fPasses.emplace(f, std::make_pair(made[0], made[1])).first;
    }
    return clear ? it->second.first : it->second.second;
}

VkFramebuffer VkBackend::framebuffer(VkTarget* t, std::string* error) {
    if (t->fb) return t->fb;
    VkRenderPass rp = renderPass(t->vkFormat, true, error);      // the load variant is compatible with it
    if (!rp) return VK_NULL_HANDLE;
    VkFramebufferCreateInfo fi = {VK_STRUCTURE_TYPE_FRAMEBUFFER_CREATE_INFO};
    fi.renderPass = rp; fi.attachmentCount = 1; fi.pAttachments = &t->view; fi.width = (uint32_t)t->width; fi.height = (uint32_t)t->height; fi.layers = 1;
    if (vkCreateFramebuffer(fDev, &fi, nullptr, &t->fb) != VK_SUCCESS) { *error = "vkCreateFramebuffer failed"; return VK_NULL_HANDLE; }
    return t->fb;
}

VkSampler VkBackend::sampler(Filter f, Wrap w, std::string* error) {
    const int key = (int)f * 8 + (int)w;
    auto it = fSamplers.find(key);
    if (it != fSamplers.end()) return it->second;
    VkSamplerCreateInfo sci = {VK_STRUCTURE_TYPE_SAMPLER_CREATE_INFO};
    sci.magFilter = sci.minFilter = f == Filter::Nearest ? VK_FILTER_NEAREST : VK_FILTER_LINEAR;
    sci.mipmapMode = VK_SAMPLER_MIPMAP_MODE_NEAREST;
    VkSamplerAddressMode mode = VK_SAMPLER_ADDRESS_MODE_CLAMP_TO_EDGE;
    if (w == Wrap::Repeat) mode = VK_SAMPLER_ADDRESS_MODE_REPEAT;
    else if (w == Wrap::Mirror) mode = VK_SAMPLER_ADDRESS_MODE_MIRRORED_REPEAT;
    else if (w == Wrap::Decal) mode = VK_SAMPLER_ADDRESS_MODE_CLAMP_TO_BORDER;
    sci.addressModeU = sci.addressModeV = sci.addressModeW = mode;
    sci.borderColor = VK_BORDER_COLOR_FLOAT_TRANSPARENT_BLACK;
    VkSampler s = VK_NULL_HANDLE;
    if (vkCreateSampler(fDev, &sci, nullptr, &s) != VK_SUCCESS) { *error = "vkCreateSampler failed"; return VK_NULL_HANDLE; }
    fSamplers[key] = s;
    return s;
}

// ================================================================== programs
void VkBackend::freeProgram(Program* p) {
    for (auto& pl : p->pipelines) vkDestroyPipeline(fDev, pl.second, nullptr);
    p->pipelines.clear();
    if (p->layout) vkDestroyPipelineLayout(fDev, p->layout, nullptr);
    if (p->dsl) vkDestroyDescriptorSetLayout(fDev, p->dsl, nullptr);
    if (p->frag) vkDestroyShaderModule(fDev, p->frag, nullptr);
    p->layout = VK_NULL_HANDLE; p->dsl = VK_NULL_HANDLE; p->frag = VK_NULL_HANDLE;
}

VkBackend::Program* VkBackend::program(const PassDesc& pass, std::string* error) {
    std::string key = std::string(ToString(pass.lang)) + "\n" + pass.source;
    for (const auto& d : pass.defines) key += "\n#" + d.first + "=" + d.second;
    const uint64_t h = Fnv(key);
    auto it = fPrograms.find(h);
    if (it != fPrograms.end()) {
        if (!it->second->ok) { *error = it->second->error; return nullptr; }
        return it->second.get();
    }
    auto prog = std::make_unique<Program>();
    auto fail = [&](const std::string& msg) {
        prog->error = msg;
        Program* raw = prog.get();
        fPrograms[h] = std::move(prog);
        *error = raw->error;
        return (Program*)nullptr;
    };

    std::vector<uint32_t> words;
    if (pass.lang == Lang::SPIRV) {
        std::vector<uint8_t> bytes;
        if (!Base64Decode(pass.source, &bytes)) return fail("the spirv source is not valid base64");
        SpirvInfo info;
        std::string err;
        if (!ParseSpirv(bytes, &info, &err)) return fail("the SPIR-V module is not valid: " + err);
        bool fragment = false;
        for (const auto& e : info.entryPoints) if (e.model == 4) { fragment = true; prog->entry = e.name; break; }
        if (!fragment) return fail("the SPIR-V module has no fragment entry point");
        words = info.words;
    } else {
        GlslDevice dev;
        dev.desktopVersion = 460; dev.vulkanGlsl = true;
        ShaderHeader header = ParseShaderHeader(pass.source);
        std::string why; int line = 0;
        if (!CheckGlslHeader(pass.lang, header, dev, &why, &line)) return fail(why + (line > 0 ? " (line " + std::to_string(line) + ")" : std::string()));
        std::string text;
        std::string note;
        if (pass.lang == Lang::GLSL) {
            GlslWrapResult w = WrapDesktopGlslForVulkan(pass.source, pass.defines);
            if (!w.ok) return fail("desktop GLSL cannot run on Vulkan as written: " + w.error + (w.errorLine > 0 ? " (line " + std::to_string(w.errorLine) + ")" : std::string()));
            text = w.text;
            note = " [desktop GLSL was rewritten for Vulkan (uniforms in one block, #version 450); compiler line numbers = your line + " + std::to_string(w.lineShift) + "]";
        } else {
            text = InsertDefines(pass.source, pass.defines);
            if (!pass.defines.empty()) note = " [" + std::to_string(pass.defines.size()) + " #define line(s) were added after #version; compiler line numbers shift by that many]";
        }
        GlslCompileResult c = CompileGlslToSpirv(text, GlslDialect::Vulkan, GlslStage::Fragment);
        if (!c.ok) return fail("glslang: " + c.log + note);
        words = c.words;
    }

    std::string err;
    if (!ReflectSpirv(words, &prog->refl, &err)) return fail("cannot read the SPIR-V resources: " + err);
    const SpirvReflection& rf = prog->refl;
    if (rf.pushConstants) return fail("push constants are not supported: put the values in a uniform block");
    if (rf.storageBuffers) return fail("storage buffers are not supported (uniform blocks and sampler2D only)");
    if (rf.otherResources) return fail("only uniform blocks and combined sampler2D are supported (separate textures / samplers / storage images are not)");
    if (rf.inputCount > 0) return fail("the fragment shader declares " + std::to_string(rf.inputCount) + " 'in' variable(s): the full-screen vertex stage passes nothing on, so use gl_FragCoord and the size uniform instead of varyings");
    if (rf.outputCount < 1) return fail("the fragment shader writes no colour output (declare 'layout(location = 0) out vec4 ...')");
    if (rf.blocks.size() > 8 || rf.samplers.size() > 16) return fail("too many uniform blocks (max 8) or samplers (max 16)");
    std::set<uint32_t> used;
    std::vector<VkDescriptorSetLayoutBinding> bindings;
    auto addBinding = [&](uint32_t set, uint32_t binding, VkDescriptorType type, const std::string& what) {
        if (set != 0) { err = what + " is in descriptor set " + std::to_string(set) + ": only set 0 is supported"; return false; }
        if (!used.insert(binding).second) { err = what + " reuses binding " + std::to_string(binding); return false; }
        VkDescriptorSetLayoutBinding b = {};
        b.binding = binding; b.descriptorType = type; b.descriptorCount = 1; b.stageFlags = VK_SHADER_STAGE_FRAGMENT_BIT;
        bindings.push_back(b);
        return true;
    };
    for (const SpirvBlock& b : rf.blocks) if (!addBinding(b.set, b.binding, VK_DESCRIPTOR_TYPE_UNIFORM_BUFFER, "uniform block '" + b.name + "'")) return fail(err);
    for (const SpirvSampler& s : rf.samplers) if (!addBinding(s.set, s.binding, VK_DESCRIPTOR_TYPE_COMBINED_IMAGE_SAMPLER, "sampler2D '" + s.name + "'")) return fail(err);
    for (const SpirvBlock& b : rf.blocks) if (b.size > kSlotUboBytes) return fail("uniform block '" + b.name + "' is larger than 64 KB");

    VkShaderModuleCreateInfo si = {VK_STRUCTURE_TYPE_SHADER_MODULE_CREATE_INFO};
    si.codeSize = words.size() * 4; si.pCode = words.data();
    if (vkCreateShaderModule(fDev, &si, nullptr, &prog->frag) != VK_SUCCESS) return fail("the driver rejected the SPIR-V module (vkCreateShaderModule)");
    VkDescriptorSetLayoutCreateInfo dl = {VK_STRUCTURE_TYPE_DESCRIPTOR_SET_LAYOUT_CREATE_INFO};
    dl.bindingCount = (uint32_t)bindings.size(); dl.pBindings = bindings.data();
    if (vkCreateDescriptorSetLayout(fDev, &dl, nullptr, &prog->dsl) != VK_SUCCESS) { freeProgram(prog.get()); return fail("vkCreateDescriptorSetLayout failed"); }
    VkPipelineLayoutCreateInfo pl = {VK_STRUCTURE_TYPE_PIPELINE_LAYOUT_CREATE_INFO};
    pl.setLayoutCount = 1; pl.pSetLayouts = &prog->dsl;
    if (vkCreatePipelineLayout(fDev, &pl, nullptr, &prog->layout) != VK_SUCCESS) { freeProgram(prog.get()); return fail("vkCreatePipelineLayout failed"); }
    prog->ok = true;
    Program* raw = prog.get();
    fPrograms[h] = std::move(prog);
    return raw;
}

VkPipeline VkBackend::pipeline(Program* p, VkTarget* out, Blend blend, std::string* error) {
    const uint64_t key = (uint64_t)out->vkFormat * 16 + (uint64_t)blend;
    auto it = p->pipelines.find(key);
    if (it != p->pipelines.end()) return it->second;
    VkRenderPass rp = renderPass(out->vkFormat, true, error);
    if (!rp) return VK_NULL_HANDLE;
    VkPipelineShaderStageCreateInfo st[2] = {};
    st[0].sType = VK_STRUCTURE_TYPE_PIPELINE_SHADER_STAGE_CREATE_INFO; st[0].stage = VK_SHADER_STAGE_VERTEX_BIT; st[0].module = fVertex; st[0].pName = "main";
    st[1].sType = VK_STRUCTURE_TYPE_PIPELINE_SHADER_STAGE_CREATE_INFO; st[1].stage = VK_SHADER_STAGE_FRAGMENT_BIT; st[1].module = p->frag; st[1].pName = p->entry.c_str();
    VkPipelineVertexInputStateCreateInfo vi = {VK_STRUCTURE_TYPE_PIPELINE_VERTEX_INPUT_STATE_CREATE_INFO};
    VkPipelineInputAssemblyStateCreateInfo ia = {VK_STRUCTURE_TYPE_PIPELINE_INPUT_ASSEMBLY_STATE_CREATE_INFO};
    ia.topology = VK_PRIMITIVE_TOPOLOGY_TRIANGLE_LIST;
    VkPipelineViewportStateCreateInfo vp = {VK_STRUCTURE_TYPE_PIPELINE_VIEWPORT_STATE_CREATE_INFO};
    vp.viewportCount = 1; vp.scissorCount = 1;
    VkPipelineRasterizationStateCreateInfo rs = {VK_STRUCTURE_TYPE_PIPELINE_RASTERIZATION_STATE_CREATE_INFO};
    rs.polygonMode = VK_POLYGON_MODE_FILL; rs.cullMode = VK_CULL_MODE_NONE; rs.frontFace = VK_FRONT_FACE_COUNTER_CLOCKWISE; rs.lineWidth = 1.0f;
    VkPipelineMultisampleStateCreateInfo ms = {VK_STRUCTURE_TYPE_PIPELINE_MULTISAMPLE_STATE_CREATE_INFO};
    ms.rasterizationSamples = VK_SAMPLE_COUNT_1_BIT;
    VkPipelineColorBlendAttachmentState cba = {};
    cba.colorWriteMask = VK_COLOR_COMPONENT_R_BIT | VK_COLOR_COMPONENT_G_BIT | VK_COLOR_COMPONENT_B_BIT | VK_COLOR_COMPONENT_A_BIT;
    // Same factors as the GL backend (premultiplied values), applied to colour and alpha.
    VkBlendFactor src = VK_BLEND_FACTOR_ONE, dst = VK_BLEND_FACTOR_ZERO;
    switch (blend) {
        case Blend::SrcOver: cba.blendEnable = VK_TRUE; dst = VK_BLEND_FACTOR_ONE_MINUS_SRC_ALPHA; break;
        case Blend::Add: cba.blendEnable = VK_TRUE; dst = VK_BLEND_FACTOR_ONE; break;
        case Blend::Multiply: cba.blendEnable = VK_TRUE; src = VK_BLEND_FACTOR_DST_COLOR; dst = VK_BLEND_FACTOR_ONE_MINUS_SRC_ALPHA; break;
        case Blend::Screen: cba.blendEnable = VK_TRUE; dst = VK_BLEND_FACTOR_ONE_MINUS_SRC_COLOR; break;
        default: break;
    }
    cba.srcColorBlendFactor = cba.srcAlphaBlendFactor = src;
    cba.dstColorBlendFactor = cba.dstAlphaBlendFactor = dst;
    cba.colorBlendOp = cba.alphaBlendOp = VK_BLEND_OP_ADD;
    VkPipelineColorBlendStateCreateInfo cbs = {VK_STRUCTURE_TYPE_PIPELINE_COLOR_BLEND_STATE_CREATE_INFO};
    cbs.attachmentCount = 1; cbs.pAttachments = &cba;
    VkDynamicState dyn[2] = {VK_DYNAMIC_STATE_VIEWPORT, VK_DYNAMIC_STATE_SCISSOR};
    VkPipelineDynamicStateCreateInfo ds = {VK_STRUCTURE_TYPE_PIPELINE_DYNAMIC_STATE_CREATE_INFO};
    ds.dynamicStateCount = 2; ds.pDynamicStates = dyn;
    VkGraphicsPipelineCreateInfo gp = {VK_STRUCTURE_TYPE_GRAPHICS_PIPELINE_CREATE_INFO};
    gp.stageCount = 2; gp.pStages = st; gp.pVertexInputState = &vi; gp.pInputAssemblyState = &ia; gp.pViewportState = &vp;
    gp.pRasterizationState = &rs; gp.pMultisampleState = &ms; gp.pColorBlendState = &cbs; gp.pDynamicState = &ds;
    gp.layout = p->layout; gp.renderPass = rp; gp.subpass = 0;
    VkPipeline made = VK_NULL_HANDLE;
    const VkResult res = vkCreateGraphicsPipelines(fDev, fCache, 1, &gp, nullptr, &made);
    if (res == VK_ERROR_DEVICE_LOST) fLost = true;
    if (res != VK_SUCCESS) { *error = "the driver could not build the pipeline (vkCreateGraphicsPipelines " + std::to_string((int)res) + "): the shader's outputs or resources do not fit a single RGBA colour target"; return VK_NULL_HANDLE; }
    p->pipelines[key] = made;
    return made;
}

// ================================================================== submission slots
VkBackend::Slot* VkBackend::acquireSlot(std::string* error) {
    reap();
    for (auto& s : fSlots) if (!s->busy) { vkResetDescriptorPool(fDev, s->pool, 0); return s.get(); }
    if (fSlots.size() < kMaxSlots) {
        auto s = std::make_unique<Slot>();
        VkFenceCreateInfo fci = {VK_STRUCTURE_TYPE_FENCE_CREATE_INFO};
        VkCommandBufferAllocateInfo cai = {VK_STRUCTURE_TYPE_COMMAND_BUFFER_ALLOCATE_INFO};
        cai.commandPool = fPool; cai.level = VK_COMMAND_BUFFER_LEVEL_PRIMARY; cai.commandBufferCount = 1;
        VkDescriptorPoolSize sizes[2] = {{VK_DESCRIPTOR_TYPE_UNIFORM_BUFFER, 8}, {VK_DESCRIPTOR_TYPE_COMBINED_IMAGE_SAMPLER, 16}};
        VkDescriptorPoolCreateInfo dpi = {VK_STRUCTURE_TYPE_DESCRIPTOR_POOL_CREATE_INFO};
        dpi.maxSets = 2; dpi.poolSizeCount = 2; dpi.pPoolSizes = sizes;
        VkBufferCreateInfo bi = {VK_STRUCTURE_TYPE_BUFFER_CREATE_INFO};
        bi.size = kSlotUboBytes; bi.usage = VK_BUFFER_USAGE_UNIFORM_BUFFER_BIT; bi.sharingMode = VK_SHARING_MODE_EXCLUSIVE;
        bool good = vkCreateFence(fDev, &fci, nullptr, &s->fence) == VK_SUCCESS && vkAllocateCommandBuffers(fDev, &cai, &s->cmd) == VK_SUCCESS &&
                    vkCreateDescriptorPool(fDev, &dpi, nullptr, &s->pool) == VK_SUCCESS && vkCreateBuffer(fDev, &bi, nullptr, &s->ubo) == VK_SUCCESS;
        if (good) {
            VkMemoryRequirements mr;
            vkGetBufferMemoryRequirements(fDev, s->ubo, &mr);
            VkMemoryAllocateInfo ai = {VK_STRUCTURE_TYPE_MEMORY_ALLOCATE_INFO};
            ai.allocationSize = mr.size;
            good = findMemory(mr.memoryTypeBits, VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT | VK_MEMORY_PROPERTY_HOST_COHERENT_BIT, &ai.memoryTypeIndex) &&
                   vkAllocateMemory(fDev, &ai, nullptr, &s->uboMemory) == VK_SUCCESS && vkBindBufferMemory(fDev, s->ubo, s->uboMemory, 0) == VK_SUCCESS;
            void* map = nullptr;
            if (good && vkMapMemory(fDev, s->uboMemory, 0, VK_WHOLE_SIZE, 0, &map) == VK_SUCCESS) s->uboMap = static_cast<uint8_t*>(map); else good = false;
        }
        Slot* raw = s.get();
        fSlots.push_back(std::move(s));      // owned from here on, so shutdown() frees whatever was made
        if (!good) { *error = "could not create a Vulkan submission slot"; fSlots.pop_back(); return nullptr; }
        return raw;
    }
    // every slot is in flight: wait for the oldest one
    Slot* s = fSlots.front().get();
    if (vkWaitForFences(fDev, 1, &s->fence, VK_TRUE, 5000000000ull) == VK_ERROR_DEVICE_LOST) fLost = true;
    reap();
    if (s->busy) { *error = "the GPU did not finish earlier Vulkan work within 5 s"; return nullptr; }
    vkResetDescriptorPool(fDev, s->pool, 0);
    return s;
}

void VkBackend::reap() {
    for (auto& s : fSlots) {
        if (!s->busy) continue;
        if (vkGetFenceStatus(fDev, s->fence) != VK_SUCCESS) continue;
        for (VkSemaphore sem : s->semaphores) vkDestroySemaphore(fDev, sem, nullptr);
        s->semaphores.clear();
        vkResetDescriptorPool(fDev, s->pool, 0);
        vkResetFences(fDev, 1, &s->fence);
        s->busy = false;
    }
}

void VkBackend::drain() {
    if (fDev) vkQueueWaitIdle(fQueue);
    reap();
}

bool VkBackend::beginSlot(Slot* s, std::string* error) {
    vkResetCommandBuffer(s->cmd, 0);
    VkCommandBufferBeginInfo bi = {VK_STRUCTURE_TYPE_COMMAND_BUFFER_BEGIN_INFO};
    bi.flags = VK_COMMAND_BUFFER_USAGE_ONE_TIME_SUBMIT_BIT;
    if (vkBeginCommandBuffer(s->cmd, &bi) != VK_SUCCESS) { *error = "vkBeginCommandBuffer failed"; return false; }
    return true;
}

VkSemaphore VkBackend::makeSemaphore(bool exportable) {
    VkExportSemaphoreCreateInfo ex = {VK_STRUCTURE_TYPE_EXPORT_SEMAPHORE_CREATE_INFO};
    ex.handleTypes = VK_EXTERNAL_SEMAPHORE_HANDLE_TYPE_SYNC_FD_BIT;
    VkSemaphoreCreateInfo sci = {VK_STRUCTURE_TYPE_SEMAPHORE_CREATE_INFO};
    if (exportable) sci.pNext = &ex;
    VkSemaphore s = VK_NULL_HANDLE;
    return vkCreateSemaphore(fDev, &sci, nullptr, &s) == VK_SUCCESS ? s : VK_NULL_HANDLE;
}

// Ends and submits the slot's command buffer. useWaits: the imported fences of other APIs (fPending) are waited for by this submit.
bool VkBackend::submit(Slot* s, VkSemaphore signal, bool useWaits, std::string* error) {
    if (vkEndCommandBuffer(s->cmd) != VK_SUCCESS) { *error = "vkEndCommandBuffer failed"; return false; }
    std::vector<VkSemaphore> waits;
    if (useWaits) { waits = fPending; fPending.clear(); }
    std::vector<VkPipelineStageFlags> stages(waits.size(), VK_PIPELINE_STAGE_ALL_COMMANDS_BIT);
    VkSubmitInfo si = {VK_STRUCTURE_TYPE_SUBMIT_INFO};
    si.waitSemaphoreCount = (uint32_t)waits.size(); si.pWaitSemaphores = waits.data(); si.pWaitDstStageMask = stages.data();
    si.commandBufferCount = 1; si.pCommandBuffers = &s->cmd;
    si.signalSemaphoreCount = signal ? 1 : 0; si.pSignalSemaphores = &signal;
    const VkResult r = vkQueueSubmit(fQueue, 1, &si, s->fence);
    for (VkSemaphore w : waits) s->semaphores.push_back(w);
    if (signal) s->semaphores.push_back(signal);
    if (r != VK_SUCCESS) {
        if (r == VK_ERROR_DEVICE_LOST) fLost = true;
        for (VkSemaphore w : s->semaphores) vkDestroySemaphore(fDev, w, nullptr);
        s->semaphores.clear();
        *error = "vkQueueSubmit failed (" + std::to_string((int)r) + (r == VK_ERROR_DEVICE_LOST ? ", the GPU device was lost" : "") + ")";
        return false;
    }
    s->busy = true;
    return true;
}

bool VkBackend::upload(VkTarget* t, const uint8_t* bytes, size_t size, std::string* error) {
    VkBuffer buf = VK_NULL_HANDLE;
    VkDeviceMemory mem = VK_NULL_HANDLE;
    void* map = nullptr;
    auto cleanup = [&] { if (map) vkUnmapMemory(fDev, mem); if (buf) vkDestroyBuffer(fDev, buf, nullptr); if (mem) vkFreeMemory(fDev, mem, nullptr); };
    VkBufferCreateInfo bi = {VK_STRUCTURE_TYPE_BUFFER_CREATE_INFO};
    bi.size = size; bi.usage = VK_BUFFER_USAGE_TRANSFER_SRC_BIT; bi.sharingMode = VK_SHARING_MODE_EXCLUSIVE;
    if (vkCreateBuffer(fDev, &bi, nullptr, &buf) != VK_SUCCESS) { *error = "staging buffer failed"; return false; }
    VkMemoryRequirements mr;
    vkGetBufferMemoryRequirements(fDev, buf, &mr);
    VkMemoryAllocateInfo ai = {VK_STRUCTURE_TYPE_MEMORY_ALLOCATE_INFO};
    ai.allocationSize = mr.size;
    if (!findMemory(mr.memoryTypeBits, VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT | VK_MEMORY_PROPERTY_HOST_COHERENT_BIT, &ai.memoryTypeIndex) ||
        vkAllocateMemory(fDev, &ai, nullptr, &mem) != VK_SUCCESS || vkBindBufferMemory(fDev, buf, mem, 0) != VK_SUCCESS || vkMapMemory(fDev, mem, 0, VK_WHOLE_SIZE, 0, &map) != VK_SUCCESS) {
        map = nullptr; cleanup(); *error = "staging memory failed"; return false;
    }
    std::memcpy(map, bytes, size);
    Slot* s = acquireSlot(error);
    if (!s || !beginSlot(s, error)) { cleanup(); return false; }
    VkImageMemoryBarrier b = {VK_STRUCTURE_TYPE_IMAGE_MEMORY_BARRIER};
    b.srcQueueFamilyIndex = b.dstQueueFamilyIndex = VK_QUEUE_FAMILY_IGNORED;
    b.image = t->image; b.subresourceRange = {VK_IMAGE_ASPECT_COLOR_BIT, 0, 1, 0, 1};
    b.oldLayout = VK_IMAGE_LAYOUT_UNDEFINED; b.newLayout = VK_IMAGE_LAYOUT_GENERAL; b.dstAccessMask = VK_ACCESS_TRANSFER_WRITE_BIT;
    vkCmdPipelineBarrier(s->cmd, VK_PIPELINE_STAGE_TOP_OF_PIPE_BIT, VK_PIPELINE_STAGE_TRANSFER_BIT, 0, 0, nullptr, 0, nullptr, 1, &b);
    VkBufferImageCopy region = {};
    region.imageSubresource = {VK_IMAGE_ASPECT_COLOR_BIT, 0, 0, 1};
    region.imageExtent = {(uint32_t)t->width, (uint32_t)t->height, 1};
    vkCmdCopyBufferToImage(s->cmd, buf, t->image, VK_IMAGE_LAYOUT_GENERAL, 1, &region);
    b.oldLayout = b.newLayout = VK_IMAGE_LAYOUT_GENERAL; b.srcAccessMask = VK_ACCESS_TRANSFER_WRITE_BIT; b.dstAccessMask = VK_ACCESS_SHADER_READ_BIT;
    vkCmdPipelineBarrier(s->cmd, VK_PIPELINE_STAGE_TRANSFER_BIT, VK_PIPELINE_STAGE_FRAGMENT_SHADER_BIT, 0, 0, nullptr, 0, nullptr, 1, &b);
    if (!submit(s, VK_NULL_HANDLE, false, error)) { cleanup(); return false; }
    const VkResult w = vkWaitForFences(fDev, 1, &s->fence, VK_TRUE, 5000000000ull);
    if (w == VK_ERROR_DEVICE_LOST) fLost = true;
    reap();
    cleanup();
    if (w != VK_SUCCESS) { *error = "the texture upload did not finish within 5 s"; return false; }
    t->layoutInit = true; t->needsAcquire = false;
    return true;
}

bool VkBackend::clearImage(VkTarget* t, std::string* error) {
    Slot* s = acquireSlot(error);
    if (!s || !beginSlot(s, error)) return false;
    VkImageMemoryBarrier b = {VK_STRUCTURE_TYPE_IMAGE_MEMORY_BARRIER};
    b.srcQueueFamilyIndex = b.dstQueueFamilyIndex = VK_QUEUE_FAMILY_IGNORED;
    b.image = t->image; b.subresourceRange = {VK_IMAGE_ASPECT_COLOR_BIT, 0, 1, 0, 1};
    b.oldLayout = VK_IMAGE_LAYOUT_UNDEFINED; b.newLayout = VK_IMAGE_LAYOUT_GENERAL; b.dstAccessMask = VK_ACCESS_TRANSFER_WRITE_BIT;
    vkCmdPipelineBarrier(s->cmd, VK_PIPELINE_STAGE_TOP_OF_PIPE_BIT, VK_PIPELINE_STAGE_TRANSFER_BIT, 0, 0, nullptr, 0, nullptr, 1, &b);
    VkClearColorValue zero = {};
    VkImageSubresourceRange range = {VK_IMAGE_ASPECT_COLOR_BIT, 0, 1, 0, 1};
    vkCmdClearColorImage(s->cmd, t->image, VK_IMAGE_LAYOUT_GENERAL, &zero, 1, &range);
    b.oldLayout = b.newLayout = VK_IMAGE_LAYOUT_GENERAL; b.srcAccessMask = VK_ACCESS_TRANSFER_WRITE_BIT; b.dstAccessMask = VK_ACCESS_SHADER_READ_BIT;
    vkCmdPipelineBarrier(s->cmd, VK_PIPELINE_STAGE_TRANSFER_BIT, VK_PIPELINE_STAGE_FRAGMENT_SHADER_BIT, 0, 0, nullptr, 0, nullptr, 1, &b);
    if (!submit(s, VK_NULL_HANDLE, false, error)) return false;
    const VkResult w = vkWaitForFences(fDev, 1, &s->fence, VK_TRUE, 5000000000ull);
    if (w == VK_ERROR_DEVICE_LOST) fLost = true;
    reap();
    if (w != VK_SUCCESS) { *error = "clearing the image did not finish within 5 s"; return false; }
    t->layoutInit = true; t->needsAcquire = false;
    return true;
}

// ================================================================== run one pass
bool VkBackend::run(const PassRun& r, std::string* error) {
    std::lock_guard<std::recursive_mutex> lock(fLock);
    if (!fOk || fLost) { *error = "the Vulkan device is not usable (lost or never created)"; return false; }
    reap();
    VkTarget* out = live(r.output);
    if (!out) { *error = "output target does not belong to the Vulkan backend"; return false; }
    Program* prog = program(*r.pass, error);
    if (!prog) return false;
    const Blend blend = r.pass->blend;
    if (blend != Blend::Replace && !caps(out->format).blend) { *error = std::string("blending into ") + ToString(out->format) + " is not supported on this device"; return false; }

    std::vector<std::pair<const BoundInput*, VkTarget*>> inputs;
    for (const BoundInput& in : r.inputs) {
        VkTarget* t = live(in.target);
        if (!t) { *error = "input '" + (in.name ? *in.name : std::string("?")) + "' does not belong to the Vulkan backend"; return false; }
        if (t == out) { *error = "pass '" + r.pass->id + "' reads the buffer it renders into (feedback loop); use a history buffer (@1) or another output"; return false; }
        if (in.filter == Filter::Linear && !caps(t->format).linear) { *error = std::string("input '") + *in.name + "' is " + ToString(t->format) + ", which this device cannot filter linearly; use filter=nearest or RGBA16F"; return false; }
        inputs.push_back({&in, t});
    }
    VkPipeline pipe = pipeline(prog, out, blend, error);
    if (!pipe) return false;
    VkFramebuffer fb = framebuffer(out, error);
    if (!fb) return false;
    VkRenderPass rp = renderPass(out->vkFormat, r.clear, error);
    if (!rp) return false;

    Slot* slot = acquireSlot(error);
    if (!slot) return false;

    // ---- uniform blocks: every member by name, like the GL backend binds uniforms by reflected name
    const SpirvReflection& rf = prog->refl;
    std::vector<VkDescriptorBufferInfo> bufferInfos(rf.blocks.size());
    uint32_t cursor = 0;
    const uint32_t align = (uint32_t)std::max<VkDeviceSize>(fProps.limits.minUniformBufferOffsetAlignment, 16);
    for (size_t bi = 0; bi < rf.blocks.size(); bi++) {
        const SpirvBlock& b = rf.blocks[bi];
        cursor = (cursor + align - 1) / align * align;
        if (cursor + b.size > kSlotUboBytes) { *error = "the uniform blocks do not fit the 64 KB slot"; return false; }
        uint8_t* dst = slot->uboMap + cursor;
        std::memset(dst, 0, b.size);
        for (const SpirvMember& m : b.members) {
            if (m.cols > 1) { *error = "uniform '" + m.name + "' is a matrix: matrices are not supported (use vectors)"; return false; }
            const int comps = (int)m.rows;
            std::vector<float> value;
            bool automatic = true;
            int want = comps;
            if (m.name == "size") value = {(float)r.areaWidth, (float)r.areaHeight};
            else if (m.name == "out_px") value = {(float)out->width, (float)out->height};
            else if (m.name == "time") value = {(float)r.timeSeconds};
            else if (m.name == "frame") value = {(float)r.frame};
            else {
                automatic = false;
                const size_t us = m.name.size();
                if (us > 3 && m.name.compare(us - 3, 3, "_px") == 0) {
                    const std::string base = m.name.substr(0, us - 3);
                    for (const auto& in : inputs) if (in.first->name && *in.first->name == base) { automatic = true; value = {(float)in.second->width, (float)in.second->height}; }
                }
                if (!automatic) {
                    bool found = false;
                    for (const Constant& c : r.pass->constants) if (c.name == m.name) { value = c.value; found = true; break; }
                    if (!found && r.control && *r.control) {
                        std::vector<float> fromControl((size_t)comps * m.arrayLength, 0.0f);
                        if ((*r.control)(m.name, comps * (int)m.arrayLength, fromControl.data())) { value = std::move(fromControl); found = true; }
                    }
                    if (!found) { *error = "uniform '" + m.name + "' has no value: it is neither an automatic uniform (size, time, frame, out_px, <input>_px), a constant of pass '" + r.pass->id + "' nor an effect control"; return false; }
                    want = comps * (int)m.arrayLength;
                }
            }
            if ((int)value.size() != want && !(automatic && (m.name == "time" || m.name == "frame"))) {
                *error = "uniform '" + m.name + "' needs " + std::to_string(want) + " values but " + std::to_string(value.size()) + " were given";
                return false;
            }
            if (automatic && comps != (int)value.size()) { *error = "automatic uniform '" + m.name + "' must be " + (value.size() == 2 ? "vec2" : "float") + ", the shader declares " + std::to_string(comps) + " components"; return false; }
            const uint32_t stride = m.arrayStride ? m.arrayStride : (uint32_t)comps * 4;
            for (uint32_t e = 0; e < m.arrayLength; e++) for (int c = 0; c < comps; c++) {
                const size_t at = m.offset + (size_t)e * stride + (size_t)c * 4;
                if (at + 4 > b.size) { *error = "uniform '" + m.name + "' does not fit its block"; return false; }
                const size_t vi = (size_t)e * comps + c;
                const float v = vi < value.size() ? value[vi] : 0.0f;
                if (m.base == SpirvMember::Float) std::memcpy(dst + at, &v, 4);
                else if (m.base == SpirvMember::UInt) { const uint32_t u = (uint32_t)std::lround(v); std::memcpy(dst + at, &u, 4); }
                else { const int32_t i = (int32_t)std::lround(v); std::memcpy(dst + at, &i, 4); }     // int and bool
            }
        }
        bufferInfos[bi] = {slot->ubo, cursor, b.size};
        cursor += b.size;
    }

    // ---- samplers: each sampler2D takes the input of the same name
    std::vector<VkDescriptorImageInfo> imageInfos(rf.samplers.size());
    for (size_t si = 0; si < rf.samplers.size(); si++) {
        const SpirvSampler& s = rf.samplers[si];
        const std::pair<const BoundInput*, VkTarget*>* use = nullptr;
        for (const auto& in : inputs) if (in.first->name && *in.first->name == s.name) use = &in;
        if (!use) {
            std::string have;
            for (const auto& in : inputs) have += (have.empty() ? "" : ", ") + (in.first->name ? *in.first->name : std::string("?"));
            *error = "sampler2D '" + s.name + "' has no input of that name (inputs: " + (have.empty() ? "none" : have) + ")";
            return false;
        }
        VkSampler smp = sampler(use->first->filter, use->first->wrap, error);
        if (!smp) return false;
        imageInfos[si] = {smp, use->second->view, VK_IMAGE_LAYOUT_GENERAL};
    }

    VkDescriptorSetAllocateInfo dsa = {VK_STRUCTURE_TYPE_DESCRIPTOR_SET_ALLOCATE_INFO};
    dsa.descriptorPool = slot->pool; dsa.descriptorSetCount = 1; dsa.pSetLayouts = &prog->dsl;
    VkDescriptorSet set = VK_NULL_HANDLE;
    if (vkAllocateDescriptorSets(fDev, &dsa, &set) != VK_SUCCESS) { *error = "vkAllocateDescriptorSets failed"; return false; }
    std::vector<VkWriteDescriptorSet> writes;
    for (size_t bi = 0; bi < rf.blocks.size(); bi++) {
        VkWriteDescriptorSet w = {VK_STRUCTURE_TYPE_WRITE_DESCRIPTOR_SET};
        w.dstSet = set; w.dstBinding = rf.blocks[bi].binding; w.descriptorCount = 1; w.descriptorType = VK_DESCRIPTOR_TYPE_UNIFORM_BUFFER; w.pBufferInfo = &bufferInfos[bi];
        writes.push_back(w);
    }
    for (size_t si = 0; si < rf.samplers.size(); si++) {
        VkWriteDescriptorSet w = {VK_STRUCTURE_TYPE_WRITE_DESCRIPTOR_SET};
        w.dstSet = set; w.dstBinding = rf.samplers[si].binding; w.descriptorCount = 1; w.descriptorType = VK_DESCRIPTOR_TYPE_COMBINED_IMAGE_SAMPLER; w.pImageInfo = &imageInfos[si];
        writes.push_back(w);
    }
    if (!writes.empty()) vkUpdateDescriptorSets(fDev, (uint32_t)writes.size(), writes.data(), 0, nullptr);

    if (!beginSlot(slot, error)) return false;
    VkCommandBuffer cmd = slot->cmd;
    // One barrier per image: the queue-family acquire when another API (or the first use) owns it, and the dependency on this queue's own
    // earlier passes. Layout is GENERAL for every image (Skia hands its images back in GENERAL too).
    std::vector<VkImageMemoryBarrier> barriers;
    VkPipelineStageFlags srcStages = 0, dstStages = 0;
    auto addBarrier = [&](VkTarget* t, bool isOutput) {
        VkImageMemoryBarrier b = {VK_STRUCTURE_TYPE_IMAGE_MEMORY_BARRIER};
        const bool foreign = t->needsAcquire && t->ahb;
        b.srcQueueFamilyIndex = foreign ? fForeign : VK_QUEUE_FAMILY_IGNORED;
        b.dstQueueFamilyIndex = foreign ? fFamily : VK_QUEUE_FAMILY_IGNORED;
        b.oldLayout = t->layoutInit ? VK_IMAGE_LAYOUT_GENERAL : VK_IMAGE_LAYOUT_UNDEFINED;
        b.newLayout = VK_IMAGE_LAYOUT_GENERAL;
        b.image = t->image; b.subresourceRange = {VK_IMAGE_ASPECT_COLOR_BIT, 0, 1, 0, 1};
        b.srcAccessMask = t->needsAcquire ? 0 : (VK_ACCESS_COLOR_ATTACHMENT_WRITE_BIT | VK_ACCESS_SHADER_READ_BIT);
        b.dstAccessMask = isOutput ? (VK_ACCESS_COLOR_ATTACHMENT_READ_BIT | VK_ACCESS_COLOR_ATTACHMENT_WRITE_BIT) : VK_ACCESS_SHADER_READ_BIT;
        srcStages |= t->needsAcquire ? VK_PIPELINE_STAGE_TOP_OF_PIPE_BIT : (VK_PIPELINE_STAGE_COLOR_ATTACHMENT_OUTPUT_BIT | VK_PIPELINE_STAGE_FRAGMENT_SHADER_BIT);
        dstStages |= isOutput ? (VK_PIPELINE_STAGE_COLOR_ATTACHMENT_OUTPUT_BIT | VK_PIPELINE_STAGE_FRAGMENT_SHADER_BIT) : VK_PIPELINE_STAGE_FRAGMENT_SHADER_BIT;
        barriers.push_back(b);
    };
    addBarrier(out, true);
    for (const auto& in : inputs) addBarrier(in.second, false);
    vkCmdPipelineBarrier(cmd, srcStages, dstStages, 0, 0, nullptr, 0, nullptr, (uint32_t)barriers.size(), barriers.data());

    VkClearValue clear = {};
    VkRenderPassBeginInfo rb = {VK_STRUCTURE_TYPE_RENDER_PASS_BEGIN_INFO};
    rb.renderPass = rp; rb.framebuffer = fb; rb.renderArea = {{0, 0}, {(uint32_t)out->width, (uint32_t)out->height}};
    rb.clearValueCount = 1; rb.pClearValues = &clear;
    vkCmdBeginRenderPass(cmd, &rb, VK_SUBPASS_CONTENTS_INLINE);
    vkCmdBindPipeline(cmd, VK_PIPELINE_BIND_POINT_GRAPHICS, pipe);
    VkViewport viewport = {0.0f, 0.0f, (float)out->width, (float)out->height, 0.0f, 1.0f};
    VkRect2D scissor = {{0, 0}, {(uint32_t)out->width, (uint32_t)out->height}};
    vkCmdSetViewport(cmd, 0, 1, &viewport);
    vkCmdSetScissor(cmd, 0, 1, &scissor);
    vkCmdBindDescriptorSets(cmd, VK_PIPELINE_BIND_POINT_GRAPHICS, prog->layout, 0, 1, &set, 0, nullptr);
    vkCmdDraw(cmd, 3, 1, 0, 0);
    vkCmdEndRenderPass(cmd);

    if (!submit(slot, VK_NULL_HANDLE, true, error)) return false;
    out->needsAcquire = false; out->layoutInit = true;
    for (const auto& in : inputs) { in.second->needsAcquire = false; in.second->layoutInit = true; }
    return true;
}

// ================================================================== hand-off
bool VkBackend::release(Target* t, Backend& to, std::string* error) {
    std::lock_guard<std::recursive_mutex> lock(fLock);
    VkTarget* vt = live(t);
    if (!vt) { *error = "vulkan: no target to hand over"; return false; }
    if (!vt->ahb) { *error = std::string("vulkan: a ") + ToString(vt->format) + " target has private storage and cannot be handed to another backend"; return false; }
    Slot* s = acquireSlot(error);
    if (!s || !beginSlot(s, error)) return false;
    VkImageMemoryBarrier b = {VK_STRUCTURE_TYPE_IMAGE_MEMORY_BARRIER};
    b.srcQueueFamilyIndex = fFamily; b.dstQueueFamilyIndex = fForeign;
    b.oldLayout = vt->layoutInit ? VK_IMAGE_LAYOUT_GENERAL : VK_IMAGE_LAYOUT_UNDEFINED; b.newLayout = VK_IMAGE_LAYOUT_GENERAL;
    b.image = vt->image; b.subresourceRange = {VK_IMAGE_ASPECT_COLOR_BIT, 0, 1, 0, 1};
    b.srcAccessMask = VK_ACCESS_COLOR_ATTACHMENT_WRITE_BIT | VK_ACCESS_SHADER_READ_BIT; b.dstAccessMask = 0;
    vkCmdPipelineBarrier(s->cmd, VK_PIPELINE_STAGE_COLOR_ATTACHMENT_OUTPUT_BIT | VK_PIPELINE_STAGE_FRAGMENT_SHADER_BIT, VK_PIPELINE_STAGE_BOTTOM_OF_PIPE_BIT, 0, 0, nullptr, 0, nullptr, 1, &b);
    const bool wantFd = fFences && fCanExport;
    VkSemaphore signal = wantFd ? makeSemaphore(true) : VK_NULL_HANDLE;
    if (!submit(s, signal, true, error)) return false;
    vt->layoutInit = true;
    vt->needsAcquire = true;
    if (signal) {
        int fd = -1;
        VkSemaphoreGetFdInfoKHR gi = {VK_STRUCTURE_TYPE_SEMAPHORE_GET_FD_INFO_KHR};
        gi.semaphore = signal; gi.handleType = VK_EXTERNAL_SEMAPHORE_HANDLE_TYPE_SYNC_FD_BIT;
        if (fGetSemaphoreFd(fDev, &gi, &fd) == VK_SUCCESS) {
            FenceCounters().vkExported++;
            return to.waitForeign(fd, error);          // fd < 0 = already finished
        }
    }
    // No fence (switch off, or the driver cannot export one): the CPU waits for the GPU, as the GL backend does with glFinish.
    FenceCounters().vkExportFallback++;
    const VkResult fw = vkWaitForFences(fDev, 1, &s->fence, VK_TRUE, 5000000000ull);
    if (fw == VK_ERROR_DEVICE_LOST) fLost = true;
    if (fw != VK_SUCCESS) { *error = fw == VK_ERROR_DEVICE_LOST ? "the GPU device was lost during the Vulkan pass" : "the GPU did not finish the Vulkan pass within 5 s"; return false; }
    reap();
    return true;
}

Target* VkBackend::acquire(Backend& from, Target* t, bool forWrite, std::string* error) {
    (void)forWrite;
    std::lock_guard<std::recursive_mutex> lock(fLock);
    if (!fAhb) { *error = "this Vulkan device cannot import hardware buffers"; return nullptr; }
    AHardwareBuffer* buffer = t ? t->hardwareBuffer() : nullptr;
    if (!buffer) { *error = std::string("vulkan: the target from backend ") + from.name() + " has no hardware buffer behind it"; return nullptr; }
    auto it = fViews.find(buffer);
    if (it != fViews.end()) {
        VkTarget* vt = it->second;
        vt->users++; vt->used = ++fClock; vt->needsAcquire = true;
        return vt;
    }
    VkTarget* vt = makeTarget(t->width > 0 ? t->width : 1, t->height > 0 ? t->height : 1, t->format == Format::RGBA16F ? Format::RGBA16F : Format::RGBA8, buffer, true, error);
    if (!vt) return nullptr;
    vt->users = 1; vt->used = ++fClock; vt->needsAcquire = true;
    fViews[buffer] = vt;
    trimViews();
    return vt;
}

bool VkBackend::waitForeign(int fd, std::string* error) {
    if (fd < 0) return true;
    std::lock_guard<std::recursive_mutex> lock(fLock);
    if (fCanImport && fOk && !fLost) {
        VkSemaphore sem = makeSemaphore(false);
        if (sem) {
            VkImportSemaphoreFdInfoKHR info = {VK_STRUCTURE_TYPE_IMPORT_SEMAPHORE_FD_INFO_KHR};
            info.semaphore = sem; info.flags = VK_SEMAPHORE_IMPORT_TEMPORARY_BIT; info.handleType = VK_EXTERNAL_SEMAPHORE_HANDLE_TYPE_SYNC_FD_BIT; info.fd = fd;
            if (fImportSemaphoreFd(fDev, &info) == VK_SUCCESS) {      // Vulkan owns the fd now
                fPending.push_back(sem);
                FenceCounters().vkGpuWaits++;
                return true;
            }
            vkDestroySemaphore(fDev, sem, nullptr);                   // the fd is still ours
        }
    }
    FenceCounters().vkCpuWaits++;
    return Backend::waitForeign(fd, error);
}

// ================================================================== factory
namespace {
VkBackend* gBackend = nullptr;
std::once_flag gOnce;
std::string gWhy;
}  // namespace

Backend* SharedVulkanBackend(std::string* why) {
    std::call_once(gOnce, [] {
        std::string w;
        gBackend = VkBackend::Create(&w);
        gWhy = gBackend ? std::string() : w;
    });
    if (!gBackend) *why = gWhy;
    return gBackend;
}

void VulkanBackendSetFences(Backend* backend, bool on) { if (backend && backend == gBackend) gBackend->setFences(on); }

std::string VulkanBackendDescribe() { return gBackend ? gBackend->describe() : std::string(); }

#endif  // AM_VK_BACKEND

}  // namespace am::rg

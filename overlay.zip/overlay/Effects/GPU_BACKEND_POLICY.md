# Automatic GPU backend policy

The user-facing Auto/OpenGL selector has been removed. The editor now always
uses the existing adaptive backend selection and validation path.

At startup, `GpuCheck.startOrder` considers prior crash/correctness results and
the Vulkan device risk check. The engine tries the preferred backend, falls
back to the other backend if initialization fails, then runs the rendered
check-picture validation and switches if the image is wrong.

This intentionally does NOT hard-code OpenGL or Vulkan as universally faster.
The best backend depends on the Android GPU driver and device. The app keeps
both implementations available and automatically selects the backend that
starts and renders correctly on that device.

The old `graphicsOpenGl` preference is ignored by engine startup. The graphics
selector and its restart observer are removed so users cannot accidentally
force a backend that is unstable on their phone.

No shader languages, effect libraries, project formats, export settings, or
GPU rendering implementations are removed.

package com.effects.motion.effects

import com.effects.motion.engine.bitdepth.BitDepth
import java.util.Locale

/** Where an effect comes from. Effects Motion = the app's own library, the other two are imported. */
object EffectSources {
    const val Native = "em"
    const val AfterEffects = "ae"
    const val AlightMotion = "am"
    val all: List<Pair<String, String>> = listOf(
        Native to "Effects Motion", AfterEffects to "After Effects", AlightMotion to "Alight Motion",
    )

    fun label(source: String): String = all.firstOrNull { it.first == source }?.second ?: source
}

/** Quality the user picks on import. Each tier is stored in the matching pack of the Default menu. */
enum class ImportTier(val pack: String, val depth: BitDepth, val label: String) {
    RAYTRACED(EffectPacks.RayTraced, BitDepth.BIT32, "RayTraced [32]"),
    VIBRANT(EffectPacks.Vibrant, BitDepth.BIT16, "Vibrant [16]"),
    DEFAULT(EffectPacks.Default, BitDepth.BIT8, "Default [8]");

    companion object {
        fun named(name: String?): ImportTier = values().firstOrNull { it.name == name } ?: DEFAULT
    }
}

/** Categories of the After Effects library (your own list, edit freely). */
val AeCategories: Map<String, String> = linkedMapOf(
    "ae_blur" to "Blur & Sharpen", "ae_color" to "Color Correction", "ae_distort" to "Distort",
    "ae_generate" to "Generate", "ae_keying" to "Keying", "ae_noise" to "Noise & Grain",
    "ae_perspective" to "Perspective", "ae_stylize" to "Stylize", "ae_time" to "Time",
    "ae_transition" to "Transition", "ae_utility" to "Utility", "ae_other" to "Imported",
)

fun importedCategoryLabel(key: String): String =
    AeCategories[key] ?: EffectCatalog.Categories[key]
        ?: key.replace('_', ' ').replaceFirstChar { it.titlecase(Locale.ROOT) }

/** Maps an Alight Motion category name to an After Effects library category. */
fun aeCategoryFor(amCategory: String): String = when (amCategory.lowercase()) {
    "blur" -> "ae_blur"
    "color" -> "ae_color"
    "distort" -> "ae_distort"
    "stylize" -> "ae_stylize"
    "noise" -> "ae_noise"
    "key" -> "ae_keying"
    "3d" -> "ae_perspective"
    "move", "repeat" -> "ae_distort"
    else -> "ae_other"
}

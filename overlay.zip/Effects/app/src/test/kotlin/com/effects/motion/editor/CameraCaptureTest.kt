package com.effects.motion.editor

import androidx.camera.core.AspectRatio
import com.effects.motion.model.MediaDeclaration
import com.effects.motion.model.Scene
import com.effects.motion.model.XmlNode
import com.effects.motion.ui.camera.cameraBlocked
import com.effects.motion.ui.camera.cameraRatio
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class CameraCaptureTest {
    private fun media(width: Int, height: Int, orientation: Int, type: String, duration: Long = -1) = MediaDeclaration(XmlNode("media", mapOf(
        "uri" to "content://media/external/1", "title" to "capture", "type" to type, "width" to "$width", "height" to "$height",
        "orientation" to "$orientation", "duration" to "$duration",
    )))

    @Test fun theSensorShapeThatCropsLeastIsChosen() {
        assertEquals(AspectRatio.RATIO_16_9, cameraRatio(9f / 16f, portrait = true))
        assertEquals(AspectRatio.RATIO_16_9, cameraRatio(16f / 9f, portrait = false))
        assertEquals(AspectRatio.RATIO_4_3, cameraRatio(1f, portrait = true))
        assertEquals(AspectRatio.RATIO_4_3, cameraRatio(4f / 5f, portrait = true))
        assertEquals(AspectRatio.RATIO_4_3, cameraRatio(9f / 16f, portrait = false))
    }

    @Test fun newClipsCoverTheirLengthWithoutAnExtraFrame() {
        for (fps in listOf(24, 25, 30, 60)) {
            val s = Scene.create("t", 100, 100, fps, 0)
            for (frame in listOf(0, 7, 15)) assertEquals(frame + 2 * fps - 1, s.lastShownFrame(s.endTimeFor(frame, 2000)))
        }
        val thirty = Scene.create("Clip", 1080, 1080, 30, 0)
        val clip = thirty.videoLayer(media(1920, 1080, 0, "video/mp4", 1_000_000), 15)!!
        assertEquals(500 to 1499, clip.startTime to clip.endTime)
        assertEquals(15, thirty.lastShownFrame(thirty.endTimeFor(15, 0)))
    }

    @Test fun onlyARefusalAfterAnEarlierOneSendsToSettings() {
        assertFalse(cameraBlocked(granted = false, rationale = false, refusedBefore = false))
        assertFalse(cameraBlocked(granted = false, rationale = true, refusedBefore = false))
        assertFalse(cameraBlocked(granted = false, rationale = true, refusedBefore = true))
        assertTrue(cameraBlocked(granted = false, rationale = false, refusedBefore = true))
        assertFalse(cameraBlocked(granted = true, rationale = false, refusedBefore = true))
    }
}

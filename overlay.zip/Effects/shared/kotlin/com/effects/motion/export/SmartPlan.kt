package com.effects.motion.export

/**
 * Smart Export planning: which frames of a video export are copied from an earlier export and which are drawn again.
 *
 * Pure logic (no Android, no engine), so it is unit tested on the host (SmartPlanTest).
 *
 * A finished export is kept as closed groups of pictures ([CachedGop]). Each starts at a key frame and holds the encoded packets of
 * frames [CachedGop.first] until [CachedGop.end]. A reused packet is copied byte for byte, so a reused frame is identical to the one of
 * the earlier export: no new encode, no generation loss. Every other frame is drawn and encoded again with the same settings.
 *
 * A cached group is reused only when none of its frames is dirty and it lies completely inside the new video.
 *
 * History (temporal) effects: a frame inside such a span is only right when every earlier frame of the span was drawn, in order
 * (render_graph.cpp, Executor::render: any jump resets the history). So a dirty frame inside a span dirties the rest of the span, and a
 * drawn run that starts inside a span first draws the span from its first frame. Those frames are [FrameAction.Warm]: drawn and encoded,
 * and their packets are dropped (the cached packets are used instead when the frame belongs to a reused group).
 */
internal class CachedGop(val first: Int, val count: Int, val offset: Long, val length: Int, val crc: Long) {
    val end: Int get() = first + count
}

/** What happens to one frame of the new export. */
internal object FrameAction {
    /** Not drawn: its packets come from the earlier export. */
    const val Skip: Byte = 0
    /** Drawn and encoded only so the history of a temporal effect is exact; the packets are dropped and the cached ones are used. */
    const val Warm: Byte = 1
    /** Drawn, encoded, and the packets are written to the file. */
    const val Keep: Byte = 2
}

internal class SmartPlan(
    val frames: Int,
    val actions: ByteArray,
    /** Groups taken from the earlier export, in timeline order. */
    val reused: List<CachedGop>,
) {
    val drawn: Int = actions.count { it != FrameAction.Skip }
    val skipped: Int = frames - drawn
    val reusedFrames: Int = reused.sumOf { it.count }

    /** True when the encoder must start a new group here: a kept frame whose predecessor in the encoder was not kept (or the first frame). */
    fun startsRun(k: Int): Boolean = actions[k] == FrameAction.Keep && (k == 0 || actions[k - 1] != FrameAction.Keep)

    /** The frames the encoder receives, in order (everything that is drawn). */
    fun drawnFrames(): IntArray = IntArray(drawn).also { out ->
        var i = 0
        for (k in 0 until frames) if (actions[k] != FrameAction.Skip) out[i++] = k
    }
}

/** Dirty frames as a boolean per frame: a dirty frame inside a temporal span dirties every later frame of that span (its history changed). */
internal fun dirtyFrames(frames: Int, dirty: List<IntRange>, temporal: List<IntRange>): BooleanArray {
    val out = BooleanArray(frames)
    for (r in dirty) for (k in maxOf(r.first, 0)..minOf(r.last, frames - 1)) out[k] = true
    for (span in temporal) {
        val from = maxOf(span.first, 0)
        val to = minOf(span.last, frames - 1)
        val first = (from..to).firstOrNull { out[it] } ?: continue
        for (k in first..to) out[k] = true
    }
    return out
}

/**
 * Builds the plan, or returns null when reuse is not worth it or cannot be made safe (the caller then renders everything, as before).
 *
 * @param cached        groups of the earlier export (must not overlap)
 * @param dirty         frames whose picture may differ from the earlier export
 * @param temporal      frame spans (inclusive) in which a history effect is drawn
 * @param minSkipped    share of frames that must not need drawing at all; below it a normal render is as fast and simpler
 * @param maxRuns       separate kept runs; every run restarts the encoder's group
 */
internal fun planSmartExport(
    frames: Int, cached: List<CachedGop>, dirty: List<IntRange>, temporal: List<IntRange>,
    minSkipped: Double = 0.15, maxRuns: Int = 32,
): SmartPlan? {
    if (frames <= 0 || cached.isEmpty()) return null
    val bad = dirtyFrames(frames, dirty, temporal)
    val sorted = cached.sortedBy { it.first }
    for (i in 1 until sorted.size) if (sorted[i].first < sorted[i - 1].end) return null      // overlapping groups: the index cannot be trusted
    val chosen = ArrayList<CachedGop>()
    for (g in sorted) {
        if (g.count <= 0 || g.first < 0 || g.end > frames) continue
        if ((g.first until g.end).any { bad[it] }) continue
        chosen += g
    }
    // The first frames are always drawn: the first encoder session is what creates the file's video track (and shows the stream format,
    // which is compared with the earlier export) before any copied packet is written. That also guarantees at least one kept frame.
    if (chosen.isNotEmpty() && chosen[0].first == 0) chosen.removeAt(0)
    if (chosen.isEmpty()) return null

    val reuse = BooleanArray(frames)
    for (g in chosen) for (k in g.first until g.end) reuse[k] = true
    val actions = ByteArray(frames) { if (reuse[it]) FrameAction.Skip else FrameAction.Keep }
    for (span in temporal) {
        val from = maxOf(span.first, 0)
        val to = minOf(span.last, frames - 1)
        if (from > to) continue
        val firstKept = (from..to).firstOrNull { actions[it] == FrameAction.Keep } ?: continue
        for (k in from until firstKept) actions[k] = FrameAction.Warm
        // After the first kept frame of a span nothing can be reused (dirtyFrames made it all dirty). If it happens the plan is unsafe.
        for (k in firstKept..to) if (reuse[k]) return null
    }
    val plan = SmartPlan(frames, actions, chosen)
    if (plan.skipped.toDouble() / frames < minSkipped) return null
    if (actions.none { it == FrameAction.Keep }) return null
    if ((0 until frames).count { plan.startsRun(it) } > maxRuns) return null
    return plan
}

/**
 * Converts a frame range of the scene (counted at [sceneFps]) to frames of an export at [fps]. With equal rates it is the same range.
 * Otherwise it is the export frames whose time falls inside it, widened by one frame on each side.
 */
internal fun toExportFrames(range: IntRange, sceneFps: Int, fps: Int, frames: Int): IntRange {
    if (fps == sceneFps) return maxOf(range.first, 0)..minOf(range.last, frames - 1)
    val startMs = range.first * 1000L / sceneFps
    val endMs = (range.last + 1) * 1000L / sceneFps
    val from = (startMs * fps / 1000).toInt() - 1
    val to = ((endMs * fps + 999) / 1000).toInt() + 1
    return maxOf(from, 0)..minOf(to, frames - 1)
}

package com.effects.motion.ui.editor.panels

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import com.effects.motion.ui.editor.DeskTip
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.selection.toggleable
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.roundToInt
import com.effects.motion.R
import com.effects.motion.editor.EditorState
import com.effects.motion.editor.KeypadField
import com.effects.motion.editor.KeypadRequest
import com.effects.motion.editor.LayerPoints
import com.effects.motion.effects.EffectDefinition
import com.effects.motion.effects.EffectParam
import com.effects.motion.model.Layer
import com.effects.motion.model.MAX_PINS
import com.effects.motion.model.Pt
import com.effects.motion.model.Scene
import com.effects.motion.model.PuppetBend
import com.effects.motion.model.PuppetPin
import com.effects.motion.model.XmlNode
import com.effects.motion.model.effectProperty
import com.effects.motion.model.effects
import com.effects.motion.model.finiteFloat
import com.effects.motion.model.formatFloats
import com.effects.motion.model.puppetFalloff
import com.effects.motion.model.allPuppetPins
import com.effects.motion.model.puppetPins
import com.effects.motion.model.renderPuppetPins
import com.effects.motion.model.puppetOffset
import com.effects.motion.model.puppetNumber
import com.effects.motion.model.puppetMeshSource
import com.effects.motion.model.withPuppetPin
import com.effects.motion.model.valueAt
import com.effects.motion.model.withEffect
import com.effects.motion.model.withEffectProperty
import com.effects.motion.model.withoutPuppetPin
import com.effects.motion.ui.editor.ChromeIcons
import com.effects.motion.ui.editor.PanelIcons
import com.effects.motion.ui.theme.Am

internal const val TEXT_PATH_ID = "absent.textpath"
internal const val PUPPET_ID = "absent.puppet"

private fun XmlNode.point(param: EffectParam, t: Float): Pt =
    (effectProperty(param.id)?.valueAt(t) ?: param.missingDefault).split(',').map { it.trim().finiteFloat() ?: 0f }.let { Pt(it.getOrElse(0) { 0f }, it.getOrElse(1) { 0f }) }

private fun XmlNode.number(param: EffectParam, t: Float): Float = (effectProperty(param.id)?.valueAt(t) ?: param.missingDefault).finiteFloat() ?: 0f

internal fun arcGuide(a: Pt, b: Pt, c: Pt, d: Pt, steps: Int = 48): List<Pt> = List(steps + 1) { i ->
    val t = i.toFloat() / steps
    val u = 1 - t
    Pt(u * u * u * a.x + 3 * u * u * t * b.x + 3 * u * t * t * c.x + t * t * t * d.x, u * u * u * a.y + 3 * u * u * t * b.y + 3 * u * t * t * c.y + t * t * t * d.y)
}

internal fun circleGuide(c: Pt, r: Float, steps: Int = 72): List<Pt> = List(steps + 1) { i ->
    val angle = 2 * Math.PI * i / steps
    Pt(c.x + r * kotlin.math.cos(angle).toFloat(), c.y + r * kotlin.math.sin(angle).toFloat())
}

internal fun textPathPoints(state: EditorState, layer: Layer, index: Int, instance: XmlNode, definition: EffectDefinition, active: EffectParam?, select: (EffectParam) -> Unit): LayerPoints? {
    fun param(id: String) = definition.params.firstOrNull { it.id == id }
    fun setPoint(p: EffectParam, to: Pt) = state.editSelected("effect-$index-${p.id}") { current ->
        current.withEffect(index) { it.withEffectProperty(p.id, p.type, formatFloats(floatArrayOf(to.x.coerceIn(p.min, p.max), to.y.coerceIn(p.min, p.max))), current.t, current.snap) }
    }
    val arc = listOf("start", "control1", "control2", "end").mapNotNull(::param).filter { definition.shown(it, instance, layer.t) }
    if (arc.size == 4) {
        val (a, b, c, d) = arc.map { instance.point(it, layer.t) }
        return LayerPoints(listOf(a, b, c, d), arc.indexOf(active), lines = listOf(0 to 1, 3 to 2), guide = arcGuide(a, b, c, d), pick = { select(arc[it]) }) { i, to -> setPoint(arc[i], to) }
    }
    val center = param("center")?.takeIf { definition.shown(it, instance, layer.t) } ?: return null
    val radius = param("radius") ?: return null
    val c = instance.point(center, layer.t)
    val r = kotlin.math.abs(instance.number(radius, layer.t))
    val chosen = when (active) { center -> 0; radius -> 1; else -> -1 }
    return LayerPoints(listOf(c, Pt(c.x, c.y - r)), chosen, lines = listOf(0 to 1), guide = circleGuide(c, r), pick = { select(if (it == 0) center else radius) }) { i, to ->
        if (i == 0) setPoint(center, to)
        else state.editSelected("effect-$index-radius") { current ->
            val now = current.effects.getOrNull(index)?.point(center, current.t) ?: c
            val value = to.distanceTo(now).coerceIn(radius.min, radius.max)
            current.withEffect(index) { it.withEffectProperty(radius.id, radius.type, formatFloats(floatArrayOf(value)), current.t, current.snap) }
        }
    }
}

internal fun Scene.missesPathBelow(layer: Layer, instance: XmlNode): Boolean {
    if ((instance.effectProperty("shape")?.valueAt(layer.t)?.finiteFloat() ?: 0f).roundToInt() != 2) return false
    val list = layers
    val index = list.indexOfFirst { it.id == layer.id }
    if (index < 0) return false
    val pinned = layer.node["pathLayer"]?.toLongOrNull()?.takeIf { it != layer.id }?.let { id -> list.firstOrNull { it.id == id } }
    val below = pinned ?: list.getOrNull(index - 1)
    return below == null || below.kind in setOf("nullobj", "camera", "audio")
}

@Composable
internal fun TextPathHint(state: EditorState, layer: Layer, instance: XmlNode) {
    if (!state.scene.missesPathBelow(layer, instance)) return
    Text(stringResource(R.string.textpath_nothing_below), Modifier.padding(horizontal = 10.dp, vertical = 4.dp), color = Am.Caption, fontSize = 12.sp, lineHeight = 15.sp)
}

private fun EditorState.movePin(index: Int, pin: PuppetPin, to: Pt, key: Any?) = editSelected(key) { current ->
    current.withEffect(index) { it.withEffectProperty(pin.name, "vec2", formatFloats(floatArrayOf(to.x, to.y)), current.t, current.snap) }
}

internal fun puppetPoints(state: EditorState, layer: Layer, index: Int, instance: XmlNode, pin: String?, adding: Boolean, onPin: (String?) -> Unit,
                          onFull: () -> Unit): LayerPoints {
    val t = layer.at(state.timeMs, state.scene.fps).t
    val pins = instance.renderPuppetPins(t, state.timeMs)
    val mesh = instance.puppetNumber("density", t, 0f, 0f, 48f) > 0 || instance.puppetNumber("expansion", t, 0f, 0f, 500f) > 0 || pins.any { it.mode != 0 }
    val source: (Pt) -> Pt = if (mesh) { at -> puppetMeshSource(pins, instance.puppetFalloff(t), at) }
        else PuppetBend(pins, instance.puppetFalloff(t))::source
    val add: ((Pt) -> Unit)? = if (!adding) null else { at ->
        if (instance.allPuppetPins(layer.t).size >= MAX_PINS) onFull()
        else {
            var made: String? = null
            val rest = source(at)
            state.editSelected { current ->
                current.withEffect(index) { effect ->
                    val added = effect.withPuppetPin(at, rest)
                    val p = added.puppetPins(current.t).last()
                    made = p.name
                    val base = at - added.puppetOffset(p, t, state.timeMs)
                    added.withEffectProperty(p.name, "vec2", formatFloats(floatArrayOf(base.x, base.y)), current.t, current.snap)
                }
            }
            onPin(made)
        }
    }
    return LayerPoints(pins.map { it.at }, pins.indexOfFirst { it.name == pin }, pick = { onPin(pins[it].name) }, tap = add, source = source) { i, to ->
        pins.getOrNull(i)?.takeIf { it.mode != 2 }?.let { p ->
            val offset = instance.puppetOffset(p, t, state.timeMs)
            state.movePin(index, p, to - offset, "puppet-$index-${p.name}")
        }
    }
}

@Composable
internal fun PuppetSection(state: EditorState, layer: Layer, index: Int, instance: XmlNode, pin: String?, field: String, onField: (String) -> Unit, adding: Boolean, onPin: (String?) -> Unit, onAdding: (Boolean) -> Unit) {
    val all = instance.allPuppetPins(layer.t)
    val pins = all.take(MAX_PINS)
    Row(Modifier.fillMaxWidth().height(56.dp).padding(horizontal = 6.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.weight(1f).fillMaxHeight().clip(PanelShape).background(if (adding) PanelDark else Am.Button).toggleable(adding, role = Role.Switch, onValueChange = onAdding), contentAlignment = Alignment.Center) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                PanelIcon(PanelIcons.Pin, if (adding) Am.Accent else Am.OnDark, size = 18.dp)
                Spacer(Modifier.width(6.dp))
                Text(stringResource(R.string.puppet_add_pins), color = if (adding) Am.Accent else Am.OnDark, fontSize = 13.sp, maxLines = 1)
            }
        }
    }
    if (pins.isEmpty() || adding) Text(stringResource(R.string.puppet_pins_hint), Modifier.padding(horizontal = 10.dp, vertical = 4.dp), color = Am.Caption, fontSize = 12.sp, lineHeight = 15.sp)
    if (all.size > MAX_PINS) Text(stringResource(R.string.puppet_pins_full, "$MAX_PINS"), Modifier.padding(horizontal = 10.dp, vertical = 4.dp), color = Am.Caption, fontSize = 12.sp, lineHeight = 15.sp)
    for (p in pins) {
        val chosen = p.name == pin
        fun keypad(which: Int) {
            onPin(p.name)
            state.keypad = KeypadRequest(listOf(KeypadField("X", p.at.x), KeypadField("Y", p.at.y)), which) { v -> state.movePin(index, p, Pt(v[0], v[1]), null) }
        }
        val label = stringResource(R.string.puppet_pin_name, "${p.number}")
        Row(Modifier.fillMaxWidth().height(52.dp).padding(horizontal = 3.dp, vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
            PropertyLabel(label, chosen, true, Modifier.width(75.dp).fillMaxHeight()) { onPin(if (chosen) null else p.name) }
            Spacer(Modifier.width(4.dp))
            ValueBox(formatFixed(p.at.x, 1), false, chosen, Modifier.weight(1f).fillMaxHeight(), 5.5f, true) { keypad(0) }
            Spacer(Modifier.width(3.dp))
            ValueBox(formatFixed(p.at.y, 1), false, chosen, Modifier.weight(1f).fillMaxHeight(), 5.5f, true) { keypad(1) }
            Box(Modifier.size(48.dp).clickable { state.movePin(index, p, p.rest, null) }, contentAlignment = Alignment.Center) {
                DeskTip("$label, ${stringResource(R.string.puppet_reset_pin)}") { Icon(ChromeIcons.Undo, "$label, ${stringResource(R.string.puppet_reset_pin)}", Modifier.size(20.dp), tint = Am.OnDark) }
            }
            Box(Modifier.size(48.dp).clickable {
                if (chosen) onPin(null)
                state.editSelected { current -> current.withEffect(index) { it.withoutPuppetPin(p.number) } }
            }, contentAlignment = Alignment.Center) {
                DeskTip("$label, ${stringResource(R.string.puppet_delete_pin)}") { Icon(ChromeIcons.Trash, "$label, ${stringResource(R.string.puppet_delete_pin)}", Modifier.size(20.dp), tint = Am.OnDark) }
            }
        }
        if (chosen) {
            val modes = listOf(stringResource(R.string.puppet_position), stringResource(R.string.puppet_bend), stringResource(R.string.puppet_stiff))
            Row(Modifier.fillMaxWidth().height(44.dp).padding(horizontal = 5.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(stringResource(R.string.puppet_mode), Modifier.width(75.dp), color = Am.OnDark, fontSize = 12.sp)
                modes.forEachIndexed { mode, label ->
                    Box(Modifier.weight(1f).fillMaxHeight().padding(2.dp).clip(PanelShape).background(if (p.mode == mode) PanelDark else Am.Button).clickable {
                        state.editSelected { current -> current.withEffect(index) {
                            it.withEffectProperty("pinMode${p.number}", "float", "$mode", current.t, current.snap)
                        } }
                        onField("position")
                    }, contentAlignment = Alignment.Center) {
                        Text(label, color = if (p.mode == mode) Am.Accent else Am.OnDark, fontSize = 12.sp)
                    }
                }
            }
            if (p.mode == 1) {
                val numbers = listOf(
                    EffectParam("pinRotation${p.number}", stringResource(R.string.puppet_rotation), "angle", "0", -3600f, 3600f, 0.1f),
                    EffectParam("pinScale${p.number}", stringResource(R.string.puppet_scale), "float", "1", 0.05f, 10f, 0.01f, percent = true),
                )
                numbers.forEachIndexed { i, param ->
                    val name = if (i == 0) "rotation" else "scale"
                    val raw = instance.effectProperty(param.id)?.valueAt(layer.t) ?: param.default
                    EffectNumbers(state, param, raw, true, field == name, { onField(name) }) { value, gesture ->
                        onField(name)
                        state.editSelected(if (gesture) "puppet-$index-${param.id}" else null) { current ->
                            current.withEffect(index) { it.withEffectProperty(param.id, "float", value, current.t, current.snap) }
                        }
                    }
                }
            }
            val swayName = "swayPin${p.number}"
            val sway = (instance.effectProperty(swayName)?.valueAt(layer.t)?.finiteFloat() ?: 0f) >= 0.5f
            Row(Modifier.fillMaxWidth().height(48.dp).toggleable(sway, role = Role.Switch) { enabled ->
                state.editSelected { current -> current.withEffect(index) {
                    it.withEffectProperty(swayName, "float", if (enabled) "1" else "0", current.t, current.snap)
                } }
            }.padding(horizontal = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(stringResource(R.string.puppet_sway_pin), color = if (sway) Am.Accent else Am.OnDark, fontSize = 13.sp)
                Spacer(Modifier.weight(1f))
                Text(stringResource(if (sway) R.string.puppet_sway_on else R.string.puppet_sway_off), color = if (sway) Am.Accent else Am.Caption, fontSize = 13.sp)
            }
        }
    }
}

@Composable
internal fun rememberPinsFull(): () -> Unit {
    val context = LocalContext.current
    val message = stringResource(R.string.puppet_pins_full, "$MAX_PINS")
    return { android.widget.Toast.makeText(context, message, android.widget.Toast.LENGTH_SHORT).show() }
}

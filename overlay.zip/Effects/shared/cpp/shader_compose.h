// shader_compose.h — builds the final GLSL ES 3.00 source: version + precision defines + shared
// header (fx_common.glsl) + the effect body. GLSL ES has no #include, so we concatenate.
// Cache compiled programs by (effectId, precision, format, manualBilinear): precision is a
// compile-time property, so each combination is its own variant.
#pragma once
#include <string>
#include "render_targets.h"

enum class ShaderPrec : int { Inherit = 0, Low = 1, Medium = 2, High = 3 };   // == ShaderPrecision.ordinal

inline ShaderPrec ResolvePrec(ShaderPrec requested, PixelFormat workingFmt) {
    if (requested != ShaderPrec::Inherit) return requested;
    return workingFmt == PixelFormat::RGBA8 ? ShaderPrec::Medium : ShaderPrec::High;  // float pipelines: keep math wide
}

inline std::string ComposeFragment(const std::string& common, const std::string& body,
                                   ShaderPrec prec, PixelFormat bufFmt, bool manualBilinear) {
    std::string s = "#version 300 es\n";                              // must be the very first line
    switch (prec) {
        case ShaderPrec::Low:    s += "#define FX_PREC lowp\n#define FX_PREC_LOW 1\n"; break;
        case ShaderPrec::Medium: s += "#define FX_PREC mediump\n"; break;
        default:                 s += "#define FX_PREC highp\n"; break;
    }
    if (bufFmt != PixelFormat::RGBA8) s += "#define FX_FLOAT_BUFFER 1\n";   // buffer holds linear, unclamped values
    if (manualBilinear)               s += "#define FX_MANUAL_BILINEAR 1\n";
    return s + common + "\n" + body;
}

// Fullscreen triangle: no vertex buffer needed. Draw with glDrawArrays(GL_TRIANGLES, 0, 3).
inline const char* FullscreenVert() {
    return "#version 300 es\n"
           "out highp vec2 v_uv;\n"
           "void main() {\n"
           "  vec2 p = vec2(float((gl_VertexID << 1) & 2), float(gl_VertexID & 2));\n"
           "  v_uv = p;\n"
           "  gl_Position = vec4(p * 2.0 - 1.0, 0.0, 1.0);\n"
           "}\n";
}

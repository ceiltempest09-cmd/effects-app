#include "spirv_reflect.h"

#include <algorithm>
#include <map>

namespace am::rg {
namespace {

enum Op : uint32_t {
    OpName = 5, OpMemberName = 6, OpTypeBool = 20, OpTypeInt = 21, OpTypeFloat = 22, OpTypeVector = 23, OpTypeMatrix = 24,
    OpTypeImage = 25, OpTypeSampler = 26, OpTypeSampledImage = 27, OpTypeArray = 28, OpTypeStruct = 30, OpTypePointer = 32,
    OpConstant = 43, OpVariable = 59, OpDecorate = 71, OpMemberDecorate = 72,
};
enum Deco : uint32_t { DBlock = 2, DBuiltIn = 11, DArrayStride = 6, DLocation = 30, DBinding = 33, DDescriptorSet = 34, DOffset = 35 };
enum Storage : uint32_t { SUniformConstant = 0, SInput = 1, SUniform = 2, SOutput = 3, SPushConstant = 9, SStorageBuffer = 12 };

struct Type {
    uint32_t op = 0;
    uint32_t a = 0, b = 0;           // scalar: a = width, b = signedness; vector/matrix/array: a = element/column type, b = count / length id
    std::vector<uint32_t> members;   // struct
    uint32_t storage = 0, pointee = 0;   // pointer
};

std::string Str(const uint32_t* p, uint32_t n) {
    std::string s;
    for (uint32_t i = 0; i < n; i++) for (int k = 0; k < 4; k++) {
        const char c = (char)((p[i] >> (8 * k)) & 0xff);
        if (!c) return s;
        s += c;
    }
    return s;
}

}  // namespace

bool ReflectSpirv(const std::vector<uint32_t>& w, SpirvReflection* out, std::string* error) {
    *out = SpirvReflection();
    if (w.size() < 6 || w[0] != 0x07230203u) { *error = "not a SPIR-V module (bad magic number)"; return false; }
    std::map<uint32_t, Type> types;
    std::map<uint32_t, uint32_t> constants;                          // id -> 32-bit value
    std::map<uint32_t, std::string> names;
    std::map<uint32_t, std::map<uint32_t, std::string>> memberNames;
    std::map<uint32_t, std::map<uint32_t, uint32_t>> decos;          // id -> decoration -> first operand
    std::map<uint32_t, std::map<uint32_t, std::map<uint32_t, uint32_t>>> memberDecos;   // struct id -> member -> decoration -> operand
    std::map<uint32_t, std::map<uint32_t, bool>> hasDeco;
    struct Var { uint32_t id, type, storage; };
    std::vector<Var> vars;

    for (size_t i = 5; i < w.size();) {
        const uint32_t count = w[i] >> 16, op = w[i] & 0xffff;
        if (count == 0 || i + count > w.size()) { *error = "SPIR-V instruction with a bad word count"; return false; }
        const uint32_t* p = &w[i + 1];
        const uint32_t n = count - 1;
        switch (op) {
            case OpName: if (n >= 2) names[p[0]] = Str(p + 1, n - 1); break;
            case OpMemberName: if (n >= 3) memberNames[p[0]][p[1]] = Str(p + 2, n - 2); break;
            case OpTypeBool: if (n >= 1) types[p[0]] = Type{OpTypeBool, 32, 0, {}, 0, 0}; break;
            case OpTypeInt: if (n >= 3) types[p[0]] = Type{OpTypeInt, p[1], p[2], {}, 0, 0}; break;
            case OpTypeFloat: if (n >= 2) types[p[0]] = Type{OpTypeFloat, p[1], 0, {}, 0, 0}; break;
            case OpTypeVector: case OpTypeMatrix: if (n >= 3) types[p[0]] = Type{op, p[1], p[2], {}, 0, 0}; break;
            case OpTypeImage: case OpTypeSampler: case OpTypeSampledImage: if (n >= 1) types[p[0]] = Type{op, n >= 2 ? p[1] : 0, 0, {}, 0, 0}; break;
            case OpTypeArray: if (n >= 3) types[p[0]] = Type{OpTypeArray, p[1], p[2], {}, 0, 0}; break;
            case OpTypeStruct: if (n >= 1) { Type t; t.op = OpTypeStruct; t.members.assign(p + 1, p + n); types[p[0]] = t; } break;
            case OpTypePointer: if (n >= 3) { Type t; t.op = OpTypePointer; t.storage = p[1]; t.pointee = p[2]; types[p[0]] = t; } break;
            case OpConstant: if (n >= 3) constants[p[1]] = p[2]; break;
            case OpVariable: if (n >= 3) vars.push_back({p[1], p[0], p[2]}); break;
            case OpDecorate: if (n >= 2) { decos[p[0]].emplace(p[1], n >= 3 ? p[2] : 0); hasDeco[p[0]][p[1]] = true; } break;
            case OpMemberDecorate: if (n >= 3) memberDecos[p[0]][p[1]].emplace(p[2], n >= 4 ? p[3] : 0); break;
            default: break;
        }
        i += count;
    }

    auto scalarOf = [&](uint32_t id, SpirvMember::Base* base) {
        auto it = types.find(id);
        if (it == types.end()) return false;
        if (it->second.op == OpTypeFloat) { *base = SpirvMember::Float; return it->second.a == 32; }
        if (it->second.op == OpTypeInt) { *base = it->second.b ? SpirvMember::Int : SpirvMember::UInt; return it->second.a == 32; }
        if (it->second.op == OpTypeBool) { *base = SpirvMember::Bool; return true; }
        return false;
    };
    // Bytes a member occupies and its shape. std140 rounds array elements and vec3 up to 16; the module's own ArrayStride is what we trust.
    auto describe = [&](uint32_t typeId, uint32_t stride, SpirvMember* m, uint32_t* bytes) {
        uint32_t t = typeId;
        uint32_t length = 1;
        auto it = types.find(t);
        if (it != types.end() && it->second.op == OpTypeArray) {
            auto c = constants.find(it->second.b);
            if (c == constants.end()) return false;
            length = c->second;
            t = it->second.a;
            it = types.find(t);
        }
        if (it == types.end()) return false;
        SpirvMember::Base base = SpirvMember::Float;
        uint32_t rows = 1, cols = 1;
        if (it->second.op == OpTypeVector) { if (!scalarOf(it->second.a, &base)) return false; rows = it->second.b; }
        else if (it->second.op == OpTypeMatrix) {
            auto col = types.find(it->second.a);
            if (col == types.end() || col->second.op != OpTypeVector || !scalarOf(col->second.a, &base)) return false;
            rows = col->second.b; cols = it->second.b;
        } else if (!scalarOf(t, &base)) return false;
        m->base = base; m->rows = rows; m->cols = cols;
        m->arrayLength = length;
        m->arrayStride = length > 1 || stride ? stride : 0;
        const uint32_t element = rows * cols * 4;
        *bytes = length > 1 ? (stride ? stride * length : element * length) : element;
        return true;
    };

    for (const Var& v : vars) {
        auto pt = types.find(v.type);
        if (pt == types.end() || pt->second.op != OpTypePointer) continue;
        const uint32_t pointee = pt->second.pointee;
        const uint32_t set = decos[v.id].count(DDescriptorSet) ? decos[v.id][DDescriptorSet] : 0;
        const uint32_t binding = decos[v.id].count(DBinding) ? decos[v.id][DBinding] : 0;
        if (v.storage == SPushConstant) { out->pushConstants = true; continue; }
        if (v.storage == SStorageBuffer) { out->storageBuffers = true; continue; }
        if (v.storage == SOutput) { if (!hasDeco[v.id].count(DBuiltIn)) out->outputCount++; continue; }
        if (v.storage == SUniformConstant) {
            auto it = types.find(pointee);
            // sampler2D arrives as OpTypeSampledImage; a separate texture2D / sampler / storage image is not supported
            if (it != types.end() && it->second.op == OpTypeSampledImage) out->samplers.push_back({names[v.id], set, binding});
            else out->otherResources = true;
            continue;
        }
        if (v.storage != SUniform) continue;
        auto st = types.find(pointee);
        if (st == types.end() || st->second.op != OpTypeStruct) { out->otherResources = true; continue; }
        if (!hasDeco[pointee].count(DBlock)) { out->storageBuffers = true; continue; }   // BufferBlock-style SSBO in old SPIR-V
        SpirvBlock block;
        block.name = names[pointee];
        block.set = set; block.binding = binding;
        uint32_t end = 0;
        for (size_t mi = 0; mi < st->second.members.size(); mi++) {
            SpirvMember m;
            m.name = memberNames[pointee][(uint32_t)mi];
            auto& md = memberDecos[pointee][(uint32_t)mi];
            if (!md.count(DOffset)) { *error = "uniform block '" + block.name + "' member " + std::to_string(mi) + " has no Offset decoration"; return false; }
            m.offset = md[DOffset];
            // ArrayStride sits on the array type itself, not on the member
            uint32_t stride = 0;
            auto ad = decos.find(st->second.members[mi]);
            if (ad != decos.end() && ad->second.count(DArrayStride)) stride = ad->second[DArrayStride];
            uint32_t bytes = 0;
            if (!describe(st->second.members[mi], stride, &m, &bytes)) {
                *error = "uniform block '" + block.name + "' member '" + m.name + "' has a type the backend cannot bind (float / int / uint / bool scalars, vectors and arrays of them)";
                return false;
            }
            end = std::max(end, m.offset + bytes);
            block.members.push_back(m);
        }
        block.size = (end + 15u) & ~15u;
        out->blocks.push_back(block);
    }
    return true;
}

}  // namespace am::rg

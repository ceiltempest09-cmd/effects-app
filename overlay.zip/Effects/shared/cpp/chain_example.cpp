// chain_example.cpp — how a multi-pass effect chain runs through the ping-pong pair.
// Chain: grade -> blur H -> blur V -> output(dither).  Intermediate passes stay in the working
// format (RGBA16F/32F, or RGBA8 on weak devices); only the last pass quantises, with dither.
#include "render_targets.h"
#include "shader_compose.h"

struct Program { GLuint id; /* + cached uniform locations */ };

static void Pass(const Program& p, const RenderTarget& src, RenderTarget& dst) {
    glBindFramebuffer(GL_FRAMEBUFFER, dst.fbo);
    glViewport(0, 0, dst.w, dst.h);
    glDisable(GL_BLEND);                    // passes overwrite; blending 32F may be unsupported anyway
    glUseProgram(p.id);
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, src.tex);  // reading src while writing dst: they are different textures
    glDrawArrays(GL_TRIANGLES, 0, 3);       // FullscreenVert()
}

// `input` = decoded video frame already uploaded as an RGBA8 texture (or a float one).
// `outFbo` = the final destination (display, or the encoder's 8-bit surface).
void RunChain(RenderTargetPool& pool, GLuint inputTex, int w, int h, PixelFormat want,
              const Program& grade, const Program& blurH, const Program& blurV,
              const Program& out, GLuint outFbo, int outW, int outH) {
    PingPong pp(pool, w, h, want);
    if (!pp.valid()) return;                // keep the previous frame on screen: never present garbage

    RenderTarget in; in.tex = inputTex;     // wrapper so Pass() can take the source uniformly
    Pass(grade, in, pp.write());      pp.swap();
    // set u_dir = (1/w, 0) on blurH, (0, 1/h) on blurV before each Pass (omitted for brevity)
    Pass(blurH, pp.read(), pp.write()); pp.swap();
    Pass(blurV, pp.read(), pp.write()); pp.swap();

    glBindFramebuffer(GL_FRAMEBUFFER, outFbo);
    glViewport(0, 0, outW, outH);
    glUseProgram(out.id);
    glBindTexture(GL_TEXTURE_2D, pp.read().tex);
    glDrawArrays(GL_TRIANGLES, 0, 3);       // u_ditherLevels = 255 (8-bit out) or 1023 (10-bit HEVC)
}

package com.effects.motion.library

import com.effects.motion.R
import com.effects.motion.i18n.AppText
import com.effects.motion.platform.readInto
import com.effects.motion.export.safeName
import com.effects.motion.model.MediaDeclaration
import com.effects.motion.model.Scene
import com.effects.motion.model.XmlNode
import com.effects.motion.model.mediaName
import com.effects.motion.model.replaceMedia
import com.effects.motion.model.storedMediaUris
import java.io.File
import java.io.FileNotFoundException
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.util.Arrays
import java.util.concurrent.CancellationException

class MediaKeeper(
    private val store: ProjectStore,
    private val open: (String) -> InputStream?,
    private val free: (File) -> Long = { it.usableSpace },
) {
    class NoSpace(val needed: Long) : IOException("Not enough free storage")

    data class Collected(val scene: Scene, val copied: Int, val unreadable: Int, val noSpace: Boolean)

    fun keep(id: String, media: MediaDeclaration, scene: Scene? = null, cancelled: () -> Boolean = { false }): MediaDeclaration {
        if (!collectable(media.uri)) return media
        scene?.media?.firstOrNull { media.size > 0 && it.size == media.size && it.filename == media.filename && store.inMediaFolder(it.uri) && same(media.uri, it.uri) }
            ?.let { return MediaDeclaration(media.node.with("uri", it.uri).with("missing", null)) }
        val dir = store.mediaDir(id).apply { mkdirs() }
        val base = safeName(media.filename.ifEmpty { media.uri.substringAfterLast('/') })
        earlierCopy(dir, base, media)?.let { return MediaDeclaration(media.node.with("uri", it.toURI().toString()).with("missing", null)) }
        val needed = maxOf(media.size, 0) + RESERVE
        if (free(dir) < needed) throw NoSpace(needed)
        val temp = File.createTempFile("keep-", ".part", dir)
        try {
            (open(media.uri) ?: throw FileNotFoundException(media.uri)).use { input ->
                temp.outputStream().use { out ->
                    copy(input, out, cancelled) { if (free(dir) < RESERVE) throw NoSpace(needed) }
                    out.fd.sync()
                }
            }
            if (media.size > 0 && temp.length() < media.size) throw IOException(AppText.get(R.string.keep_err_incomplete, base, temp.length().toString(), media.size.toString()))
            val target = synchronized(Naming) {
                val name = (sequenceOf(base) + generateSequence(2) { it + 1 }.map { "${it}_$base" }).first { !File(dir, it).exists() }
                File(dir, name).also { if (!temp.renameTo(it)) throw IOException(AppText.get(R.string.keep_err_cannot_keep, name)) }
            }
            return MediaDeclaration(media.node.with("uri", target.toURI().toString()).with("missing", null))
        } catch (e: IOException) {
            if (free(dir) < RESERVE) throw NoSpace(needed)
            throw e
        } finally {
            temp.delete()
        }
    }

    private fun earlierCopy(dir: File, base: String, media: MediaDeclaration): File? {
        if (media.size <= 0) return null
        val numbered = Regex("[0-9]+_" + Regex.escape(base))
        return dir.listFiles { f -> f.isFile && f.length() == media.size && (f.name == base || numbered.matches(f.name)) }.orEmpty()
            .sortedBy { it.name }.firstOrNull { same(media.uri, it.toURI().toString()) }
    }

    private fun copy(input: InputStream, out: OutputStream, cancelled: () -> Boolean, checkSpace: () -> Unit) {
        val buffer = ByteArray(1 shl 16)
        var unchecked = 0L
        while (true) {
            if (cancelled()) throw CancellationException("Copy cancelled")
            val n = input.read(buffer)
            if (n < 0) return
            out.write(buffer, 0, n)
            unchecked += n
            if (unchecked >= SPACE_CHECK_BYTES) {
                unchecked = 0
                checkSpace()
            }
        }
    }

    fun collect(id: String, scene: Scene): Collected {
        var result = scene
        var copied = 0
        var unreadable = 0
        val declared = LinkedHashMap<String, MediaDeclaration>()
        fun declarations(node: XmlNode) {
            if (node.name == "media") node["uri"]?.let { declared.putIfAbsent(it, MediaDeclaration(node)) }
            node.children.forEach(::declarations)
        }
        declarations(scene.node)
        for (uri in scene.node.storedMediaUris().filter(::collectable)) {
            val media = declared[uri] ?: MediaDeclaration(XmlNode("media", mapOf("uri" to uri, "filename" to scene.mediaName(uri))))
            try {
                result = result.replaceMedia(media.uri, keep(id, media, result))
                copied++
            } catch (e: NoSpace) {
                return Collected(result, copied, unreadable, true)
            } catch (e: IOException) {
                unreadable++
            } catch (e: SecurityException) {
                unreadable++
            }
        }
        return Collected(result, copied, unreadable, false)
    }

    private fun same(a: String, b: String): Boolean = runCatching {
        (open(a) ?: return false).use { x -> (open(b) ?: return false).use { y -> equal(x, y) } }
    }.getOrDefault(false)

    private fun equal(x: InputStream, y: InputStream): Boolean {
        val one = ByteArray(1 shl 16)
        val two = ByteArray(1 shl 16)
        while (true) {
            val n = x.readInto(one, 0, one.size)
            val m = y.readInto(two, 0, two.size)
            if (n != m || !Arrays.equals(one, 0, n, two, 0, m)) return false
            if (n < one.size) return true
        }
    }

    private fun collectable(uri: String) = (uri.startsWith("content:") || uri.startsWith("file:")) && !store.inMediaFolder(uri)

    companion object {
        private val Naming = Any()

        const val RESERVE = 200L shl 20
        private const val SPACE_CHECK_BYTES = 16L shl 20
    }
}

#include "render_targets.h"

static GLenum InternalFormat(PixelFormat f) {
    switch (f) {
        case PixelFormat::RGBA16F: return GL_RGBA16F;
        case PixelFormat::RGBA32F: return GL_RGBA32F;
        default:                   return GL_RGBA8;
    }
}

PixelFormat RenderTargetPool::clamp(PixelFormat want) const {
    if (want == PixelFormat::RGBA32F && fCaps.f32Render) return PixelFormat::RGBA32F;
    if (want >= PixelFormat::RGBA16F && fCaps.f16Render) return PixelFormat::RGBA16F;
    return PixelFormat::RGBA8;
}

bool RenderTargetPool::create(RenderTarget& t, int w, int h, PixelFormat fmt) {
    while (glGetError() != GL_NO_ERROR) {}
    const bool linear = fmt == PixelFormat::RGBA8 ? true
                      : fmt == PixelFormat::RGBA16F ? fCaps.f16Linear : fCaps.f32Linear;
    glGenTextures(1, &t.tex);
    glBindTexture(GL_TEXTURE_2D, t.tex);
    glTexStorage2D(GL_TEXTURE_2D, 1, InternalFormat(fmt), w, h);     // immutable storage, 1 mip
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, linear ? GL_LINEAR : GL_NEAREST);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, linear ? GL_LINEAR : GL_NEAREST);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
    glGenFramebuffers(1, &t.fbo);
    glBindFramebuffer(GL_FRAMEBUFFER, t.fbo);
    glFramebufferTexture2D(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0, GL_TEXTURE_2D, t.tex, 0);
    const bool ok = glGetError() == GL_NO_ERROR &&
                    glCheckFramebufferStatus(GL_FRAMEBUFFER) == GL_FRAMEBUFFER_COMPLETE;
    glBindFramebuffer(GL_FRAMEBUFFER, 0);
    if (!ok) {                                                       // out of memory / bad driver: clean up
        glDeleteFramebuffers(1, &t.fbo); glDeleteTextures(1, &t.tex);
        t.fbo = t.tex = 0;
        return false;
    }
    t.w = w; t.h = h; t.fmt = fmt; t.manualBilinear = !linear;
    return true;
}

RenderTarget* RenderTargetPool::acquire(int w, int h, PixelFormat want) {
    PixelFormat fmt = clamp(want);
    for (RenderTarget* t : fTargets)                                  // reuse an idle match
        if (!t->inUse && t->w == w && t->h == h && t->fmt == fmt) { t->inUse = true; return t; }

    for (int f = (int)fmt; f >= 0; --f) {                             // degrade until one works
        auto* t = new RenderTarget();
        if (create(*t, w, h, (PixelFormat)f)) { t->inUse = true; fTargets.push_back(t); return t; }
        delete t;
    }
    return nullptr;     // caller keeps showing the last good frame instead of a black viewport
}

void RenderTargetPool::trim(bool all) {
    for (size_t i = 0; i < fTargets.size();) {
        RenderTarget* t = fTargets[i];
        if (!t->inUse || all) {
            glDeleteFramebuffers(1, &t->fbo); glDeleteTextures(1, &t->tex);
            delete t; fTargets.erase(fTargets.begin() + i);
        } else ++i;
    }
}

PingPong::PingPong(RenderTargetPool& pool, int w, int h, PixelFormat want) : fPool(pool) {
    fA = pool.acquire(w, h, want);
    // B must match A's *actual* format, otherwise one side could silently be lower precision.
    if (fA) fB = pool.acquire(w, h, fA->fmt);
}

PingPong::~PingPong() { fPool.release(fA); fPool.release(fB); }

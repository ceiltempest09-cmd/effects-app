// render_targets.h — format-aware render target pool + ping-pong pair.
// Rule: allocation NEVER fails visibly. If a requested format can't be created (unsupported or an
// incomplete FBO), we degrade 32F -> 16F -> 8 automatically and report what we actually got.
#pragma once
#include <GLES3/gl3.h>
#include <vector>

enum class PixelFormat : int { RGBA8 = 0, RGBA16F = 1, RGBA32F = 2 };   // == BitDepth.nativeId in Kotlin

struct GpuCaps {                       // native mirror of GpuCapabilities.kt
    bool f16Render = false, f16Linear = true, f32Render = false, f32Linear = false, f32Blend = false;
};

struct RenderTarget {
    GLuint fbo = 0, tex = 0;
    int w = 0, h = 0;
    PixelFormat fmt = PixelFormat::RGBA8;
    bool manualBilinear = false;       // true => shaders must define FX_MANUAL_BILINEAR (no HW linear filter)
    bool inUse = false;
};

class RenderTargetPool {
public:
    explicit RenderTargetPool(const GpuCaps& caps) : fCaps(caps) {}
    ~RenderTargetPool() { trim(true); }

    PixelFormat clamp(PixelFormat want) const;            // best supported format <= want
    RenderTarget* acquire(int w, int h, PixelFormat want); // nullptr only if even RGBA8 fails
    void release(RenderTarget* t) { if (t) t->inUse = false; }
    void trim(bool all = false);                           // free idle targets (call on resize / low memory)

private:
    bool create(RenderTarget& t, int w, int h, PixelFormat fmt);
    GpuCaps fCaps;
    std::vector<RenderTarget*> fTargets;
};

// Two same-format targets; read() is last pass output, write() is where the next pass renders.
class PingPong {
public:
    PingPong(RenderTargetPool& pool, int w, int h, PixelFormat want);
    ~PingPong();
    bool valid() const { return fA && fB; }
    RenderTarget& read()  { return fFlip ? *fB : *fA; }
    RenderTarget& write() { return fFlip ? *fA : *fB; }
    void swap() { fFlip = !fFlip; }
    PixelFormat format() const { return fA->fmt; }
private:
    RenderTargetPool& fPool;
    RenderTarget *fA = nullptr, *fB = nullptr;
    bool fFlip = false;
};

package com.effects.motion.export

import android.media.MediaCodec
import android.media.MediaFormat
import java.nio.ByteBuffer

internal fun streamFormatOf(f: MediaFormat): StreamFormat = StreamFormat(
    f.getString(MediaFormat.KEY_MIME).orEmpty(), f.getInteger(MediaFormat.KEY_WIDTH), f.getInteger(MediaFormat.KEY_HEIGHT),
    (0..2).mapNotNull { i -> f.getByteBuffer("csd-$i")?.let { b -> ByteArray(b.remaining()).also { a -> b.duplicate().get(a) } } },
)

/** What a normal export learns about its video stream, so that it can be saved for later Smart Exports. */
internal class SmartCapture {
    @Volatile var format: StreamFormat? = null
    @Volatile var path: String = ""
    @Volatile var encoder: String = ""
}

/** One encoder session of a Smart Export: frames [drawStart] until [keepStart] only warm up history effects, [keepStart]..[keepEnd] are kept. */
internal class SmartSession(val drawStart: Int, val keepStart: Int, val keepEnd: Int) {
    val drawn: Int get() = keepEnd - drawStart + 1
}

/** The encoder sessions of a plan, in timeline order: one per run of kept frames, preceded by the warm-up frames that belong to it. */
internal fun smartSessions(plan: SmartPlan): List<SmartSession> {
    val out = ArrayList<SmartSession>()
    var k = 0
    while (k < plan.frames) {
        if (plan.actions[k] != FrameAction.Keep) { k++; continue }
        var from = k
        while (from > 0 && plan.actions[from - 1] == FrameAction.Warm) from--
        var to = k
        while (to + 1 < plan.frames && plan.actions[to + 1] == FrameAction.Keep) to++
        out += SmartSession(from, k, to)
        k = to + 1
    }
    return out
}

/**
 * Writes the video track of a Smart Export: packets of freshly encoded runs and packets copied from the saved export, in timeline order.
 * Every packet goes through [write], which checks that frames follow each other exactly (no gap, no repeat) and feeds the recorder that
 * saves this export for next time. Any doubt throws [SmartFallback].
 */
internal class SmartJob(
    val plan: SmartPlan, private val entry: SmartEntry, val recorder: SegmentRecorder?, private val fps: Int, val frames: Int,
) : AutoCloseable {
    private val reader = SegmentReader(entry)
    private val pending = ArrayDeque(plan.reused)
    private val info = MediaCodec.BufferInfo()
    private var mux: Mux? = null
    var track = -1
        private set
    var format: StreamFormat? = null
        private set
    private var next = 0
    val copied: Int get() = copiedFrames
    private var copiedFrames = 0
    /** How the saved export was rendered (swapchain or encoder buffers); a different path is not mixed with it. */
    val entryPath: String get() = entry.path

    /** The output format of a session's encoder. Every one must be the stream of the saved export; the first creates the track. */
    fun onFormat(f: MediaFormat, sink: Mux) {
        val seen = streamFormatOf(f)
        if (!seen.matches(entry.format)) throw SmartFallback("the encoder's stream differs from the saved export", benign = true)
        if (track < 0) {
            mux = sink
            track = sink.addTrack(f)
            format = seen
        }
    }

    fun write(ptsUs: Long, flags: Int, bytes: ByteArray, off: Int, size: Int) {
        val k = ((ptsUs * fps + 500_000L) / 1_000_000L).toInt()
        if (k != next) throw SmartFallback("frame $k written where frame $next belongs")
        next++
        val m = mux ?: throw SmartFallback("no video track yet")
        val key = flags and MediaCodec.BUFFER_FLAG_KEY_FRAME
        info.set(off, size, ptsUs, key)
        m.write(track, ByteBuffer.wrap(bytes), info)
        recorder?.add(ptsUs, key, bytes, off, size)
    }

    /** Writes every saved group that comes before frame [k]. */
    fun flushBefore(k: Int) {
        while (pending.isNotEmpty() && pending.first().first < k) {
            val g = pending.removeFirst()
            if (g.first != next) throw SmartFallback("saved group starts at ${g.first}, expected $next")
            val region = reader.read(g)
            forEachRecord(region, g.count) { pts, flags, off, size -> write(pts, flags, region, off, size) }
            copiedFrames += g.count
        }
    }

    /** After the last session: the saved groups behind it, and the check that every frame is there exactly once. */
    fun finish(m: Mux) {
        flushBefore(Int.MAX_VALUE)
        if (next != frames) throw SmartFallback("wrote $next frames, expected $frames")
        if (track >= 0) m.end(track)
    }

    override fun close() = reader.close()
}

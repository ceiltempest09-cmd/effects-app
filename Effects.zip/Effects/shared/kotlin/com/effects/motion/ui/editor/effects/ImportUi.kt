package com.effects.motion.ui.editor.effects

import android.provider.OpenableColumns
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.effects.motion.editor.EditorState
import com.effects.motion.effects.EffectImporter
import com.effects.motion.effects.EffectSources
import com.effects.motion.effects.ImportLine
import com.effects.motion.effects.ImportTier
import com.effects.motion.effects.ImportedEffects
import com.effects.motion.platform.LocalContext
import com.effects.motion.ui.theme.Am
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** The small "Import" box in the Effects Library header (red box in photo 3). */
@Composable
internal fun ImportChip(onClick: () -> Unit) {
    Row(
        Modifier.padding(start = 4.dp).height(34.dp).clip(RoundedCornerShape(8.dp)).background(Am.Panel)
            .clickable(onClick = onClick).padding(horizontal = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) { Text("Import", color = Am.Accent, fontSize = 12.sp, maxLines = 1) }
}

/** The two source buttons under the header (red boxes in photo 2). Tap the selected one again to go back to Effects Motion. */
@Composable
internal fun SourceBar(source: String, empty: Boolean, onPick: (String) -> Unit) {
    Column(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp)) {
        Row {
            listOf(EffectSources.AfterEffects, EffectSources.AlightMotion).forEachIndexed { i, key ->
                val on = key == source
                Box(
                    Modifier.weight(1f).padding(start = if (i == 0) 0.dp else 8.dp).height(44.dp).clip(RoundedCornerShape(8.dp))
                        .background(if (on) Am.Accent.copy(alpha = 0.3f) else Am.Panel)
                        .clickable { onPick(if (on) EffectSources.Native else key) },
                    contentAlignment = Alignment.Center,
                ) { Text(EffectSources.label(key), color = if (on) Am.Accent else Am.OnDark, fontSize = 14.sp, maxLines = 1) }
            }
        }
        if (empty && source != EffectSources.Native)
            Text("Nothing here yet. Tap Import to add effects.", Modifier.padding(top = 10.dp), color = Am.OnDark.copy(alpha = 0.7f), fontSize = 13.sp)
    }
}

/** Import flow: choose source, pick files, choose quality tier, convert, report. Shows nothing while [open] is false. */
@Composable
internal fun EffectImportFlow(state: EditorState, open: Boolean, onClose: () -> Unit, onShow: (source: String, pack: String) -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var source by remember { mutableStateOf<String?>(null) }
    var picked by remember { mutableStateOf<List<android.net.Uri>?>(null) }
    var working by remember { mutableStateOf(false) }
    var tier by remember { mutableStateOf(ImportTier.DEFAULT) }
    var report by remember { mutableStateOf<List<ImportLine>?>(null) }
    fun finish() { source = null; picked = null; working = false; report = null; onClose() }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isEmpty()) finish() else picked = uris
    }
    if (!open) return

    fun run(chosen: ImportTier) {
        tier = chosen
        val uris = picked ?: return
        val target = source ?: return
        working = true
        scope.launch {
            val first = withContext(Dispatchers.IO) {
                val resolver = context.contentResolver
                val named = uris.map { uri ->
                    val label = resolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
                        ?.use { c -> if (c.moveToFirst()) c.getString(0) else null } ?: uri.lastPathSegment ?: "file"
                    label to { resolver.openInputStream(uri) }
                }
                EffectImporter.import(context, target, chosen, named)
            }
            state.engine.reloadEffects(context).join()
            val catalog = state.engine.effects.value
            var dropped = false
            val checked = first.lines.map { line ->
                val id = line.effectId ?: return@map line
                val status = catalog.find(id)?.status ?: "not registered"
                if (status == "ok") line else {
                    withContext(Dispatchers.IO) { ImportedEffects.delete(context, id) }
                    dropped = true
                    ImportLine(line.file, false, "Converted, but the shader did not compile: " + status.removePrefix("shader error: "))
                }
            }
            if (dropped) state.engine.reloadEffects(context).join()
            report = checked
            working = false
        }
    }

    when {
        report != null -> AlertDialog(
            onDismissRequest = ::finish, containerColor = Am.Field, titleContentColor = Am.OnDark, textContentColor = Am.OnDark,
            title = { Text(if (report!!.any { it.ok }) "Import finished" else "Nothing imported") },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState())) {
                    report!!.forEach { Text((if (it.ok) "\u2713 " else "\u2717 ") + (if (it.file.isBlank()) "" else it.file + ": ") + it.text, Modifier.padding(bottom = 8.dp), fontSize = 13.sp) }
                }
            },
            confirmButton = {
                TextButton({ if (report!!.any { it.ok }) onShow(source ?: EffectSources.Native, tier.pack); finish() }) { Text("OK", color = Am.Accent) }
            },
        )
        working -> AlertDialog(
            onDismissRequest = {}, containerColor = Am.Field, titleContentColor = Am.OnDark, textContentColor = Am.OnDark,
            title = { Text("Importing\u2026") }, text = { Text("Converting and checking the shaders.") }, confirmButton = {},
        )
        picked != null -> AlertDialog(
            onDismissRequest = ::finish, containerColor = Am.Field, titleContentColor = Am.OnDark, textContentColor = Am.OnDark,
            title = { Text("Choose quality") },
            text = { Text("Nothing is upgraded automatically. If your device cannot do this depth it falls back to the nearest it can.") },
            confirmButton = {
                Column {
                    ImportTier.values().forEach { tier -> TextButton({ run(tier) }) { Text(tier.label, color = Am.Accent) } }
                }
            },
            dismissButton = { TextButton(::finish) { Text("Cancel", color = Am.OnDark) } },
        )
        source == null -> AlertDialog(
            onDismissRequest = ::finish, containerColor = Am.Field, titleContentColor = Am.OnDark, textContentColor = Am.OnDark,
            title = { Text("Import effects from") },
            text = { Text("Effects Motion: .json effects or a zip.\nAfter Effects: plug-in files or a zip.\nAlight Motion: .xml effects or a zip pack.") },
            confirmButton = {
                Column {
                    EffectSources.all.forEach { (key, label) -> TextButton({ source = key; picker.launch(arrayOf("*/*")) }) { Text(label, color = Am.Accent) } }
                }
            },
            dismissButton = { TextButton(::finish) { Text("Cancel", color = Am.OnDark) } },
        )
    }
}

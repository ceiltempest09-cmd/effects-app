#include "render_graph.h"

#include <algorithm>
#include <chrono>
#include <cmath>
#include <cstring>
#include <functional>
#include <queue>
#include <set>

namespace am::rg {

// ------------------------------------------------------------------ names
const char* ToString(Format f) {
    switch (f) {
        case Format::RGBA8: return "rgba8";
        case Format::RGBA16F: return "rgba16f";
        case Format::RGBA32F: return "rgba32f";
        default: return "inherit";
    }
}
const char* ToString(Lang l) {
    switch (l) {
        case Lang::GLSL: return "glsl";
        case Lang::GLSLES: return "glsl-es";
        case Lang::VulkanGLSL: return "glsl-vk";
        case Lang::SPIRV: return "spirv";
        default: return "sksl";
    }
}
bool ParseFormat(const std::string& s, Format* f) {
    if (s == "inherit" || s.empty()) *f = Format::Inherit;
    else if (s == "rgba8") *f = Format::RGBA8;
    else if (s == "rgba16f") *f = Format::RGBA16F;
    else if (s == "rgba32f") *f = Format::RGBA32F;
    else return false;
    return true;
}
bool ParseLang(const std::string& s, Lang* l) {
    if (s == "sksl" || s.empty()) *l = Lang::SkSL;
    else if (s == "glsl") *l = Lang::GLSL;
    else if (s == "glsl-es" || s == "glsl-es300" || s == "glsles") *l = Lang::GLSLES;
    else if (s == "glsl-vk" || s == "glsl-vulkan" || s == "vkglsl") *l = Lang::VulkanGLSL;
    else if (s == "spirv" || s == "spir-v") *l = Lang::SPIRV;
    else return false;
    return true;
}
bool ParseBlend(const std::string& s, Blend* b) {
    if (s == "replace" || s.empty()) *b = Blend::Replace;
    else if (s == "over" || s == "src-over") *b = Blend::SrcOver;
    else if (s == "add") *b = Blend::Add;
    else if (s == "multiply") *b = Blend::Multiply;
    else if (s == "screen") *b = Blend::Screen;
    else return false;
    return true;
}
bool ParseFilter(const std::string& s, Filter* f) {
    if (s == "linear" || s.empty()) *f = Filter::Linear;
    else if (s == "nearest") *f = Filter::Nearest;
    else return false;
    return true;
}
bool ParseWrap(const std::string& s, Wrap* w) {
    if (s == "clamp" || s.empty()) *w = Wrap::Clamp;
    else if (s == "repeat") *w = Wrap::Repeat;
    else if (s == "mirror") *w = Wrap::Mirror;
    else if (s == "decal") *w = Wrap::Decal;
    else return false;
    return true;
}
int BytesPerPixel(Format f) { return f == Format::RGBA16F ? 8 : f == Format::RGBA32F ? 16 : 4; }

static const char* KindName(DiagKind k) {
    switch (k) {
        case DiagKind::Malformed: return "malformed";
        case DiagKind::Unsupported: return "unsupported";
        case DiagKind::Translation: return "translation";
        case DiagKind::Capability: return "capability";
        default: return "validation";
    }
}

std::string Diag::format() const {
    std::string s = error ? "error[" : "warning[";
    s += KindName(kind);
    s += "]";
    if (!effect.empty()) s += " effect '" + effect + "'";
    if (!pass.empty()) {
        s += " pass '" + pass + "'";
        if (passIndex >= 0) s += " (#" + std::to_string(passIndex) + ")";
    }
    if (!backend.empty()) s += " backend " + backend;
    if (!file.empty()) s += " (" + file + (line > 0 ? ":" + std::to_string(line) : std::string()) + ")";
    return s + ": " + message;
}

bool HasError(const std::vector<Diag>& d) {
    return std::any_of(d.begin(), d.end(), [](const Diag& x) { return x.error; });
}

int Plan::bufferIndex(const std::string& id) const {
    for (size_t i = 0; i < desc.buffers.size(); i++) if (desc.buffers[i].id == id) return (int)i;
    return -1;
}

// ------------------------------------------------------------------ planning
namespace {

bool ValidId(const std::string& s) {
    if (s.empty() || s.size() > 48) return false;
    if (!(std::isalpha((unsigned char)s[0]) || s[0] == '_')) return false;
    return std::all_of(s.begin(), s.end(), [](char c) { return std::isalnum((unsigned char)c) || c == '_'; });
}

int Distance(const std::string& a, const std::string& b) {
    std::vector<int> prev(b.size() + 1), cur(b.size() + 1);
    for (size_t j = 0; j <= b.size(); j++) prev[j] = (int)j;
    for (size_t i = 1; i <= a.size(); i++) {
        cur[0] = (int)i;
        for (size_t j = 1; j <= b.size(); j++)
            cur[j] = std::min({prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + (a[i - 1] == b[j - 1] ? 0 : 1)});
        std::swap(prev, cur);
    }
    return prev[b.size()];
}

std::string Suggest(const std::string& wanted, const std::vector<std::string>& known) {
    std::string best;
    int bestD = 3;
    for (const std::string& k : known) {
        const int d = Distance(wanted, k);
        if (d < bestD) bestD = d, best = k;
    }
    return best.empty() ? std::string() : " Did you mean '" + best + "'?";
}

struct RefParts { std::string kind, id; int back = 0; bool ok = true; };

RefParts SplitRef(const std::string& ref) {
    RefParts r;
    if (ref == "source") { r.kind = "source"; return r; }
    const size_t colon = ref.find(':');
    if (colon == std::string::npos) { r.ok = false; return r; }
    r.kind = ref.substr(0, colon);
    std::string rest = ref.substr(colon + 1);
    const size_t at = rest.find('@');
    if (at != std::string::npos) {
        const std::string n = rest.substr(at + 1);
        rest = rest.substr(0, at);
        if (n.empty() || !std::all_of(n.begin(), n.end(), [](char c) { return std::isdigit((unsigned char)c); }) || n.size() > 2) r.ok = false;
        else r.back = std::atoi(n.c_str());
    }
    r.id = rest;
    if (r.kind != "buffer" && r.kind != "texture" && r.kind != "pass") r.ok = false;
    return r;
}

}  // namespace

Plan BuildPlan(const GraphDesc& graph, const PlanOptions& opt) {
    Plan plan;
    plan.desc = graph;
    GraphDesc& d = plan.desc;
    auto add = [&](bool error, DiagKind kind, const PassDesc* pass, int index, std::string msg) {
        Diag x;
        x.error = error;
        x.kind = kind;
        x.effect = d.effectId;
        x.backend = opt.backend;
        if (pass) { x.pass = pass->id; x.passIndex = index; x.file = pass->file; x.line = pass->line; }
        x.message = std::move(msg);
        plan.diags.push_back(std::move(x));
    };
    auto fail = [&](DiagKind kind, const PassDesc* pass, int index, std::string msg) { add(true, kind, pass, index, std::move(msg)); };
    auto warn = [&](const PassDesc* pass, int index, std::string msg) { add(false, DiagKind::Validation, pass, index, std::move(msg)); };

    const int np = (int)d.passes.size();
    if (np == 0) { fail(DiagKind::Malformed, nullptr, -1, "the effect has no passes"); return plan; }
    if (np > opt.maxPasses) { fail(DiagKind::Unsupported, nullptr, -1, "has " + std::to_string(np) + " passes; the limit is " + std::to_string(opt.maxPasses)); return plan; }

    // ---- ids
    std::map<std::string, int> passAt, texAt, bufAt;
    for (int i = 0; i < np; i++) {
        const PassDesc& p = d.passes[i];
        if (!ValidId(p.id)) fail(DiagKind::Malformed, &p, i, "pass id '" + p.id + "' is not a valid name (letters, digits, underscore)");
        else if (!passAt.emplace(p.id, i).second) fail(DiagKind::Malformed, &p, i, "pass id '" + p.id + "' is used twice");
        if (p.source.find_first_not_of(" \t\r\n") == std::string::npos) fail(DiagKind::Malformed, &p, i, "has no shader source");
        if (!std::any_of(opt.languages.begin(), opt.languages.end(), [&](Lang l) { return l == p.lang; }))
            fail(DiagKind::Capability, &p, i, std::string("is written in ") + ToString(p.lang) + ", which the " + opt.backend +
                 " backend cannot run. Convert the pass to a supported language or run on a device/backend that has it.");
        if ((int)p.inputs.size() > opt.maxInputs) fail(DiagKind::Unsupported, &p, i, "has " + std::to_string(p.inputs.size()) + " inputs; the limit is " + std::to_string(opt.maxInputs));
    }
    for (size_t i = 0; i < d.textures.size(); i++) {
        const TextureDesc& t = d.textures[i];
        if (!ValidId(t.id) || !texAt.emplace(t.id, (int)i).second) fail(DiagKind::Malformed, nullptr, -1, "texture id '" + t.id + "' is invalid or used twice");
        if (t.source != "builtin:noise" && t.source != "builtin:ramp-x" && t.source != "builtin:ramp-y")
            fail(DiagKind::Unsupported, nullptr, -1, "texture '" + t.id + "' has source '" + t.source + "'; only builtin:noise, builtin:ramp-x and builtin:ramp-y exist in this build");
        if (t.width < 1 || t.height < 1 || t.width > 2048 || t.height > 2048) fail(DiagKind::Malformed, nullptr, -1, "texture '" + t.id + "' size must be 1..2048");
    }
    for (size_t i = 0; i < d.buffers.size(); i++) {
        const BufferDesc& b = d.buffers[i];
        if (!ValidId(b.id) || b.id == "source") fail(DiagKind::Malformed, nullptr, -1, "buffer id '" + b.id + "' is invalid ('source' is reserved)");
        else if (!bufAt.emplace(b.id, (int)i).second) fail(DiagKind::Malformed, nullptr, -1, "buffer id '" + b.id + "' is declared twice");
        else if (texAt.count(b.id)) fail(DiagKind::Malformed, nullptr, -1, "'" + b.id + "' is both a buffer and a texture");
        if (!(b.scale > 0 && b.scale <= 8)) fail(DiagKind::Malformed, nullptr, -1, "buffer '" + b.id + "' scale must be in (0, 8]");
        if (b.width < 0 || b.height < 0 || b.width > opt.maxTexture || b.height > opt.maxTexture) fail(DiagKind::Malformed, nullptr, -1, "buffer '" + b.id + "' size exceeds " + std::to_string(opt.maxTexture));
        if (b.history < 0 || b.history > 8) fail(DiagKind::Malformed, nullptr, -1, "buffer '" + b.id + "' history must be 0..8");
    }
    if (HasError(plan.diags)) return plan;

    // ---- implicit buffers: a pass that names no (or an undeclared) output gets a plain full-size temporary
    for (int i = 0; i < np; i++) {
        PassDesc& p = d.passes[i];
        if (p.output.empty()) p.output = p.id;
        if (!ValidId(p.output)) { fail(DiagKind::Malformed, &p, i, "output '" + p.output + "' is not a valid name"); continue; }
        if (texAt.count(p.output)) { fail(DiagKind::Validation, &p, i, "writes '" + p.output + "', which is a texture (textures are read-only)"); continue; }
        if (!bufAt.count(p.output)) {
            BufferDesc b;
            b.id = p.output;
            bufAt[b.id] = (int)d.buffers.size();
            d.buffers.push_back(b);
        }
    }
    if (d.output.empty()) d.output = d.passes.back().output;
    if (!bufAt.count(d.output)) {
        std::vector<std::string> ids;
        for (const auto& b : d.buffers) ids.push_back(b.id);
        fail(DiagKind::Validation, nullptr, -1, "the effect output '" + d.output + "' is not a buffer." + Suggest(d.output, ids));
    }
    if ((int)d.buffers.size() > opt.maxBuffers) fail(DiagKind::Unsupported, nullptr, -1, "has " + std::to_string(d.buffers.size()) + " buffers; the limit is " + std::to_string(opt.maxBuffers));
    if (HasError(plan.diags)) return plan;

    std::vector<std::string> bufferIds, textureIds, passIds;
    for (const auto& b : d.buffers) bufferIds.push_back(b.id);
    for (const auto& t : d.textures) textureIds.push_back(t.id);
    for (const auto& p : d.passes) passIds.push_back(p.id);

    // ---- resolve inputs
    const int nb = (int)d.buffers.size();
    std::vector<std::vector<ResolvedInput>> inputs(np);
    std::vector<std::vector<int>> writers(nb);
    for (int i = 0; i < np; i++) writers[bufAt[d.passes[i].output]].push_back(i);
    for (int i = 0; i < np; i++) {
        const PassDesc& p = d.passes[i];
        std::set<std::string> names;
        for (const PassInput& in : p.inputs) {
            if (!ValidId(in.name)) { fail(DiagKind::Malformed, &p, i, "input name '" + in.name + "' is not a valid shader child name"); continue; }
            if (!names.insert(in.name).second) { fail(DiagKind::Malformed, &p, i, "input '" + in.name + "' is declared twice"); continue; }
            const RefParts ref = SplitRef(in.ref);
            if (!ref.ok) { fail(DiagKind::Malformed, &p, i, "input '" + in.name + "' has reference '" + in.ref + "'; expected source, buffer:<id>[@n], texture:<id> or pass:<id>[@n]"); continue; }
            ResolvedInput r;
            r.name = in.name;
            r.back = ref.back;
            if (ref.kind == "source") {
                r.kind = ResolvedInput::Source;
                if (ref.back) { fail(DiagKind::Unsupported, &p, i, "input '" + in.name + "': the layer image has no history (source@n)"); continue; }
            } else if (ref.kind == "texture") {
                auto t = texAt.find(ref.id);
                if (t == texAt.end()) { fail(DiagKind::Validation, &p, i, "input '" + in.name + "' reads unknown texture '" + ref.id + "'." + Suggest(ref.id, textureIds)); continue; }
                if (ref.back) { fail(DiagKind::Validation, &p, i, "input '" + in.name + "': textures have no history"); continue; }
                r.kind = ResolvedInput::Texture;
                r.index = t->second;
            } else {
                std::string id = ref.id;
                if (ref.kind == "pass") {
                    auto q = passAt.find(id);
                    if (q == passAt.end()) { fail(DiagKind::Validation, &p, i, "input '" + in.name + "' reads unknown pass '" + id + "'." + Suggest(id, passIds)); continue; }
                    id = d.passes[q->second].output;
                }
                auto b = bufAt.find(id);
                if (b == bufAt.end()) { fail(DiagKind::Validation, &p, i, "input '" + in.name + "' reads unknown buffer '" + id + "'." + Suggest(id, bufferIds)); continue; }
                r.kind = ResolvedInput::Buffer;
                r.index = b->second;
                const BufferDesc& bd = d.buffers[r.index];
                if (r.back > bd.history) {
                    fail(DiagKind::Validation, &p, i, "input '" + in.name + "' reads '" + id + "@" + std::to_string(r.back) + "' but the buffer keeps " +
                         std::to_string(bd.history) + " frame(s) of history. Set history >= " + std::to_string(r.back) + " on the buffer.");
                    continue;
                }
                if (r.back == 0) {
                    if (bufAt[p.output] == r.index) {
                        fail(DiagKind::Validation, &p, i, "reads and writes buffer '" + id + "' in the same pass (read/write feedback hazard). Read '" + id +
                             "@1' (previous frame) or write to a different buffer.");
                        continue;
                    }
                    if (writers[r.index].empty()) {
                        fail(DiagKind::Validation, &p, i, "input '" + in.name + "' reads buffer '" + id + "' that no pass writes" +
                             (bd.history > 0 ? ". Use '" + id + "@1' for the previous frame." : std::string(".")));
                        continue;
                    }
                }
            }
            inputs[i].push_back(r);
        }
        for (const std::string& a : p.after)
            if (!passAt.count(a)) fail(DiagKind::Validation, &p, i, "after '" + a + "': no such pass." + Suggest(a, passIds));
    }
    for (int b = 0; b < nb; b++) {
        if (writers[b].size() > 1) {
            for (size_t k = 1; k < writers[b].size(); k++) {
                const PassDesc& later = d.passes[writers[b][k]];
                if (later.clear && later.blend == Blend::Replace)
                    fail(DiagKind::Validation, &later, writers[b][k], "overwrites buffer '" + d.buffers[b].id + "' that pass '" + d.passes[writers[b][k - 1]].id +
                         "' already wrote. Set clear=false with a blend mode to accumulate, or write to another buffer.");
            }
        }
    }
    if (HasError(plan.diags)) return plan;

    // ---- dependency edges (same-frame only: reading @n does not order passes, which is what makes feedback legal)
    std::vector<std::set<int>> preds(np), succs(np);
    auto edge = [&](int from, int to) { if (from != to && preds[to].insert(from).second) succs[from].insert(to); };
    for (int i = 0; i < np; i++) {
        for (const ResolvedInput& r : inputs[i])
            if (r.kind == ResolvedInput::Buffer && r.back == 0) for (int w : writers[r.index]) edge(w, i);
        for (const std::string& a : d.passes[i].after) edge(passAt[a], i);
    }
    for (int b = 0; b < nb; b++)
        for (size_t k = 1; k < writers[b].size(); k++) edge(writers[b][k - 1], writers[b][k]);   // accumulate in declaration order

    // ---- topological order (Kahn, ties by declaration order) with cycle report
    std::vector<int> indeg(np), order;
    for (int i = 0; i < np; i++) indeg[i] = (int)preds[i].size();
    std::priority_queue<int, std::vector<int>, std::greater<int>> ready;
    for (int i = 0; i < np; i++) if (!indeg[i]) ready.push(i);
    while (!ready.empty()) {
        const int n = ready.top();
        ready.pop();
        order.push_back(n);
        for (int s : succs[n]) if (--indeg[s] == 0) ready.push(s);
    }
    if ((int)order.size() != np) {
        std::vector<char> ordered(np, 0);
        for (int n : order) ordered[n] = 1;
        std::vector<int> color(np, 0), stack, cycle;
        std::function<bool(int)> dfs = [&](int n) -> bool {
            color[n] = 1;
            stack.push_back(n);
            for (int s : succs[n]) {
                if (ordered[s]) continue;
                if (color[s] == 1) {
                    cycle.assign(std::find(stack.begin(), stack.end(), s), stack.end());
                    cycle.push_back(s);
                    return true;
                }
                if (color[s] == 0 && dfs(s)) return true;
            }
            stack.pop_back();
            color[n] = 2;
            return false;
        };
        for (int i = 0; i < np && cycle.empty(); i++)
            if (!ordered[i] && color[i] == 0) dfs(i);
        std::string path;
        for (size_t k = 0; k < cycle.size(); k++) path += (k ? " -> " : "") + d.passes[cycle[k]].id;
        fail(DiagKind::Validation, cycle.empty() ? nullptr : &d.passes[cycle[0]], cycle.empty() ? -1 : cycle[0],
             "dependency cycle: " + path + ". Break it by reading the previous frame ('buffer:<id>@1') on one edge.");
        return plan;
    }

    // ---- cull: keep what the output needs, plus whatever feeds a history buffer that a live pass reads
    const int finalBuf = bufAt[d.output];
    if (writers[finalBuf].empty()) { fail(DiagKind::Validation, nullptr, -1, "no pass writes the output buffer '" + d.output + "'"); return plan; }
    std::vector<char> live(np, 0);
    std::vector<int> work;
    auto mark = [&](int p) { if (!live[p]) live[p] = 1, work.push_back(p); };
    for (int w : writers[finalBuf]) mark(w);
    while (!work.empty()) {
        const int n = work.back();
        work.pop_back();
        for (int pr : preds[n]) mark(pr);
        for (const ResolvedInput& r : inputs[n])
            if (r.kind == ResolvedInput::Buffer && r.back > 0) for (int w : writers[r.index]) mark(w);
    }
    for (int i = 0; i < np; i++) {
        if (!live[i]) {
            plan.culled.push_back(d.passes[i].id);
            warn(&d.passes[i], i, "does not contribute to the output and is skipped");
        }
    }

    // ---- steps, lifetimes
    std::vector<int> firstWrite(nb, -1), lastUse(nb, -1);
    std::vector<char> keep(nb, 0);
    keep[finalBuf] = 1;
    for (int b = 0; b < nb; b++) if (d.buffers[b].history > 0) keep[b] = 1;
    for (int n : order) {
        if (!live[n]) continue;
        Step s;
        s.pass = n;
        s.output = bufAt[d.passes[n].output];
        s.inputs = inputs[n];
        const int at = (int)plan.steps.size();
        if (firstWrite[s.output] < 0) firstWrite[s.output] = at, s.firstWriter = true;
        lastUse[s.output] = std::max(lastUse[s.output], at);
        for (const ResolvedInput& r : s.inputs) {
            if (r.kind == ResolvedInput::Buffer && r.back == 0) lastUse[r.index] = std::max(lastUse[r.index], at);
            if (r.kind == ResolvedInput::Buffer && r.back > 0) plan.temporal = true;
        }
        plan.steps.push_back(std::move(s));
    }
    int liveNow = 0;
    for (size_t at = 0; at < plan.steps.size(); at++) {
        Step& s = plan.steps[at];
        if (s.firstWriter) liveNow++;
        plan.peakLive = std::max(plan.peakLive, liveNow);
        for (int b = 0; b < nb; b++)
            if (!keep[b] && lastUse[b] == (int)at && firstWrite[b] >= 0) { s.releaseAfter.push_back(b); liveNow--; }
    }
    plan.finalBuffer = finalBuf;

    // ---- unused declarations
    for (int b = 0; b < nb; b++)
        if (writers[b].empty() && !std::any_of(plan.steps.begin(), plan.steps.end(), [&](const Step& s) {
                return std::any_of(s.inputs.begin(), s.inputs.end(), [&](const ResolvedInput& r) { return r.kind == ResolvedInput::Buffer && r.index == b; }); }))
            warn(nullptr, -1, "buffer '" + d.buffers[b].id + "' is declared but never used");
    for (size_t t = 0; t < d.textures.size(); t++)
        if (!std::any_of(plan.steps.begin(), plan.steps.end(), [&](const Step& s) {
                return std::any_of(s.inputs.begin(), s.inputs.end(), [&](const ResolvedInput& r) { return r.kind == ResolvedInput::Texture && r.index == (int)t; }); }))
            warn(nullptr, -1, "texture '" + d.textures[t].id + "' is declared but never used");
    return plan;
}

void BufferSize(const BufferDesc& b, int areaW, int areaH, int* w, int* h) {
    *w = b.width > 0 ? b.width : std::max(1, (int)std::ceil(areaW * b.scale - 1e-4));
    *h = b.height > 0 ? b.height : std::max(1, (int)std::ceil(areaH * b.scale - 1e-4));
}

std::vector<uint8_t> NoisePixels(int w, int h, int seed) {
    std::vector<uint8_t> px((size_t)w * h * 4);
    for (int y = 0; y < h; y++)
        for (int x = 0; x < w; x++)
            for (int c = 0; c < 4; c++) {
                uint32_t v = (uint32_t)x * 0x9E3779B1u ^ (uint32_t)y * 0x85EBCA77u ^ (uint32_t)(c + 1) * 0xC2B2AE3Du ^ (uint32_t)seed * 0x27D4EB2Fu;
                v ^= v >> 15; v *= 0x2C1B3C6Du; v ^= v >> 12; v *= 0x297A2D39u; v ^= v >> 15;
                px[((size_t)y * w + x) * 4 + c] = (uint8_t)(v >> 24);
            }
    return px;
}

// ------------------------------------------------------------------ pool
Target* TargetPool::acquire(int w, int h, Format f, bool shared) {
    for (Entry& e : fEntries) {
        if (!e.inUse && e.shared == shared && e.t->width == w && e.t->height == h && e.t->format == f) {
            e.inUse = true;
            e.last = fTick;
            fStats.reused++;
            fStats.live++;
            fStats.idle--;
            return e.t;
        }
    }
    const int64_t need = (int64_t)w * h * BytesPerPixel(f);
    const auto bytesNow = [&] { return fStats.bytes; };
    if (fBudget > 0 && bytesNow() + need > fBudget) trim(false, 0);
    if (fBudget > 0 && bytesNow() + need > fBudget) return nullptr;
    Target* t = shared ? fBackend.createShared(w, h, f) : fBackend.create(w, h, f);
    if (!t) {
        trim(false, 0);                       // out of memory: give idle targets back and try once more
        t = shared ? fBackend.createShared(w, h, f) : fBackend.create(w, h, f);
        if (!t) return nullptr;
    }
    t->width = w;
    t->height = h;
    t->format = f;
    t->owner = &fBackend;
    fEntries.push_back({t, true, fTick, shared});
    fStats.created++;
    fStats.live++;
    fStats.bytes += need;
    fStats.peakBytes = std::max(fStats.peakBytes, fStats.bytes);
    return t;
}

void TargetPool::release(Target* t) {
    if (!t) return;
    for (Entry& e : fEntries) {
        if (e.t == t) {
            if (e.inUse) { e.inUse = false; e.last = fTick; fStats.live--; fStats.idle++; }
            return;
        }
    }
}

void TargetPool::trim(bool all, int idleTicks) {
    for (size_t i = 0; i < fEntries.size();) {
        Entry& e = fEntries[i];
        if (all || (!e.inUse && fTick - e.last >= (uint64_t)idleTicks)) {
            if (e.inUse) { fStats.live--; } else { fStats.idle--; }
            fStats.bytes -= (int64_t)e.t->width * e.t->height * BytesPerPixel(e.t->format);
            fStats.destroyed++;
            fBackend.destroy(e.t);
            fEntries.erase(fEntries.begin() + i);
        } else {
            ++i;
        }
    }
}

TargetPool::Stats TargetPool::stats() const { return fStats; }

// ------------------------------------------------------------------ executor
Executor::Executor(Backend& backend, std::shared_ptr<const Plan> plan) : Executor(std::vector<Backend*>{&backend}, std::move(plan)) {}

Executor::Executor(std::vector<Backend*> backends, std::shared_ptr<const Plan> plan) : fBackends(std::move(backends)), fPlan(std::move(plan)) {
    for (Backend* b : fBackends) fPools.push_back(std::make_unique<TargetPool>(*b));
    const size_t nb = fPlan->desc.buffers.size();
    fCommitted.resize(nb);
    fPending.assign(nb, nullptr);
    fFormats.assign(nb, Format::RGBA8);
    fHome.assign(nb, 0);
    fShared.assign(nb, 0);
}

Executor::~Executor() { reset(); }

void Executor::release(Target* t) {
    if (!t) return;
    for (size_t i = 0; i < fBackends.size(); i++) {
        if (t->owner == fBackends[i]) { fPools[i]->release(t); return; }
    }
}

void Executor::reset() {
    for (auto& q : fCommitted) {
        for (Target* t : q) release(t);
        q.clear();
    }
    for (Target*& t : fPending) { release(t); t = nullptr; }
    fLastFrame = -1;
}

void Executor::dropAll() {
    reset();
    for (auto& p : fPools) p->trim(true);
    fFormatsDone = false;
}

void Executor::trimIdle() { for (auto& p : fPools) p->trim(false, 0); }

TargetPool::Stats Executor::poolStats() const {
    TargetPool::Stats sum;
    for (const auto& p : fPools) {
        const TargetPool::Stats s = p->stats();
        sum.created += s.created; sum.destroyed += s.destroyed; sum.reused += s.reused;
        sum.bytes += s.bytes; sum.peakBytes += s.peakBytes; sum.live += s.live; sum.idle += s.idle;
    }
    return sum;
}

Target* Executor::acquireTarget(int backend, int w, int h, Format f, bool shared) {
    if (fBudget > 0) {
        const int64_t need = (int64_t)w * h * BytesPerPixel(f);
        if (poolStats().bytes + need > fBudget) trimIdle();
        if (poolStats().bytes + need > fBudget) return nullptr;
    }
    return fPools[backend]->acquire(w, h, f, shared);
}

void Executor::commit() {
    for (size_t b = 0; b < fPending.size(); b++) {
        if (!fPending[b]) continue;
        fCommitted[b].push_front(fPending[b]);
        fPending[b] = nullptr;
        while ((int)fCommitted[b].size() > fPlan->desc.buffers[b].history) {
            release(fCommitted[b].back());
            fCommitted[b].pop_back();
        }
    }
}

void Executor::sizeOf(int b, int w, int h, int* ow, int* oh) const { BufferSize(fPlan->desc.buffers[b], w, h, ow, oh); }

namespace {
Diag CapabilityDiag(const Plan& plan, const PassDesc* pass, int passIndex, const std::string& backend, std::string message, bool error = true) {
    Diag x;
    x.error = error;
    x.kind = DiagKind::Capability;
    x.effect = plan.desc.effectId;
    x.backend = backend;
    if (pass) { x.pass = pass->id; x.passIndex = passIndex; x.file = pass->file; x.line = pass->line; }
    x.message = std::move(message);
    return x;
}
}  // namespace

// Decides, once per device, which backend runs each step, which backend owns each buffer, and the format of every buffer.
// Anything a backend cannot do is reported as a Capability diagnostic; there is no fallback to another language or backend.
bool Executor::resolveRoutes(FrameResult* out) {
    if (fFormatsDone) return true;
    const Plan& p = *fPlan;
    const GraphDesc& d = p.desc;
    auto failWith = [&](const Diag& x) {
        out->notes.push_back(x);
        out->status = FrameResult::Failed;
        out->error = x.format();
        return false;
    };

    std::string tried;
    for (Backend* b : fBackends) tried += (tried.empty() ? "" : ",") + std::string(b->name());

    fRoute.assign(p.steps.size(), -1);
    std::vector<std::set<int>> touching(d.buffers.size());
    std::vector<bool> homed(d.buffers.size(), false);
    for (size_t si = 0; si < p.steps.size(); si++) {
        const Step& st = p.steps[si];
        const PassDesc& pd = d.passes[st.pass];
        std::string refusals;
        for (size_t bi = 0; bi < fBackends.size() && fRoute[si] < 0; bi++) {
            Backend* be = fBackends[bi];
            if (!be->supports(pd.lang)) { refusals += std::string(refusals.empty() ? "" : "; ") + be->name() + " does not run " + ToString(pd.lang); continue; }
            Diag why;
            why.kind = DiagKind::Capability;
            if (!be->accepts(pd, &why)) { refusals += std::string(refusals.empty() ? "" : "; ") + be->name() + ": " + why.message; continue; }
            fRoute[si] = (int)bi;
        }
        if (fRoute[si] < 0)
            return failWith(CapabilityDiag(p, &pd, st.pass, tried, std::string("no backend on this device can run this ") + ToString(pd.lang) + " pass (" + refusals + ")"));
        if (!homed[st.output]) { fHome[st.output] = fRoute[si]; homed[st.output] = true; }
        touching[st.output].insert(fRoute[si]);
        for (const ResolvedInput& in : st.inputs) if (in.kind == ResolvedInput::Buffer) touching[in.index].insert(fRoute[si]);
    }

    // The primary backend (the one that owns the layer and receives the result) reads the final buffer, so it touches it even when a
    // different backend wrote it: that buffer must be created shared, or the hand-off at the end of the frame has no storage to import.
    if (p.finalBuffer >= 0 && homed[p.finalBuffer] && fHome[p.finalBuffer] != 0) touching[p.finalBuffer].insert(0);

    for (size_t b = 0; b < d.buffers.size(); b++) {
        const BufferDesc& bd = d.buffers[b];
        if (!homed[b]) { fFormats[b] = Format::RGBA8; continue; }
        touching[b].insert(fHome[b]);
        const bool shared = touching[b].size() > 1;
        fShared[b] = shared ? 1 : 0;
        const Format want = bd.format == Format::Inherit ? fBackends[fHome[b]]->workingFormat() : bd.format;
        Format got = want;
        std::string limiter = fBackends[fHome[b]]->name();
        // A buffer used by several backends must be storage they can all see: every one of them has to render / sample the format AND
        // share it (an AHardwareBuffer has no RGBA32F format, for instance), otherwise the format is lowered like any other limit.
        auto usable = [&](Format f, std::string* who) {
            for (int bi : touching[b]) {
                if (f != Format::RGBA8 && !fBackends[bi]->supports(f)) { *who = fBackends[bi]->name(); return false; }
                if (shared && !fBackends[bi]->canShare(f)) { *who = fBackends[bi]->name(); return false; }
            }
            return true;
        };
        std::string who;
        while (!usable(got, &who) && got != Format::RGBA8) { limiter = who; got = got == Format::RGBA32F ? Format::RGBA16F : Format::RGBA8; }
        if (!usable(got, &who)) {
            std::string names;
            for (int bi : touching[b]) names += (names.empty() ? "" : " and ") + std::string(fBackends[bi]->name());
            return failWith(CapabilityDiag(p, nullptr, -1, who, std::string("buffer '") + bd.id + "' is used by " + names + ", which cannot share " + ToString(got) + " storage on this device (backend " + who + ")"));
        }
        if (got != want) {
            std::string msg = std::string("buffer '") + bd.id + "' wants " + ToString(want) + " but backend " + limiter + " on this device only " + (shared ? "renders and shares " : "renders ") + ToString(got);
            if (bd.precision == Precision::Required) {
                msg += "; the buffer is marked precision=required so the effect cannot run here";
                return failWith(CapabilityDiag(p, nullptr, -1, limiter, msg));
            }
            out->notes.push_back(CapabilityDiag(p, nullptr, -1, limiter, msg, false));
        }
        fFormats[b] = got;
    }
    fFormatsDone = true;
    return true;
}

FrameResult Executor::render(const FrameRequest& r, const std::function<void(Target*)>& consume) {
    FrameResult out;
    auto failWith = [&](FrameResult::Status s, const std::string& why) {
        out.status = s;
        out.error = why;
        reset();
        return out;
    };
    if (!fPlan->ok()) return failWith(FrameResult::Failed, "the effect plan is not valid");
    int maxSize = fBackends.empty() ? 0 : fBackends[0]->maxTextureSize();
    for (Backend* b : fBackends) maxSize = std::min(maxSize, b->maxTextureSize());
    if (!r.source || r.width < 1 || r.height < 1 || r.width > maxSize || r.height > maxSize)
        return failWith(FrameResult::Failed, "bad frame size or no source image");
    if (!resolveRoutes(&out)) return out;
    for (auto& p : fPools) p->tick();

    if (fLastFrame >= 0 && (r.signature != fSignature || r.width != fW || r.height != fH)) { reset(); out.historyReset = true; }
    fSignature = r.signature;
    fW = r.width;
    fH = r.height;

    const bool temporal = fPlan->temporal;
    if (fLastFrame >= 0 && temporal) {
        if (r.frame == fLastFrame) {
            for (Target*& t : fPending) { release(t); t = nullptr; }      // redo: history = frames before `frame`
        } else if (r.frame == fLastFrame + 1) {
            commit();
        } else {
            reset();                                                       // jump
            out.historyReset = true;
        }
    } else if (!temporal) {
        reset();
    }

    if (temporal && fLastFrame < 0 && fPlan->desc.seek == SeekMode::Replay && r.frame > 0) {
        if (!r.sourceAt) {
            out.notes.push_back(CapabilityDiag(*fPlan, nullptr, -1, fBackends[0]->name(),
                "seek=replay needs the layer image at earlier frames and the caller cannot supply it; history was reset instead", false));
        } else {
            const int64_t first = std::max<int64_t>(0, r.frame - fPlan->desc.maxReplay);
            for (int64_t f = first; f < r.frame; f++) {
                Target* s = r.sourceAt(f);
                if (!s) return failWith(FrameResult::Failed, "the layer image for replay frame " + std::to_string(f) + " is not available");
                if (fLastFrame >= 0) commit();
                if (!runOne(r, f, s, nullptr, &out)) return out;
                fLastFrame = f;
                out.replayed++;
            }
            if (fLastFrame >= 0) commit();
            out.historyReset = true;
        }
    }

    if (!runOne(r, r.frame, r.source, &consume, &out)) return out;
    fLastFrame = r.frame;
    if (!temporal) { for (Target*& t : fPending) { release(t); t = nullptr; } }
    for (auto& p : fPools) p->trim(false, 8);
    return out;
}

bool Executor::runOne(const FrameRequest& r, int64_t frame, Target* source, const std::function<void(Target*)>* consume, FrameResult* out) {
    const Plan& p = *fPlan;
    const GraphDesc& d = p.desc;
    const size_t nb = d.buffers.size();
    std::vector<Target*> live(nb, nullptr);
    Backend* sourceOwner = r.sourceOwner ? r.sourceOwner : fBackends[0];
    auto abandon = [&](FrameResult::Status s, const std::string& why) {
        for (Target*& t : live) { release(t); t = nullptr; }
        out->status = s;
        out->error = why;
        reset();
        return false;
    };

    for (size_t si = 0; si < p.steps.size(); si++) {
        if (r.cancel && r.cancel->load(std::memory_order_relaxed)) return abandon(FrameResult::Cancelled, "cancelled");
        const Step& st = p.steps[si];
        const PassDesc& pd = d.passes[st.pass];
        Backend* be = fBackends[fRoute[si]];
        auto handoffFail = [&](const std::string& what, const std::string& why) {
            return abandon(FrameResult::Failed, CapabilityDiag(p, &pd, st.pass, be->name(), what + ": " + why).format());
        };
        bool first = false;
        if (!live[st.output]) {
            int w, h;
            sizeOf(st.output, r.width, r.height, &w, &h);
            live[st.output] = acquireTarget(fHome[st.output], w, h, fFormats[st.output], fShared[st.output] != 0);
            if (!live[st.output]) return abandon(FrameResult::Failed, "out of GPU memory allocating buffer '" + d.buffers[st.output].id + "' (" + std::to_string(w) + "x" + std::to_string(h) + ")");
            first = true;
        }

        struct View { Backend* from; Target* original; Target* view; bool written; };
        std::vector<View> views;
        // Gives `be` a target it can use: its own targets as they are, anything another backend owns through the hand-off protocol.
        auto bring = [&](Target* t, Backend* holder, bool forWrite, Target** use, std::string* why) {
            if (holder == be) { *use = t; return true; }
            if (!holder->release(t, *be, why)) return false;
            Target* v = be->acquire(*holder, t, forWrite, why);
            if (!v) return false;
            views.push_back({holder, t, v, forWrite});
            *use = v;
            return true;
        };
        auto giveBack = [&](bool ok) {
            for (const View& v : views) {
                std::string ignore;
                if (ok && v.written) {
                    be->release(v.view, *v.from, &ignore);
                    be->relinquish(v.view);
                    v.from->reclaim(v.original, *be);
                } else {
                    be->relinquish(v.view);
                }
            }
            views.clear();
        };

        PassRun run;
        run.pass = &pd;
        run.step = (int)si;
        run.clear = pd.clear || first;
        run.frame = frame;
        run.timeSeconds = r.timeSeconds + (double)(frame - r.frame) * r.frameSeconds;
        run.areaWidth = r.width;
        run.areaHeight = r.height;
        run.control = r.control ? &r.control : nullptr;
        std::string why;
        Target* outUse = nullptr;
        Backend* outOwner = fBackends[fHome[st.output]];
        if (!bring(live[st.output], outOwner, true, &outUse, &why)) { giveBack(false); return handoffFail("cannot render into buffer '" + d.buffers[st.output].id + "'", why); }
        run.output = outUse;

        for (const ResolvedInput& in : st.inputs) {
            BoundInput b;
            b.name = &in.name;
            Target* raw = nullptr;
            Backend* holder = be;
            if (in.kind == ResolvedInput::Source) {
                raw = source;
                holder = sourceOwner;
                b.source = true;
            } else if (in.kind == ResolvedInput::Texture) {
                const TextureDesc& td = d.textures[in.index];
                raw = be->texture(td);
                b.filter = td.filter;
                b.wrap = td.wrap;
            } else {
                const BufferDesc& bd = d.buffers[in.index];
                b.filter = bd.filter;
                b.wrap = bd.wrap;
                holder = fBackends[fHome[in.index]];
                if (in.back == 0) {
                    raw = live[in.index];
                } else if ((int)fCommitted[in.index].size() >= in.back) {
                    raw = fCommitted[in.index][in.back - 1];
                } else {
                    int w, h;
                    sizeOf(in.index, r.width, r.height, &w, &h);
                    raw = be->blank(w, h, fFormats[in.index]);
                    holder = be;
                }
            }
            if (!raw) { giveBack(false); return abandon(FrameResult::Failed, "input '" + in.name + "' of pass '" + pd.id + "' has no image"); }
            if (!bring(raw, holder, false, &b.target, &why)) { giveBack(false); return handoffFail("cannot read input '" + in.name + "'", why); }
            run.inputs.push_back(b);
        }
        std::string error;
        const auto t0 = std::chrono::steady_clock::now();
        const bool ok = be->run(run, &error);
        const auto t1 = std::chrono::steady_clock::now();
        giveBack(ok);
        if (!ok) {
            Diag x;
            x.kind = DiagKind::Translation;
            x.effect = d.effectId;
            x.pass = pd.id;
            x.passIndex = st.pass;
            x.backend = be->name();
            x.file = pd.file;
            x.line = pd.line;
            x.message = error;
            return abandon(FrameResult::Failed, x.format());
        }
        out->timings.push_back({pd.id, (int)si, std::chrono::duration_cast<std::chrono::nanoseconds>(t1 - t0).count(), be->gpuNanos()});
        for (int b : st.releaseAfter) { release(live[b]); live[b] = nullptr; }
    }

    Target* final = live[p.finalBuffer];
    if (consume && *consume && final) {
        Backend* primary = fBackends[0];
        Backend* holder = fBackends[fHome[p.finalBuffer]];
        Target* use = final;
        std::string why;
        bool viewed = false;
        if (holder != primary) {
            Target* v = nullptr;
            if (holder->release(final, *primary, &why)) v = primary->acquire(*holder, final, false, &why);
            if (!v) return abandon(FrameResult::Failed, CapabilityDiag(p, nullptr, -1, primary->name(), "cannot hand the effect result from backend " + std::string(holder->name()) + " to " + primary->name() + ": " + why).format());
            use = v;
            viewed = true;
        }
        (*consume)(use);
        if (viewed) primary->relinquish(use);
    }
    for (size_t b = 0; b < nb; b++) {
        if (!live[b]) continue;
        if (d.buffers[b].history > 0) {
            release(fPending[b]);
            fPending[b] = live[b];
        } else {
            release(live[b]);
        }
        live[b] = nullptr;
    }
    return true;
}

}  // namespace am::rg

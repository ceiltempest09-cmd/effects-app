# Alight Motion library visibility fix

## Confirmed root cause
`EffectSources.libraries(context)` was documented as returning the built-in
After Effects and Alight Motion libraries followed by custom libraries, but its
implementation returned only `CustomLibraries.list(context)`. Therefore the
Effects Library header never displayed either built-in library button.

## Changes
- Always expose the built-in After Effects and Alight Motion source buttons.
- Keep user-created libraries after the built-in buttons.
- Add an asset lookup fallback for Alight Motion thumbnail files under
  `assets/alightmotion/thumb` when the native `assets/effects` path misses.

## Files changed
- `Effects/shared/kotlin/com/effects/motion/effects/EffectSources.kt`
- `Effects/shared/kotlin/com/effects/motion/effects/EffectCatalog.kt`

## Repository upload
Replace the repository's `overlay.zip` with this archive renamed to
`overlay.zip`. Keep the existing `Effects.zip`, `aligthmotion.zip`, and workflow
file unchanged.

## Validation
The source implementation now includes the Alight Motion library in the
library-bar list. APK build and on-device display still need to be verified.

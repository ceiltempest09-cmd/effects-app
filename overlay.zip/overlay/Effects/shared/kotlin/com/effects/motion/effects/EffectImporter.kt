package com.effects.motion.effects

import com.effects.motion.platform.Context
import com.effects.motion.effects.graph.EffectGraph
import com.effects.motion.effects.graph.GraphConvert
import com.effects.motion.effects.graph.GraphPass
import com.effects.motion.effects.graph.GraphValidator
import com.effects.motion.effects.graph.PassInput
import com.effects.motion.effects.graph.hasError
import com.effects.motion.effects.engine.CubeLut
import com.effects.motion.effects.engine.CubeLutResult
import com.effects.motion.effects.engine.LutBake
import com.effects.motion.effects.graph.GraphJson
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.InputStream
import java.util.Locale
import java.util.zip.ZipInputStream

class ImportLine(val file: String, val ok: Boolean, val text: String, val effectId: String? = null)

class ImportResult(val lines: List<ImportLine>)

/**
 * Reads picked files / zips, converts what it can, stores it. Never runs native code and never writes by zip entry name.
 * After Effects plug-in files (.aex, .plugin, .dll, .vst, .ffx) are not imported (a compiled plug-in has no shader the app can run); the After Effects
 * library itself is still there and can hold effects converted from .xml files.
 */
object EffectImporter {
    private const val MAX_FILE = 2 shl 20
    private const val MAX_CUBE = 24 shl 20      // a 65-point .cube is about 8 MB of text
    private const val MAX_ENTRIES = 500
    private const val MAX_TOTAL = 64L shl 20
    private val Wanted = setOf("xml", "json", "glsl", "frag", "cube")

    /** [source] = the library the effects are stored in (Library effect), [tier] = the bit depth / pack (Bit float), [lang] = the Shader language. */
    fun import(context: Context, source: String, tier: ImportTier, files: List<Pair<String, () -> InputStream?>>, lang: ShaderLang = ShaderLang.SKSL): ImportResult {
        val lines = mutableListOf<ImportLine>()
        var budget = MAX_TOTAL
        for ((name, open) in files) {
            try {
                val input = open() ?: throw java.io.IOException("cannot open the file")
                if (name.lowercase(Locale.ROOT).endsWith(".zip")) {
                    var entries = 0
                    ZipInputStream(input).use { zip ->
                        while (true) {
                            val e = zip.nextEntry ?: break
                            if (e.isDirectory) continue
                            val leaf = e.name.substringAfterLast('/').substringAfterLast('\\')
                            if (leaf.startsWith(".") || leaf.substringAfterLast('.', "").lowercase(Locale.ROOT) !in Wanted) continue
                            if (++entries > MAX_ENTRIES) { lines += ImportLine(name, false, "Too many files in the zip (limit $MAX_ENTRIES)."); break }
                            val bytes = readLimited(zip, limitFor(leaf))
                            if (bytes == null) { lines += ImportLine(leaf, false, "Skipped: file is too large."); continue }
                            budget -= bytes.size
                            lines += single(context, source, tier, lang, leaf, bytes)
                            if (budget <= 0) { lines += ImportLine(name, false, "Stopped: the zip unpacks to too much data."); break }
                        }
                    }
                } else {
                    val bytes = input.use { readLimited(it, limitFor(name)) }
                    lines += if (bytes == null) ImportLine(name, false, if (limitFor(name) == MAX_CUBE) "File is too large (limit 24 MB per LUT)." else "File is too large (limit 2 MB per effect).") else single(context, source, tier, lang, name, bytes)
                }
            } catch (e: Exception) {
                lines += ImportLine(name, false, "Could not read this file: ${e.message}")
            }
        }
        if (lines.isEmpty()) lines += ImportLine("", false, "No effect files found (.xml, .json, .cube or a zip of them).")
        return ImportResult(lines)
    }

    /** One file of the library bundled in assets (see ImportedEffects.installBundled): same conversion as a picked file, stored as an Alight Motion effect. */
    internal fun importBundled(context: Context, tier: ImportTier, name: String, bytes: ByteArray, source: String = EffectSources.AlightMotion): ImportLine =
        single(context, source, tier, ShaderLang.SKSL, name, bytes)

    private fun limitFor(name: String) = if (name.lowercase(Locale.ROOT).endsWith(".cube")) MAX_CUBE else MAX_FILE

    private fun readLimited(input: InputStream, limit: Int): ByteArray? {
        val out = ByteArrayOutputStream()
        val buffer = ByteArray(1 shl 14)
        while (true) {
            val n = input.read(buffer)
            if (n < 0) break
            if (out.size() + n > limit) return null
            out.write(buffer, 0, n)
        }
        return out.toByteArray()
    }

    private fun single(context: Context, source: String, tier: ImportTier, lang: ShaderLang, name: String, bytes: ByteArray): ImportLine =
        when (name.substringAfterLast('.', "").lowercase(Locale.ROOT)) {
            "xml" -> fromXml(context, source, tier, lang, name, bytes)
            "json" -> fromJson(context, source, tier, name, bytes)
            "cube" -> fromCube(context, tier, name, bytes)
            "glsl", "frag" -> ImportLine(name, false, "Shader files alone are not enough (no controls). Use an effect .xml.")
            else -> ImportLine(name, false, "This file type can't be imported. Use an effect .xml, .json, a .cube LUT or a zip of them.")
        }

    private fun slugOf(fx: AmEffect) = fx.id.substringAfterLast('.').ifBlank { fx.name }.lowercase(Locale.ROOT).replace(Regex("[^a-z0-9]+"), "_").trim('_').ifBlank { "effect" }

    /** The category an effect gets in the library it is stored in. */
    private fun categoryFor(target: String, amCategory: String, tier: ImportTier): String = when (target) {
        EffectSources.Native -> nativeCategoryFor(amCategory, tier.pack)
        EffectSources.AfterEffects -> aeCategoryFor(amCategory)
        EffectSources.AlightMotion -> amCardFor(amCategory)
        else -> amCategory.lowercase(Locale.ROOT).ifBlank { "other" }
    }

    private fun fromXml(context: Context, source: String, tier: ImportTier, lang: ShaderLang, name: String, bytes: ByteArray): ImportLine {
        val fx = try { AmXml.parse(bytes.toString(Charsets.UTF_8)) } catch (e: AmFormatError) { return ImportLine(name, false, e.message.orEmpty()) }
        if (fx.isGraph) return fromGraphXml(context, source, tier, lang, name, fx)
        if (lang == ShaderLang.GLSL) return fromGlslXml(context, source, tier, name, fx)
        val converted = SkslConvert.convert(fx)
        if (!converted.ok) return ImportLine(name, false, "\"${fx.name}\" not converted: " + converted.problems.joinToString(" "))
        val target = source
        val key = "${target}_${slugOf(fx)}"
        val category = categoryFor(target, fx.category, tier)
        val json = JSONObject().put("id", key).put("name", fx.name).put("description", fx.description).put("category", category)
            .put("source", target).put("tier", tier.name).put("lang", lang.name).put("sksl", converted.sksl).put("params", converted.params).put("origin", fx.id)
        ImportedEffects.save(context, json)
        return ImportLine(name, true, "\"${fx.name}\" added to ${EffectSources.label(target)} (${tier.label}, ${lang.label}).", "fx.$key")
    }

    /** One-pass XML as GLSL: the shader becomes a native GLSL ES pass of a one-pass graph, so it runs in the float pipeline at the chosen depth. */
    private fun fromGlslXml(context: Context, target: String, tier: ImportTier, name: String, fx: AmEffect): ImportLine {
        val converted = SkslConvert.convert(fx, glsl = true)
        if (!converted.ok) return ImportLine(name, false, "\"${fx.name}\" not converted to GLSL: " + converted.problems.joinToString(" ") + " Choose SkSL to import it for Skia.")
        val key = "${target}_${slugOf(fx)}"
        val effectId = fx.id.ifEmpty { fx.name }
        val graph = EffectGraph(passes = listOf(GraphPass("main", converted.sksl, fx.name, "glsl-es", listOf(PassInput("image", "source")), file = name)))
        val issues = GraphValidator.validate(effectId, graph, GraphConvert.NativeLanguages, "Skia, OpenGL ES or Vulkan")
        if (issues.hasError) return ImportLine(name, false, "\"${fx.name}\" not converted to GLSL:\n" + issues.filter { it.error }.joinToString("\n") { it.text })
        val json = JSONObject().put("id", key).put("name", fx.name).put("description", fx.description).put("category", categoryFor(target, fx.category, tier))
            .put("source", target).put("tier", tier.name).put("lang", ShaderLang.GLSL.name).put("params", converted.params).put("origin", fx.id)
        GraphJson.write(graph, json)
        val saved = try { EffectDefinition.parse(JSONObject(json.toString()), tier.pack, strictCategory = target != EffectSources.Native) } catch (e: Exception) { return ImportLine(name, false, "\"${fx.name}\" not stored: ${e.message}") }
        ImportedEffects.save(context, json)
        return ImportLine(name, true, "\"${saved.name}\" added to ${EffectSources.label(target)} (${tier.label}, GLSL).", "fx.$key")
    }

    /** Multi-pass XML: every pass is converted and validated; the result is stored as a native schema-2 JSON effect. */
    private fun fromGraphXml(context: Context, source: String, tier: ImportTier, lang: ShaderLang, name: String, fx: AmEffect): ImportLine {
        val converted = GraphConvert.convert(fx, name, native = lang == ShaderLang.GLSL)
        if (!converted.ok) return ImportLine(name, false, "\"${fx.name}\" not converted (${converted.problems.size} problem(s)):\n" + converted.problems.joinToString("\n") + if (lang == ShaderLang.GLSL) "\nChoose SkSL to import it for Skia." else "")
        val target = source
        val key = "${target}_${slugOf(fx)}"
        val category = categoryFor(target, fx.category, tier)
        val json = JSONObject().put("id", key).put("name", fx.name).put("description", fx.description).put("category", category)
            .put("source", target).put("tier", tier.name).put("lang", lang.name).put("params", converted.params).put("origin", fx.id)
        GraphJson.write(converted.graph!!, json)
        val saved = try { EffectDefinition.parse(JSONObject(json.toString()), tier.pack, strictCategory = target == EffectSources.Native) } catch (e: Exception) { return ImportLine(name, false, "\"${fx.name}\" not stored: ${e.message}") }
        ImportedEffects.save(context, json)
        val warnings = converted.issues.filter { !it.error }.map { it.text } + converted.notes
        return ImportLine(name, true, "\"${saved.name}\" added to ${EffectSources.label(target)} (${tier.label}, ${lang.label}) as a ${converted.graph.passes.size}-pass effect." +
            (if (warnings.isEmpty()) "" else "\n" + warnings.joinToString("\n")), "fx.$key")
    }

    /** An Effects Motion .json effect, stored in the chosen library. A native (built-in engine) effect can only live in Effects Motion. */
    private fun fromJson(context: Context, source: String, tier: ImportTier, name: String, bytes: ByteArray): ImportLine = try {
        val json = JSONObject(bytes.toString(Charsets.UTF_8))
        val def = EffectDefinition.parse(json, tier.pack, strictCategory = source == EffectSources.Native)
        if (source != EffectSources.Native && json.optBoolean("native")) throw IllegalArgumentException("it uses the app's built-in engine, so it can only be stored in Effects Motion")
        json.put("source", source).put("tier", tier.name)
        if (source != EffectSources.Native) json.put("id", "${source}_${json.getString("id")}")
        ImportedEffects.save(context, json)
        ImportLine(name, true, "\"${def.name}\" added to ${EffectSources.label(source)} (${tier.label}).", if (source == EffectSources.Native) def.id else "fx.${json.getString("id")}")
    } catch (e: Exception) {
        ImportLine(name, false, "Not an Effects Motion effect: ${e.message}")
    }

    /** A .cube LUT: parsed and validated, baked to a float16 file in filesDir/luts, stored as a one-pass effect that reads it. */
    private fun fromCube(context: Context, tier: ImportTier, name: String, bytes: ByteArray): ImportLine {
        val lut = when (val r = CubeLut.parse(bytes.toString(Charsets.UTF_8))) {
            is CubeLutResult.Ok -> r.lut
            is CubeLutResult.Error -> return ImportLine(name, false, "Not a valid .cube LUT" + (if (r.line > 0) " (line ${r.line})" else "") + ": ${r.message}")
        }
        LutBake.problem(lut)?.let { return ImportLine(name, false, it) }
        return try {
            val hash = LutEffect.hash(bytes)
            val display = lut.title.ifBlank { name.substringBeforeLast('.') }
            val dir = java.io.File(context.filesDir, "luts").apply { mkdirs() }
            val bin = java.io.File(dir, "$hash.lut16")
            if (!bin.isFile) {
                val temp = java.io.File(dir, "$hash.lut16.tmp")
                temp.writeBytes(LutBake.bake(lut))
                if (!temp.renameTo(bin)) { bin.writeBytes(temp.readBytes()); temp.delete() }
            }
            val built = LutEffect.build(display, lut, hash, bin.absolutePath)
            built.json.put("source", EffectSources.Native).put("tier", tier.name)
            val saved = EffectDefinition.parse(JSONObject(built.json.toString()), tier.pack)
            ImportedEffects.save(context, built.json)
            ImportLine(name, true, "\"${saved.name}\" added (${lut.size}-point LUT, Color).", "fx.${built.key}")
        } catch (e: Exception) {
            ImportLine(name, false, "LUT not stored: ${e.message}")
        }
    }
}

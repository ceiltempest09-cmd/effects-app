import com.effects.motion.effects.engine.EffectCapability
import com.effects.motion.effects.engine.ServedCapabilities
import com.effects.motion.effects.graph.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

object FrameTests {
    private fun load(): JSONObject {
        val root = File(System.getProperty("effects.root") ?: ".")
        return JSONObject(File(root, "docs/examples/timewarp_rgb.json").readText())
    }

    private fun issues(json: JSONObject, served: Set<EffectCapability> = ServedCapabilities.now): List<Issue> {
        val parsed = GraphJson.parse(json, "fx.timewarprgb")
        return parsed.issues + GraphValidator.validate("fx.timewarprgb", parsed.graph!!, served = served)
    }

    fun run() {
        section("frame access contract")
        check(Refs.parse("frame:+2") == Ref("frame", "2", 0) && Refs.parse("frame:-3") == Ref("frame", "-3", 0) && Refs.parse("frame:0") == Ref("frame", "0", 0), "frame refs parse")
        check(Refs.parse("frame:x") == null && Refs.parse("frame:02") == null && Refs.parse("frame:-0") == null && Refs.parse("frame:") == null, "bad frame refs are rejected")
        check(ServedCapabilities.now.none { it in setOf(EffectCapability.FrameWindow, EffectCapability.PreviousFrame, EffectCapability.NextFrame, EffectCapability.TimeAccess) },
            "this build does not claim frame access it cannot serve")

        val fx = load()
        val now = issues(fx)
        check(now.hasError && now.errors().contains("frame_window"), "reference Timewarp RGB is refused today, naming frame_window: ${now.errors()}")
        val served = ServedCapabilities.now + EffectCapability.FrameWindow
        val ok = issues(fx, served)
        check(!ok.hasError, "reference Timewarp RGB is valid once a provider serves frame_window: ${ok.errors()}")

        val outside = JSONObject(fx.toString())
        outside.getJSONArray("passes").getJSONObject(0).getJSONObject("inputs").put("n1", "frame:2")
        check(issues(outside, served).errors().contains("frame:2"), "frame outside the declared window is an error")

        val undeclared = JSONObject(fx.toString())
        undeclared.getJSONObject("requires").put("capabilities", JSONArray())
        undeclared.remove("frames")
        check(issues(undeclared, served).hasError, "frame inputs without declaring the capability are an error")

        val unknown = JSONObject(fx.toString())
        unknown.getJSONObject("requires").put("capabilities", JSONArray().put("frame_window").put("teleport"))
        check(issues(unknown, served).errors().contains("teleport"), "unknown capability names are an error")

        val windowOnly = JSONObject(fx.toString())
        windowOnly.getJSONObject("requires").put("capabilities", JSONArray())
        check(issues(windowOnly, served).errors().contains("frame_window"), "frames {before, after} without the capability is an error")

        val huge = JSONObject(fx.toString())
        huge.put("frames", JSONObject().put("before", 99).put("after", 1))
        check(issues(huge, served).hasError, "window larger than ${GraphVocabulary.MaxFrameWindow} frames is an error")

        val prev = JSONObject(fx.toString())
        prev.getJSONObject("requires").put("capabilities", JSONArray().put("previous_frame"))
        prev.remove("frames")
        prev.getJSONArray("passes").getJSONObject(0).getJSONObject("inputs").put("n1", "frame:0")
        check(!issues(prev, served + EffectCapability.PreviousFrame).hasError, "previous_frame alone covers frame:-1")
        check(issues(prev, served).errors().contains("previous_frame"), "previous_frame refused when not served")

        val parsed = GraphJson.parse(fx, "fx.timewarprgb").graph!!
        val written = GraphJson.write(parsed)
        val again = GraphJson.parse(written, "fx.timewarprgb").graph!!
        check(again.frames == FrameWindow(1, 1) && again.requires.capabilities == listOf("frame_window"), "capabilities and frame window survive save and reload")

        // nothing shipped changed meaning: effects without these fields write exactly as before
        val plain = EffectGraph(passes = parsed.passes)
        check(!GraphJson.write(plain).has("frames") && !GraphJson.write(plain).has("requires"), "effects without frame access write no frame fields")
    }
}

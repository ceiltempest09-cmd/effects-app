# R8 release protection. Do not disable obfuscation or optimization here.
# Preserve JNI methods because native code resolves their Java/Kotlin names.
-keepclasseswithmembers,includedescriptorclasses class * {
    native <methods>;
}

# Retain metadata used by reflection and Android component discovery.
-keepattributes *Annotation*, Signature, InnerClasses, EnclosingMethod

# Optional AndroidX integrations are not packaged by this app.
-dontwarn androidx.window.extensions.**
-dontwarn androidx.window.sidecar.**

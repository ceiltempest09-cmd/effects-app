// Host tests for the render graph: planner, executor, pool, history, XML reader.
// The CPU backend below really executes every pass on float images (it is a software renderer,
// not a mock): each pass id maps to a kernel that reads its bound inputs and writes its target.
//   g++ -std=c++20 -fno-exceptions -fno-rtti -I shared/cpp tests/native/render_graph_test.cpp shared/cpp/render_graph*.cpp shared/cpp/xml.cpp -lexpat
#include "render_graph.h"
#include "render_graph_xml.h"
#include <algorithm>

#include <cmath>
#include <cstdio>
#include <atomic>
#include <cstdlib>
#include <map>
#include <set>

using namespace am::rg;

static int gFailed = 0, gChecks = 0;
#define CHECK(cond) do { gChecks++; if (!(cond)) { gFailed++; std::printf("  FAIL %s:%d  %s\n", __FILE__, __LINE__, #cond); } } while (0)
#define CHECK_NEAR(a, b, eps) do { gChecks++; const double _a = (a), _b = (b); if (!(std::fabs(_a - _b) <= (eps))) { gFailed++; std::printf("  FAIL %s:%d  %s=%g vs %s=%g\n", __FILE__, __LINE__, #a, _a, #b, _b); } } while (0)

// ----------------------------------------------------------------- CPU reference backend
struct Img : Target {
    std::vector<float> px;
    float& at(int x, int y, int c) { return px[((size_t)y * width + x) * 4 + c]; }
    float at(int x, int y, int c) const { return px[((size_t)y * width + x) * 4 + c]; }
};

static float Wrapi(int i, int n, Wrap w, bool* inside) {
    *inside = true;
    if (i >= 0 && i < n) return (float)i;
    switch (w) {
        case Wrap::Repeat: return (float)(((i % n) + n) % n);
        case Wrap::Mirror: { int p = ((i % (2 * n)) + 2 * n) % (2 * n); return (float)(p < n ? p : 2 * n - 1 - p); }
        case Wrap::Decal: *inside = false; return 0;
        default: return (float)(i < 0 ? 0 : n - 1);
    }
}
static float Fetch(const Img& im, int x, int y, int c, Wrap w) {
    bool a, b;
    const float fx = Wrapi(x, im.width, w, &a), fy = Wrapi(y, im.height, w, &b);
    return a && b ? im.at((int)fx, (int)fy, c) : 0.0f;
}
// u,v in 0..1 over the whole image (resolution independent, like the Skia backend's layer-space coordinates)
static float Sample(const Img& im, float u, float v, int c, Filter f, Wrap w) {
    const float x = u * im.width - 0.5f, y = v * im.height - 0.5f;
    if (f == Filter::Nearest) return Fetch(im, (int)std::floor(x + 0.5f), (int)std::floor(y + 0.5f), c, w);
    const int x0 = (int)std::floor(x), y0 = (int)std::floor(y);
    const float tx = x - x0, ty = y - y0;
    return (Fetch(im, x0, y0, c, w) * (1 - tx) + Fetch(im, x0 + 1, y0, c, w) * tx) * (1 - ty) +
           (Fetch(im, x0, y0 + 1, c, w) * (1 - tx) + Fetch(im, x0 + 1, y0 + 1, c, w) * tx) * ty;
}

struct Ctx {
    const PassRun& run;
    Img& out;
    const BoundInput* in(const char* name) const {
        for (const BoundInput& b : run.inputs) if (*b.name == name) return &b;
        return nullptr;
    }
    float tex(const char* name, float u, float v, int c) const {
        const BoundInput* b = in(name);
        return b ? Sample(*static_cast<const Img*>(b->target), u, v, c, b->filter, b->wrap) : -999.0f;
    }
};
using Kernel = std::function<void(float u, float v, int x, int y, float* rgba, const Ctx&)>;

struct CpuBackend : Backend {
    std::map<std::string, Kernel> kernels;
    Format working = Format::RGBA16F;
    bool f16 = true, f32 = true;
    int alive = 0, runs = 0;
    int maxTex = 4096;
    int failCreateAfter = -1;                       // fail target creation after this many creates (memory pressure)
    int created = 0, createdShared = 0;
    std::set<Format> unshareable;                   // formats this backend cannot put in storage another backend can see
    std::vector<std::string> order;
    std::map<std::string, std::pair<int, int>> sizeOfOutput;
    std::map<std::string, std::vector<std::string>> inputNames;
    std::map<std::string, std::unique_ptr<Img>> textures;
    std::map<std::string, std::unique_ptr<Img>> blanks;
    const char* name() const override { return "cpu"; }
    bool supports(Lang l) const override { return l == Lang::SkSL; }
    bool supports(Format f) const override { return f == Format::RGBA8 || (f == Format::RGBA16F && f16) || (f == Format::RGBA32F && f32); }
    Format workingFormat() const override { return working; }
    int maxTextureSize() const override { return maxTex; }
    Target* create(int w, int h, Format) override {
        if (failCreateAfter >= 0 && created >= failCreateAfter) return nullptr;
        created++;
        auto* i = new Img();
        i->px.assign((size_t)w * h * 4, 0.123f);     // garbage on purpose: passes must clear or overwrite
        alive++;
        i->width = w; i->height = h;
        return i;
    }
    void destroy(Target* t) override { delete static_cast<Img*>(t); alive--; }
    bool canShare(Format f) const override { return supports(f) && !unshareable.count(f); }
    Target* createShared(int w, int h, Format f) override { Target* t = create(w, h, f); if (t) createdShared++; return t; }
    Target* texture(const TextureDesc& t) override {
        auto& slot = textures[t.id];
        if (!slot) {
            slot = std::make_unique<Img>();
            slot->width = t.width; slot->height = t.height;
            slot->px.resize((size_t)t.width * t.height * 4);
            if (t.source == "builtin:noise") {
                const auto n = NoisePixels(t.width, t.height, t.seed);
                for (size_t i = 0; i < n.size(); i++) slot->px[i] = n[i] / 255.0f;
            } else {
                for (int y = 0; y < t.height; y++) for (int x = 0; x < t.width; x++)
                    for (int c = 0; c < 4; c++) slot->at(x, y, c) = t.source == "builtin:ramp-x" ? (x + 0.5f) / t.width : (y + 0.5f) / t.height;
            }
        }
        return slot.get();
    }
    Target* blank(int w, int h, Format) override {
        auto& slot = blanks[std::to_string(w) + "x" + std::to_string(h)];
        if (!slot) { slot = std::make_unique<Img>(); slot->width = w; slot->height = h; slot->px.assign((size_t)w * h * 4, 0.0f); }
        return slot.get();
    }
    bool run(const PassRun& r, std::string* error) override {
        auto k = kernels.find(r.pass->id);
        if (k == kernels.end()) { *error = "no kernel for " + r.pass->id; return false; }
        runs++;
        order.push_back(r.pass->id);
        Img& out = *static_cast<Img*>(r.output);
        sizeOfOutput[r.pass->id] = {out.width, out.height};
        for (const BoundInput& b : r.inputs) inputNames[r.pass->id].push_back(*b.name);
        Ctx ctx{r, out};
        for (int y = 0; y < out.height; y++)
            for (int x = 0; x < out.width; x++) {
                float c[4];
                for (int i = 0; i < 4; i++) c[i] = r.clear ? 0.0f : out.at(x, y, i);   // clear=false keeps the contents (accumulation)
                float rgba[4] = {c[0], c[1], c[2], c[3]};
                const float u = (x + 0.5f) / out.width, v = (y + 0.5f) / out.height;
                k->second(u, v, x, y, rgba, ctx);
                for (int i = 0; i < 4; i++) {
                    float val = rgba[i];
                    if (r.pass->blend == Blend::Add && !r.clear) val += c[i];
                    out.at(x, y, i) = val;
                }
            }
        return true;
    }
};

// ----------------------------------------------------------------- builders
static PassDesc P(const char* id, const char* output, std::vector<PassInput> in) {
    PassDesc p;
    p.id = id;
    p.output = output;
    p.inputs = std::move(in);
    p.source = "half4 main(float2 c) { return half4(0); }";   // text is irrelevant to the CPU backend; the planner needs it non-empty
    p.file = std::string(id) + ".json";
    p.line = 3;
    return p;
}
static BufferDesc B(const char* id, float scale = 1, int history = 0, Format f = Format::Inherit) {
    BufferDesc b;
    b.id = id; b.scale = scale; b.history = history; b.format = f;
    return b;
}
static std::shared_ptr<const Plan> MakePlan(const GraphDesc& g, bool expectOk = true) {
    auto p = std::make_shared<Plan>(BuildPlan(g, PlanOptions{}));
    if (expectOk && !p->ok()) for (const Diag& d : p->diags) std::printf("    plan diag: %s\n", d.format().c_str());
    return p;
}
static std::unique_ptr<Img> MakeSource(int w, int h, const std::function<float(int, int, int)>& f) {
    auto s = std::make_unique<Img>();
    s->width = w; s->height = h; s->px.resize((size_t)w * h * 4);
    for (int y = 0; y < h; y++) for (int x = 0; x < w; x++) for (int c = 0; c < 4; c++) s->at(x, y, c) = f(x, y, c);
    return s;
}
static std::string Errors(const Plan& p) {
    std::string s;
    for (const Diag& d : p.diags) if (d.error) s += d.format() + "\n";
    return s;
}
static bool Has(const std::string& s, const char* needle) { return s.find(needle) != std::string::npos; }

// ----------------------------------------------------------------- tests
static void TestOnePassStillWorks() {
    std::printf("one-pass graph\n");
    GraphDesc g; g.effectId = "fx.one";
    g.passes = {P("only", "", {{"image", "source"}})};
    auto plan = MakePlan(g);
    CHECK(plan->ok() && plan->steps.size() == 1 && plan->peakLive == 1 && !plan->temporal);
    CpuBackend be;
    be.kernels["only"] = [](float u, float v, int, int, float* o, const Ctx& c) { for (int i = 0; i < 4; i++) o[i] = c.tex("image", u, v, i) * 0.5f; };
    Executor ex(be, plan);
    auto src = MakeSource(8, 8, [](int x, int, int) { return x / 8.0f; });
    float got = -1;
    FrameRequest r; r.frame = 0; r.width = 8; r.height = 8; r.source = src.get();
    auto res = ex.render(r, [&](Target* t) { got = static_cast<Img*>(t)->at(4, 4, 0); });
    CHECK(res.status == FrameResult::Ok);
    CHECK_NEAR(got, 0.5f * 4 / 8.0f, 1e-6);
    CHECK(res.timings.size() == 1);
}

static void TestTwoPassChaining() {
    std::printf("two passes: pass 1 output feeds pass 2\n");
    GraphDesc g; g.effectId = "fx.two";
    g.buffers = {B("mid")};
    g.passes = {P("double", "mid", {{"image", "source"}}), P("plus", "out", {{"image", "buffer:mid"}})};
    auto plan = MakePlan(g);
    CHECK(plan->ok() && plan->steps.size() == 2);
    CHECK(plan->steps[0].releaseAfter.empty() && plan->steps[1].releaseAfter.size() == 1);   // `mid` is freed right after its last reader
    CpuBackend be;
    be.kernels["double"] = [](float u, float v, int, int, float* o, const Ctx& c) { for (int i = 0; i < 4; i++) o[i] = c.tex("image", u, v, i) * 2; };
    be.kernels["plus"] = [](float u, float v, int, int, float* o, const Ctx& c) { for (int i = 0; i < 4; i++) o[i] = c.tex("image", u, v, i) + 0.25f; };
    Executor ex(be, plan);
    auto src = MakeSource(4, 4, [](int, int, int c) { return c == 0 ? 0.1f : 0.2f; });
    float r0 = 0, r1 = 0;
    FrameRequest r; r.width = 4; r.height = 4; r.source = src.get();
    ex.render(r, [&](Target* t) { r0 = static_cast<Img*>(t)->at(1, 1, 0); r1 = static_cast<Img*>(t)->at(1, 1, 1); });
    CHECK_NEAR(r0, 0.1f * 2 + 0.25f, 1e-6);
    CHECK_NEAR(r1, 0.2f * 2 + 0.25f, 1e-6);
    CHECK(be.order.size() == 2 && be.order[0] == "double" && be.order[1] == "plus");
}

static void TestOrderIgnoresDeclarationOrder() {
    std::printf("automatic ordering from dependencies\n");
    GraphDesc g; g.effectId = "fx.order"; g.output = "c";
    g.passes = {P("pc", "c", {{"a", "buffer:b"}, {"b2", "buffer:a"}}), P("pb", "b", {{"a", "buffer:a"}}), P("pa", "a", {{"image", "source"}})};
    auto plan = MakePlan(g);
    CHECK(plan->ok() && plan->steps.size() == 3);
    CHECK(g.passes[plan->steps[0].pass].id == "pa" || plan->desc.passes[plan->steps[0].pass].id == "pa");
    CHECK(plan->desc.passes[plan->steps[1].pass].id == "pb" && plan->desc.passes[plan->steps[2].pass].id == "pc");
}

static void TestBloomMultiScale() {
    std::printf("multi-scale bloom: several intermediate textures at different sizes\n");
    GraphDesc g; g.effectId = "fx.bloom"; g.output = "out";
    g.buffers = {B("bright", 1), B("d1", 0.5f), B("d2", 0.25f), B("blur2", 0.25f)};
    g.passes = {
        P("threshold", "bright", {{"image", "source"}}),
        P("down1", "d1", {{"image", "buffer:bright"}}),
        P("down2", "d2", {{"image", "buffer:d1"}}),
        P("blur", "blur2", {{"image", "buffer:d2"}}),
        P("combine", "out", {{"image", "source"}, {"glow1", "buffer:d1"}, {"glow2", "buffer:blur2"}}),
    };
    auto plan = MakePlan(g);
    CHECK(plan->ok() && plan->steps.size() == 5 && plan->culled.empty());
    CHECK(plan->peakLive <= 3);                                    // not one target per buffer: temporaries are recycled
    CpuBackend be;
    be.kernels["threshold"] = [](float u, float v, int, int, float* o, const Ctx& c) { for (int i = 0; i < 4; i++) o[i] = c.tex("image", u, v, 0) > 0.5f ? c.tex("image", u, v, i) : 0.0f; };
    const Kernel copy = [](float u, float v, int, int, float* o, const Ctx& c) { for (int i = 0; i < 4; i++) o[i] = c.tex("image", u, v, i); };
    be.kernels["down1"] = copy;
    be.kernels["down2"] = copy;
    be.kernels["blur"] = [](float u, float v, int, int, float* o, const Ctx& c) {   // 5x5 tent in the 16x16 buffer
        const BoundInput* b = c.in("image");
        const Img& im = *static_cast<const Img*>(b->target);
        const float tx = 1.0f / im.width, ty = 1.0f / im.height;
        float sum = 0, wsum = 0;
        for (int j = -2; j <= 2; j++) for (int i = -2; i <= 2; i++) {
            const float w = (3 - std::abs(i)) * (3 - std::abs(j));
            sum += w * Sample(im, u + i * tx, v + j * ty, 0, Filter::Linear, Wrap::Clamp);
            wsum += w;
        }
        for (int i = 0; i < 4; i++) o[i] = sum / wsum;
    };
    be.kernels["combine"] = [](float u, float v, int, int, float* o, const Ctx& c) {
        for (int i = 0; i < 4; i++) o[i] = c.tex("image", u, v, i) + 0.5f * c.tex("glow1", u, v, 0) + 1.0f * c.tex("glow2", u, v, 0);
    };
    Executor ex(be, plan);
    auto src = MakeSource(64, 64, [](int x, int y, int) { return (x >= 30 && x < 34 && y >= 30 && y < 34) ? 1.0f : 0.0f; });
    Img result;
    FrameRequest r; r.width = 64; r.height = 64; r.source = src.get();
    auto res = ex.render(r, [&](Target* t) { result = *static_cast<Img*>(t); });
    CHECK(res.status == FrameResult::Ok && be.runs == 5);
    CHECK(be.sizeOfOutput["threshold"] == std::make_pair(64, 64));
    CHECK(be.sizeOfOutput["down1"] == std::make_pair(32, 32));
    CHECK(be.sizeOfOutput["down2"] == std::make_pair(16, 16));
    CHECK(be.sizeOfOutput["combine"] == std::make_pair(64, 64));
    CHECK(be.inputNames["combine"].size() == 3);
    float onSquare = result.at(31, 31, 0), nearby = result.at(40, 31, 0), far = result.at(2, 2, 0);
    CHECK(onSquare > 1.0f);                     // glow adds light on top of the source
    CHECK(nearby > 0.01f);                      // and spreads outward: only possible through the low-res passes
    CHECK_NEAR(far, 0.0f, 1e-6);
    CHECK(nearby < onSquare);
    CHECK_NEAR(result.at(28, 31, 0), result.at(35, 31, 0), 1e-4);   // symmetric about the square
    // energy: low-res blur must not create light out of nothing (source 16 + glow bounded)
    double total = 0; for (int y = 0; y < 64; y++) for (int x = 0; x < 64; x++) total += result.at(x, y, 0);
    CHECK(total > 16.0 && total < 16.0 * (1 + 0.5 + 1.0) + 1.0);
}

static void TestDisplacementMultiTexture() {
    std::printf("displacement: source + generated map + noise texture sampled in one pass\n");
    GraphDesc g; g.effectId = "fx.displace"; g.output = "out";
    TextureDesc ramp; ramp.id = "ramp"; ramp.source = "builtin:ramp-x"; ramp.width = 64; ramp.height = 4; ramp.filter = Filter::Linear; ramp.wrap = Wrap::Clamp;
    TextureDesc noise; noise.id = "noise"; noise.source = "builtin:noise"; noise.width = 32; noise.height = 32; noise.seed = 7;
    g.textures = {ramp, noise};
    g.buffers = {B("map", 0.5f)};
    g.passes = {
        P("makemap", "map", {{"ramp", "texture:ramp"}}),
        P("displace", "out", {{"image", "source"}, {"map", "buffer:map"}, {"noise", "texture:noise"}}),
    };
    auto plan = MakePlan(g);
    CHECK(plan->ok());
    CpuBackend be;
    be.kernels["makemap"] = [](float u, float v, int, int, float* o, const Ctx& c) { const float t = c.tex("ramp", u, v, 0); for (int i = 0; i < 3; i++) o[i] = 0.5f + 0.25f * t; o[3] = 1; };
    be.kernels["displace"] = [](float u, float v, int, int, float* o, const Ctx& c) {
        const float d = c.tex("map", u, v, 0) - 0.5f;
        const float n = c.tex("noise", u, v, 0);          // sampled too; weight 0 so the analytic answer stays exact
        for (int i = 0; i < 4; i++) o[i] = c.tex("image", u + d * 0.2f + n * 0.0f, v, i);
    };
    Executor ex(be, plan);
    auto src = MakeSource(64, 8, [](int x, int, int c) { return c == 3 ? 1.0f : (x + 0.5f) / 64.0f; });   // horizontal ramp = u
    Img result;
    FrameRequest r; r.width = 64; r.height = 8; r.source = src.get();
    ex.render(r, [&](Target* t) { result = *static_cast<Img*>(t); });
    CHECK(be.inputNames["displace"].size() == 3);
    for (int x = 8; x < 48; x += 8) {
        const float u = (x + 0.5f) / 64.0f;
        CHECK_NEAR(result.at(x, 4, 0), u + 0.25f * u * 0.2f, 4e-3);           // analytic: u + (0.25u)*0.2
    }
    CHECK(be.textures.count("noise") == 1);
}

static std::shared_ptr<const Plan> FeedbackPlan(int history = 1) {
    GraphDesc g; g.effectId = "fx.trail"; g.output = "acc";
    g.buffers = {B("acc", 1, history, Format::RGBA16F)};
    g.passes = {P("mix", "acc", {{"image", "source"}, {"prev", "buffer:acc@1"}})};
    return MakePlan(g);
}
static void AddFeedbackKernel(CpuBackend& be) {
    be.kernels["mix"] = [](float u, float v, int, int, float* o, const Ctx& c) {
        for (int i = 0; i < 4; i++) o[i] = std::max(c.tex("image", u, v, i), 0.5f * c.tex("prev", u, v, i));
    };
}
static std::unique_ptr<Img> Impulse(int w, int h, bool on) { return MakeSource(w, h, [on](int x, int y, int) { return on && x == 2 && y == 2 ? 1.0f : 0.0f; }); }
static float Run(Executor& ex, int64_t frame, Img* src, uint64_t sig = 0, std::function<Target*(int64_t)> at = nullptr, FrameResult* out = nullptr) {
    float v = -1;
    FrameRequest r; r.frame = frame; r.width = src->width; r.height = src->height; r.source = src; r.signature = sig; r.sourceAt = at;
    FrameResult res = ex.render(r, [&](Target* t) { v = static_cast<Img*>(t)->at(2, 2, 0); });
    if (out) *out = res;
    return res.status == FrameResult::Ok ? v : -2.0f;
}

static void TestTemporalFeedback() {
    std::printf("ping-pong temporal feedback across frames\n");
    auto plan = FeedbackPlan();
    CHECK(plan->temporal && plan->steps.size() == 1);
    CpuBackend be; AddFeedbackKernel(be);
    {
        Executor ex(be, plan);
        auto on = Impulse(8, 8, true), off = Impulse(8, 8, false);
        CHECK_NEAR(Run(ex, 0, on.get()), 1.0, 1e-6);
        for (int f = 1; f <= 6; f++) CHECK_NEAR(Run(ex, f, off.get()), std::pow(0.5, f), 1e-6);   // trail decays 1, .5, .25 ...
        CHECK(ex.poolStats().created == 2);                      // exactly one ping-pong pair, nothing else
        for (int f = 7; f < 400; f++) Run(ex, f, off.get());
        CHECK(ex.poolStats().created == 2 && ex.poolStats().live <= 2);   // no per-frame allocation, no growth
        CHECK(plan->desc.buffers[0].history == 1);
    }
    CHECK(be.alive == 0);                                        // destructor returned everything
}

static void TestSeekDeterminism() {
    std::printf("timeline seek: reset and replay\n");
    auto on = Impulse(8, 8, true), off = Impulse(8, 8, false);
    auto sourceAt = [&](int64_t f) -> Target* { return f == 0 ? on.get() : off.get(); };
    // reference: play 0..10 sequentially
    float sequential;
    {
        CpuBackend be; AddFeedbackKernel(be);
        Executor ex(be, FeedbackPlan());
        Run(ex, 0, on.get());
        for (int f = 1; f < 10; f++) Run(ex, f, off.get());
        sequential = Run(ex, 10, off.get());
        CHECK_NEAR(sequential, std::pow(0.5, 10), 1e-9);
    }
    // seek=reset: jumping starts a fresh history; same answer every time and independent of where we came from
    {
        GraphDesc g; g.effectId = "fx.trail"; g.output = "acc";
        g.buffers = {B("acc", 1, 1)}; g.passes = {P("mix", "acc", {{"image", "source"}, {"prev", "buffer:acc@1"}})};
        CpuBackend be; AddFeedbackKernel(be);
        Executor a(be, MakePlan(g)), b(be, MakePlan(g));
        Run(a, 0, on.get()); Run(a, 1, off.get());
        FrameResult ra;
        const float fromA = Run(a, 10, off.get(), 0, nullptr, &ra);
        const float fromB = Run(b, 10, off.get());               // never saw frames 0/1
        CHECK(fromA == fromB && ra.historyReset);
        CHECK_NEAR(fromA, 0.0, 1e-9);                            // documented: history starts empty after a jump
    }
    // seek=replay: history is rebuilt from the layer image at earlier frames -> identical to sequential playback
    {
        GraphDesc g; g.effectId = "fx.trail"; g.output = "acc"; g.seek = SeekMode::Replay; g.maxReplay = 60;
        g.buffers = {B("acc", 1, 1)}; g.passes = {P("mix", "acc", {{"image", "source"}, {"prev", "buffer:acc@1"}})};
        CpuBackend be; AddFeedbackKernel(be);
        Executor ex(be, MakePlan(g));
        Run(ex, 0, on.get()); Run(ex, 1, off.get());
        FrameResult res;
        const float jumped = Run(ex, 10, off.get(), 0, sourceAt, &res);
        CHECK(res.status == FrameResult::Ok && res.replayed == 10 && res.historyReset);
        CHECK(jumped == sequential);                             // bit-identical
        const float backwards = Run(ex, 4, off.get(), 0, sourceAt, &res);
        CHECK_NEAR(backwards, std::pow(0.5, 4), 1e-9);
        // replay requested but the caller cannot supply earlier images: explicit note, never silent
        CpuBackend be2; AddFeedbackKernel(be2);
        Executor ex2(be2, MakePlan(g));
        Run(ex2, 10, off.get(), 0, nullptr, &res);
        CHECK(!res.notes.empty() && Has(res.notes[0].message, "replay"));
    }
}

static void TestRedoSameFrameAndSignature() {
    std::printf("re-rendering a frame / property edits\n");
    CpuBackend be; AddFeedbackKernel(be);
    Executor ex(be, FeedbackPlan());
    auto on = Impulse(8, 8, true), off = Impulse(8, 8, false);
    Run(ex, 0, on.get());
    const float a = Run(ex, 1, off.get());
    const float again = Run(ex, 1, off.get());
    CHECK(a == again && std::fabs(a - 0.5f) < 1e-6);             // redo does not feed itself
    auto half = MakeSource(8, 8, [](int x, int y, int) { return x == 2 && y == 2 ? 0.9f : 0.0f; });
    CHECK_NEAR(Run(ex, 1, half.get()), 0.9f, 1e-6);              // an upstream edit at the same frame is not served from a stale cache
    CHECK_NEAR(Run(ex, 2, off.get()), 0.45f, 1e-6);              // and the next frame builds on the latest redo
    FrameResult res;
    Run(ex, 3, off.get(), /*signature*/ 99, nullptr, &res);      // effect properties changed: history is invalid
    CHECK(res.historyReset);
    CHECK_NEAR(Run(ex, 4, off.get(), 99), 0.0, 1e-9);
    // area resized: reset too
    auto big = Impulse(16, 16, false);
    Run(ex, 5, big.get(), 99, nullptr, &res);
    CHECK(res.historyReset);
}

static void TestInvalidGraphs() {
    std::printf("actionable errors\n");
    PlanOptions opt;
    {   // cycle
        GraphDesc g; g.effectId = "fx.cycle";
        g.passes = {P("a", "ba", {{"x", "buffer:bb"}}), P("b", "bb", {{"x", "buffer:ba"}})};
        const auto p = BuildPlan(g, opt);
        CHECK(!p.ok());
        const std::string e = Errors(p);
        CHECK(Has(e, "dependency cycle") && Has(e, "a -> b -> a") && Has(e, "@1"));
        CHECK(Has(e, "effect 'fx.cycle'") && Has(e, "pass 'a'") && Has(e, "a.json:3") && Has(e, "backend skia"));
    }
    {   // feedback is fine when it goes through history
        GraphDesc g; g.effectId = "fx.loop"; g.buffers = {B("ba", 1, 1)};
        g.passes = {P("a", "ba", {{"x", "buffer:bb"}, {"p", "buffer:ba@1"}}), P("b", "bb", {{"x", "source"}})};
        CHECK(BuildPlan(g, opt).ok());
    }
    {   // unknown buffer with suggestion
        GraphDesc g; g.effectId = "fx.typo"; g.buffers = {B("bright")};
        g.passes = {P("a", "bright", {{"x", "source"}}), P("b", "out", {{"x", "buffer:brigth"}})};
        const std::string e = Errors(BuildPlan(g, opt));
        CHECK(Has(e, "unknown buffer 'brigth'") && Has(e, "Did you mean 'bright'"));
    }
    {   // read/write hazard
        GraphDesc g; g.effectId = "fx.hazard"; g.buffers = {B("x")};
        g.passes = {P("a", "x", {{"i", "source"}}), P("b", "x", {{"i", "buffer:x"}})};
        g.passes[1].clear = false; g.passes[1].blend = Blend::Add;
        const std::string e = Errors(BuildPlan(g, opt));
        CHECK(Has(e, "same pass") && Has(e, "hazard"));
    }
    {   // history deeper than declared
        GraphDesc g; g.effectId = "fx.depth"; g.buffers = {B("x", 1, 1)};
        g.passes = {P("a", "x", {{"i", "source"}, {"p", "buffer:x@2"}})};
        CHECK(Has(Errors(BuildPlan(g, opt)), "history >= 2"));
    }
    {   // previous frame of a buffer that is not kept
        GraphDesc g; g.effectId = "fx.nohist"; g.buffers = {B("x", 1, 0)};
        g.passes = {P("a", "x", {{"i", "source"}, {"p", "buffer:x@1"}})};
        CHECK(!BuildPlan(g, opt).ok());
    }
    {   // glsl on a Skia backend
        GraphDesc g; g.effectId = "fx.glsl"; g.passes = {P("a", "", {{"i", "source"}})};
        g.passes[0].lang = Lang::GLSLES;
        const std::string e = Errors(BuildPlan(g, opt));
        CHECK(Has(e, "glsl-es") && Has(e, "cannot run"));
    }
    {   // missing texture, bad id, empty source, unsupported texture source
        GraphDesc g; g.effectId = "fx.bad";
        TextureDesc t; t.id = "t1"; t.source = "file:foo.png"; g.textures = {t};
        g.passes = {P("a", "", {{"i", "texture:nope"}})};
        g.passes[0].source = "  ";
        const std::string e = Errors(BuildPlan(g, opt));
        CHECK(Has(e, "no shader source") && Has(e, "only builtin:noise"));
        GraphDesc g2; g2.effectId = "fx.bad2"; g2.passes = {P("a", "", {{"i", "texture:nope"}})};
        CHECK(Has(Errors(BuildPlan(g2, opt)), "unknown texture 'nope'"));
        GraphDesc g3; g3.effectId = "fx.bad3"; g3.passes = {P("bad id", "", {{"i", "source"}})};
        CHECK(Has(Errors(BuildPlan(g3, opt)), "not a valid name"));
    }
    {   // second writer clears the first writer's work
        GraphDesc g; g.effectId = "fx.over"; g.buffers = {B("x")};
        g.passes = {P("a", "x", {{"i", "source"}}), P("b", "x", {{"i", "source"}})};
        CHECK(Has(Errors(BuildPlan(g, opt)), "overwrites buffer 'x'"));
    }
    {   // output never written / no passes / too many
        GraphDesc g; g.effectId = "fx.empty";
        CHECK(Has(Errors(BuildPlan(g, opt)), "no passes"));
        GraphDesc h; h.effectId = "fx.out"; h.output = "ghost"; h.passes = {P("a", "", {{"i", "source"}})};
        CHECK(Has(Errors(BuildPlan(h, opt)), "output 'ghost'"));
        GraphDesc m; m.effectId = "fx.many";
        for (int i = 0; i < 65; i++) m.passes.push_back(P(("p" + std::to_string(i)).c_str(), "", {{"i", "source"}}));
        CHECK(Has(Errors(BuildPlan(m, opt)), "limit is 64"));
    }
}

static void TestCulling() {
    std::printf("culling and accumulation\n");
    GraphDesc g; g.effectId = "fx.cull"; g.output = "out";
    g.passes = {P("used", "out", {{"i", "source"}}), P("dead", "d", {{"i", "source"}})};
    const auto p = BuildPlan(g, PlanOptions{});
    CHECK(p.ok() && p.steps.size() == 1 && p.culled.size() == 1 && p.culled[0] == "dead");
    CHECK(std::any_of(p.diags.begin(), p.diags.end(), [](const Diag& d) { return !d.error && d.pass == "dead"; }));

    // accumulate: two passes add into one buffer (clear=false, additive), garbage in a fresh target must not leak into the sum
    GraphDesc a; a.effectId = "fx.acc"; a.output = "sum"; a.buffers = {B("sum")};
    a.passes = {P("one", "sum", {{"i", "source"}}), P("two", "sum", {{"i", "source"}})};
    a.passes[1].clear = false; a.passes[1].blend = Blend::Add;
    auto plan = MakePlan(a);
    CHECK(plan->ok() && plan->steps[0].firstWriter && !plan->steps[1].firstWriter);
    CpuBackend be;
    be.kernels["one"] = be.kernels["two"] = [](float u, float v, int, int, float* o, const Ctx& c) { for (int i = 0; i < 4; i++) o[i] = c.tex("i", u, v, i); };
    Executor ex(be, plan);
    auto src = MakeSource(4, 4, [](int, int, int) { return 0.25f; });
    float v = 0; FrameRequest r; r.width = 4; r.height = 4; r.source = src.get();
    ex.render(r, [&](Target* t) { v = static_cast<Img*>(t)->at(0, 0, 0); });
    CHECK_NEAR(v, 0.5, 1e-6);
}

static void TestPoolBoundedAndNoLeak() {
    std::printf("render-target pool: no leak, bounded growth, budget, cancel, resize\n");
    GraphDesc g; g.effectId = "fx.pool"; g.output = "out";
    g.buffers = {B("a"), B("b", 0.5f), B("c", 0.25f)};
    g.passes = {P("pa", "a", {{"i", "source"}}), P("pb", "b", {{"i", "buffer:a"}}), P("pc", "c", {{"i", "buffer:b"}}), P("po", "out", {{"i", "source"}, {"c", "buffer:c"}})};
    auto plan = MakePlan(g);
    CpuBackend be;
    const Kernel copy = [](float u, float v, int, int, float* o, const Ctx& c) { for (int i = 0; i < 4; i++) o[i] = c.tex("i", u, v, i); };
    for (const char* k : {"pa", "pb", "pc", "po"}) be.kernels[k] = copy;
    {
        Executor ex(be, plan);
        auto src = MakeSource(32, 32, [](int, int, int) { return 0.5f; });
        FrameRequest r; r.width = 32; r.height = 32; r.source = src.get();
        ex.render(r, [](Target*) {});
        const auto first = ex.poolStats();
        for (int f = 1; f < 2000; f++) { r.frame = f; ex.render(r, [](Target*) {}); }
        const auto last = ex.poolStats();
        CHECK(last.created == first.created && last.bytes == first.bytes && last.live == 0);
        CHECK(last.reused > 1000);
        // resizing the area (user changes the layer): old sizes are trimmed after a few idle frames
        auto big = MakeSource(64, 64, [](int, int, int) { return 0.5f; });
        r.source = big.get(); r.width = 64; r.height = 64;
        for (int f = 0; f < 40; f++) { r.frame = 5000 + f; ex.render(r, [](Target*) {}); }
        const auto resized = ex.poolStats();
        CHECK(resized.bytes < first.bytes * 6 && resized.live == 0);
        CHECK(be.alive == resized.live + resized.idle);
        // low memory
        ex.dropAll();
        CHECK(ex.poolStats().bytes == 0 && be.alive == 0);
        // cancellation releases everything
        std::atomic<bool> stop{true};
        r.cancel = &stop;
        const auto res = ex.render(r, [](Target*) {});
        CHECK(res.status == FrameResult::Cancelled && ex.poolStats().live == 0);
        r.cancel = nullptr;
        // memory pressure: allocation refused after 2 targets -> Failed with a message, nothing leaked
        ex.dropAll();
        be.created = 0; be.failCreateAfter = 2;
        const auto oom = ex.render(r, [](Target*) {});
        CHECK(oom.status == FrameResult::Failed && Has(oom.error, "out of GPU memory") && ex.poolStats().live == 0);
        be.failCreateAfter = -1;
        CHECK(ex.render(r, [](Target*) {}).status == FrameResult::Ok);        // and it recovers
        // byte budget: refuse politely instead of growing without bound
        ex.dropAll();
        ex.setBudget(32 * 32 * 4 * 4 + 100);                                  // room for ~1 full-size 16F buffer only
        const auto tight = ex.render(r, [](Target*) {});
        CHECK(tight.status == FrameResult::Failed && Has(tight.error, "out of GPU memory") && ex.poolStats().live == 0);
        CHECK(ex.poolStats().bytes <= 32 * 32 * 4 * 4 + 100);
        ex.setBudget(0);
        CHECK(ex.render(r, [](Target*) {}).status == FrameResult::Ok);
    }
    CHECK(be.alive == 0);
}

static void TestFormatNegotiation() {
    std::printf("precision / format fallback\n");
    GraphDesc g; g.effectId = "fx.fmt"; g.output = "hdr";
    BufferDesc hdr = B("hdr", 1, 0, Format::RGBA16F);
    g.buffers = {hdr}; g.passes = {P("a", "hdr", {{"i", "source"}})};
    auto plan = MakePlan(g);
    CpuBackend be; be.f16 = false; be.f32 = false; be.working = Format::RGBA8;
    be.kernels["a"] = [](float u, float v, int, int, float* o, const Ctx& c) { for (int i = 0; i < 4; i++) o[i] = c.tex("i", u, v, i); };
    Executor ex(be, plan);
    auto src = MakeSource(4, 4, [](int, int, int) { return 1.0f; });
    FrameRequest r; r.width = 4; r.height = 4; r.source = src.get();
    Format seen = Format::Inherit;
    auto res = ex.render(r, [&](Target* t) { seen = t->format; });
    CHECK(res.status == FrameResult::Ok && seen == Format::RGBA8);
    CHECK(res.notes.size() == 1 && !res.notes[0].error && Has(res.notes[0].message, "rgba16f"));
    g.buffers[0].precision = Precision::Required;
    CpuBackend be2; be2.f16 = false; be2.working = Format::RGBA8; be2.kernels = be.kernels;
    Executor ex2(be2, MakePlan(g));
    auto res2 = ex2.render(r, [](Target*) {});
    CHECK(res2.status == FrameResult::Failed && Has(res2.error, "precision=required") && Has(res2.error, "capability"));
}

static void TestXmlRoundTrip() {
    std::printf("runtime XML reader\n");
    const char* xml =
        "<effect id=\"fx.glow2\" graph=\"2\" output=\"out\" seek=\"replay\" max_replay=\"30\" future=\"yes\">"
        "<param name=\"strength\" value=\"1\"/>"
        "<texture id=\"noise\" source=\"builtin:noise\" width=\"64\" height=\"64\" seed=\"3\" wrap=\"repeat\" tag=\"x\"/>"
        "<buffer id=\"hist\" scale=\"0.5\" format=\"rgba16f\" precision=\"required\" history=\"1\" filter=\"linear\" keep=\"me\"/>"
        "<pass id=\"p1\" lang=\"sksl\" output=\"hist\" blend=\"over\" clear=\"false\" after=\"p0\" file=\"a.json\" line=\"7\" note=\"hello\">"
        "<source>half4 main(float2 c) { return half4(1); }</source><input name=\"image\" ref=\"source\"/><input name=\"prev\" ref=\"buffer:hist@1\"/>"
        "<const name=\"k\" value=\"1, 2.5\"/><define name=\"TAPS\" value=\"9\"/><mystery>keep</mystery></pass>"
        "<surprise>1</surprise></effect>";
    std::string err;
    auto root = am::ParseXml(xml, &err);
    CHECK(root && am::rg::IsGraphXml(*root));
    GraphDesc g; std::vector<Diag> diags;
    CHECK(ParseGraphXml(*root, &g, &diags) && diags.empty());
    CHECK(g.effectId == "fx.glow2" && g.output == "out" && g.seek == SeekMode::Replay && g.maxReplay == 30);
    CHECK(g.extra["future"] == "yes" && g.extra["child:surprise"] == "1");                      // unknown metadata survives
    CHECK(g.textures.size() == 1 && g.textures[0].seed == 3 && g.textures[0].wrap == Wrap::Repeat && g.textures[0].extra["tag"] == "x");
    CHECK(g.buffers.size() == 1 && g.buffers[0].precision == Precision::Required && g.buffers[0].history == 1 && g.buffers[0].scale == 0.5f && g.buffers[0].extra["keep"] == "me");
    CHECK(g.passes.size() == 1);
    const PassDesc& p = g.passes[0];
    CHECK(p.blend == Blend::SrcOver && !p.clear && p.after.size() == 1 && p.file == "a.json" && p.line == 7 && p.extra.at("note") == "hello" && p.extra.at("child:mystery") == "keep");
    CHECK(p.inputs.size() == 2 && p.inputs[1].ref == "buffer:hist@1" && p.constants[0].value.size() == 2 && p.constants[0].value[1] == 2.5f && p.defines.at("TAPS") == "9");
    CHECK(p.source.find("half4 main") != std::string::npos);

    // malformed values and a newer schema are reported, not swallowed
    auto bad = am::ParseXml("<effect id=\"fx.bad\" graph=\"9\"><buffer id=\"b\" format=\"rgb565\" scale=\"abc\"/><pass id=\"p\" blend=\"dodge\"><source>x</source></pass></effect>", &err);
    GraphDesc g2; std::vector<Diag> d2;
    CHECK(!ParseGraphXml(*bad, &g2, &d2));
    std::string all; for (const Diag& d : d2) all += d.format() + "\n";
    CHECK(Has(all, "newer than this build") && Has(all, "not a valid format") && Has(all, "scale is not a number") && Has(all, "not a valid blend"));
    CHECK(Has(all, "pass 'p'"));
    // a plain one-pass file is not a graph
    auto old = am::ParseXml("<effect id=\"fx.old\" sksl=\"half4 main(float2 c){return half4(1);}\"><param name=\"a\" value=\"1\"/></effect>", &err);
    CHECK(!am::rg::IsGraphXml(*old));
}

static void TestTimingsAndDiagnostics() {
    std::printf("diagnostics: pass timings, runtime failure names the pass\n");
    GraphDesc g; g.effectId = "fx.diag"; g.output = "out"; g.buffers = {B("m")};
    g.passes = {P("first", "m", {{"i", "source"}}), P("second", "out", {{"i", "buffer:m"}})};
    g.passes[1].file = "diag.json"; g.passes[1].line = 21;
    CpuBackend be;
    be.kernels["first"] = [](float u, float v, int, int, float* o, const Ctx& c) { for (int i = 0; i < 4; i++) o[i] = c.tex("i", u, v, i); };
    Executor ex(be, MakePlan(g));       // no kernel for "second": the backend fails it
    auto src = MakeSource(4, 4, [](int, int, int) { return 1.0f; });
    FrameRequest r; r.width = 4; r.height = 4; r.source = src.get();
    auto res = ex.render(r, [](Target*) {});
    CHECK(res.status == FrameResult::Failed && Has(res.error, "pass 'second'") && Has(res.error, "diag.json:21") && Has(res.error, "backend cpu") && Has(res.error, "fx.diag"));
    CHECK(ex.poolStats().live == 0);
}

// ----------------------------------------------------------------- multi-language / multi-backend
// A second CPU "device" that shares memory with the first, so a hand-off is a real zero-copy protocol exchange whose ORDER is logged.
// It stands in for a native backend: it is a graph-logic test double, not a GLSL implementation.
struct Dev : CpuBackend {
    std::string nm;
    std::set<Lang> langs;
    bool share = true;
    std::string refuse;                      // non-empty: accepts() refuses every pass with this message
    std::vector<std::string>* log = nullptr;
    int handoffsIn = 0;
    const char* name() const override { return nm.c_str(); }
    bool supports(Lang l) const override { return langs.count(l) > 0; }
    bool accepts(const PassDesc& p, Diag* why) override {
        if (!supports(p.lang)) return false;
        if (refuse.empty()) return true;
        why->message = refuse;
        return false;
    }
    bool run(const PassRun& r, std::string* error) override {
        if (log) log->push_back(nm + ".run:" + r.pass->id);
        return CpuBackend::run(r, error);
    }
    bool release(Target*, Backend& to, std::string* error) override {
        if (!share) { *error = nm + " cannot share storage with " + to.name(); return false; }
        if (log) log->push_back(nm + ".release>" + to.name());
        return true;
    }
    Target* acquire(Backend& from, Target* t, bool forWrite, std::string* error) override {
        if (!share) { *error = "no shared storage"; return nullptr; }
        handoffsIn++;
        if (log) log->push_back(nm + ".acquire<" + from.name() + (forWrite ? ":w" : ":r"));
        return t;
    }
    void relinquish(Target*) override { if (log) log->push_back(nm + ".relinquish"); }
    void reclaim(Target*, Backend& user) override { if (log) log->push_back(nm + ".reclaim<" + user.name()); }
};

static std::shared_ptr<const Plan> MakeMixedPlan(const GraphDesc& g) {
    PlanOptions o;
    o.backend = "skia+native";
    o.languages = {Lang::SkSL, Lang::GLSLES, Lang::GLSL, Lang::VulkanGLSL, Lang::SPIRV};
    auto p = std::make_shared<Plan>(BuildPlan(g, o));
    if (!p->ok()) for (const Diag& d : p->diags) std::printf("    plan diag: %s\n", d.format().c_str());
    return p;
}
static Kernel Scale(float k) { return [k](float u, float v, int, int, float* o, const Ctx& c) { for (int i = 0; i < 4; i++) o[i] = c.tex("i", u, v, i) * k; }; }
static Kernel Offset(float d) { return [d](float u, float v, int, int, float* o, const Ctx& c) { for (int i = 0; i < 4; i++) o[i] = c.tex("i", u, v, i) + d; }; }
static bool InOrder(const std::vector<std::string>& log, std::initializer_list<const char*> want) {
    size_t at = 0;
    for (const char* w : want) {
        while (at < log.size() && log[at] != w) at++;
        if (at == log.size()) return false;
        at++;
    }
    return true;
}

static void TestMixedLanguageGraph() {
    std::printf("mixed languages: SkSL -> GLSL ES -> SkSL, with hand-offs\n");
    GraphDesc g; g.effectId = "fx.mixed";
    g.buffers = {B("m1"), B("m2")};
    g.passes = {P("a", "m1", {{"i", "source"}}), P("b", "m2", {{"i", "buffer:m1"}}), P("c", "out", {{"i", "buffer:m2"}})};
    g.passes[1].lang = Lang::GLSLES;
    auto plan = MakeMixedPlan(g);
    CHECK(plan->ok() && plan->steps.size() == 3);
    std::vector<std::string> log;
    Dev skia, native;
    skia.nm = "skia"; skia.langs = {Lang::SkSL}; skia.log = &log;
    native.nm = "native"; native.langs = {Lang::GLSLES, Lang::SPIRV}; native.log = &log;
    skia.kernels["a"] = Scale(0.5f); native.kernels["b"] = Offset(0.25f); skia.kernels["c"] = Scale(2.0f);
    Executor ex(std::vector<Backend*>{&skia, &native}, plan);
    auto src = MakeSource(4, 4, [](int, int, int) { return 0.4f; });
    FrameRequest r; r.width = 4; r.height = 4; r.source = src.get();
    float got = -1;
    auto res = ex.render(r, [&](Target* t) { got = static_cast<Img*>(t)->at(1, 1, 0); });
    CHECK(res.status == FrameResult::Ok);
    CHECK_NEAR(got, (0.4f * 0.5f + 0.25f) * 2.0f, 1e-6);                   // 0.9: every pass ran, in order, on the right data
    CHECK(ex.backendOfStep(0) == 0 && ex.backendOfStep(1) == 1 && ex.backendOfStep(2) == 0);
    CHECK(native.runs == 1 && skia.runs == 2);                              // GLSL ES ran only on the native backend
    // m1 (written by skia) is read by native: skia releases to native BEFORE native acquires and runs; the view dies after the run;
    // m2 (home native) is read by skia: native releases to skia before skia runs c.
    CHECK(InOrder(log, {"skia.run:a", "skia.release>native", "native.acquire<skia:r", "native.run:b", "native.relinquish",
                        "native.release>skia", "skia.acquire<native:r", "skia.run:c", "skia.relinquish"}));
    CHECK(ex.poolStats().live == 0);
}

static void TestHandoffOfFinalAndOutputs() {
    std::printf("hand-off: native result consumed by the primary backend; native pass writing a skia-owned buffer\n");
    {
        GraphDesc g; g.effectId = "fx.tail";
        g.buffers = {B("m")};
        g.passes = {P("a", "m", {{"i", "source"}}), P("b", "out", {{"i", "buffer:m"}})};
        g.passes[1].lang = Lang::SPIRV;
        std::vector<std::string> log;
        Dev skia, native;
        skia.nm = "skia"; skia.langs = {Lang::SkSL}; skia.log = &log;
        native.nm = "native"; native.langs = {Lang::SPIRV}; native.log = &log;
        skia.kernels["a"] = Scale(1.0f); native.kernels["b"] = Offset(0.5f);
        Executor ex(std::vector<Backend*>{&skia, &native}, MakeMixedPlan(g));
        auto src = MakeSource(2, 2, [](int, int, int) { return 0.25f; });
        FrameRequest r; r.width = 2; r.height = 2; r.source = src.get();
        float got = -1;
        std::vector<std::string> atConsume;
        auto res = ex.render(r, [&](Target* t) { got = static_cast<Img*>(t)->at(0, 0, 0); atConsume = log; });
        CHECK(res.status == FrameResult::Ok);
        CHECK_NEAR(got, 0.75f, 1e-6);
        // the consumer (primary) was given its view BEFORE it drew, and gave it up after
        CHECK(InOrder(atConsume, {"native.run:b", "native.release>skia", "skia.acquire<native:r"}));
        CHECK(log.back() == "skia.relinquish");
    }
    {
        // 'second' writes buffer 'm' that 'first' created on skia, from the native backend (blend over, no clear)
        GraphDesc g; g.effectId = "fx.cowrite";
        g.buffers = {B("m")};
        g.passes = {P("first", "m", {{"i", "source"}}), P("second", "m", {{"i", "source"}}), P("done", "out", {{"i", "buffer:m"}})};
        g.passes[1].lang = Lang::GLSLES; g.passes[1].clear = false; g.passes[1].after = {"first"};
        std::vector<std::string> log;
        Dev skia, native;
        skia.nm = "skia"; skia.langs = {Lang::SkSL}; skia.log = &log;
        native.nm = "native"; native.langs = {Lang::GLSLES}; native.log = &log;
        skia.kernels["first"] = Scale(1.0f); native.kernels["second"] = Scale(1.0f); skia.kernels["done"] = Scale(1.0f);
        auto plan = MakeMixedPlan(g);
        Executor ex(std::vector<Backend*>{&skia, &native}, plan);
        auto src = MakeSource(2, 2, [](int, int, int) { return 0.5f; });
        FrameRequest r; r.width = 2; r.height = 2; r.source = src.get();
        auto res = ex.render(r, [](Target*) {});
        if (res.status != FrameResult::Ok) std::printf("    %s\n", res.error.c_str());
        CHECK(res.status == FrameResult::Ok);
        CHECK(InOrder(log, {"skia.run:first", "skia.release>native", "native.acquire<skia:w", "native.run:second", "native.release>skia", "native.relinquish", "skia.reclaim<native", "skia.run:done"}));
    }
}

// ----------------------------------------------------------------- shared storage between backends
static void TestSharedStorageAndControls() {
    std::printf("shared storage: buffers two backends touch are createShared(); formats are negotiated over sharing; controls reach the backend\n");
    {
        GraphDesc g; g.effectId = "fx.shared";
        g.buffers = {B("m"), B("local")};
        g.passes = {P("a", "local", {{"i", "source"}}), P("b", "m", {{"i", "buffer:local"}}), P("c", "out", {{"i", "buffer:m"}})};
        g.passes[1].lang = Lang::GLSLES;
        Dev skia, native;
        skia.nm = "skia"; skia.langs = {Lang::SkSL}; native.nm = "native"; native.langs = {Lang::GLSLES};
        skia.kernels["a"] = Scale(1.0f); native.kernels["b"] = Offset(0.25f); skia.kernels["c"] = Scale(1.0f);
        Executor ex(std::vector<Backend*>{&skia, &native}, MakeMixedPlan(g));
        auto src = MakeSource(2, 2, [](int, int, int) { return 0.5f; });
        FrameRequest r; r.width = 2; r.height = 2; r.source = src.get();
        float got = -1;
        auto res = ex.render(r, [&](Target* t) { got = static_cast<Img*>(t)->at(0, 0, 0); });
        CHECK(res.status == FrameResult::Ok);
        CHECK_NEAR(got, 0.75f, 1e-6);
        // 'local' is only touched by skia and 'a' ... but also read by native pass 'b', so it crosses; 'm' is written by native, read by skia.
        CHECK(skia.createdShared + native.createdShared >= 2);
        // 'out' (the final buffer) is only used by skia: a private target, created the ordinary way.
        CHECK(skia.created > skia.createdShared);
    }
    {
        // The LAST pass is native: the primary backend still has to read the result, so the final buffer is created shared.
        GraphDesc g; g.effectId = "fx.nativelast";
        g.buffers = {B("m")};
        g.passes = {P("a", "m", {{"i", "source"}}), P("b", "out", {{"i", "buffer:m"}})};
        g.passes[1].lang = Lang::GLSLES;
        Dev skia, native;
        skia.nm = "skia"; skia.langs = {Lang::SkSL}; native.nm = "native"; native.langs = {Lang::GLSLES};
        skia.kernels["a"] = Scale(1.0f); native.kernels["b"] = Offset(0.25f);
        Executor ex(std::vector<Backend*>{&skia, &native}, MakeMixedPlan(g));
        auto src = MakeSource(2, 2, [](int, int, int) { return 0.5f; });
        FrameRequest r; r.width = 2; r.height = 2; r.source = src.get();
        float got = -1;
        auto res = ex.render(r, [&](Target* t) { got = static_cast<Img*>(t)->at(0, 0, 0); });
        CHECK(res.status == FrameResult::Ok);
        CHECK_NEAR(got, 0.75f, 1e-6);
        CHECK(native.createdShared >= 1);     // the final buffer (written by native, read by skia) is shared storage
    }
    {
        GraphDesc g; g.effectId = "fx.private";
        g.buffers = {B("m")};
        g.passes = {P("a", "m", {{"i", "source"}}), P("b", "out", {{"i", "buffer:m"}})};
        Dev skia; skia.nm = "skia"; skia.langs = {Lang::SkSL};
        skia.kernels["a"] = Scale(1.0f); skia.kernels["b"] = Scale(1.0f);
        Executor ex(std::vector<Backend*>{&skia}, MakeMixedPlan(g));
        auto src = MakeSource(2, 2, [](int, int, int) { return 0.5f; });
        FrameRequest r; r.width = 2; r.height = 2; r.source = src.get();
        CHECK(ex.render(r, [](Target*) {}).status == FrameResult::Ok);
        CHECK(skia.createdShared == 0 && skia.created > 0);     // one backend: nothing is shared
    }
    {
        // RGBA32F crossing backends where one cannot share it: lowered to RGBA16F with a note, or a Capability error for precision=required
        GraphDesc g; g.effectId = "fx.f32";
        g.buffers = {B("m", 1, 0, Format::RGBA32F)};
        g.passes = {P("a", "m", {{"i", "source"}}), P("b", "out", {{"i", "buffer:m"}})};
        g.passes[1].lang = Lang::GLSLES;
        Dev skia, native;
        skia.nm = "skia"; skia.langs = {Lang::SkSL}; native.nm = "native"; native.langs = {Lang::GLSLES};
        native.unshareable = {Format::RGBA32F};
        skia.kernels["a"] = Scale(1.0f); native.kernels["b"] = Scale(1.0f);
        {
            Executor ex(std::vector<Backend*>{&skia, &native}, MakeMixedPlan(g));
            auto src = MakeSource(2, 2, [](int, int, int) { return 0.5f; });
            FrameRequest r; r.width = 2; r.height = 2; r.source = src.get();
            auto res = ex.render(r, [](Target*) {});
            CHECK(res.status == FrameResult::Ok);
            bool noted = false;
            for (const Diag& n : res.notes) if (!n.error && n.message.find("rgba32f") != std::string::npos && n.message.find("rgba16f") != std::string::npos && n.message.find("shares") != std::string::npos) noted = true;
            CHECK(noted);
        }
        g.buffers[0].precision = Precision::Required;
        {
            Executor ex(std::vector<Backend*>{&skia, &native}, MakeMixedPlan(g));
            auto src = MakeSource(2, 2, [](int, int, int) { return 0.5f; });
            FrameRequest r; r.width = 2; r.height = 2; r.source = src.get();
            auto res = ex.render(r, [](Target*) {});
            CHECK(res.status == FrameResult::Failed && res.error.find("precision=required") != std::string::npos && res.error.find("capability") != std::string::npos);
        }
    }
    {
        // a backend that shares nothing cannot take part in a cross-backend buffer at all: a clear Capability diagnostic, no CPU copy
        GraphDesc g; g.effectId = "fx.noshare";
        g.buffers = {B("m")};
        g.passes = {P("a", "m", {{"i", "source"}}), P("b", "out", {{"i", "buffer:m"}})};
        g.passes[1].lang = Lang::GLSLES;
        Dev skia, native;
        skia.nm = "skia"; skia.langs = {Lang::SkSL}; native.nm = "native"; native.langs = {Lang::GLSLES};
        native.unshareable = {Format::RGBA8, Format::RGBA16F, Format::RGBA32F};
        skia.kernels["a"] = Scale(1.0f); native.kernels["b"] = Scale(1.0f);
        Executor ex(std::vector<Backend*>{&skia, &native}, MakeMixedPlan(g));
        auto src = MakeSource(2, 2, [](int, int, int) { return 0.5f; });
        FrameRequest r; r.width = 2; r.height = 2; r.source = src.get();
        auto res = ex.render(r, [](Target*) {});
        CHECK(res.status == FrameResult::Failed && res.error.find("cannot share") != std::string::npos && res.error.find("native") != std::string::npos);
        CHECK(skia.runs == 0 && native.runs == 0);
    }
    {
        // effect controls travel with the frame to every pass
        GraphDesc g; g.effectId = "fx.control";
        g.passes = {P("a", "out", {{"i", "source"}})};
        Dev skia; skia.nm = "skia"; skia.langs = {Lang::SkSL};
        float seen = -1; bool unknown = true;
        skia.kernels["a"] = [&](float, float, int, int, float* o, const Ctx& c) {
            float v[2] = {0, 0};
            if (c.run.control && (*c.run.control)("amount", 2, v)) seen = v[1];
            unknown = c.run.control ? (*c.run.control)("nope", 1, v) : true;
            for (int i = 0; i < 4; i++) o[i] = 0;
        };
        Executor ex(std::vector<Backend*>{&skia}, MakeMixedPlan(g));
        auto src = MakeSource(2, 2, [](int, int, int) { return 0.5f; });
        FrameRequest r; r.width = 2; r.height = 2; r.source = src.get();
        r.control = [](const std::string& name, int count, float* v) { if (name != "amount" || count != 2) return false; v[0] = 1; v[1] = 7.5f; return true; };
        CHECK(ex.render(r, [](Target*) {}).status == FrameResult::Ok);
        CHECK_NEAR(seen, 7.5f, 1e-6);
        CHECK(!unknown);
    }
}

static void TestCapabilityDiagnostics() {
    std::printf("capability failures name effect, pass, backend, file:line; nothing falls back\n");
    GraphDesc g; g.effectId = "fx.cap";
    g.buffers = {B("m")};
    g.passes = {P("a", "m", {{"i", "source"}}), P("b", "out", {{"i", "buffer:m"}})};
    g.passes[1].lang = Lang::GLSLES; g.passes[1].file = "cap.json"; g.passes[1].line = 40;
    auto src = MakeSource(2, 2, [](int, int, int) { return 0.5f; });
    FrameRequest r; r.width = 2; r.height = 2; r.source = src.get();
    {   // planner: the languages offered by the backends do not include glsl-es
        PlanOptions o;
        Plan p = BuildPlan(g, o);
        bool cap = false;
        for (const Diag& d : p.diags) cap = cap || (d.error && d.kind == DiagKind::Capability && d.pass == "b" && d.line == 40 && d.file == "cap.json");
        CHECK(!p.ok() && cap);
    }
    {   // executor: the plan was built for a richer device; this device has only Skia -> that frame fails, 'a' never runs
        Dev skia;
        skia.nm = "skia"; skia.langs = {Lang::SkSL};
        skia.kernels["a"] = Scale(1.0f); skia.kernels["b"] = Scale(1.0f);
        Executor ex(skia, MakeMixedPlan(g));
        auto res = ex.render(r, [](Target*) {});
        CHECK(res.status == FrameResult::Failed);
        CHECK(Has(res.error, "error[capability]") && Has(res.error, "effect 'fx.cap'") && Has(res.error, "pass 'b'") && Has(res.error, "backend skia") && Has(res.error, "cap.json:40") && Has(res.error, "glsl-es"));
        CHECK(skia.runs == 0);                                              // checked before anything was drawn; no rerun with another shader
        bool noted = false;
        for (const Diag& d : res.notes) noted = noted || (d.kind == DiagKind::Capability && d.pass == "b");
        CHECK(noted);
        CHECK(ex.poolStats().live == 0);
    }
    {   // a backend that knows the language but refuses THIS pass (device too old): its reason is reported; the other backend must not run it
        Dev skia, native;
        skia.nm = "skia"; skia.langs = {Lang::SkSL, Lang::GLSLES};         // skia claims glsl-es here only to prove accepts() of the first match decides... it is asked second
        skia.langs = {Lang::SkSL};
        native.nm = "native"; native.langs = {Lang::GLSLES}; native.refuse = "needs GLSL ES 3.2 but this device supports up to 3.1";
        skia.kernels["a"] = Scale(1.0f); native.kernels["b"] = Scale(1.0f);
        Executor ex(std::vector<Backend*>{&skia, &native}, MakeMixedPlan(g));
        auto res = ex.render(r, [](Target*) {});
        CHECK(res.status == FrameResult::Failed && Has(res.error, "needs GLSL ES 3.2") && Has(res.error, "native") && Has(res.error, "cap.json:40"));
        CHECK(skia.runs == 0 && native.runs == 0);
    }
    {   // two backends that cannot share storage: the pass is refused, there is no CPU copy
        Dev skia, native;
        skia.nm = "skia"; skia.langs = {Lang::SkSL}; skia.share = false;
        native.nm = "native"; native.langs = {Lang::GLSLES}; native.share = false;
        skia.kernels["a"] = Scale(1.0f); native.kernels["b"] = Scale(1.0f);
        Executor ex(std::vector<Backend*>{&skia, &native}, MakeMixedPlan(g));
        auto res = ex.render(r, [](Target*) {});
        CHECK(res.status == FrameResult::Failed && Has(res.error, "error[capability]") && Has(res.error, "cannot read input 'i'") && Has(res.error, "pass 'b'") && Has(res.error, "cannot share storage"));
        CHECK(native.runs == 0 && ex.poolStats().live == 0);
    }
    {   // precision=required: the buffer is shared with a backend that has no RGBA16F
        GraphDesc h; h.effectId = "fx.prec";
        BufferDesc m = B("m", 1, 0, Format::RGBA16F); m.precision = Precision::Required;
        h.buffers = {m};
        h.passes = {P("a", "m", {{"i", "source"}}), P("b", "out", {{"i", "buffer:m"}})};
        h.passes[1].lang = Lang::GLSLES;
        Dev skia, native;
        skia.nm = "skia"; skia.langs = {Lang::SkSL};
        native.nm = "native"; native.langs = {Lang::GLSLES}; native.f16 = false; native.f32 = false;
        skia.kernels["a"] = Scale(1.0f); native.kernels["b"] = Scale(1.0f);
        Executor ex(std::vector<Backend*>{&skia, &native}, MakeMixedPlan(h));
        auto res = ex.render(r, [](Target*) {});
        CHECK(res.status == FrameResult::Failed && Has(res.error, "error[capability]") && Has(res.error, "backend native") && Has(res.error, "precision=required"));
        m.precision = Precision::Preferred;                                  // preferred: degrades to what BOTH backends render, with a note
        h.buffers = {m};
        Dev skia2, native2;
        skia2.nm = "skia"; skia2.langs = {Lang::SkSL};
        native2.nm = "native"; native2.langs = {Lang::GLSLES}; native2.f16 = false; native2.f32 = false;
        skia2.kernels["a"] = Scale(1.0f); native2.kernels["b"] = Scale(1.0f);
        Executor ex2(std::vector<Backend*>{&skia2, &native2}, MakeMixedPlan(h));
        auto res2 = ex2.render(r, [](Target*) {});
        CHECK(res2.status == FrameResult::Ok);
        bool degraded = false;
        for (const Diag& d : res2.notes) degraded = degraded || (!d.error && d.kind == DiagKind::Capability && Has(d.message.c_str(), "only renders and shares rgba8") && d.backend == "native");
        CHECK(degraded);
    }
}

static void TestMixedHistoryBudgetCancel() {
    std::printf("mixed languages: history across backends, shared memory budget, cancel\n");
    auto build = [] {
        GraphDesc g; g.effectId = "fx.mixfb";
        BufferDesc acc = B("acc", 1, 1);
        g.buffers = {acc};
        g.passes = {P("fb", "acc", {{"i", "source"}, {"prev", "buffer:acc@1"}}), P("show", "out", {{"i", "buffer:acc"}})};
        g.passes[0].lang = Lang::GLSLES;
        return g;
    };
    {
        Dev skia, native;
        skia.nm = "skia"; skia.langs = {Lang::SkSL};
        native.nm = "native"; native.langs = {Lang::GLSLES};
        native.kernels["fb"] = [](float u, float v, int, int, float* o, const Ctx& c) { for (int i = 0; i < 4; i++) o[i] = c.tex("i", u, v, i) * 0.5f + c.tex("prev", u, v, i) * 0.5f; };
        skia.kernels["show"] = Scale(1.0f);
        Executor ex(std::vector<Backend*>{&skia, &native}, MakeMixedPlan(build()));
        auto src = MakeSource(2, 2, [](int, int, int) { return 1.0f; });
        const float want[3] = {0.5f, 0.75f, 0.875f};
        for (int f = 0; f < 3; f++) {
            FrameRequest r; r.frame = f; r.width = 2; r.height = 2; r.source = src.get();
            float got = -1;
            auto res = ex.render(r, [&](Target* t) { got = static_cast<Img*>(t)->at(0, 0, 0); });
            CHECK(res.status == FrameResult::Ok);
            CHECK_NEAR(got, want[f], 1e-6);
        }
        CHECK(skia.created + native.created >= 2);
    }
    {   // budget counts both backends together: 2x2 RGBA16F targets are 16 bytes each
        Dev skia, native;
        skia.nm = "skia"; skia.langs = {Lang::SkSL};
        native.nm = "native"; native.langs = {Lang::GLSLES};
        native.kernels["fb"] = Scale(1.0f); skia.kernels["show"] = Scale(1.0f);
        Executor ex(std::vector<Backend*>{&skia, &native}, MakeMixedPlan(build()));
        ex.setBudget(8);
        auto src = MakeSource(2, 2, [](int, int, int) { return 1.0f; });
        FrameRequest r; r.width = 2; r.height = 2; r.source = src.get();
        auto res = ex.render(r, [](Target*) {});
        CHECK(res.status == FrameResult::Failed && Has(res.error, "out of GPU memory"));
        CHECK(ex.poolStats().live == 0 && ex.heldBytes() == 0);
    }
    {   // cancel between two passes that live on different backends
        Dev skia, native;
        skia.nm = "skia"; skia.langs = {Lang::SkSL};
        native.nm = "native"; native.langs = {Lang::GLSLES};
        native.kernels["fb"] = Scale(1.0f); skia.kernels["show"] = Scale(1.0f);
        Executor ex(std::vector<Backend*>{&skia, &native}, MakeMixedPlan(build()));
        std::atomic<bool> cancel(true);
        auto src = MakeSource(2, 2, [](int, int, int) { return 1.0f; });
        FrameRequest r; r.width = 2; r.height = 2; r.source = src.get(); r.cancel = &cancel;
        auto res = ex.render(r, [](Target*) {});
        CHECK(res.status == FrameResult::Cancelled && skia.runs == 0 && native.runs == 0 && ex.poolStats().live == 0);
        ex.dropAll();
        CHECK(skia.alive == 0 && native.alive == 0);                          // dropAll returns every target of every backend
    }
}

static void TestSampleMultiLanguageEffect() {
    std::printf("sample effect testdata/graphs/multilang_blur.xml: parsed, planned, routed\n");
    FILE* f = std::fopen("testdata/graphs/multilang_blur.xml", "rb");
    if (!f) { CHECK(!"run the test from the repository root: testdata/graphs/multilang_blur.xml not found"); return; }
    std::string xml; char buf[4096]; size_t n;
    while ((n = std::fread(buf, 1, sizeof(buf), f)) > 0) xml.append(buf, n);
    std::fclose(f);
    std::string err;
    auto root = am::ParseXml(xml, &err);
    CHECK(root && am::rg::IsGraphXml(*root));
    GraphDesc g; std::vector<Diag> diags;
    CHECK(ParseGraphXml(*root, &g, &diags));
    CHECK(g.passes.size() == 3 && g.passes[0].lang == Lang::SkSL && g.passes[1].lang == Lang::GLSLES && g.passes[2].lang == Lang::SkSL);
    CHECK(g.passes[1].source.find("#version 300 es") == 0 || g.passes[1].source.find("#version 300 es") == 1);    // starts the shader text (a newline may precede it)
    auto plan = MakeMixedPlan(g);
    CHECK(plan->ok() && plan->steps.size() == 3);
    Dev skia, native;
    skia.nm = "skia"; skia.langs = {Lang::SkSL};
    native.nm = "native"; native.langs = {Lang::GLSLES};
    skia.kernels["prep"] = Scale(1.0f); native.kernels["blur_h"] = Scale(1.0f); skia.kernels["comp"] = Scale(1.0f);
    Executor ex(std::vector<Backend*>{&skia, &native}, plan);
    auto src = MakeSource(4, 4, [](int, int, int) { return 0.5f; });
    FrameRequest r; r.width = 4; r.height = 4; r.source = src.get();
    auto res = ex.render(r, [](Target*) {});
    CHECK(res.status == FrameResult::Ok && ex.backendOfStep(0) == 0 && ex.backendOfStep(1) == 1 && ex.backendOfStep(2) == 0);
    // the same file on a device with only the Skia backend fails with the GLSL ES pass named, at its line in the file
    Dev only;
    only.nm = "skia"; only.langs = {Lang::SkSL};
    only.kernels = skia.kernels;
    Executor ex2(only, plan);
    auto res2 = ex2.render(r, [](Target*) {});
    CHECK(res2.status == FrameResult::Failed && Has(res2.error, "error[capability]") && Has(res2.error, "pass 'blur_h'") && Has(res2.error, "multilang_blur.xml:26"));
}

int main() {
    TestOnePassStillWorks();
    TestTwoPassChaining();
    TestOrderIgnoresDeclarationOrder();
    TestBloomMultiScale();
    TestDisplacementMultiTexture();
    TestTemporalFeedback();
    TestSeekDeterminism();
    TestRedoSameFrameAndSignature();
    TestInvalidGraphs();
    TestCulling();
    TestPoolBoundedAndNoLeak();
    TestFormatNegotiation();
    TestXmlRoundTrip();
    TestTimingsAndDiagnostics();
    TestMixedLanguageGraph();
    TestHandoffOfFinalAndOutputs();
    TestSharedStorageAndControls();
    TestCapabilityDiagnostics();
    TestMixedHistoryBudgetCancel();
    TestSampleMultiLanguageEffect();
    std::printf("\n%d checks, %d failed\n", gChecks, gFailed);
    return gFailed ? 1 : 0;
}

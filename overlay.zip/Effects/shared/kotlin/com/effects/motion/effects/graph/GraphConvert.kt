package com.effects.motion.effects.graph

import com.effects.motion.effects.AmEffect
import com.effects.motion.effects.AmParam
import org.json.JSONArray
import org.json.JSONObject

class GraphConverted(val graph: EffectGraph?, val params: JSONArray, val notes: List<String>, val issues: List<Issue>) {
    val ok: Boolean get() = graph != null && !issues.hasError
    val problems: List<String> get() = issues.filter { it.error }.map { it.text }
}

/**
 * Effect XML (EM pass dialect) -> native schema 2 graph. Every pass is parsed, its GLSL translated to SkSL (or SkSL kept),
 * and the whole graph validated. Anything that cannot be converted is an [Issue] with effect, pass and line; nothing is dropped
 * silently and a graph is never reduced to a single pass.
 */
object GraphConvert {
    private val Ident = Regex("[A-Za-z_][A-Za-z0-9_]*")
    /** Languages the importer accepts in the stored graph: sksl (Skia), glsl-es (native OpenGL ES driver), glsl-vk and spirv (native Vulkan backend). */
    val NativeLanguages = setOf("sksl", "glsl-es", "glsl-vk", "spirv")
    private val Reserved = setOf("size", "time", "layer", "fromLayer", "toLayer", "duration", "image", "_out")

    /** [native] = the "GLSL" shader language of the import dialog: legacy `glsl` passes become native GLSL ES passes ([GlslNative]) instead of being translated to SkSL. */
    fun convert(fx: AmEffect, fileName: String = fx.id, native: Boolean = false): GraphConverted {
        val issues = mutableListOf<Issue>()
        val notes = mutableListOf<String>()
        val effectId = fx.id.ifEmpty { fx.name }
        fun fail(kind: IssueKind, msg: String, pass: String? = null) { issues += Issue(kind, msg, true, effectId, pass, -1, null, fileName) }

        if (fx.hasScript) fail(IssueKind.UNSUPPORTED, "has a JavaScript animate() script, which is not supported")
        fx.unknownChildren.keys.forEach { notes += "Kept the unknown element <$it> as metadata (not used for rendering)." }

        // ---- controls -> params json + uniform declarations the passes may rely on
        val params = JSONArray()
        val implicit = mutableListOf<GlslToSksl.Implicit>()
        val colors = hashSetOf<String>()
        val textureRefs = linkedMapOf<String, String>()    // control id -> "source" | "texture:<id>"
        val textures = mutableListOf<GraphTexture>()
        val seen = hashSetOf<String>()
        fun num(s: String?, d: Double) = s?.trim()?.toDoubleOrNull() ?: d
        fun scalar(p: AmParam, kind: String) = JSONObject().put("id", p.id).put("label", p.label).put("type", kind).put("default", num(p.default, 0.0)).apply {
            p.min?.toDoubleOrNull()?.let { put("min", it) }
            p.max?.toDoubleOrNull()?.let { put("max", it) }
            put("step", num(p.step, 0.01))
            if (p.type == "percent") put("percent", true)
        }
        for (p in fx.params) {
            if (p.tag == "section") { continue }
            if (p.tag == "texture") {
                when (p.srcType) {
                    "content" -> textureRefs[p.id] = "source"
                    "noise" -> { textureRefs[p.id] = "texture:${p.id}"; textures += GraphTexture(p.id, "builtin:noise") }
                    else -> fail(IssueKind.UNSUPPORTED, "texture control '${p.id}' has srcType '${p.srcType ?: "unknown"}'; this build supports content and noise")
                }
                continue
            }
            if (!Ident.matches(p.id)) { fail(IssueKind.MALFORMED, "control id '${p.id}' is not a valid name"); continue }
            if (!seen.add(p.id)) { fail(IssueKind.MALFORMED, "control id '${p.id}' appears twice"); continue }
            if (p.id in Reserved) { fail(IssueKind.VALIDATION, "control id '${p.id}' is reserved for the engine; rename it"); continue }
            when (p.tag) {
                "slider", "spinner" -> { params.put(scalar(p, if (p.type == "angle") "angle" else "float")); implicit += GlslToSksl.Implicit(p.id, "uniform float ${p.id};") }
                "switch" -> {
                    params.put(JSONObject().put("id", p.id).put("label", p.label).put("type", "switch").put("default", p.default.equals("true", true) || p.default == "1"))
                    implicit += GlslToSksl.Implicit(p.id, "uniform float ${p.id};", bool = true)
                }
                "selector" -> {
                    val values = p.choices.map { it.value }
                    if (values.isEmpty()) fail(IssueKind.MALFORMED, "selector '${p.id}' has no choices")
                    else if (values != values.indices.toList()) fail(IssueKind.UNSUPPORTED, "selector '${p.id}' has values $values; multi-pass effects need 0..n-1")
                    else {
                        params.put(JSONObject().put("id", p.id).put("label", p.label).put("type", "choice").put("default", p.default.trim().toIntOrNull()?.coerceIn(0, values.size - 1) ?: 0)
                            .put("options", JSONArray(p.choices.map { it.label })))
                        implicit += GlslToSksl.Implicit(p.id, "uniform int ${p.id};")
                    }
                }
                "point" -> {
                    val xy = p.default.split(',').map { num(it, 0.0) } + listOf(0.0, 0.0)
                    params.put(JSONObject().put("id", p.id).put("label", p.label).put("type", "point").put("default", JSONArray().put(xy[0]).put(xy[1])))
                    implicit += GlslToSksl.Implicit(p.id, "uniform float2 ${p.id};")
                }
                "color" -> {
                    val c = p.default.trim().lowercase().takeIf { Regex("#[0-9a-f]{6}|#[0-9a-f]{8}").matches(it) } ?: "#ff000000"
                    params.put(JSONObject().put("id", p.id).put("label", p.label).put("type", "color").put("default", c))
                    colors += p.id
                    implicit += GlslToSksl.Implicit(p.id, "layout(color) uniform half4 ${p.id};")
                }
                "xyz" -> fail(IssueKind.UNSUPPORTED, "control '${p.id}' is an <xyz>; split it into three sliders for multi-pass effects")
                else -> notes += "Skipped unknown control <${p.tag}>."
            }
        }
        if (fx.params.any { it.tag == "section" }) notes += "Section headings are flattened (no groups yet)."

        // ---- buffers
        val buffers = fx.buffers.map { b ->
            val a = b.attrs
            fun s(k: String, d: String) = a[k] ?: d
            GraphBuffer(b.id, a["scale"]?.toFloatOrNull() ?: 1f, a["width"]?.toIntOrNull() ?: 0, a["height"]?.toIntOrNull() ?: 0, s("format", "inherit"),
                s("precision", "preferred"), s("filter", "linear"), s("wrap", "clamp"), a["history"]?.toIntOrNull() ?: 0,
                a.filterKeys { it !in setOf("scale", "width", "height", "format", "precision", "filter", "wrap", "history") })
        }
        for (b in fx.buffers) for ((k, v) in b.attrs) {
            val numeric = k in setOf("scale", "width", "height", "history")
            if (numeric && v.toFloatOrNull() == null) fail(IssueKind.MALFORMED, "buffer '${b.id}' attribute $k='$v' is not a number")
        }
        val bufferIds = buffers.map { it.id }.toSet()
        val passIds = fx.passList.map { it.id }.toSet()

        // ---- passes
        val passes = fx.passList.mapIndexed { index, p ->
            fun passFail(kind: IssueKind, msg: String) { issues += Issue(kind, msg, true, effectId, p.id, index, null, fileName) }
            val inputs = p.inputs.map { (name, ref) ->
                val resolved = when {
                    ref in textureRefs -> textureRefs.getValue(ref)
                    ref == "source" || ref.contains(':') -> ref
                    ref in passIds -> "pass:$ref"
                    ref in bufferIds -> "buffer:$ref"
                    else -> ref
                }
                PassInput(name, resolved)
            }
            if (p.constants.values.any { v -> v.any { it.isNaN() } }) passFail(IssueKind.MALFORMED, "a <const> has a value that is not a number")
            val firstLine = 1
            var lang = p.lang
            var source = p.shader
            var line = firstLine
            val extra = LinkedHashMap(p.extra)
            var defines = emptyMap<String, String>()
            if (lang == "glsl-es" || lang == "glsl-vk" || lang == "spirv") {
                // Native GLSL ES (OpenGL ES driver), Vulkan GLSL or SPIR-V (Vulkan backend): the text is kept exactly as written. Nothing is translated.
                // It must follow the native contract (docs/EFFECT_FORMAT.md section 9): premultiplied in and out, no varyings, uniforms by name.
                defines = p.defines
                notes += "Pass '${p.id}' runs natively as $lang (not translated to SkSL)."
            } else if (lang == "glsl" && native) {
                val r = GlslNative.convert(p.shader, inputs.map { it.name }, implicit, effectId, p.id, fileName, firstLine, p.defines)
                issues += r.issues
                source = r.source
                line = firstLine - r.headerLines
                extra["origin-lang"] = lang
                lang = "glsl-es"
                notes += "Pass '${p.id}' runs natively as GLSL ES (not translated to SkSL)."
            } else if (lang == "glsl") {
                // Legacy effect-XML dialect (v_uv, acScreenSize, straight alpha): still translated until the Vulkan backend can run desktop GLSL.
                val r = GlslToSksl.convert(p.shader, inputs.map { it.name }, colors, effectId, p.id, fileName, firstLine, p.defines, implicit)
                issues += r.issues
                source = r.sksl
                line = firstLine - r.headerLines
                extra["origin-lang"] = lang
                lang = "sksl"
            } else if (lang == "sksl") {
                if (p.defines.isNotEmpty()) passFail(IssueKind.UNSUPPORTED, "<define> is only applied to GLSL passes; write the value into the SkSL")
            }
            GraphPass(p.id, source, p.name, lang, inputs, p.output, p.blend, p.clear, p.after, p.constants, defines, fileName, line, extra)
        }
        val seek = fx.history["seek"] ?: "reset"
        val graph = EffectGraph(
            passes = passes, buffers = buffers, textures = textures, output = fx.attrs["output"].orEmpty(), seek = seek,
            maxReplay = fx.history["maxReplay"]?.toIntOrNull() ?: 120,
            extra = fx.attrs.filterKeys { it != "output" }.mapKeys { "xml_" + it.key } + fx.unknownChildren.mapKeys { "xmlchild_" + it.key },
        )
        issues += GraphValidator.validate(effectId, graph, NativeLanguages, "Skia, OpenGL ES or Vulkan")
        return GraphConverted(graph, params, notes, issues)
    }
}

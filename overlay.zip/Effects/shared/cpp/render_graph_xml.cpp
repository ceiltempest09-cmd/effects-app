#include "render_graph_xml.h"

#include <cstdlib>
#include <set>

namespace am::rg {

namespace {

std::string Attr(const XmlNode& n, const char* k, const char* fallback = "") {
    const char* v = n.attr(k);
    return v ? v : fallback;
}

bool Number(const std::string& s, float* v) {
    if (s.empty()) return false;
    char* end = nullptr;
    *v = std::strtof(s.c_str(), &end);
    return end && *end == 0;
}

bool Int(const std::string& s, int* v) {
    if (s.empty()) return false;
    char* end = nullptr;
    const long x = std::strtol(s.c_str(), &end, 10);
    if (!end || *end) return false;
    *v = (int)x;
    return true;
}

std::vector<std::string> Split(const std::string& s, char sep) {
    std::vector<std::string> r;
    size_t at = 0;
    while (at <= s.size()) {
        size_t n = s.find(sep, at);
        if (n == std::string::npos) n = s.size();
        std::string part = s.substr(at, n - at);
        const size_t a = part.find_first_not_of(" \t\r\n"), b = part.find_last_not_of(" \t\r\n");
        if (a != std::string::npos) r.push_back(part.substr(a, b - a + 1));
        at = n + 1;
    }
    return r;
}

struct Reader {
    Reader(GraphDesc* graph, std::vector<Diag>* d) : g(graph), diags(d) {}
    GraphDesc* g;
    std::vector<Diag>* diags;
    bool ok = true;
    const XmlNode* where = nullptr;
    std::string pass;
    int passIndex = -1;

    void bad(DiagKind kind, const std::string& msg) {
        Diag d;
        d.kind = kind;
        d.effect = g->effectId;
        d.pass = pass;
        d.passIndex = passIndex;
        d.backend = "import";
        d.message = msg;
        diags->push_back(d);
        ok = false;
    }

    template <class E, class F>
    void Enum(const XmlNode& n, const char* key, E* out, F parse) {
        const char* v = n.attr(key);
        if (v && !parse(v, out)) bad(DiagKind::Malformed, std::string("'") + v + "' is not a valid " + key + " on <" + n.name + ">");
    }

    void Rest(const XmlNode& n, const std::set<std::string>& known, std::map<std::string, std::string>* extra) {
        for (const auto& a : n.attrs) if (!known.count(a.first)) (*extra)[a.first] = a.second;
    }
};

}  // namespace

bool IsGraphXml(const XmlNode& root) {
    if (root.attr("graph")) return true;
    return root.child("pass") != nullptr;
}

bool ParseGraphXml(const XmlNode& root, GraphDesc* out, std::vector<Diag>* diags) {
    GraphDesc g;
    g.effectId = Attr(root, "id");
    Reader r(&g, diags);
    int version = kGraphSchema;
    if (root.attr("graph") && !Int(Attr(root, "graph"), &version)) r.bad(DiagKind::Malformed, "graph=\"" + Attr(root, "graph") + "\" is not a version number");
    if (version > kGraphSchema)
        r.bad(DiagKind::Unsupported, "effect schema " + std::to_string(version) + " is newer than this build understands (" + std::to_string(kGraphSchema) + "). Update the app.");
    g.output = Attr(root, "output");
    const std::string seek = Attr(root, "seek", "reset");
    if (seek == "reset") g.seek = SeekMode::Reset;
    else if (seek == "replay") g.seek = SeekMode::Replay;
    else r.bad(DiagKind::Malformed, "seek must be reset or replay, not '" + seek + "'");
    if (root.attr("max_replay") && (!Int(Attr(root, "max_replay"), &g.maxReplay) || g.maxReplay < 1 || g.maxReplay > 1000))
        r.bad(DiagKind::Malformed, "max_replay must be 1..1000");
    r.Rest(root, {"id", "graph", "output", "seek", "max_replay", "sksl", "native"}, &g.extra);

    for (const auto& c : root.children) {
        const XmlNode& n = *c;
        if (n.name == "texture") {
            TextureDesc t;
            t.id = Attr(n, "id");
            t.source = Attr(n, "source");
            if (n.attr("width") && !Int(Attr(n, "width"), &t.width)) r.bad(DiagKind::Malformed, "texture '" + t.id + "' width is not a number");
            if (n.attr("height") && !Int(Attr(n, "height"), &t.height)) r.bad(DiagKind::Malformed, "texture '" + t.id + "' height is not a number");
            if (n.attr("seed") && !Int(Attr(n, "seed"), &t.seed)) r.bad(DiagKind::Malformed, "texture '" + t.id + "' seed is not a number");
            r.Enum(n, "filter", &t.filter, ParseFilter);
            r.Enum(n, "wrap", &t.wrap, ParseWrap);
            r.Rest(n, {"id", "source", "width", "height", "seed", "filter", "wrap"}, &t.extra);
            g.textures.push_back(t);
        } else if (n.name == "buffer") {
            BufferDesc b;
            b.id = Attr(n, "id");
            if (n.attr("scale") && !Number(Attr(n, "scale"), &b.scale)) r.bad(DiagKind::Malformed, "buffer '" + b.id + "' scale is not a number");
            if (n.attr("width") && !Int(Attr(n, "width"), &b.width)) r.bad(DiagKind::Malformed, "buffer '" + b.id + "' width is not a number");
            if (n.attr("height") && !Int(Attr(n, "height"), &b.height)) r.bad(DiagKind::Malformed, "buffer '" + b.id + "' height is not a number");
            if (n.attr("history") && !Int(Attr(n, "history"), &b.history)) r.bad(DiagKind::Malformed, "buffer '" + b.id + "' history is not a number");
            r.Enum(n, "format", &b.format, ParseFormat);
            r.Enum(n, "filter", &b.filter, ParseFilter);
            r.Enum(n, "wrap", &b.wrap, ParseWrap);
            const std::string prec = Attr(n, "precision", "preferred");
            if (prec == "required") b.precision = Precision::Required;
            else if (prec != "preferred") r.bad(DiagKind::Malformed, "buffer '" + b.id + "' precision must be preferred or required");
            r.Rest(n, {"id", "scale", "width", "height", "format", "precision", "filter", "wrap", "history"}, &b.extra);
            g.buffers.push_back(b);
        } else if (n.name == "pass") {
            PassDesc p;
            p.id = Attr(n, "id");
            p.name = Attr(n, "name", p.id.c_str());
            r.pass = p.id;
            r.passIndex = (int)g.passes.size();
            r.Enum(n, "lang", &p.lang, ParseLang);
            r.Enum(n, "blend", &p.blend, ParseBlend);
            p.output = Attr(n, "output");
            p.file = Attr(n, "file");
            if (n.attr("line") && !Int(Attr(n, "line"), &p.line)) r.bad(DiagKind::Malformed, "line is not a number");
            const std::string clear = Attr(n, "clear", "true");
            if (clear == "true") p.clear = true;
            else if (clear == "false") p.clear = false;
            else r.bad(DiagKind::Malformed, "clear must be true or false");
            p.after = Split(Attr(n, "after"), ',');
            r.Rest(n, {"id", "name", "lang", "blend", "output", "file", "line", "clear", "after"}, &p.extra);
            for (const auto& cc : n.children) {
                const XmlNode& k = *cc;
                if (k.name == "source") p.source = k.text;
                else if (k.name == "input") p.inputs.push_back({Attr(k, "name"), Attr(k, "ref")});
                else if (k.name == "const") {
                    Constant c;
                    c.name = Attr(k, "name");
                    for (const std::string& s : Split(Attr(k, "value"), ',')) {
                        float v;
                        if (!Number(s, &v)) r.bad(DiagKind::Malformed, "const '" + c.name + "' has the non-number '" + s + "'");
                        else c.value.push_back(v);
                    }
                    p.constants.push_back(c);
                } else if (k.name == "define") p.defines[Attr(k, "name")] = Attr(k, "value");
                else p.extra["child:" + k.name] = k.text;      // keep what we do not understand
            }
            g.passes.push_back(std::move(p));
            r.pass.clear();
            r.passIndex = -1;
        } else if (n.name == "param") {
            continue;                                        // controls: handled by EffectRuntime::load
        } else {
            g.extra["child:" + n.name] = n.text;
        }
    }
    *out = std::move(g);
    return r.ok;
}

}  // namespace am::rg

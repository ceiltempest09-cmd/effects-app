// vulkan_backend.h - step 5b-2: a real rg::Backend that runs vulkan-glsl, desktop glsl (uniforms wrapped into a block, see glsl_wrap.h)
// and pre-compiled spirv passes on the phone's Vulkan driver, next to the Skia and GL backends of the same graph.
//   * its own VkInstance / VkDevice (not Skia's), created once per process, used from any thread (one mutex)
//   * targets are AHardwareBuffer-backed (RGBA8 / RGBA16F), so Skia and the GL backend see the same memory: no copy, hand-off through the
//     usual Backend::release / acquire protocol, with sync-fd semaphores in both directions (or a CPU wait when fences are off or unavailable)
//   * GLSL -> SPIR-V with glslang (glsl_compile.h); uniform blocks and samplers are found by reflecting the SPIR-V (spirv_reflect.h) and bound by
//     name exactly like the GL backend binds uniforms: automatic size / time / frame / out_px / <input>_px, pass constants, effect controls
// Nothing is translated between languages and nothing runs on the CPU. Without Vulkan headers (host builds) the factory reports "not built".
#pragma once

#include "render_graph.h"

#include <string>

namespace am::rg {

// The process-wide Vulkan backend (created on the first call). nullptr + *why when this device or build cannot run it.
Backend* SharedVulkanBackend(std::string* why);
// true: hand-offs to the next backend use a sync fd (the CPU does not wait for the GPU) whenever the driver can export one.
void VulkanBackendSetFences(Backend* backend, bool on);
// One line per fact for the GPU Test report ("" when the backend was never created).
std::string VulkanBackendDescribe();

}  // namespace am::rg

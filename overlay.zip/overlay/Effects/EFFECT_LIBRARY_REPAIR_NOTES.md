# Effect library repair and preview contention tuning

## Fixed in this overlay
- Alight Motion `@am:string/...` parameter labels and choice options are
  humanized into readable text (for example `Before Offset`) because the
  external Alight Motion Android resource table is not part of this app.
- The merged catalog and search/list results deduplicate identical effect IDs
  before they are passed to Compose lazy-list keys, preventing duplicate-key
  crashes such as `fx.glow`.
- Imported graph effects receive an explicit thumbnail path into the bundled
  Alight Motion or After Effects thumbnail folder.
- Thumbnail loading tries native effect assets first, then the direct bundled
  asset path, then Alight Motion / After Effects thumbnail folders.
- Effect cards show the supplied thumbnail as one full image. The artificial
  half test-card, split, and divider are removed.
- Alight Motion bundled effects use the 16-bit Balance tier, matching the
  existing 16-bit After Effects tier.
- Background preview cache workers, capture queue and look-ahead are reduced
  to limit CPU/memory-bandwidth contention during live playback.

## Important scope
The original Alight Motion ZIP contains 385 valid effect JSON definitions.
The repaired index contains those 385 definitions. It cannot restore effect
definitions that are absent from the supplied archive; the original source
archive or missing JSON files are needed for those.

## Verification required
Build the FOSS Release APK, then test:
1. Open and search the Effects Library repeatedly (duplicate-key crash).
2. Open an imported effect with choice parameters (no `@am:string/...` text).
3. Check Alight Motion and AE thumbnails.
4. Check category placement across Color & Light, Blur, Warp, 3D and other tabs.
5. Play a 1080p clip while watching preview frame pacing on the Helio G99.

This is a source patch; it has not been compiled or measured on the device.

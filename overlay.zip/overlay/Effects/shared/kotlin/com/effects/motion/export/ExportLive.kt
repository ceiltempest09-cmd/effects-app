package com.effects.motion.export

/**
 * What the video encoder is really doing right now, for the export progress dialog.
 * Everything here is written by the export loop (VideoExport.kt) after each frame is handed to the encoder;
 * nothing is estimated or invented. The dialog only reads it.
 */
object ExportLive {
    class Preview(val rgba: ByteArray, val width: Int, val height: Int, val frame: Int)

    @Volatile var frame = 0
    @Volatile var frames = 0
    @Volatile var width = 0
    @Volatile var height = 0
    @Volatile var bitrate = 0
    @Volatile var preview: Preview? = null

    fun begin(frames: Int, width: Int, height: Int, bitrate: Int) {
        this.frames = frames
        this.width = width
        this.height = height
        this.bitrate = bitrate
        frame = 0
        preview = null
    }

    fun clear() {
        frame = 0
        frames = 0
        preview = null
    }
}

package com.effects.motion.library

import com.effects.motion.platform.drain
import com.effects.motion.platform.readAtMost
import com.effects.motion.R
import com.effects.motion.i18n.AppText
import com.effects.motion.i18n.UiText
import com.effects.motion.i18n.txt
import com.effects.motion.platform.Context
import com.effects.motion.platform.Uri
import com.effects.motion.compat.EffectMigration
import com.effects.motion.compat.FlaPart
import com.effects.motion.compat.flaPicture
import com.effects.motion.compat.flaSound
import com.effects.motion.compat.readFla
import com.effects.motion.effects.EffectCatalog
import com.effects.motion.fonts.FontImportError
import com.effects.motion.fonts.FontLibrary
import com.effects.motion.fonts.MAX_FONT_BYTES
import com.effects.motion.fonts.checkedFont
import com.effects.motion.model.Layer
import com.effects.motion.model.MediaDeclaration
import com.effects.motion.model.Scene
import com.effects.motion.model.XmlNode
import com.effects.motion.model.mapMediaUris
import com.effects.motion.model.mediaUris
import com.effects.motion.model.storedMediaUris
import com.effects.motion.model.withSiblingRefs
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.io.InputStream
import java.io.Serializable
import java.util.zip.ZipInputStream

internal fun XmlNode.mapFonts(change: Map<String, String>): XmlNode =
    (this["font"]?.let(change::get)?.let { with("font", it) } ?: this).let { it.copy(children = it.children.map { child -> child.mapFonts(change) }) }

class ImportFailed(val text: UiText) : Exception(text.toString())

fun reportText(value: String): UiText = txt(R.string.library_text_value, value)

data class ImportReport(
    val id: String,
    val title: String,
    val element: Boolean,
    val sections: List<Pair<UiText, List<UiText>>>,
    val template: Boolean = false,
) : Serializable

data class ImportLimits(
    val entries: Int = 2_000,
    val scenes: Int = 32,
    val unpacked: Long = 2L shl 30,
    val sceneText: Int = 32 shl 20,
)

class Importer(
    private val store: ProjectStore,
    private val exists: (String) -> Boolean = { true },
    private val canRun: (String) -> Boolean = { true },
    private val hasFont: (String) -> Boolean = { true },
    private val relink: (Scene) -> Scene = { it },
    private val migration: EffectMigration? = null,
    private val access: MediaAccess = MediaAccess.Unlimited,
    private val limits: ImportLimits = ImportLimits(),
    private val fonts: File? = null,
) {
    fun import(open: () -> InputStream?): List<ImportReport> = try {
        fun stream() = open() ?: throw ImportFailed(txt(R.string.library_err_no_data))
        val head = stream().use { it.readAtMost(4) }
        if (head.size >= 2 && head[0] == 'P'.code.toByte() && head[1] == 'K'.code.toByte()) fromPackage(::stream)
        else if (head.contentEquals(byteArrayOf(0xD0.toByte(), 0xCF.toByte(), 0x11, 0xE0.toByte()))) throw ImportFailed(txt(R.string.fla_err_old))
        else {
            val text = stream().use { readText(it, MaxXml) }.removePrefix("\uFEFF")
            if (text.startsWith("PROXY-CS5")) throw ImportFailed(txt(R.string.fla_err_xfl_alone))
            if (!text.trimStart().startsWith("<")) throw ImportFailed(txt(R.string.library_err_unsupported_type))
            listOf(add(store.newId(), check(text), emptyMap()))
        }
    } catch (e: OutOfMemoryError) {
        throw ImportFailed(txt(R.string.library_err_xml_large))
    }

    private fun fromPackage(open: () -> InputStream): List<ImportReport> {
        val scenes = ArrayList<String>()
        val files = LinkedHashSet<String>()
        var sigs: Map<String, String>? = null
        var links: Map<String, String>? = null
        var companions: Map<String, List<String>> = emptyMap()
        var packedFonts: Map<String, String> = emptyMap()
        val fontFiles = ArrayList<File>()
        var projectEntry: String? = null
        var ours = false
        var sceneText = 0
        var written = limits.unpacked
        val ids = ArrayList<String>()
        val saved = ArrayList<ImportReport>()
        try {
            eachEntry(open, limits) { name, input ->
                files += name
                when {
                    leaf(name) == "manifest.txt" -> sigs = readText(input, MaxXml).lineSequence().map { it.trim().split(':', limit = 3) }.filter { it.size >= 2 }
                        .associate { p -> p[0] to p.last() }
                    leaf(name) == "manifest.json" -> {
                        val manifest = JSONObject(readText(input, MaxXml))
                        projectEntry = manifest.optString("project").takeIf { it.isNotBlank() }
                        ours = manifest.optString("format") == "effects-package"
                        val listed = manifest.optJSONArray("media")?.let { list -> (0 until list.length()).map { list.getJSONObject(it) }.filter { it.has("entry") } }.orEmpty()
                        links = listed.associate { m -> m.getString("uri") to m.getString("entry") }
                        companions = listed.filter { it.has("companions") }.associate { m ->
                            m.getString("uri") to m.getJSONArray("companions").let { c -> List(c.length()) { c.getString(it) } }
                        }
                        packedFonts = manifest.optJSONArray("fonts")?.let { list -> (0 until list.length()).map { list.getJSONObject(it) } }.orEmpty()
                            .filter { it.optString("font").startsWith("imported?") && it.has("entry") }.associate { it.getString("entry") to it.getString("font") }
                    }
                }
            }
            if (sigs == null && links == null) {
                if (files.any { leaf(it) == "DOMDocument.xml" }) return fromFla(open, files)
                throw ImportFailed(txt(R.string.library_err_missing_manifest))
            }
            val declaredProject = projectEntry?.let { find(it, files) ?: throw ImportFailed(txt(R.string.library_err_package_project_missing)) }
            val mediaEntries = (links.orEmpty().values + sigs.orEmpty().values).mapNotNull { find(it, files) }.toSet()
            eachEntry(open, limits) { name, input ->
                if (name == declaredProject || declaredProject == null && name.endsWith(".xml", ignoreCase = true) && name !in mediaEntries) {
                    val text = readText(input, MaxXml)
                    val isScene = declaredProject != null || runCatching { XmlNode.parse(text.removePrefix("\uFEFF"), XmlNode.IMPORT_NODES).name == "scene" }.getOrDefault(false)
                    if (isScene) {
                        if (scenes.size >= limits.scenes) throw ImportFailed(txt(R.string.library_err_too_many_projects, limits.scenes.toString()))
                        sceneText += text.length
                        if (sceneText > limits.sceneText) throw ImportFailed(txt(R.string.library_err_project_files_large))
                        scenes += text
                    }
                }
            }
            if (scenes.isEmpty()) throw ImportFailed(txt(R.string.library_err_no_project))
            repeat(scenes.size) { ids += store.newId(ids) }
            ids.forEach { File(store.mediaDir(it), ImportMarker).apply { parentFile?.mkdirs(); createNewFile() } }
            val copies = HashMap<String, MutableList<File>>()
            val used = HashSet<String>()
            val moved = scenes.mapIndexed { i, text ->
                val id = ids[i]
                val root = check(text)
                used += fontsOf(root)
                val declared = Scene(root).media.associateBy { it.uri }
                val entries = root.storedMediaUris().mapNotNull { uri ->
                    val entry = links?.get(uri) ?: declared[uri]?.node?.get("sig")?.let { sigs?.get(it) }
                        ?: uri.substringAfter(':').takeIf { uri.startsWith("amproj:") || uri.startsWith("am-docs:") }
                    entry?.let { find(it, files) }?.let { uri to it }
                }.toMap()
                val names = hashSetOf(ImportMarker)
                fun unique(name: String) = (sequenceOf(name) + generateSequence(2) { it + 1 }.map { "${it}_$name" }).first { names.add(it) }
                val target = HashMap<String, File>()
                for ((uri, path) in entries) {
                    if (path in target) continue
                    val parts = companions[uri]?.mapNotNull { find(it, files) }
                    if (parts == null) target[path] = File(store.mediaDir(id), unique(portable(leaf(path)!!)))
                    else {
                        val folder = File(store.mediaDir(id), generateSequence(1) { it + 1 }.map { "model-$it" }.first { names.add(it) })
                        (listOf(path) + parts).forEach { part -> target.putIfAbsent(part, File(folder, portable(leaf(part)!!))) }
                    }
                }
                target.forEach { (path, file) -> copies.getOrPut(path) { ArrayList() } += file }
                entries.mapValues { (_, entry) -> target.getValue(entry).toURI().toString() }
            }
            val fontEntries = if (fonts == null) emptyMap() else packedFonts.mapNotNull { (entry, font) -> find(entry, files)?.takeIf { font in used }?.let { it to font } }.toMap()
            val localFonts = HashMap<String, String>()
            if (copies.isNotEmpty() || fontEntries.isNotEmpty()) {
                copies.values.flatten().forEach { it.parentFile?.mkdirs() }
                eachEntry(open, limits) { name, input ->
                    fontEntries[name]?.let { font -> installFont(input, font, fonts!!, fontFiles)?.let { localFonts[font] = it } }
                    val targets = copies[name] ?: return@eachEntry
                    written -= copy(input, targets.first(), written)
                    for (other in targets.drop(1)) written -= targets.first().inputStream().use { copy(it, other, written) }
                }
            }
            val renamedFonts = localFonts.filter { (old, new) -> old != new }
            scenes.indices.mapTo(saved) { add(ids[it], check(scenes[it]).let { root -> if (renamedFonts.isEmpty()) root else root.mapFonts(renamedFonts) }, moved[it]) }
            ids.forEach { File(store.mediaDir(it), ImportMarker).delete(); store.mediaDir(it).delete() }
            return if (ours) saved else saved.map { if (it.element) it else it.copy(template = true) }
        } catch (t: Throwable) {
            ids.forEach { store.mediaDir(it).deleteRecursively() }
            saved.forEach { store.delete(it.id) }
            fontFiles.forEach { it.delete() }
            if (t is IOException || t is org.json.JSONException) throw ImportFailed(txt(R.string.library_err_malformed_package, t.message.toString()))
            throw t
        }
    }

    private fun fromFla(open: () -> InputStream, files: Set<String>): List<ImportReport> {
        val root = files.filter { leaf(it) == "DOMDocument.xml" }.minBy { path -> path.count { it == '/' } }.removeSuffix("DOMDocument.xml")
        val texts = HashMap<String, String>()
        var size = 0
        eachEntry(open, limits) { name, input ->
            val path = name.takeIf { it.startsWith(root) }?.removePrefix(root) ?: return@eachEntry
            if (path == "DOMDocument.xml" || path.startsWith("LIBRARY/") && path.endsWith(".xml", ignoreCase = true)) {
                val text = readText(input, MaxXml)
                size += text.length
                if (size > limits.sceneText) throw ImportFailed(txt(R.string.library_err_project_files_large))
                texts[path] = text
            }
        }
        val fla = try { readFla(texts) } catch (e: IllegalArgumentException) { throw ImportFailed(txt(R.string.library_err_malformed_xml, e.message.toString())) }
        checkScene(fla.root)?.let { throw ImportFailed(it) }
        val title = files.lastOrNull { it.startsWith(root) && '/' !in it.removePrefix(root) && it.endsWith(".xfl", ignoreCase = true) }?.removePrefix(root)?.dropLast(4).orEmpty()
        val records = fla.root.children.filter { it.name == "media" }.associateBy { it["uri"] }
        val wanted = fla.media.entries.groupBy({ root + it.value }, { it.key })
        val counts = LinkedHashMap(fla.counts)
        val id = store.newId()
        val dir = store.mediaDir(id)
        val marker = File(dir, ImportMarker)
        val written = ArrayList<File>()
        val moved = HashMap<String, String>()
        try {
            marker.parentFile?.mkdirs()
            marker.createNewFile()
            var left = limits.unpacked
            val names = HashSet<String>()
            eachEntry(open, limits) { name, input ->
                val uris = wanted[name] ?: return@eachEntry
                val sound = records[uris.first()]?.get("type")?.startsWith("audio/") == true
                val bytes = input.readAtMost(MaxFlaMedia + 1).takeIf { it.size <= MaxFlaMedia }
                val decoded = bytes?.let { if (sound) flaSound(it) else flaPicture(it) }
                if (decoded == null) {
                    val part = if (sound) FlaPart.UnreadSounds else FlaPart.UnreadPictures
                    counts[part] = (counts[part] ?: 0) + 1
                    return@eachEntry
                }
                left -= decoded.first.size
                if (left < 0) throw ImportFailed(txt(R.string.library_err_package_large, (limits.unpacked shr 20).toString()))
                val stem = (records[uris.first()]?.get("filename") ?: "media").substringBeforeLast('.').replace(Regex("[^\\p{L}\\p{N} ._-]"), "_").take(80).ifBlank { "media" }
                val file = File(dir, (sequenceOf("$stem.${decoded.second}") + generateSequence(2) { it + 1 }.map { "$stem-$it.${decoded.second}" }).first { names.add(it) })
                written += file
                file.outputStream().use { it.write(decoded.first); it.fd.sync() }
                uris.forEach { moved[it] = file.toURI().toString() }
            }
            val parts = counts.filterValues { it > 0 }.entries
            val sections = listOf(true, false).map { kept ->
                txt(if (kept) R.string.fla_report_imported else R.string.fla_report_skipped) to parts.filter { it.key.imported == kept }.map { txt(it.key.label, it.value.toString()) }
            }.filter { it.second.isNotEmpty() }
            val report = add(id, fla.root.with("title", title), moved, sections)
            marker.delete()
            dir.delete()
            return listOf(report)
        } catch (t: Throwable) {
            written.forEach { it.delete() }
            marker.delete()
            dir.delete()
            throw t
        }
    }

    private fun check(text: String): XmlNode {
        val root = try { XmlNode.parse(text.removePrefix("\uFEFF"), XmlNode.IMPORT_NODES) } catch (e: Exception) { throw ImportFailed(txt(R.string.library_err_malformed_xml, e.message.toString())) }
        checkScene(root)?.let { throw ImportFailed(it) }
        return root
    }

    private fun add(id: String, root: XmlNode, moved: Map<String, String>, sections: List<Pair<UiText, List<UiText>>> = emptyList()): ImportReport {
        try {
            var scene = relink(Scene(uniqueLayerIds(root.mapMediaUris { moved[it] ?: access.imported(it) })))
            val migrated = migration?.migrate(scene)
            if (migrated != null) scene = migrated.scene
            if (scene.title.isBlank()) scene = scene.withTitle(AppText.get(R.string.library_imported_project))
            val missing = scene.node.mediaUris().filterNot { access.allows(it) && exists(it) }
            for (uri in missing) scene = scene.withMedia(MediaDeclaration(XmlNode("media", mapOf("uri" to uri))))
            scene = Scene(scene.node.copy(children = scene.node.children.map { if (it.name == "media" && it["uri"] in missing) it.with("missing", "true") else it }))
            val result = ImportReport(id, scene.title, scene.node["type"] == "element", sections + report(scene, missing, migrated))
            store.save(id, scene)
            return result
        } catch (t: Throwable) {
            store.mediaDir(id).deleteRecursively()
            throw t
        }
    }

    private fun report(scene: Scene, missing: List<String>, migrated: EffectMigration.Result?): List<Pair<UiText, List<UiText>>> {
        val layers = allLayers(scene.node).toList()
        val unknown = sortedSetOf<String>()
        scene.node.children.filter { it.name !in Scene.LAYER_TAGS && it.name != "media" && it.name != "bookmark" }.forEach { unknown += "<${it.name}>" }
        for (layer in layers) for (attr in layer.attrs.keys - KnownAttributes) unknown += "${layer.name} $attr"
        val effects = layers.flatMap { l -> l.children.filter { it.name == "effect" }.mapNotNull { it["id"] }.distinct() }
            .groupingBy { it }.eachCount().filterKeys { !canRun(it) }
            .map { (id, n) -> UiText.plural(R.plurals.library_report_effect_layers, n, id.substringAfterLast('.'), n.toString()) }
        val fonts = layers.filter { it.name == "text" }.mapNotNull { it["font"] }.filter { it.startsWith("imported") && !hasFont(it) }
            .map { it.substringAfter("name=").substringBefore('&') }.distinct()
        val names = missing.map { uri -> scene.media(uri)?.filename?.takeIf { it.isNotEmpty() } ?: uri.substringAfterLast('/') }
        return listOf(
            txt(R.string.library_report_unknown) to unknown.map(::reportText), txt(R.string.library_report_cannot_run) to effects,
            txt(R.string.library_report_dropped) to migrated?.dropped?.map(::reportText).orEmpty(),
            txt(R.string.library_report_media) to names.map(::reportText), txt(R.string.library_report_fonts) to fonts.map(::reportText),
        ).filter { it.second.isNotEmpty() }
    }

    companion object {
        private const val MaxXml = 16 shl 20
        private const val MaxFlaMedia = 256 shl 20
        private const val MaxSide = 16384
        private const val MaxFps = 240
        private const val MaxHours = 24

        internal fun checkScene(root: XmlNode): UiText? {
            val width = root["width"]?.toIntOrNull() ?: 0
            val height = root["height"]?.toIntOrNull() ?: 0
            return when {
                root.name != "scene" || width <= 0 || height <= 0 -> txt(R.string.library_err_scene_needs_size)
                width > MaxSide || height > MaxSide -> txt(R.string.library_err_scene_too_big, MaxSide.toString())
                root["fps"]?.toIntOrNull()?.let { it !in 1..MaxFps } == true -> txt(R.string.library_err_scene_fps, MaxFps.toString())
                root["totalTime"]?.toLongOrNull()?.let { it !in 0..MaxHours * 3_600_000L } == true -> txt(R.string.library_err_scene_long, MaxHours.toString())
                else -> null
            }
        }

        private val KnownAttributes = setOf(
            "id", "label", "startTime", "endTime", "fillType", "fillImage", "fillVideo", "inTime", "outTime", "speed", "blending",
            "parent", "hidden", "clippingMask", "mediaFillMode", "s", "tag", "align", "font", "size", "wrapWidth", "src", "type", "link",
            "presetId", "templatePPId", "points", "color", "stroke", "style", "scaleLinked", "loop", "loopIn", "mixPieces", "threeD",
            "noiseId", "retimeLength", "pathLayer", "matteFrame", "matteEdge", "genIn", "genOut", "genLoop", "outlineShape", "outlineMark",
        )

        private fun uniqueLayerIds(root: XmlNode): XmlNode {
            val taken = HashSet<Long>()
            fun collect(node: XmlNode) {
                if (node.name in Scene.LAYER_TAGS) node["id"]?.toLongOrNull()?.let(taken::add)
                node.children.forEach(::collect)
            }
            collect(root)
            val seen = HashSet<Long>()
            fun scene(node: XmlNode): XmlNode {
                val owners = HashMap<Long, Long>()
                val renumbered = node.children.map { child ->
                    if (child.name !in Scene.LAYER_TAGS) return@map child
                    val old = child["id"]?.toLongOrNull()?.takeIf { it != 0L }
                    val id = if (old != null && seen.add(old)) old else generateSequence { Layer.newId() }.first { taken.add(it) }
                    if (old != null) owners.putIfAbsent(old, id)
                    if (id == old) child else child.with("id", "$id")
                }
                return node.copy(children = renumbered.map { child ->
                    if (child.name !in Scene.LAYER_TAGS) return@map child
                    val parent = child["parent"]?.toLongOrNull()?.let(owners::get)
                    val linked = (if (parent == null || child["parent"] == "$parent") child else child.with("parent", "$parent")).withSiblingRefs(owners::get)
                    if (linked.name == "embedScene") linked.child("scene")?.let { linked.withChild("scene", scene(it)) } ?: linked else linked
                })
            }
            return scene(root)
        }

        private fun allLayers(scene: XmlNode): Sequence<XmlNode> = scene.children.asSequence().filter { it.name in Scene.LAYER_TAGS }
            .flatMap { sequenceOf(it) + (it.child("scene")?.let(::allLayers) ?: emptySequence()) }

        private fun fontsOf(root: XmlNode): Set<String> = allLayers(root).filter { it.name == "text" }.mapNotNull { it["font"] }.filter { it.startsWith("imported?") }.toSet()

        private fun installFont(input: InputStream, font: String, dir: File, made: MutableList<File>): String? {
            val bytes = input.readAtMost(MAX_FONT_BYTES + 1).takeIf { it.size <= MAX_FONT_BYTES } ?: return null
            val (checked, kind) = try { checkedFont(bytes) } catch (e: FontImportError) { return null }
            if (!dir.isDirectory && !dir.mkdirs()) return null
            dir.listFiles()?.firstOrNull { it.isFile && it.length() == checked.size.toLong() && it.readBytes().contentEquals(checked) }?.let { return "imported?name=${it.name}" }
            val clean = File(font.substringAfter("name=").substringBefore('&')).name.substringBeforeLast('.').replace(Regex("[^\\p{L}\\p{N} ._-]"), "_").take(80).ifBlank { "font" }
            val target = (sequenceOf("$clean.${kind.extension}") + generateSequence(1) { it + 1 }.map { "$clean-$it.${kind.extension}" }).map { File(dir, it) }.first { !it.exists() }
            val part = File(dir, target.name + ".part")
            try {
                part.outputStream().use { it.write(checked); it.fd.sync() }
                if (!part.renameTo(target)) return null
            } finally {
                part.delete()
            }
            made += target
            return "imported?name=${target.name}"
        }

        private fun leaf(name: String): String? = name.substringAfterLast('/').substringAfterLast('\\').takeIf { it.isNotEmpty() && it != "." && it != ".." }

        private fun portable(name: String) = name.replace(Regex("[<>:\"|?*\\x00-\\x1f]"), "_").trimEnd(' ', '.').ifEmpty { "media" }

        private fun entryPath(name: String) = name.replace('\\', '/').trimStart('/')

        private fun find(reference: String, paths: Collection<String>): String? {
            val path = entryPath(reference)
            val name = leaf(path) ?: return null
            return path.takeIf { it in paths } ?: paths.firstOrNull { it.endsWith("/$path") } ?: paths.firstOrNull { leaf(it) == name }
        }

        private fun eachEntry(open: () -> InputStream, limits: ImportLimits, visit: (String, InputStream) -> Unit) {
            var left = limits.unpacked
            var entries = 0
            ZipInputStream(open().buffered()).use { zip ->
                fun charge(n: Int) {
                    left -= n
                    if (left < 0) throw ImportFailed(txt(R.string.library_err_package_large, (limits.unpacked shr 20).toString()))
                }
                val counted = object : InputStream() {
                    override fun read(): Int = zip.read().also { if (it >= 0) charge(1) }
                    override fun read(b: ByteArray, off: Int, len: Int): Int = zip.read(b, off, len).also { if (it > 0) charge(it) }
                }
                while (true) {
                    val entry = (try { zip.nextEntry } catch (e: IllegalArgumentException) { throw ImportFailed(txt(R.string.library_err_malformed_package, e.message.toString())) }) ?: break
                    if (++entries > limits.entries) throw ImportFailed(txt(R.string.library_err_too_many_files, limits.entries.toString()))
                    if (!entry.isDirectory) entryPath(entry.name).takeIf { leaf(it) != null }?.let { visit(it, counted) }
                    counted.drain()
                }
            }
        }

        private fun readText(input: InputStream, limit: Int): String {
            val bytes = input.readAtMost(limit + 1)
            if (bytes.size > limit) throw ImportFailed(txt(R.string.library_err_xml_large))
            return bytes.toString(Charsets.UTF_8)
        }

        private fun copy(input: InputStream, target: File, allowed: Long): Long {
            var total = 0L
            val buffer = ByteArray(64 * 1024)
            try {
                target.outputStream().use { out ->
                    while (true) {
                        val n = input.read(buffer)
                        if (n < 0) break
                        total += n
                        if (total > allowed) throw ImportFailed(txt(R.string.library_err_media_large, (allowed shr 20).toString()))
                        out.write(buffer, 0, n)
                    }
                    out.fd.sync()
                }
            } catch (t: Throwable) {
                target.delete()
                throw t
            }
            return total
        }

        fun forApp(context: Context, store: ProjectStore): Importer {
            val catalog = EffectCatalog.read(context)
            val fonts = FontLibrary(context)
            return Importer(
                store,
                access = MediaAccess.forApp(context),
                exists = { uri -> runCatching { context.contentResolver.openAssetFileDescriptor(Uri.parse(uri), "r")?.use { true } }.getOrNull() == true },
                canRun = { catalog.find(it) != null || it.endsWith(".textspacing") },
                hasFont = { fonts.localFile(it) != null },
                relink = { MediaRelink.relink(context, it) },
                migration = EffectMigration.read(context, catalog),
                fonts = File(context.filesDir, "fonts/imported"),
            )
        }
    }
}

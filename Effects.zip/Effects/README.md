# Effects

Android video / motion editor. Kotlin + Jetpack Compose UI, C++ engine on Skia (Vulkan/GL), package `com.effects.motion`.

Derived from the open-source AbsentMotion 5.0.2 (GPL-3.0). See `LICENSE`, `NOTICE` and `THIRD_PARTY_NOTICES.md`,
which must stay with the source and the app.

## Build
See `docs/BUILD.md`. Skia is built from source first (`tools/build_skia.sh`), then:

    ./gradlew :app:assembleFossDebug

No PC? Push this folder to a GitHub repository: `.github/workflows/build.yml` builds Skia and the APK in the cloud
(Actions tab > build > Run workflow) and attaches `Effects-debug-apk`. The first run takes 1 to 2 hours, later runs reuse the cached Skia.
`third_party/whisper.cpp` and `third_party/ncnn` are fetched by the workflow (they are not in the zip).

## Effects
The effect system (browser, panels, parameters, presets, native renderer) is in place but the catalog is empty:
`shared/assets/effects/index.json` is `[]`. Effects are added by dropping `<id>.json` (plus thumbnails) into
`shared/assets/effects/` and listing the id in `index.json`. Tests that need real effects are parked in
`app/disabled_tests_until_effects_return/`.

## Preview rendering
Pressing Play or stopping playback now renders the preview automatically when it is out of date
(`ui/editor/RenderPreview.kt`, `RenderPreviewNotes`). The Pre-render button still works as a manual trigger.

## Thumbnails
Put pictures in the repo's `thumbs/` folder (the cloud build copies them into `shared/assets/effects/thumb/`):
- `category-color.png`, `category-blur.png`, ... one picture per category. Every effect in that category uses it, and the category card shows it too. Categories: color, blur, distort, stylize, noise, repeat, key, move, beat, 3d, text, other.
- `<effect id>.png` gives one effect its own picture (it wins over the category picture).
Formats: png, jpg, jpeg or webp. A category with no picture keeps its built-in look.

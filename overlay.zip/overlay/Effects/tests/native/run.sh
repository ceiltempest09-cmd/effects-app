#!/bin/bash
# Builds and runs the host tests (no Android SDK/NDK, Skia, GPU or shader compiler needed). Run from anywhere.
set -e
cd "$(dirname "$0")/../.."
CXX=${CXX:-g++}
FLAGS="-std=c++20 -fno-exceptions -fno-rtti -Wall -Wextra -I shared/cpp"
OUT=${OUT:-/tmp/em-native-tests}; mkdir -p "$OUT"
$CXX $FLAGS tests/native/render_graph_test.cpp shared/cpp/render_graph.cpp shared/cpp/render_graph_xml.cpp shared/cpp/xml.cpp -lexpat -o "$OUT/render_graph_test"
$CXX $FLAGS tests/native/native_shader_test.cpp shared/cpp/render_graph.cpp shared/cpp/shader_info.cpp shared/cpp/shader_diag.cpp shared/cpp/shader_cache.cpp shared/cpp/spirv_util.cpp -o "$OUT/native_shader_test"
$CXX $FLAGS tests/native/spirv_reflect_test.cpp shared/cpp/spirv_reflect.cpp -o "$OUT/spirv_reflect_test"
$CXX $FLAGS tests/native/glsl_wrap_test.cpp shared/cpp/glsl_wrap.cpp -o "$OUT/glsl_wrap_test"
$CXX $FLAGS tests/native/history_signature_test.cpp -o "$OUT/history_signature_test"
$CXX $FLAGS tests/native/color_pipeline_test.cpp -o "$OUT/color_pipeline_test"
"$OUT/render_graph_test"
"$OUT/native_shader_test"
"$OUT/spirv_reflect_test"
"$OUT/glsl_wrap_test"
"$OUT/history_signature_test"
"$OUT/color_pipeline_test"
# Real-GPU tests (GL backend + executor on the machine's EGL driver). Skipped with a message when there is no libEGL / GL driver.
if ldconfig -p 2>/dev/null | grep -q libEGL; then bash tests/native/build_gl.sh; else echo "SKIP gl_backend_test: no libEGL on this machine"; fi

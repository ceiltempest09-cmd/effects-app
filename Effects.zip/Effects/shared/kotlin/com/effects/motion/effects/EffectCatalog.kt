package com.effects.motion.effects

import android.graphics.ImageDecoder
import android.graphics.drawable.Drawable
import com.effects.motion.R
import com.effects.motion.i18n.currentLanguage
import com.effects.motion.platform.Context
import com.effects.motion.ui.editor.matchesSearch
import org.json.JSONArray
import org.json.JSONObject
import java.io.InputStream

/** The three effect packs shown by the picker in the Effects Library header. Default = json, Vibrant HQS = glsl, RayTraced VFX = emx. */
object EffectPacks {
    const val Default = "default"
    const val Vibrant = "vibrant"
    const val RayTraced = "raytraced"
    val all: List<Pair<String, String>> = listOf(Default to "Default", Vibrant to "Vibrant HQS", RayTraced to "RayTraced VFX")
    fun index(pack: String): String = if (pack == Default) "index.json" else "index.$pack.json"
}

val EffectCategories: List<Pair<String, String>> = EffectCatalog.Categories.toList() + (if (com.effects.motion.platform.PlatformFeatures.ai) listOf("ai" to "AI") else emptyList())

data class EffectCatalog(
    val definitions: List<EffectDefinition> = emptyList(),
    val message: String? = null,
    private val open: ((String) -> InputStream)? = null,
    val newest: Set<String> = emptySet(),
    val categoryNames: Map<String, String> = emptyMap(),
    val pack: String = EffectPacks.Default,
    val source: String = EffectSources.Native,
) {
    /** The same catalog showing only one pack's effects and categories (the engine keeps using the full catalog). */
    fun forPack(pack: String): EffectCatalog = copy(pack = pack, definitions = definitions.filter { it.pack == pack })

    fun forSource(source: String): EffectCatalog = copy(source = source, definitions = definitions.filter { it.source == source })

    fun find(id: String): EffectDefinition? = definitions.firstOrNull { it.id == id }

    fun isNew(effect: EffectDefinition): Boolean = effect.since in newest

    fun listed(category: String? = null): List<EffectDefinition> =
        definitions.filter { category == null || it.category == category || (category == "new" && isNew(it)) }

    fun search(query: String): List<EffectDefinition> {
        val byName = definitions.filter { matchesSearch(query, it.name) }.sortedWith(compareBy({ searchRank(query, it.name) }, { it.name.lowercase() }))
        return byName + definitions.filter { it !in byName && matchesSearch(query, it.name, it.description) }.sortedBy { it.name.lowercase() }
    }

    val categories: List<Pair<String, String>> get() =
        if (source != EffectSources.Native) definitions.map { it.category }.distinct().map { it to (categoryNames[it] ?: importedCategoryLabel(it)) }
        else nativeCategories
    private val nativeCategories: List<Pair<String, String>> get() =
        ((if (definitions.any(::isNew)) listOf("new" to "New") else emptyList()) + (if (pack == EffectPacks.Default) EffectCategories else categoriesOf(pack).toList())).map { (k, v) -> k to (categoryNames[k] ?: v) }

    fun categoryThumbnail(category: String): String? = open?.let { o ->
        (if (pack != EffectPacks.Default) firstThumbnail(o, "category-$pack-$category") else null) ?: firstThumbnail(o, "category-$category")
    }

    fun bytes(path: String?): ByteArray? = path?.let { p -> runCatching { open?.invoke(p)?.use { it.readBytes() } }.getOrNull() }

    fun drawable(path: String?): Drawable? = bytes(path)?.let { bytes ->
        runCatching {
            if (android.os.Build.VERSION.SDK_INT >= 28) ImageDecoder.decodeDrawable(ImageDecoder.createSource(java.nio.ByteBuffer.wrap(bytes)))
            else android.graphics.BitmapFactory.decodeByteArray(bytes, 0, bytes.size)?.let { android.graphics.drawable.BitmapDrawable(null, it) }
        }.getOrNull()
    }

    fun loadInto(load: (String) -> String): EffectCatalog {
        val status = definitions.associate { it.id to load(it.runtimeXml()).substringBefore('\n') }
        return copy(definitions = definitions.map { it.copy(status = status.getValue(it.id)) })
    }

    fun withRuntimeStatusFrom(previous: EffectCatalog): EffectCatalog {
        if (message != null && previous.definitions.isNotEmpty()) return previous
        val status = previous.definitions.associate { it.id to it.status }
        return copy(definitions = definitions.map { it.copy(status = status[it.id] ?: it.status) })
    }

    companion object {
        val Categories = linkedMapOf("color" to "Color", "blur" to "Blur", "distort" to "Distort", "stylize" to "Stylize",
            "noise" to "Noise", "repeat" to "Repeat", "key" to "Key", "move" to "Move", "beat" to "Beat", "3d" to "3D", "text" to "Text", "other" to "Other")

        // Vibrant HQS (glsl files): its own category set.
        val VibrantCategories = linkedMapOf("glow" to "Glow & Bloom", "neon" to "Neon & Color", "liquid" to "Liquid & Wave", "glitch" to "Glitch & Pulse",
            "leaks" to "Light Leaks", "sparkle" to "Sparkle & Particles", "depth" to "3D Depth", "beat" to "Beat Sync", "text" to "Text FX", "other" to "Other")

        // RayTraced VFX (emx files): the layout of the category picture (Color & Light ... PNKJ).
        val RayTracedCategories = linkedMapOf("colorlight" to "Color & Light", "drawedge" to "Drawing & Edge", "blur" to "Blur", "warp" to "Distortion/Warp",
            "procedural" to "Procedural", "3d" to "3D", "transform" to "Move/Transform", "repeat" to "Repeat", "matte" to "Matte/Mask/Key",
            "opacity" to "Opacity/Visibility", "text" to "Text", "pnkj" to "PNKJ")

        fun categoriesOf(pack: String): Map<String, String> = when (pack) {
            EffectPacks.Vibrant -> VibrantCategories
            EffectPacks.RayTraced -> RayTracedCategories
            else -> Categories
        }

        fun read(context: Context): EffectCatalog = parse(currentLanguage(context).tag) { context.assets.open("effects/$it") }
            .let { if (it.message != null) it.copy(message = context.getString(R.string.effects_not_loaded)) else it }
            .let { it.copy(definitions = it.definitions + ImportedEffects.load(context)) }

        fun parse(language: String = "en", open: (String) -> InputStream): EffectCatalog = runCatching {
            fun text(path: String) = open(path).bufferedReader().use { it.readText() }
            // index.json (Default) is required; index.vibrant.json and index.raytraced.json are optional.
            val definitions = EffectPacks.all.flatMap { (pack, _) ->
                val keys = if (pack == EffectPacks.Default) JSONArray(text(EffectPacks.index(pack)))
                    else runCatching { JSONArray(text(EffectPacks.index(pack))) }.getOrNull() ?: return@flatMap emptyList()
                List(keys.length()) { keys.getString(it) }.mapNotNull { key ->
                    runCatching { EffectDefinition.parse(JSONObject(text("$key.json")), pack) }.getOrNull()
                }
            }.map { d -> (firstThumbnail(open, d.key) ?: firstThumbnail(open, "category-${d.category}"))?.let { d.copy(thumbnailPath = it) } ?: d }
            val releases = runCatching { JSONArray(text("releases.json")).let { a -> List(a.length()) { a.getString(it) } } }.getOrDefault(emptyList())
            val versions = releases + definitions.mapNotNull { it.since }
            val major = versions.mapNotNull { it.substringBefore('.').toIntOrNull() }.maxOrNull()
            val catalog = EffectCatalog(definitions, open = open, newest = versions.filter { it.substringBefore('.').toIntOrNull() == major }.toSet())
            if (language == "en") catalog else runCatching { catalog.translated(JSONObject(text("i18n/$language.json"))) }.getOrDefault(catalog)
        }.getOrElse { EffectCatalog(message = "The effects could not be loaded") }
    }
}

fun EffectCatalog.translated(json: JSONObject): EffectCatalog {
    val effects = json.optJSONObject("effects") ?: JSONObject()
    val names = json.optJSONObject("categories")
    return copy(
        categoryNames = names?.keys()?.asSequence()?.associateWith { names.getString(it) }.orEmpty(),
        definitions = definitions.map { d -> effects.optJSONObject(d.key)?.let(d::translated) ?: d },
    )
}

private fun EffectDefinition.translated(json: JSONObject): EffectDefinition {
    val params = json.optJSONObject("params") ?: JSONObject()
    val presetNames = json.optJSONObject("presets") ?: JSONObject()
    return copy(
        name = json.optString("name").ifBlank { name },
        description = json.optString("description").ifBlank { description },
        params = this.params.map { p ->
            val t = params.optJSONObject(p.id) ?: return@map p
            val options = t.optJSONArray("options")?.let { a -> List(a.length()) { a.optString(it) } }
            p.copy(
                label = t.optString("label").ifBlank { p.label },
                options = if (options != null && options.size == p.options.size && options.none { it.isBlank() }) options else p.options,
            )
        },
        presets = presets.map { it.copy(name = presetNames.optString(it.slug).ifBlank { it.name }) },
    )
}

internal fun searchRank(query: String, name: String): Int {
    val q = query.trim().lowercase()
    val n = name.trim().lowercase()
    return when {
        q.isEmpty() -> 3
        n == q -> 0
        n.startsWith(q) -> 1
        n.split(' ', '-', '/', '(').any { it.startsWith(q) } -> 2
        else -> 3
    }
}

private val ThumbnailTypes = listOf("webp", "png", "jpg", "jpeg")

// A picture added by the user: thumb/<name>.webp, .png, .jpg or .jpeg
private fun firstThumbnail(open: (String) -> InputStream, name: String): String? =
    ThumbnailTypes.map { "thumb/$name.$it" }.firstOrNull { path -> runCatching { open(path).close(); true }.getOrDefault(false) }

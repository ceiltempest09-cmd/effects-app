// bridge_selftest.h - end-to-end check of the Skia <-> native GL bridge with the REAL engine (Graphite on Vulkan).
#pragma once
#include <string>
namespace am {
// Appends report lines to *text and counts PASS/FAIL. Renders a scene three ways (no effect, all-SkSL effect, SkSL -> GLSL ES -> SkSL
// effect) into hardware buffers and compares the pixels read back on the CPU.
void RunBridgeSelfTest(std::string* text, int* pass, int* fail, const std::string& cacheDir);
// Crash isolation: before each risky stage a marker file is written in cacheDir. If the app dies in that stage, the next run reports it and
// skips that stage once, so the rest of the report still appears.
}

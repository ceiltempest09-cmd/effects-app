package com.effects.motion.export

import android.os.Build
import android.util.Log
import com.effects.motion.editor.previewDirtyRanges
import com.effects.motion.editor.temporalSpans
import com.effects.motion.model.Scene
import com.effects.motion.model.mediaUris
import com.effects.motion.platform.Context

/** Everything one export needs to know about Smart Export before it starts. */
internal class SmartSetup(
    /** Key of everything that decides how a frame is encoded; saved groups are only used when it is equal. */
    val ctx: String,
    /** The scene as it is rendered, without titles and timestamps. Saved next to the encoded groups. */
    val canonical: String,
    val media: Map<String, String>,
    val frames: Int,
    /** History (temporal) spans in export frames. The live pictures stay off these frames either way. */
    val history: List<IntRange>,
    /** The saved export to copy from and the plan for it; null when nothing can be reused (the export is still saved for next time). */
    val entry: SmartEntry?,
    val plan: SmartPlan?,
    val estimateBytes: Long,
)

/**
 * Smart Export: reuse the encoded groups of pictures of an earlier export for the parts of the timeline that did not change, and render
 * only the rest. Quality is never traded: reused packets are the exact bytes of the earlier export, everything else is rendered and
 * encoded with the same size, frame rate, codec, bitrate and precision. Whenever that cannot be guaranteed the export renders everything.
 */
internal object SmartExport {
    private const val TAG = "AMSmart"
    private const val GUARD = "smart_export_guard"
    private const val MAX_TRIPS = 3

    /** Effects that keep state from frame to frame without declaring it in an effect graph. Treated like history effects, to be safe. */
    private fun statefulBuiltin(id: String) = id.startsWith("fx.particles")

    fun supported(s: ExportSettings): Boolean =
        s.smart && (s.codec == Codec.H264 || s.codec == Codec.Hevc) && !s.smoothing.active &&
            (s.container == Container.Mp4 || s.container == Container.Mov || s.container == Container.Mkv)

    private fun prefs(context: Context) = context.applicationContext.getSharedPreferences(GUARD, android.content.Context.MODE_PRIVATE)

    private fun appStamp(context: Context): Long = runCatching { context.packageManager.getPackageInfo(context.packageName, 0).lastUpdateTime }.getOrDefault(0L)

    /** Smart Export switches itself off on a device after it had to fall back for integrity reasons several times; an app update resets that. */
    fun tripped(context: Context): Boolean {
        val p = prefs(context)
        if (p.getLong("stamp", -1L) != appStamp(context)) { p.edit().clear().putLong("stamp", appStamp(context)).apply(); return false }
        return p.getInt("trips", 0) >= MAX_TRIPS
    }

    fun trip(context: Context, why: String) {
        Log.w(TAG, "falling back to a full render: $why")
        val p = prefs(context)
        p.edit().putLong("stamp", appStamp(context)).putInt("trips", p.getInt("trips", 0) + 1).apply()
    }

    fun contextKey(context: Context, s: ExportSettings, width: Int, height: Int, turn: Boolean, bitrate: Int): String =
        ExportReuse.sha(listOf(
            "smart1", Build.FINGERPRINT, appStamp(context), s.codec.name, s.container.name, s.shortSide, s.fps, width, height, turn, bitrate,
            s.precision.name, s.quality,
            ExportReuse.foldersSignature(context, "effect", "lut"), ExportReuse.foldersSignature(context, "font"),
        ).joinToString("\n"))

    /** Frame spans (of the export) in which an effect keeps history from frame to frame. */
    fun history(rendered: Scene, s: ExportSettings, frames: Int, isTemporal: (String) -> Boolean): List<IntRange> =
        temporalSpans(rendered) { isTemporal(it) || statefulBuiltin(it) }.map { toExportFrames(it, rendered.fps, s.fps, frames) }

    /** The scene as saved: no title or timestamps, which never change a picture. */
    fun canonical(xml: String): String = Scene.parse(xml).node.let { it.copy(attrs = it.attrs - setOf("title", "modifiedTime", "createdTime")) }.toXml()

    /** Null when something the video uses cannot be read (then nothing is reused). */
    private fun mediaOf(context: Context, scene: Scene): Map<String, String>? {
        val out = HashMap<String, String>()
        for (uri in scene.node.mediaUris()) {
            val sample = ExportReuse.sampleOf(context, uri) ?: return null
            out[uri] = "${sample.second}:${ExportReuse.modified(context, uri)}"
        }
        return out
    }

    /**
     * Looks for the saved export that lets the most frames be skipped. Runs on a background thread. Returns null when Smart Export does not
     * apply at all (then the export runs the normal way and does not touch the cache).
     */
    fun prepare(
        context: Context, scene: Scene, xml: String, s: ExportSettings, width: Int, height: Int, turn: Boolean, bitrate: Int,
        frames: Int, history: List<IntRange>, estimateBytes: Long,
    ): SmartSetup? {
        try {
            if (!supported(s) || tripped(context)) return null
            val canonical = canonical(xml)
            val media = mediaOf(context, scene) ?: return null
            val ctx = contextKey(context, s, width, height, turn, bitrate)
            val rendered = Scene.parse(canonical)
            var best: Pair<SmartEntry, SmartPlan>? = null
            for (e in SegmentStore.candidates(context, ctx)) {
                val plan = planFor(e, rendered, media, s, frames, history) ?: continue
                if (best == null || plan.skipped > best.second.skipped) best = e to plan
            }
            return SmartSetup(ctx, canonical, media, frames, history, best?.first, best?.second, estimateBytes)
        } catch (e: Exception) {
            Log.w(TAG, "Smart Export is not used for this export", e)
            return null
        }
    }

    private fun planFor(e: SmartEntry, rendered: Scene, media: Map<String, String>, s: ExportSettings, frames: Int, history: List<IntRange>): SmartPlan? {
        val old = Scene.parse(e.scene)
        if (old.fps != rendered.fps) return null
        val dirty = ArrayList<IntRange>()
        // Media that changed on disk: the layers that use it are dirty, through the same dependency rules as an edit.
        val changed = media.filter { (uri, fp) -> e.media[uri] != fp }.keys
        val owners = HashSet<String>()
        val headerUris = rendered.node.copy(children = rendered.node.children.filter { it.name !in Scene.LAYER_TAGS }).mediaUris()
        if (changed.any { it in headerUris }) return null
        for (layer in rendered.layers) if (layer.node.mediaUris().any { it in changed }) owners += layer.id.toString()
        for (r in previewDirtyRanges(old, rendered, owners)) dirty += toExportFrames(r, rendered.fps, s.fps, frames)
        return planSmartExport(frames, e.gops, dirty, history)
    }
}

#pragma once

#include "scene.h"
#include "include/effects/SkRuntimeEffect.h"
#include <cstdint>
#include <functional>
#include <map>
#include <memory>
#include <set>
#include <string>
#include <vector>

class SkImage;
class SkImageFilter;

namespace am {

struct Palette;

using Grab = std::function<bool(int, int, const std::function<void(SkCanvas*)>&, std::vector<uint8_t>*)>;
using Upload = std::function<sk_sp<SkImage>(const sk_sp<SkImage>&)>;

struct GraphProgram;

// Which render stream the calling thread belongs to. Temporal (history) multi-pass effects keep one history per stream, so a preview
// scrubbing at one time never disturbs an export running at another. 0 = live preview (default), 1 = export, 2 = still frames.
class GraphStream {
public:
    explicit GraphStream(int id);
    ~GraphStream();
    GraphStream(const GraphStream&) = delete;
    GraphStream& operator=(const GraphStream&) = delete;
private:
    int fPrevious;
};

class EffectRuntime {
public:
    EffectRuntime();
    ~EffectRuntime();
    EffectRuntime(const EffectRuntime&) = delete;
    EffectRuntime& operator=(const EffectRuntime&) = delete;
    std::string load(const std::string& xml);
    // Multi-pass effects: free every pooled render target and history (device loss, context recreation, low memory, backgrounding).
    void dropGraphs() const;
    void clearGraphs() const;  // destroys graph runners while their owning GPU context is still alive
    void trimGraphs() const;
    // JSON array with pass timings and pool statistics of every live multi-pass effect instance.
    std::string graphReport() const;
    bool active(const Layer& layer) const;
    bool lifted(const Layer& layer) const;
    bool spills(const Layer& layer) const;
    bool behind(const Layer& layer) const;
    bool steady(const Layer& layer, float from, float to) const;
    bool grabs(const std::vector<Layer>& layers) const;
    bool draw(SkCanvas* canvas, const Scene& scene, const Layer& layer, double timeMs, const SkRect& area, const SkMatrix& placed,
              const std::function<void(SkCanvas*)>& source, const std::function<void(SkCanvas*)>& below, const Grab& grab = nullptr,
              const Upload& upload = nullptr) const;

private:
    struct Definition {
        bool shader = false;   // always false: SkSL layer shaders were removed (single-pass effects load as GLSL ES graphs)
        bool blurred = false;
        bool brightPass = false;
        bool plainBlur = false;
        bool backdrop = false;
        bool below = false;
        bool pointwise = false;
        bool timed = false;
        bool palette = false;
        bool matrix = false;
        bool glyphs = false;
        std::shared_ptr<const GraphProgram> graph;   // multi-pass effect (effect schema 2); shader is null then
        std::map<std::string, Anim> defaults;
        std::map<std::string, std::string> texts;
        std::set<std::string> colors;                // controls declared type="color" (native passes get them as RGBA, like layout(color))
    };
    const Definition* find(const std::string& id) const;
    int liftAt(const Layer& layer) const;
    bool needs(const Layer& layer, bool Definition::*input) const;
    int method(const LayerEffect& e, const Definition* d, float t) const;
    std::shared_ptr<const Palette> palette(const LayerEffect& e, const Definition* d, float t) const;
    int diffusing(const Layer& layer, int lift, float t) const;
    bool mayDiffuse(const LayerEffect& e, const Definition* d) const;
    sk_sp<SkImageFilter> chain(const Scene& scene, const Layer& layer, double timeMs, const SkRect& area, const SkRect& seen,
                               const SkRect& drawn, const SkMatrix& placed, sk_sp<SkImageFilter> content, sk_sp<SkImageFilter> below,
                               int before = -1, int from = -1) const;
    bool drawGraphs(SkCanvas* canvas, const Scene& scene, const Layer& layer, double timeMs, const SkRect& area, const SkRect& bounds, const SkRect& local,
                    const SkMatrix& placed, const std::function<void(SkCanvas*)>& source, const Upload& upload) const;
    struct GraphStore;
    std::map<std::string, Definition> fDefinitions;
    std::shared_ptr<GraphStore> fGraphs;
};

}

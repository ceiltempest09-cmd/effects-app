// output_dither.frag — FINAL pass: working space -> display space -> dithered quantisation.
// This is the ONLY place where precision is deliberately thrown away, and it's dithered so the
// loss shows up as invisible noise instead of contour bands.
in highp vec2 v_uv;
uniform sampler2D u_src;
uniform float u_ditherLevels;    // 255.0 for 8-bit output, 1023.0 for 10-bit, 0.0 = off (float/EXR export)
out vec4 o_color;

void main() {
    vec4 s = fxSample(u_src, v_uv);
    vec3 rgb = s.a > 0.0 ? s.rgb / s.a : s.rgb;
    vec3 d = clamp(fxToDisplay(rgb), 0.0, 1.0);
    if (u_ditherLevels > 0.0) d = fxDither(d, gl_FragCoord.xy, u_ditherLevels);
    o_color = vec4(d * s.a, s.a);
}

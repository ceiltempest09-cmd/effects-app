// EdgeTAM (on-device SAM 2) for ncnn. Phase 1: one image, point/box prompts -> 256x256 mask probabilities.
// Image encoder runs once per image (features cached); the prompt-encoder + mask-decoder runs per prompt set.
// CPU only. Models: edgetam_encoder.{param,bin}, edgetam_decoder.{param,bin} (exported by tools/edgetam/export_ncnn.py).
#include <android/bitmap.h>
#include <jni.h>

#include <algorithm>
#include <atomic>
#include <cmath>
#include <cstdint>
#include <cstdlib>
#include <cstring>
#include <new>
#include <string>
#include <vector>

#include "cpu.h"
#include "cutout.h"
#include "mat.h"
#include "net.h"

namespace {

constexpr int Side = 1024;     // encoder input
constexpr int MaskSide = 256;  // decoder output (low-res logits)
constexpr int Slots = 8;       // prompt points the decoder was exported with

struct Sam {
    ncnn::Net enc, dec;
    ncnn::Mat f0, f1, f2;  // cached encoder outputs: 256x64x64, 32x256x256, 64x128x128
    int width = 0, height = 0;
    bool ready = false;
    std::atomic<bool> cancel{false};
};

Sam *sam(jlong handle) { return reinterpret_cast<Sam *>(handle); }

std::string text(JNIEnv *env, jstring value) {
    if (!value) return {};
    const char *chars = env->GetStringUTFChars(value, nullptr);
    std::string out = chars ? chars : "";
    if (chars) env->ReleaseStringUTFChars(value, chars);
    return out;
}

void configure(ncnn::Net &net) {
    ncnn::Option &opt = net.opt;
    opt.num_threads = std::max(1, ncnn::get_big_cpu_count());
    opt.use_vulkan_compute = false;
    opt.use_fp16_packed = false;
    opt.use_fp16_storage = false;
    opt.use_fp16_arithmetic = false;
    opt.use_local_pool_allocator = false;
}

bool hasName(const std::vector<const char *> &names, const char *wanted) {
    for (const char *n : names)
        if (n && std::strcmp(n, wanted) == 0) return true;
    return false;
}

inline float sample(const uint8_t *rgba, size_t stride, int width, int height, float x, float y, int c) {
    x = std::clamp(x, 0.f, static_cast<float>(width - 1));
    y = std::clamp(y, 0.f, static_cast<float>(height - 1));
    const int x0 = static_cast<int>(x), y0 = static_cast<int>(y);
    const int x1 = std::min(x0 + 1, width - 1), y1 = std::min(y0 + 1, height - 1);
    const float fx = x - x0, fy = y - y0;
    auto at = [&](int px, int py) {
        const uint8_t *p = rgba + static_cast<size_t>(py) * stride + static_cast<size_t>(px) * 4;
        const int a = p[3];
        float v = p[c];
        if (a > 0 && a < 255) v = std::min(255.f, v * 255.f / static_cast<float>(a));  // bitmap may be premultiplied
        return v;
    };
    const float top = at(x0, y0) * (1 - fx) + at(x1, y0) * fx;
    const float bottom = at(x0, y1) * (1 - fx) + at(x1, y1) * fx;
    return (top * (1 - fy) + bottom * fy) / 255.f;
}

}  // namespace

extern "C" JNIEXPORT jlong JNICALL
Java_com_effects_motion_ai_EdgeNative_nativeOpen(JNIEnv *env, jobject, jstring encParam, jstring encBin, jstring decParam, jstring decBin) {
    auto *m = new (std::nothrow) Sam;
    if (!m) return 0;
    configure(m->enc);
    configure(m->dec);
    const std::string ep = text(env, encParam), eb = text(env, encBin), dp = text(env, decParam), db = text(env, decBin);
    bool ok = m->enc.load_param(ep.c_str()) == 0 && m->enc.load_model(eb.c_str()) == 0 &&
              m->dec.load_param(dp.c_str()) == 0 && m->dec.load_model(db.c_str()) == 0;
    if (ok) {
        const auto &ei = m->enc.input_names();
        const auto &eo = m->enc.output_names();
        const auto &di = m->dec.input_names();
        const auto &dout = m->dec.output_names();
        ok = hasName(ei, "in0") && hasName(eo, "out0") && hasName(eo, "out1") && hasName(eo, "out2") &&
             hasName(di, "in0") && hasName(di, "in1") && hasName(di, "in2") && hasName(di, "in3") && hasName(di, "in4") &&
             hasName(dout, "out0") && hasName(dout, "out1");
    }
    if (!ok) {
        delete m;
        return 0;
    }
    return reinterpret_cast<jlong>(m);
}

extern "C" JNIEXPORT void JNICALL
Java_com_effects_motion_ai_EdgeNative_nativeClose(JNIEnv *, jobject, jlong handle) {
    if (handle) delete sam(handle);
}

extern "C" JNIEXPORT void JNICALL
Java_com_effects_motion_ai_EdgeNative_nativeCancel(JNIEnv *, jobject, jlong handle) {
    sam(handle)->cancel = true;
}

extern "C" JNIEXPORT void JNICALL
Java_com_effects_motion_ai_EdgeNative_nativeClearCancel(JNIEnv *, jobject, jlong handle) {
    sam(handle)->cancel = false;
}

// Runs the image encoder and caches its three feature maps. 0 = ok, 1 = cancelled, -1 bad input, -2 memory, -3 model failure.
extern "C" JNIEXPORT jint JNICALL
Java_com_effects_motion_ai_EdgeNative_nativeSetImage(JNIEnv *env, jobject, jlong handle, jobject bitmap) {
    Sam *m = sam(handle);
    m->ready = false;
    AndroidBitmapInfo info;
    if (AndroidBitmap_getInfo(env, bitmap, &info) != ANDROID_BITMAP_RESULT_SUCCESS || info.format != ANDROID_BITMAP_FORMAT_RGBA_8888 ||
        info.width < 1 || info.height < 1) return -1;
    void *pixels = nullptr;
    if (AndroidBitmap_lockPixels(env, bitmap, &pixels) != ANDROID_BITMAP_RESULT_SUCCESS || !pixels) return -2;
    const auto *rgba = static_cast<const uint8_t *>(pixels);
    const int width = static_cast<int>(info.width), height = static_cast<int>(info.height);
    int code = 0;
    {
        ncnn::Mat in(Side, Side, 3);
        if (in.empty()) {
            code = -2;
        } else {
            static const float mean[3] = {0.485f, 0.456f, 0.406f};
            static const float inv[3] = {1.f / 0.229f, 1.f / 0.224f, 1.f / 0.225f};
            const float sx = static_cast<float>(width) / Side, sy = static_cast<float>(height) / Side;
            for (int c = 0; c < 3; c++) {
                float *plane = in.channel(c);
                for (int y = 0; y < Side; y++) {
                    const float srcY = (y + .5f) * sy - .5f;
                    for (int x = 0; x < Side; x++)
                        plane[y * Side + x] = (sample(rgba, info.stride, width, height, (x + .5f) * sx - .5f, srcY, c) - mean[c]) * inv[c];
                }
            }
        }
        if (code == 0 && m->cancel) code = 1;
        if (code == 0) {
            ncnn::Extractor ex = m->enc.create_extractor();
            if (ex.input("in0", in) != 0 || ex.extract("out0", m->f0) != 0 || ex.extract("out1", m->f1) != 0 || ex.extract("out2", m->f2) != 0) code = -3;
        }
    }
    AndroidBitmap_unlockPixels(env, bitmap);
    if (code == 0 && (m->f0.w != 64 || m->f0.h != 64 || m->f0.c != 256 || m->f1.w != 256 || m->f1.h != 256 || m->f1.c != 32 ||
                      m->f2.w != 128 || m->f2.h != 128 || m->f2.c != 64)) code = -3;
    if (code == 0) {
        m->width = width;
        m->height = height;
        m->ready = true;
    }
    return code;
}

// points: x,y pairs in image pixels; labels: 0 background, 1 foreground, 2 box top-left, 3 box bottom-right. count <= 8.
// mask receives 256*256 foreground probabilities (best of the 3 candidate masks by predicted quality).
extern "C" JNIEXPORT jint JNICALL
Java_com_effects_motion_ai_EdgeNative_nativeDecode(JNIEnv *env, jobject, jlong handle, jfloatArray points, jintArray labels, jint count, jfloatArray mask) {
    Sam *m = sam(handle);
    if (!m->ready || count < 1 || count > Slots) return -1;
    if (env->GetArrayLength(points) < count * 2 || env->GetArrayLength(labels) < count || env->GetArrayLength(mask) < MaskSide * MaskSide) return -1;
    ncnn::Mat coords(2, Slots), tags(Slots);
    if (coords.empty() || tags.empty()) return -2;
    coords.fill(0.f);
    tags.fill(-1.f);
    {
        jfloat *p = env->GetFloatArrayElements(points, nullptr);
        jint *l = env->GetIntArrayElements(labels, nullptr);
        if (!p || !l) {
            if (p) env->ReleaseFloatArrayElements(points, p, JNI_ABORT);
            if (l) env->ReleaseIntArrayElements(labels, l, JNI_ABORT);
            return -2;
        }
        for (int i = 0; i < count; i++) {
            float *row = coords.row(i);
            row[0] = std::clamp(p[i * 2] * Side / static_cast<float>(m->width), 0.f, static_cast<float>(Side));
            row[1] = std::clamp(p[i * 2 + 1] * Side / static_cast<float>(m->height), 0.f, static_cast<float>(Side));
            static_cast<float *>(tags.data)[i] = static_cast<float>(std::clamp(l[i], 0, 3));
        }
        env->ReleaseFloatArrayElements(points, p, JNI_ABORT);
        env->ReleaseIntArrayElements(labels, l, JNI_ABORT);
    }
    if (m->cancel) return 1;
    ncnn::Mat masks, iou;
    {
        ncnn::Extractor ex = m->dec.create_extractor();
        if (ex.input("in0", m->f0) != 0 || ex.input("in1", m->f1) != 0 || ex.input("in2", m->f2) != 0 || ex.input("in3", coords) != 0 ||
            ex.input("in4", tags) != 0 || ex.extract("out0", masks) != 0 || ex.extract("out1", iou) != 0) return -3;
    }
    if (masks.w != MaskSide || masks.h != MaskSide || masks.c != 3 || static_cast<size_t>(iou.w) * iou.h * iou.c < 3) return -3;
    const float *scores = static_cast<const float *>(iou.data);
    int best = 0;
    for (int k = 1; k < 3; k++)
        if (scores[k] > scores[best]) best = k;
    const float *logits = masks.channel(best);
    jfloat *out = env->GetFloatArrayElements(mask, nullptr);
    if (!out) return -2;
    for (int i = 0; i < MaskSide * MaskSide; i++) out[i] = 1.f / (1.f + std::exp(-logits[i]));
    env->ReleaseFloatArrayElements(mask, out, 0);
    return 0;
}

// Turns a 256x256 probability mask into the final matte: writes alpha (and cleaned colours) into the bitmap,
// using the same clean + refine steps as the background-removal cutout.
extern "C" JNIEXPORT jint JNICALL
Java_com_effects_motion_ai_EdgeNative_nativeApply(JNIEnv *env, jobject, jlong handle, jfloatArray mask, jobject bitmap) {
    Sam *m = sam(handle);
    AndroidBitmapInfo info;
    if (AndroidBitmap_getInfo(env, bitmap, &info) != ANDROID_BITMAP_RESULT_SUCCESS || info.format != ANDROID_BITMAP_FORMAT_RGBA_8888 ||
        info.width < 1 || info.height < 1 || env->GetArrayLength(mask) < MaskSide * MaskSide) return -1;
    auto *alpha = static_cast<float *>(std::malloc(sizeof(float) * MaskSide * MaskSide));
    if (!alpha) return -2;
    jfloat *src = env->GetFloatArrayElements(mask, nullptr);
    if (!src) {
        std::free(alpha);
        return -2;
    }
    std::memcpy(alpha, src, sizeof(float) * MaskSide * MaskSide);
    env->ReleaseFloatArrayElements(mask, src, JNI_ABORT);
    void *pixels = nullptr;
    if (AndroidBitmap_lockPixels(env, bitmap, &pixels) != ANDROID_BITMAP_RESULT_SUCCESS || !pixels) {
        std::free(alpha);
        return -2;
    }
    auto *rgba = static_cast<uint8_t *>(pixels);
    int code = 0;
    cutout::unpremultiply(rgba, info.stride, static_cast<int>(info.width), static_cast<int>(info.height));
    cutout::clean(alpha, MaskSide, MaskSide);
    code = cutout::refine(rgba, info.stride, static_cast<int>(info.width), static_cast<int>(info.height), alpha, MaskSide, MaskSide, m->cancel);
    std::free(alpha);
    AndroidBitmap_unlockPixels(env, bitmap);
    return code;
}

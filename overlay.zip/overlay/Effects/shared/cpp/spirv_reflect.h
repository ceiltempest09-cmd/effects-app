// spirv_reflect.h - what a SPIR-V fragment module asks of the descriptor sets: uniform blocks (member names, types, std140/std430 offsets)
// and combined image samplers, read straight from the module (names, decorations, types). Pure C++, host-tested (tests/native/spirv_reflect_test.cpp).
// Not a compiler or optimiser. Built with -fno-exceptions -fno-rtti.
#pragma once

#include <cstdint>
#include <string>
#include <vector>

namespace am::rg {

struct SpirvMember {
    enum Base { Float = 0, Int = 1, UInt = 2, Bool = 3 };
    std::string name;
    Base base = Float;
    uint32_t rows = 1, cols = 1;     // vecN = rows N, cols 1; scalar = 1x1; matrices (cols > 1) are reported but not bindable
    uint32_t arrayLength = 1;        // 1 = not an array
    uint32_t arrayStride = 0;        // bytes between elements (0 = not an array)
    uint32_t offset = 0;             // bytes from the start of the block
    int components() const { return (int)(rows * cols); }
};

struct SpirvBlock {
    std::string name;                // block type name (instance name is not used for binding)
    uint32_t set = 0, binding = 0;
    uint32_t size = 0;               // bytes, rounded up to 16
    std::vector<SpirvMember> members;
};

struct SpirvSampler { std::string name; uint32_t set = 0, binding = 0; };

struct SpirvReflection {
    std::vector<SpirvBlock> blocks;          // storage class Uniform, Block decoration
    std::vector<SpirvSampler> samplers;      // UniformConstant combined image samplers (sampler2D)
    bool pushConstants = false;              // not supported by the backend
    bool storageBuffers = false;             // not supported by the backend
    bool otherResources = false;             // separate images / samplers / storage images: not supported
    uint32_t outputCount = 0;                // fragment outputs (Output variables that are not built-ins)
};

// `words` = a whole module (header included). false + message when the stream is malformed.
bool ReflectSpirv(const std::vector<uint32_t>& words, SpirvReflection* out, std::string* error);

}  // namespace am::rg

// Host test for glsl_wrap (text rewrite only). Build: g++ -std=c++20 -I../../shared/cpp glsl_wrap_test.cpp ../../shared/cpp/glsl_wrap.cpp
#include "glsl_wrap.h"
#include <cstdio>
using namespace am::rg;
static int gFail = 0, gChecks = 0;
#define CHECK(c) do { gChecks++; if (!(c)) { gFail++; std::printf("FAIL line %d: %s\n", __LINE__, #c); } } while (0)
static bool Has(const std::string& t, const char* s) { return t.find(s) != std::string::npos; }

int main() {
    const char* src =
        "// a comment first\n"
        "#version 330\n"
        "uniform sampler2D image;\n"
        "uniform vec2 size;\n"
        "uniform highp float gain;\n"
        "uniform bool flip;\n"
        "uniform vec4 tint[2];\n"
        "out vec4 fragColor;\n"
        "void main() {\n"
        "    vec2 uv = gl_FragCoord.xy / size;\n"
        "    uniform_like_text(uv);\n"
        "    fragColor = texture(image, uv) * gain;\n"
        "}\n";
    GlslWrapResult r = WrapDesktopGlslForVulkan(src, {{"MODE", "2"}});
    CHECK(r.ok);
    CHECK(Has(r.text, "#version 450\n#define MODE 2\n"));
    CHECK(Has(r.text, "layout(set = 0, binding = 1) uniform sampler2D image;"));
    CHECK(Has(r.text, "layout(std140, set = 0, binding = 0) uniform AmLoose { vec2 size; float gain; int am_b_flip; vec4 tint[2]; };"));
    CHECK(Has(r.text, "#define flip (am_b_flip != 0)"));
    CHECK(Has(r.text, "layout(location = 0) out vec4 fragColor;"));
    CHECK(Has(r.text, "fragColor = texture(image, uv) * gain;"));
    CHECK(!Has(r.text, "uniform vec2 size;") && !Has(r.text, "uniform bool"));
    CHECK(r.samplers == 1 && r.looseUniforms == 4);

    // errors, each with the original line
    r = WrapDesktopGlslForVulkan("void main() {}\n", {});
    CHECK(!r.ok && r.errorLine == 1);
    r = WrapDesktopGlslForVulkan("#version 120\nvoid main() {}\n", {});
    CHECK(!r.ok && r.errorLine == 1);
    r = WrapDesktopGlslForVulkan("#version 300 es\nvoid main() {}\n", {});
    CHECK(!r.ok && Has(r.error, "glsl-es"));
    r = WrapDesktopGlslForVulkan("#version 330\nuniform mat4 m;\nvoid main() {}\n", {});
    CHECK(!r.ok && r.errorLine == 2 && Has(r.error, "mat4"));
    r = WrapDesktopGlslForVulkan("#version 330\nuniform float a = 1.0;\nvoid main() {}\n", {});
    CHECK(!r.ok && r.errorLine == 2);
    r = WrapDesktopGlslForVulkan("#version 330\nuniform samplerCube c;\nvoid main() {}\n", {});
    CHECK(!r.ok && r.errorLine == 2);

    // uniforms inside a function / comment are left alone; an explicit location is kept; later removed lines keep the line count
    r = WrapDesktopGlslForVulkan("#version 450\n/* uniform float no; */\nuniform float a;\nuniform float b;\nlayout(location = 1) out vec4 o;\nvoid main() { /* x */ }\n", {});
    CHECK(r.ok && Has(r.text, "/* uniform float no; */") && Has(r.text, "{ float a; float b; }") && Has(r.text, "layout(location = 1) out vec4 o;") && !Has(r.text, "layout(location = 0)"));
    int lines = 0; for (char c : r.text) if (c == '\n') lines++;
    CHECK(lines == 7);   // 6 source lines + the final newline, none lost
    std::printf("glsl_wrap_test: %d checks, %d failed\n", gChecks, gFail);
    return gFail ? 1 : 0;
}

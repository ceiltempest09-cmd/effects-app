import com.effects.motion.effects.AmFormatError
import com.effects.motion.effects.AmXml
import com.effects.motion.effects.SkslConvert
import com.effects.motion.effects.graph.*

object ImportTests {
    private fun xml(body: String, attrs: String = "") = "<effect id=\"em.test\" name=\"Test\" category=\"blur\"$attrs>$body</effect>"

    fun run() {
        section("xml importer")
        val oneShader = "void main() { gl_FragColor = vec4(1.0); }"
        // the original one-pass path is untouched
        val one = AmXml.parse(xml("<params><texture id=\"img\" srcType=\"content\"/><slider id=\"amount\" default=\"1\"/></params><shader>uniform sampler2D x;\n$oneShader</shader>"))
        check(!one.isGraph, "one-pass xml is not a graph")
        val c1 = SkslConvert.convert(one)
        check(c1.ok && c1.sksl.contains("half4 main(float2 _fc)"), "one-pass xml still converts: ${c1.problems}")
        // a one-pass file that uses #define now converts through the real preprocessor
        val withDefine = AmXml.parse(xml("<params/><shader>#define V 0.25\nvoid main() { gl_FragColor = vec4(V); }</shader>"))
        val cd = SkslConvert.convert(withDefine)
        check(cd.ok && cd.sksl.contains("vec4(0.25)".replace("vec4", "float4")), "define expanded: ${cd.problems} / ${cd.sksl.takeLast(120)}")
        check(AmXml.parse(xml("<params/><passes><pass id=\"a\"/></passes><shader>$oneShader</shader>")).isGraph.not(), "<passes> with one pass and a file shader is still one-pass")

        // Shader language GLSL: the same file becomes a native GLSL ES pass (premultiplied out, controls by name), SkSL stays as it was
        val glslFx = AmXml.parse(xml("<params><texture id=\"img\" srcType=\"content\"/><slider id=\"amount\" default=\"1\"/><switch id=\"flip\" default=\"false\"/></params><shader>void main() { vec4 c = texture2DCv(img.texture, acScreenNorm); if (flip) c = c * amount; gl_FragColor = c; }</shader>"))
        val cg = SkslConvert.convert(glslFx, glsl = true)
        check(cg.ok && cg.sksl.startsWith("#version 300 es") && cg.sksl.contains("void _am_main()") && cg.sksl.contains("uniform float amount;") && cg.sksl.contains("(flip > 0.5)") && cg.sksl.contains("_frag = vec4(_out.rgb * _out.a, _out.a)"), "glsl mode builds a native pass: ${cg.problems} / ${cg.sksl}")
        check(!cg.sksl.contains("float4") && !cg.sksl.contains("half4"), "glsl mode has no SkSL types")
        val layerFx = AmXml.parse(xml("<params/><shader>void main() { gl_FragColor = vec4(acLayerSize.x); }</shader>"))
        check(!SkslConvert.convert(layerFx, glsl = true).ok && SkslConvert.convert(layerFx).ok, "acLayerSize is refused as GLSL (no layer uniform) and still converts as SkSL")
        val multiGlsl = AmXml.parse(xml("<params><texture id=\"img\" srcType=\"content\"/><switch id=\"flip\" default=\"false\"/></params><passes><pass id=\"a\" lang=\"glsl\" input=\"image=img\"><shader>uniform sampler2D image;\nin vec2 v_uv;\nvoid main() { vec4 c = texture2D(image, v_uv); if (flip) c = c.bgra; gl_FragColor = c; }</shader></pass></passes>", " graph=\"2\""))
        val native = GraphConvert.convert(multiGlsl, "n.xml", native = true)
        check(native.ok && native.graph!!.passes[0].lang == "glsl-es" && native.graph!!.passes[0].source.contains("_amTex(image, v_uv)"), "graph pass keeps GLSL when native: ${native.problems}")
        check(GraphConvert.convert(multiGlsl, "n.xml").graph!!.passes[0].lang == "sksl", "graph pass is still translated to SkSL by default")

        // multi-pass: the one-pass converter must refuse and say where to go, never run only the first pass
        val multi = """
          <params><texture id="img" srcType="content"/><slider id="strength" label="Strength" default="0.5" min="0" max="1"/><switch id="flip" label="Flip" default="false"/>
            <color id="tint" label="Tint" default="#ffcc00"/></params>
          <buffers><buffer id="half" scale="0.5" format="rgba16f"/></buffers>
          <passes>
            <pass id="down" output="half" lang="glsl" input="image=img">
              <shader>
                #version 300 es
                precision mediump float;
                uniform sampler2D image;
                out vec4 o;
                void main() { vec2 uv = gl_FragCoord.xy / acScreenSize; o = texture(image, uv); }
              </shader>
            </pass>
            <pass id="apply" lang="glsl" input="image=img, low=down">
              <shader>
                uniform sampler2D image;
                uniform sampler2D low;
                uniform float strength; uniform bool flip; uniform vec4 tint;
                in vec2 v_uv;
                out vec4 o;
                void main() {
                  vec4 a = texture(image, v_uv); vec4 b = texture(low, v_uv);
                  o = mix(a, b * tint, flip ? 1.0 - strength : strength);
                }
              </shader>
            </pass>
          </passes>"""
        val fx = AmXml.parse(xml(multi))
        check(fx.isGraph && fx.passList.size == 2 && fx.buffers.size == 1, "xml parsed as 2 passes + 1 buffer")
        check(!SkslConvert.convert(fx).ok && SkslConvert.convert(fx).problems.joinToString().contains("GraphConvert"), "one-pass converter refuses a graph and names the right converter")
        val r = GraphConvert.convert(fx, "multi.xml")
        check(r.ok, "multi-pass converts: ${r.problems}")
        val g = r.graph!!
        check(g.passes.size == 2 && g.passes.all { it.lang == "sksl" && it.extra["origin-lang"] == "glsl" }, "both passes translated and tagged with their origin")
        check(g.passes[0].inputs == listOf(PassInput("image", "source")) && g.passes[1].inputs == listOf(PassInput("image", "source"), PassInput("low", "pass:down")), "inputs resolved: ${g.passes[1].inputs}")
        check(g.passes[1].source.contains("layout(color) uniform half4 tint;") && g.passes[1].source.contains("_tex_low(v_uv)"), "pass 2 uses the first pass output")
        check(g.buffers[0].format == "rgba16f" && g.buffers[0].scale == 0.5f, "buffer carried over")
        check(r.params.length() == 3, "params converted")
        check(GraphValidator.validate("em.test", g).none { it.error }, "validated")

        section("xml importer: glsl-es passes stay native")
        val es = """#version 300 es
precision highp float;
uniform sampler2D image;
uniform vec2 size;
uniform float gain;
uniform vec4 tint;
out vec4 fragColor;
void main() { fragColor = texture(image, gl_FragCoord.xy / size) * gain * tint; }"""
        val nativeFx = AmXml.parse(xml("<params><texture id=\"img\" srcType=\"content\"/><slider id=\"gain\" default=\"0.5\" min=\"0\" max=\"1\"/><color id=\"tint\" default=\"#ffcc00\"/></params>" +
            "<passes><pass id=\"a\" lang=\"glsl-es\" input=\"image=img\"><shader>$es</shader></pass></passes>"))
        val nr = GraphConvert.convert(nativeFx, "native.xml")
        check(nr.ok, "glsl-es graph converts: ${nr.problems}")
        val np = nr.graph!!.passes[0]
        check(np.lang == "glsl-es" && np.source.contains("#version 300 es") && np.source.contains("fragColor") && !np.source.contains("half4") && np.extra["origin-lang"] == null, "glsl-es text kept, not translated")
        check(nr.params.length() == 2, "controls still listed")
        val rx = GraphXml.write("fx.n", listOf("gain" to "0.5", "tint" to "#ffcc00"), nr.graph!!, setOf("tint"))
        check(rx.contains("<param name=\"tint\" value=\"#ffcc00\" type=\"color\" />") && rx.contains("<param name=\"gain\" value=\"0.5\" />") && rx.contains("lang=\"glsl-es\""), "runtime xml marks colour controls: $rx")

        section("xml importer: failures are explicit")
        fun conv(body: String) = GraphConvert.convert(AmXml.parse(xml(body)), "bad.xml")
        val shaderOk = "<shader>uniform sampler2D image; out vec4 o; void main(){ o = texture(image, vec2(0.5)); }</shader>"
        var e = conv("<params/><passes><pass id=\"a\" input=\"image=source\">$shaderOk</pass><pass id=\"b\" input=\"image=pass:zzz\">$shaderOk</pass></passes>")
        check(!e.ok && e.problems.joinToString().contains("unknown pass 'zzz'") && e.problems.joinToString().contains("pass 'b'") && e.problems.joinToString().contains("bad.xml"), "unknown pass reference: ${e.problems}")
        e = conv("<params/><passes><pass id=\"a\" output=\"x\" input=\"image=buffer:y\">$shaderOk</pass><pass id=\"b\" output=\"y\" input=\"image=buffer:x\">$shaderOk</pass></passes>")
        check(e.problems.joinToString().contains("dependency cycle"), "cycle: ${e.problems}")
        e = conv("<params/><passes><pass id=\"a\" input=\"image=source\"><shader>uniform sampler2D image; out vec4 o; void main(){ discard; }</shader></pass><pass id=\"b\" input=\"image=pass:a\">$shaderOk</pass></passes>")
        check(e.problems.joinToString().contains("discard"), "unsupported shader feature reported: ${e.problems}")
        check(e.issues.any { it.kind == IssueKind.UNSUPPORTED && it.pass == "a" && it.file == "bad.xml" && it.line > 0 }, "issue has pass, file and line")
        e = conv("<params><texture id=\"lut\" srcType=\"file\"/></params><passes><pass id=\"a\" input=\"image=source\">$shaderOk</pass><pass id=\"b\" input=\"image=pass:a\">$shaderOk</pass></passes>")
        check(e.problems.joinToString().contains("srcType"), "unsupported texture source")
        e = conv("<params/><script>animate()</script><passes><pass id=\"a\" input=\"image=source\">$shaderOk</pass><pass id=\"b\" input=\"image=pass:a\">$shaderOk</pass></passes>")
        check(e.problems.joinToString().contains("JavaScript"), "script reported")
        e = conv("<params/><passes><pass id=\"a\" input=\"image=source\" lang=\"sksl\"><shader>half4 main(float2 p){return half4(1);}</shader></pass><pass id=\"b\" input=\"image=pass:a\" lang=\"sksl\"><define name=\"X\" value=\"1\"/><shader>half4 main(float2 p){return half4(1);}</shader></pass></passes>")
        check(e.problems.joinToString().contains("<define> is only applied to GLSL"), "define on sksl pass is not silently ignored")
        check(try { AmXml.parse("<effect id=\"x\"><params/>"); false } catch (e: AmFormatError) { e.message!!.startsWith("Not valid XML") }, "malformed xml is reported as malformed")
        check(try { AmXml.parse("<!DOCTYPE x><effect/>"); false } catch (e: AmFormatError) { e.message!!.contains("DOCTYPE") }, "DOCTYPE refused")
        val kept = GraphConvert.convert(AmXml.parse(xml("<params/><vendor>x</vendor><passes><pass id=\"a\" input=\"image=source\" gizmo=\"7\">$shaderOk</pass><pass id=\"b\" input=\"image=pass:a\">$shaderOk</pass></passes>", " extra=\"1\"")), "k.xml")
        check(kept.ok && kept.graph!!.passes[0].extra["gizmo"] == "7" && kept.graph.extra["xmlchild_vendor"] == "x" && kept.graph.extra["xml_extra"] == "1", "unknown attributes and elements preserved: ${kept.problems}")
    }
}

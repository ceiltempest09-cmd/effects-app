# Effect libraries in the repo

Not compiled or run here: the Kotlin below is untested until the first CI build; `tools/fxconvert.py` was run on the uploaded zips.

Upload as zips to the repo root (the workflow unzips whichever exist): `pack.zip` (-> `pack/`), `aligthmotion.zip` (-> `aligthmotion/`), `glsl.zip`, `emx.zip`.

| Folder | Files | Library (picker name) |
|---|---|---|
| `effects/`, `pack/` | `.json` (+ the pack's `index.json`, `releases.json`, `foreign.json`) | Performance (was Default) |
| `glsl/` | `.glsl` | Balance (was Vibrant HQS) |
| `emx/` | `.emx` | Heavy effects (was RayTraced VFX) |
| `aligthmotion/` | `.xml`, pictures in `thumb/` | Alight Motion source |
| After Effects `.aex` | not supported: a compiled desktop plug-in has no shader the app can run | - |

Alight Motion: `fxconvert.py` puts each xml in `assets/alightmotion/am_<name>.xml`, sets its `category` to one of the 11 cards (Color & Light, Drawing & Edge,
Blur, Distortion/Warp, Procedural, 3D, Move/Transform, Repeat, Matte/Mask/Key, Opacity/Visibility, Text; no PNKJ, no Custom), shrinks its picture to
`thumb/am_<name>.webp`, and writes `alightmotion/index.json`. Files that need an image texture are skipped (the app does not load texture files).
On the first start after an install/update the app converts the files in the background (`ImportedEffects.installBundledInBackground`) into the Performance
pack under the Alight Motion source; the effects appear the next time the library is opened. Files the converter rejects are skipped (see the `Effects` log tag).

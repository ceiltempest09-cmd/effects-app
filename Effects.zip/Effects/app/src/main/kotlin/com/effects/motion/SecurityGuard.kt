package com.effects.motion

import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Debug
import android.util.Log
import java.security.MessageDigest

/** Release integrity checks. This is a deterrent, not a substitute for server-side trust. */
internal object SecurityGuard {
    private const val TAG = "SecurityGuard"

    // Public SHA-256 fingerprint of the official release certificate used by CI.
    // A certificate fingerprint is an identifier, not a private signing key.
    private const val EXPECTED_SIGNING_CERT_SHA256 =
        "A5ABEB52778750BE8A9925477E72DA5E0DF7B3BB59A362A6CB39D161A3FE42B7"

    fun allowLaunch(context: Context): Boolean {
        // Debug builds remain usable for local development and CI debug APKs.
        if (BuildConfig.DEBUG) return true

        if (Debug.isDebuggerConnected() || Debug.waitingForDebugger()) {
            Log.e(TAG, "Debugger detected")
            return false
        }

        val actual = runCatching { signingCertificateSha256(context) }.getOrElse { error ->
            Log.e(TAG, "Unable to read signing certificate", error)
            return false
        }
        val expectedBytes = EXPECTED_SIGNING_CERT_SHA256.toByteArray(Charsets.US_ASCII)
        val actualBytes = actual.toByteArray(Charsets.US_ASCII)
        val valid = MessageDigest.isEqual(expectedBytes, actualBytes)
        if (!valid) Log.e(TAG, "Signing certificate mismatch")
        return valid
    }

    @Suppress("DEPRECATION")
    private fun signingCertificateSha256(context: Context): String {
        val packageInfo = if (Build.VERSION.SDK_INT >= P) {
            context.packageManager.getPackageInfo(
                context.packageName,
                PackageManager.GET_SIGNING_CERTIFICATES,
            )
        } else {
            context.packageManager.getPackageInfo(
                context.packageName,
                PackageManager.GET_SIGNATURES,
            )
        }
        val signatures = if (Build.VERSION.SDK_INT >= P) {
            val info = packageInfo.signingInfo ?: error("Missing signing info")
            if (info.hasMultipleSigners()) info.apkContentsSigners else info.signingCertificateHistory
        } else {
            packageInfo.signatures ?: error("Missing signatures")
        }
        val certificate = signatures.firstOrNull()?.toByteArray() ?: error("No signing certificate")
        return MessageDigest.getInstance("SHA-256").digest(certificate)
            .joinToString("") { byte -> "%02X".format(byte) }
    }

    private const val P = 28
}

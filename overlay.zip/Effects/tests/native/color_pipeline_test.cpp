// Host test for the project colour settings (shared/cpp/color_pipeline.h): parsing, the plan the engine makes for a GPU, the highlight
// roll-off and the primaries conversion. No Skia, no GPU.
//   g++ -std=c++20 -Wall -Wextra -I shared/cpp tests/native/color_pipeline_test.cpp -o /tmp/cp && /tmp/cp
#include "color_pipeline.h"

#include <cmath>
#include <cstdio>

static int gFailed = 0, gChecks = 0;
#define CHECK(cond) do { gChecks++; if (!(cond)) { gFailed++; std::printf("  FAIL %s:%d  %s\n", __FILE__, __LINE__, #cond); } } while (0)
#define NEAR(a, b, eps) CHECK(std::fabs((double)(a) - (double)(b)) <= (eps))

using namespace am;

int main() {
    std::printf("parsing: old projects and damaged attributes\n");
    {
        const ColorSettings legacy = ParseColorSettings(nullptr, nullptr, nullptr, nullptr);
        CHECK(legacy.legacy());
        CHECK(ParseColorSettings("12", "high", "linear", "hdr").legacy());         // unknown depth: the whole thing is legacy, nothing else is trusted
        CHECK(ParseColorSettings("", "high", "linear", "hdr").legacy());
        const ColorSettings a = ParseColorSettings("16", "high", "linear", "hdr");
        CHECK(a.bitDepth == 16 && a.preview == PreviewMode::kHigh && a.space == WorkingSpace::kLinearSrgb && a.hdrRange);
        const ColorSettings b = ParseColorSettings("32", "banana", "??", "none");     // a depth with junk beside it: junk falls back one by one
        CHECK(b.bitDepth == 32 && b.preview == PreviewMode::kStandard && b.space == WorkingSpace::kSrgb && !b.hdrRange);
        const ColorSettings c = ParseColorSettings("8", "hdr", "rec2020", "sdr");
        CHECK(c.bitDepth == 8 && c.preview == PreviewMode::kHdr && c.space == WorkingSpace::kRec2020 && !c.hdrRange);
    }

    std::printf("plan: legacy projects are untouched\n");
    {
        const ColorPlan p = PlanColor(ColorSettings{}, false, true, true);
        CHECK(!p.managed && p.bits == 8 && !p.toneMap && !p.dither && !p.accurateBlur);
        CHECK(GraphDepth(ColorSettings{}, p) == 0);
    }

    std::printf("plan: the three bit depths are real, and fall back 32 -> 16 -> 8 when the GPU lacks them\n");
    {
        const ColorSettings s32 = ParseColorSettings("32", "standard", "linear", "sdr");
        ColorPlan p = PlanColor(s32, true, true, true);
        CHECK(p.managed && p.bits == 32 && !p.downgraded);
        p = PlanColor(s32, true, true, false);
        CHECK(p.bits == 16 && p.downgraded);
        p = PlanColor(s32, true, false, false);
        CHECK(p.bits == 8 && p.downgraded);
        const ColorSettings s16 = ParseColorSettings("16", "standard", "linear", "sdr");
        CHECK(PlanColor(s16, true, true, true).bits == 16);
        CHECK(PlanColor(s16, true, false, true).bits == 8);                      // a GPU with f32 but no f16 render target: still safe
        const ColorSettings s8 = ParseColorSettings("8", "standard", "linear", "sdr");
        CHECK(PlanColor(s8, true, true, true).bits == 8 && PlanColor(s8, true, true, true).managed);   // 8-bit, linear light: its own surface
        CHECK(GraphDepth(s32, PlanColor(s32, true, true, true)) == 32);
        CHECK(GraphDepth(s8, PlanColor(s8, true, true, true)) == 8);
    }

    std::printf("plan: 8-bit sRGB is the engine's old path, with no extra surface or pass\n");
    {
        const ColorSettings s = ParseColorSettings("8", "high", "srgb", "sdr");
        CHECK(!PlanColor(s, false, true, true).managed);
    }

    std::printf("plan: bit depth, HDR range and preview quality stay separate\n");
    {
        // 32-bit is NOT HDR
        const ColorSettings sdr32 = ParseColorSettings("32", "high", "linear", "sdr");
        CHECK(!PlanColor(sdr32, false, true, true).keepHdr);
        // 16-bit HDR keeps highlights
        const ColorSettings hdr16 = ParseColorSettings("16", "standard", "linear", "hdr");
        CHECK(PlanColor(hdr16, false, true, true).keepHdr);
        // ... but an HDR range cannot be kept in 8 bits
        const ColorSettings hdr8 = ParseColorSettings("8", "standard", "linear", "hdr");
        CHECK(!PlanColor(hdr8, true, true, true).keepHdr);
        // Standard / High never tone-map; they show the SDR picture
        CHECK(!PlanColor(hdr16, false, true, true).toneMap);
        CHECK(!PlanColor(ParseColorSettings("16", "high", "linear", "hdr"), false, true, true).toneMap);
    }

    std::printf("plan: HDR preview lifts the preview to float, never the export\n");
    {
        const ColorSettings s = ParseColorSettings("8", "hdr", "linear", "hdr");
        ColorPlan p = PlanColor(s, false, true, true);
        CHECK(p.bits == 16 && p.keepHdr && p.toneMap);
        p = PlanColor(s, true, true, true);                                       // the export of the same project is still 8-bit
        CHECK(p.bits == 8 && !p.toneMap && !p.keepHdr);
        // HDR preview without an HDR range has nothing to show
        CHECK(!PlanColor(ParseColorSettings("16", "hdr", "linear", "sdr"), false, true, true).toneMap);
        // a GPU with no float targets: preserved internally is impossible, so no tone map and no claim of HDR
        p = PlanColor(s, false, false, false);
        CHECK(p.bits == 8 && !p.keepHdr && !p.toneMap);
    }

    std::printf("plan: preview-only differences never touch the export\n");
    {
        const ColorSettings std16 = ParseColorSettings("16", "standard", "linear", "hdr");
        const ColorSettings high16 = ParseColorSettings("16", "high", "linear", "hdr");
        CHECK(PlanColor(high16, false, true, true).accurateBlur && !PlanColor(std16, false, true, true).accurateBlur);
        CHECK(!PlanColor(high16, true, true, true).accurateBlur);
        // the exported pixels are the same whatever the preview quality is
        const ColorPlan e1 = PlanColor(std16, true, true, true), e2 = PlanColor(high16, true, true, true);
        CHECK(e1.bits == e2.bits && e1.space == e2.space && e1.keepHdr == e2.keepHdr && e1.toneMap == e2.toneMap && e1.dither == e2.dither);
        // dithering float output: always on export, only in High / HDR in the preview
        CHECK(e1.dither);
        CHECK(!PlanColor(std16, false, true, true).dither && PlanColor(high16, false, true, true).dither);
    }

    std::printf("roll-off: identity below the knee, continuous, monotonic, peak maps to 1, nothing above 1\n");
    {
        for (float x = 0; x <= kToneKnee; x += 0.01f) NEAR(RollOff(x), x, 1e-6);
        NEAR(RollOff(kToneKnee + 1e-4f), kToneKnee + 1e-4f, 1e-3);              // continuous at the knee
        const float slope = (RollOff(kToneKnee + 1e-3f) - RollOff(kToneKnee)) / 1e-3f;
        NEAR(slope, 1.0, 5e-2);                                                  // and has the same slope
        NEAR(RollOff(kTonePeak), 1.0, 1e-5);
        float last = 0;
        bool monotonic = true, bounded = true;
        for (float x = 0; x <= kTonePeak; x += 0.005f) {
            const float y = RollOff(x);
            if (y + 1e-6f < last) monotonic = false;
            if (y > 1.0f + 1e-5f) bounded = false;
            last = y;
        }
        CHECK(monotonic && bounded);
        // a highlight that would have been clipped keeps its separation: 2.0 and 4.0 stay different
        CHECK(RollOff(4.0f) - RollOff(2.0f) > 0.05f);
        // SDR white keeps most of its brightness (about 0.8 of display white: the price of leaving room for highlights on an SDR panel)
        CHECK(RollOff(1.0f) > 0.78f && RollOff(1.0f) < 0.85f);
    }

    std::printf("tone map keeps the hue: channel ratios are preserved and no channel exceeds 1\n");
    {
        float rgb[3] = {5.0f, 2.0f, 0.5f};
        ToneMapRgb(rgb);
        CHECK(rgb[0] <= 1.0f && rgb[1] <= 1.0f && rgb[2] <= 1.0f);
        NEAR(rgb[1] / rgb[0], 2.0 / 5.0, 1e-5);
        NEAR(rgb[2] / rgb[0], 0.5 / 5.0, 1e-5);
        float dark[3] = {0.2f, 0.4f, 0.1f};
        ToneMapRgb(dark);
        CHECK(dark[0] == 0.2f && dark[1] == 0.4f && dark[2] == 0.1f);            // below the knee: untouched
    }

    std::printf("primaries and transfer function\n");
    {
        for (int row = 0; row < 3; row++) {                                       // white stays white: each row sums to 1
            const float sum = kRec2020ToSrgb[row * 3] + kRec2020ToSrgb[row * 3 + 1] + kRec2020ToSrgb[row * 3 + 2];
            NEAR(sum, 1.0, 1e-3);
        }
        for (float v : {0.0f, 0.002f, 0.04f, 0.2f, 0.5f, 0.9f, 1.0f}) NEAR(SrgbDecode(SrgbEncode(v)), v, 1e-5);
        NEAR(SrgbEncode(0.18f), 0.4614, 1e-3);
        CHECK(SrgbEncode(4.0f) > 1.0f);                                           // extended range is not clamped by the curve itself
    }

    std::printf("%d checks, %d failed\n", gChecks, gFailed);
    return gFailed ? 1 : 0;
}

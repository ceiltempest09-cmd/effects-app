package com.effects.motion.effects.engine

/** Data an effect can ask the renderer for. Names are the strings used in effect manifests. */
enum class EffectCapability(val id: String) {
    CurrentFrame("current_frame"), PreviousFrame("previous_frame"), NextFrame("next_frame"),
    FrameWindow("frame_window"), TimeAccess("time_access"), MotionData("motion_data"),
    MaskInput("mask_input"), DepthInput("depth_input"), AuxiliaryInputs("auxiliary_inputs"),
    MultiPass("multi_pass"), GeometryInput("geometry_input"), AudioData("audio_data");

    companion object {
        private val byId = entries.associateBy { it.id }
        fun parse(id: String): EffectCapability? = byId[id.trim().lowercase()]
    }
}

data class CapabilityIssue(val capability: String, val message: String)

data class CapabilityReport(val missing: List<CapabilityIssue>, val unknown: List<CapabilityIssue>) {
    val ok: Boolean get() = missing.isEmpty() && unknown.isEmpty()
    fun message(): String = (unknown + missing).joinToString("\n") { it.message }
}

object CapabilityCheck {
    /** Compares what an effect declares against what this build/device can serve. Never silently drops a requirement. */
    fun check(declared: Collection<String>, available: Set<EffectCapability>): CapabilityReport {
        val unknown = mutableListOf<CapabilityIssue>()
        val missing = mutableListOf<CapabilityIssue>()
        for (id in declared.distinct()) {
            val cap = EffectCapability.parse(id)
            when {
                cap == null -> unknown += CapabilityIssue(id, "Unknown capability '$id'. Known: ${EffectCapability.entries.joinToString { it.id }}.")
                cap !in available -> missing += CapabilityIssue(id, "This device or build cannot provide '${cap.id}', which the effect needs.")
            }
        }
        return CapabilityReport(missing, unknown)
    }
}

/**
 * What this build can really serve to an effect today. A capability is added here only together with the code and the
 * tests that serve it; until then an effect that declares it is refused at import with a clear message instead of
 * running with the data missing.
 */
object ServedCapabilities {
    val now: Set<EffectCapability> = setOf(EffectCapability.CurrentFrame, EffectCapability.MultiPass, EffectCapability.AuxiliaryInputs)
}

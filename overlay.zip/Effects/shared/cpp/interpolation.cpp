// interpolation.cpp - Skia-facing adapter of the GL optical-flow pipeline (gl_flow.cpp). There is no SkSL here any more: every pass is a
// GLSL ES shader from glsl_library.cpp run by the native GL backend. This file only moves images between Skia and GL targets.
//
// Transfers go through the CPU (RGBA8 for pictures, RGBA32F for flow fields). Flow fields that this file produced stay on the GL side too
// (a small cache keyed by the SkImage's unique id), so the common loop "estimate once, synthesize many frames" does not re-upload them.
#include "interpolation.h"

#ifndef AM_DESKTOP
#include <android/log.h>
#endif

#include <algorithm>
#include <chrono>
#include <cstring>
#include <map>
#include <memory>
#include <string>
#include <vector>

#include "gl_backend.h"
#include "gl_flow.h"
#include "include/core/SkColorSpace.h"
#include "include/core/SkImageInfo.h"
#include "include/core/SkPixmap.h"
#include "include/gpu/ganesh/GrDirectContext.h"
#include "include/gpu/graphite/Context.h"
#include "include/gpu/graphite/Recorder.h"

#ifdef AM_DESKTOP
#define LOGE(...) ((void)0)
#else
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, "AMInterp", __VA_ARGS__)
#endif

namespace am {
namespace {

// One GL backend + flow pipeline per thread. With Ganesh on OpenGL the engine's EGL context is already current: adopt it (a second
// context would steal the thread's current context from Skia). Otherwise (Vulkan engines) make a private ES context.
struct ThreadFlow {
    std::unique_ptr<rg::GlContext> context;
    std::unique_ptr<rg::GlBackend> backend;
    std::unique_ptr<flow::Flow> flow;
    std::map<uint32_t, rg::Target*> kept;      // SkImage unique id -> GL target that holds the same pixels (flow / mosh motion)
    std::vector<uint32_t> order;
    bool adopted = false, tried = false;
    std::string error;
    ~ThreadFlow() { reset(); }
    void reset() {
        if (flow) for (auto& k : kept) flow->release(k.second);
        kept.clear(); order.clear();
        flow.reset(); backend.reset(); context.reset();
    }
};
thread_local ThreadFlow gThread;

flow::Flow* Pipeline(const GpuContext& context) {
    ThreadFlow& t = gThread;
    if (!t.tried) {
        t.tried = true;
        std::string err;
        t.context = rg::GlContext::Adopt(&err);
        t.adopted = t.context != nullptr;
        if (!t.context) { err.clear(); t.context = rg::GlContext::Create(rg::GlContext::Api::ES, &err); }
        if (!t.context) { t.error = "no OpenGL ES context: " + err; }
        else {
            t.backend = std::make_unique<rg::GlBackend>(*t.context);
            if (!t.backend->ok()) { t.error = t.backend->error(); t.backend.reset(); t.context.reset(); }
            else t.flow = std::make_unique<flow::Flow>(*t.backend);
        }
        if (!t.flow) LOGE("optical flow needs OpenGL ES: %s", t.error.c_str());
    }
    if (t.flow) t.context->makeCurrent();
    (void)context;
    return t.flow.get();
}

// Skia must forget what it knew about GL state after raw GL calls on a shared context.
void Done(const GpuContext& context) {
    if (gThread.adopted && context.ganesh) context.ganesh->resetContext(kAll_GrBackendState);
}

bool ReadPixels(const GpuContext& context, const sk_sp<SkImage>& image, const SkPixmap& dst) {
    if (!image->isTextureBacked()) return image->readPixels(nullptr, dst, 0, 0);
    if (context.ganesh) return image->readPixels(context.ganesh, dst, 0, 0);
#ifndef AM_DESKTOP
    if (context.graphite) {
        struct State { bool done = false, ok = false; const SkPixmap* dst = nullptr; };
        State state; state.dst = &dst;
        context.graphite->asyncRescaleAndReadPixels(
            image.get(), dst.info(), SkIRect::MakeWH(image->width(), image->height()), SkImage::RescaleGamma::kSrc, SkImage::RescaleMode::kNearest,
            [](SkImage::ReadPixelsContext c, std::unique_ptr<const SkImage::AsyncReadResult> r) {
                auto* s = static_cast<State*>(c);
                s->done = true;
                if (!r || r->count() < 1) return;
                const uint8_t* src = static_cast<const uint8_t*>(r->data(0));
                for (int y = 0; y < s->dst->height(); y++)
                    std::memcpy(s->dst->writable_addr(0, y), src + (size_t)y * r->rowBytes(0), s->dst->info().minRowBytes());
                s->ok = true;
            }, &state);
        context.graphite->submit(skgpu::graphite::SyncToCpu::kYes);
        return state.done && state.ok;
    }
#endif
    return false;
}

// SkImage -> RGBA8 premultiplied sRGB GL target.
rg::Target* UploadPicture(const GpuContext& context, flow::Flow& fx, const sk_sp<SkImage>& image) {
    const int w = image->width(), h = image->height();
    std::vector<uint8_t> bytes((size_t)w * h * 4);
    const SkImageInfo info = SkImageInfo::Make(w, h, kRGBA_8888_SkColorType, kPremul_SkAlphaType, SkColorSpace::MakeSRGB());
    if (!ReadPixels(context, image, SkPixmap(info, bytes.data(), (size_t)w * 4))) { LOGE("could not read a frame back from the GPU"); return nullptr; }
    rg::Target* t = fx.picture(w, h);
    if (t && !gThread.backend->uploadRgba8(t, bytes.data())) { fx.release(t); return nullptr; }
    return t;
}

// An image that carries a field (RGBA32F): reuse the GL target it came from, else upload its pixels.
rg::Target* FieldFor(const GpuContext& context, flow::Flow& fx, const sk_sp<SkImage>& image, bool* owned) {
    ThreadFlow& t = gThread;
    auto it = t.kept.find(image->uniqueID());
    if (it != t.kept.end()) { *owned = false; return it->second; }
    const int w = image->width(), h = image->height();
    std::vector<float> px((size_t)w * h * 4);
    const SkImageInfo info = SkImageInfo::Make(w, h, kRGBA_F32_SkColorType, kPremul_SkAlphaType, nullptr);
    if (!ReadPixels(context, image, SkPixmap(info, px.data(), (size_t)w * 16))) return nullptr;
    rg::Target* target = fx.field(w, h);
    if (target && !t.backend->upload(target, px.data())) { fx.release(target); return nullptr; }
    *owned = true;
    return target;
}

// GL field -> SkImage (RGBA32F raster) and remember the GL target under the image's id.
sk_sp<SkImage> KeepField(flow::Flow& fx, rg::Target* target) {
    ThreadFlow& t = gThread;
    std::vector<float> px;
    if (!t.backend->readback(target, &px)) return nullptr;
    const SkImageInfo info = SkImageInfo::Make(target->width, target->height, kRGBA_F32_SkColorType, kPremul_SkAlphaType, nullptr);
    sk_sp<SkImage> image = SkImages::RasterFromPixmapCopy(SkPixmap(info, px.data(), (size_t)target->width * 16));
    if (!image) return nullptr;
    t.kept[image->uniqueID()] = target;
    t.order.push_back(image->uniqueID());
    while (t.order.size() > 8) {                               // keep the newest few
        const uint32_t old = t.order.front();
        t.order.erase(t.order.begin());
        auto it = t.kept.find(old);
        if (it != t.kept.end()) { fx.release(it->second); t.kept.erase(it); }
    }
    return image;
}

// GL picture -> SkImage (RGBA8 premul sRGB raster), then the target is released.
sk_sp<SkImage> TakePicture(flow::Flow& fx, rg::Target* target) {
    if (!target) return nullptr;
    std::vector<float> px;
    const bool ok = gThread.backend->readback(target, &px);
    const int w = target->width, h = target->height;
    fx.release(target);
    if (!ok) return nullptr;
    std::vector<uint8_t> bytes((size_t)w * h * 4);
    for (size_t i = 0; i < bytes.size(); i++) bytes[i] = (uint8_t)std::clamp((int)(px[i] * 255.0f + 0.5f), 0, 255);
    const SkImageInfo info = SkImageInfo::Make(w, h, kRGBA_8888_SkColorType, kPremul_SkAlphaType, SkColorSpace::MakeSRGB());
    return SkImages::RasterFromPixmapCopy(SkPixmap(info, bytes.data(), (size_t)w * 4));
}

flow::Params Convert(const InterpolationParams& p) {
    flow::Params f;
    f.divisor = p.divisor; f.levels = p.levels; f.iterations = p.iterations; f.warps = p.warps; f.alpha = p.alpha; f.fuse = p.fuse;
    return f;
}

struct Release {                      // frees a GL target that this call uploaded
    flow::Flow* fx; rg::Target* t;
    ~Release() { if (t) fx->release(t); }
};

}  // namespace

sk_sp<SkImage> EstimateFlow(const GpuContext& context, const sk_sp<SkImage>& a, const sk_sp<SkImage>& b,
                            const InterpolationParams& params, FlowStats* stats) {
    if (!a || !b) return nullptr;
    flow::Flow* fx = Pipeline(context);
    if (!fx) return nullptr;
    Release ta{fx, UploadPicture(context, *fx, a)}, tb{fx, UploadPicture(context, *fx, b)};
    if (!ta.t || !tb.t) { Done(context); return nullptr; }
    flow::Stats s;
    rg::Target* field = fx->estimate(ta.t, tb.t, Convert(params), &s);
    sk_sp<SkImage> out;
    if (field) {
        out = KeepField(*fx, field);
        if (!out) fx->release(field);
    } else {
        LOGE("flow estimation failed: %s", fx->error().c_str());
    }
    if (stats) *stats = {s.passes, s.levels, s.ms};
    Done(context);
    return out;
}

sk_sp<SkImage> SynthesizeFrame(const GpuContext& context, const sk_sp<SkImage>& a, const sk_sp<SkImage>& b, const sk_sp<SkImage>& flowImage,
                               float t, int divisor, double* ms, const sk_sp<SkImage>& before, const sk_sp<SkImage>& after) {
    if (!a || !b) return nullptr;
    flow::Flow* fx = Pipeline(context);
    if (!fx) return nullptr;
    const auto start = std::chrono::steady_clock::now();
    Release ta{fx, UploadPicture(context, *fx, a)}, tb{fx, UploadPicture(context, *fx, b)};
    Release tp{fx, nullptr}, tn{fx, nullptr};
    const bool four = !flowImage && before && after;
    if (four) { tp.t = UploadPicture(context, *fx, before); tn.t = UploadPicture(context, *fx, after); }
    bool ownsFlow = false;
    rg::Target* field = flowImage ? FieldFor(context, *fx, flowImage, &ownsFlow) : nullptr;
    Release tf{fx, ownsFlow ? field : nullptr};
    sk_sp<SkImage> out;
    if (ta.t && tb.t && (!four || (tp.t && tn.t)) && (!flowImage || field))
        out = TakePicture(*fx, fx->synthesize(ta.t, tb.t, field, t, divisor, tp.t, tn.t));
    if (!out) LOGE("frame synthesis failed: %s", fx->error().c_str());
    if (ms) *ms = std::chrono::duration<double, std::milli>(std::chrono::steady_clock::now() - start).count();
    Done(context);
    return out;
}

sk_sp<SkImage> MotionBlur(const GpuContext& context, const sk_sp<SkImage>& image, const sk_sp<SkImage>& flowImage, float t, float length,
                          int divisor) {
    if (!image || !flowImage) return nullptr;
    flow::Flow* fx = Pipeline(context);
    if (!fx) return nullptr;
    Release ti{fx, UploadPicture(context, *fx, image)};
    bool ownsFlow = false;
    rg::Target* field = FieldFor(context, *fx, flowImage, &ownsFlow);
    Release tf{fx, ownsFlow ? field : nullptr};
    sk_sp<SkImage> out;
    if (ti.t && field) out = TakePicture(*fx, fx->motionBlur(ti.t, field, t, length, divisor));
    if (!out) LOGE("motion blur failed: %s", fx->error().c_str());
    Done(context);
    return out;
}

sk_sp<SkImage> MoshStep(const GpuContext& context, const sk_sp<SkImage>& state, const sk_sp<SkImage>& prior, const sk_sp<SkImage>& frame,
                        const sk_sp<SkImage>& flowImage, const MoshParams& params, float salt, sk_sp<SkImage>* motion) {
    if (!state || !frame) return nullptr;
    flow::Flow* fx = Pipeline(context);
    if (!fx) return nullptr;
    Release ts{fx, UploadPicture(context, *fx, state)}, tr{fx, UploadPicture(context, *fx, frame)};
    bool ownsFlow = false, ownsPrior = false;
    rg::Target* field = flowImage ? FieldFor(context, *fx, flowImage, &ownsFlow) : nullptr;
    Release tf{fx, ownsFlow ? field : nullptr};
    rg::Target* before = prior ? FieldFor(context, *fx, prior, &ownsPrior) : nullptr;
    Release tp{fx, ownsPrior ? before : nullptr};
    flow::MoshParams m;
    m.intensity = params.intensity; m.block = params.block; m.decay = params.decay; m.glitch = params.glitch; m.bloom = params.bloom;
    m.flow = Convert(params.flow);
    sk_sp<SkImage> out;
    if (ts.t && tr.t && (!flowImage || field)) {
        rg::Target* moved = nullptr;
        out = TakePicture(*fx, fx->moshStep(ts.t, before, tr.t, field, m, salt, &moved));
        if (out && moved) {
            sk_sp<SkImage> keep = KeepField(*fx, moved);
            if (keep) *motion = keep; else { fx->release(moved); out.reset(); }
        } else if (moved) {
            fx->release(moved);
        }
    }
    if (!out) LOGE("datamosh step failed: %s", fx->error().c_str());
    Done(context);
    return out;
}

}  // namespace am

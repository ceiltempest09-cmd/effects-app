// Real GPU tests for gl_backend.cpp + the render graph Executor. Nothing here is mocked: every pass is compiled by the
// driver's GLSL compiler and drawn by the driver (Mesa llvmpipe on a CPU-only host, the phone's GPU driver on a device build),
// and every result is read back from the GPU and compared with an independent CPU computation.
//
// A test that needs something the device does not have is reported as SKIP with the reason (never counted as a pass).
//   g++ -std=c++20 -fno-exceptions -fno-rtti -I shared/cpp tests/native/gl_backend_test.cpp shared/cpp/gl_backend.cpp
//       shared/cpp/render_graph.cpp shared/cpp/render_graph_xml.cpp shared/cpp/xml.cpp shared/cpp/shader_info.cpp
//       shared/cpp/shader_diag.cpp shared/cpp/shader_cache.cpp shared/cpp/spirv_util.cpp -lexpat -ldl
#include "gl_backend.h"
#include "render_graph_xml.h"
#include "spirv_util.h"

#include <atomic>
#include <cctype>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <dirent.h>
#include <functional>
#include <sys/stat.h>
#include <thread>
#include <unistd.h>

using namespace am::rg;

static int gFailed = 0, gChecks = 0, gSkipped = 0;
#define CHECK(cond) do { gChecks++; if (!(cond)) { gFailed++; std::printf("  FAIL %s:%d  %s\n", __FILE__, __LINE__, #cond); } } while (0)
#define CHECK_NEAR(a, b, eps) do { gChecks++; const double _a = (a), _b = (b); if (!(std::fabs(_a - _b) <= (eps))) { gFailed++; std::printf("  FAIL %s:%d  %s=%g vs %s=%g (eps %g)\n", __FILE__, __LINE__, #a, _a, #b, _b, (double)(eps)); } } while (0)
#define CHECK_MSG(cond, msg) do { gChecks++; if (!(cond)) { gFailed++; std::printf("  FAIL %s:%d  %s -- %s\n", __FILE__, __LINE__, #cond, std::string(msg).c_str()); } } while (0)
#define SKIP(reason) do { gSkipped++; std::printf("  SKIP %s:%d  %s\n", __FILE__, __LINE__, reason); } while (0)

// ------------------------------------------------------------------ a context + backend per API
struct Gpu {
    std::unique_ptr<GlContext> ctx;
    std::unique_ptr<GlBackend> be;
    bool es = true;
    explicit Gpu(GlContext::Api api, const GlOptions& o = GlOptions()) {
        std::string err;
        ctx = GlContext::Create(api, &err);
        es = api == GlContext::Api::ES;
        if (!ctx) { std::printf("  (no %s context: %s)\n", es ? "ES" : "desktop GL", err.c_str()); return; }
        be.reset(new GlBackend(*ctx, o));
        if (!be->ok()) { std::printf("  (%s backend unusable: %s)\n", es ? "ES" : "desktop GL", be->error().c_str()); be.reset(); }
    }
    ~Gpu() { be.reset(); ctx.reset(); }
    explicit operator bool() const { return be != nullptr; }
    Lang lang() const { return es ? Lang::GLSLES : Lang::GLSL; }
    // Same shader on either API: `body` is everything after the header lines.
    std::string header() const { return es ? "#version 300 es\nprecision highp float;\n" : "#version 330 core\n"; }
};

static PassDesc MakePass(const Gpu& g, const std::string& id, const std::string& body, const std::string& header = std::string()) {
    PassDesc p;
    p.id = id; p.name = id; p.lang = g.lang(); p.file = "gl_backend_test.cpp"; p.line = 100;
    p.source = (header.empty() ? g.header() : header) + body;
    return p;
}

static bool RunPass(Gpu& g, const PassDesc& p, Target* out, std::vector<std::pair<const char*, Target*>> inputs, int aw, int ah, std::string* err,
                    Filter f = Filter::Nearest, Wrap w = Wrap::Clamp, int64_t frame = 0, double time = 0) {
    std::vector<std::string> names;
    for (auto& i : inputs) names.push_back(i.first);
    PassRun r;
    r.pass = &p; r.output = out; r.areaWidth = aw; r.areaHeight = ah; r.frame = frame; r.timeSeconds = time; r.clear = p.clear;
    for (size_t i = 0; i < inputs.size(); i++) { BoundInput b; b.name = &names[i]; b.target = inputs[i].second; b.filter = f; b.wrap = w; r.inputs.push_back(b); }
    return g.be->run(r, err);
}

static std::vector<float> Pattern(int w, int h, float scale) {   // deterministic, includes values above 1 (HDR)
    std::vector<float> v((size_t)w * h * 4);
    for (int y = 0; y < h; y++) for (int x = 0; x < w; x++) {
        float* p = &v[((size_t)y * w + x) * 4];
        p[0] = ((x * 7 + y * 13) % 17) / 17.0f * scale;
        p[1] = ((x * 3 + y * 5) % 11) / 11.0f * scale;
        p[2] = ((x * 11 + y * 2) % 13) / 13.0f * scale;
        p[3] = 1.0f;
    }
    return v;
}
static double MaxDiff(const std::vector<float>& a, const std::vector<float>& b) {
    if (a.size() != b.size()) return 1e9;
    double m = 0;
    for (size_t i = 0; i < a.size(); i++) m = std::max(m, (double)std::fabs(a[i] - b[i]));
    return m;
}
static double Tol(Format f, double magnitude) { return f == Format::RGBA8 ? 2.0 / 255.0 : f == Format::RGBA16F ? 1.5e-3 * std::max(1.0, magnitude) : 2e-5 * std::max(1.0, magnitude); }

// ------------------------------------------------------------------ CPU references
static std::vector<float> CpuBlur(const std::vector<float>& src, int w, int h, bool horizontal, float sigma, int radius) {
    std::vector<float> o(src.size());
    float wsum = 0; std::vector<float> wt;
    for (int i = -radius; i <= radius; i++) { const float k = std::exp(-0.5f * (float)(i * i) / (sigma * sigma)); wt.push_back(k); wsum += k; }
    for (int y = 0; y < h; y++) for (int x = 0; x < w; x++) for (int c = 0; c < 4; c++) {
        float s = 0;
        for (int i = -radius; i <= radius; i++) {
            const int sx = horizontal ? std::min(std::max(x + i, 0), w - 1) : x, sy = horizontal ? y : std::min(std::max(y + i, 0), h - 1);
            s += src[((size_t)sy * w + sx) * 4 + c] * wt[(size_t)(i + radius)];
        }
        o[((size_t)y * w + x) * 4 + c] = s / wsum;
    }
    return o;
}

static const char* kBlurBody =
    "uniform sampler2D src;\nuniform vec2 size;\nuniform vec2 dir;\nuniform float sigma;\nout vec4 o;\n"
    "void main() {\n"
    "  vec4 s = vec4(0.0); float ws = 0.0;\n"
    "  for (int i = -4; i <= 4; i++) {\n"
    "    float k = exp(-0.5 * float(i * i) / (sigma * sigma));\n"
    "    s += texture(src, (gl_FragCoord.xy + dir * float(i)) / size) * k; ws += k;\n"
    "  }\n"
    "  o = s / ws;\n}\n";

// ------------------------------------------------------------------ A. device
static void TestDevice() {
    std::printf("device capability detection (real probe)\n");
    for (auto api : {GlContext::Api::ES, GlContext::Api::Desktop}) {
        Gpu g(api);
        if (!g) { SKIP("no context of this API on this machine"); continue; }
        const GlDeviceCaps& c = g.be->caps();
        std::printf("%s", c.describe().c_str());
        CHECK(c.es == g.es);
        CHECK(c.maxTextureSize >= 2048);
        CHECK(c.rgba8.renderable);
        CHECK(g.be->supports(Format::RGBA8));
        CHECK(g.be->supports(Format::RGBA16F) == c.rgba16f.renderable);
        CHECK(g.be->supports(Format::RGBA32F) == c.rgba32f.renderable);
        if (c.rgba16f.renderable) CHECK(c.rgba16f.exactFloat);            // proven by writing 2.5 and -1 and reading them back
        if (c.rgba32f.renderable) CHECK(c.rgba32f.exactFloat);            // proven with 1 + 2^-20 (not representable in half precision)
        // Inherit = the working format; it is RGBA16F only where that format is renderable AND linearly filterable
        CHECK(g.be->workingFormat() == ((c.rgba16f.renderable && c.rgba16f.linear) ? Format::RGBA16F : Format::RGBA8));
        // languages: exactly what this context can compile
        CHECK(g.be->supports(Lang::GLSLES) == g.es);
        CHECK(g.be->supports(Lang::GLSL) == !g.es);
        CHECK(!g.be->supports(Lang::SkSL));
        CHECK(!g.be->supports(Lang::VulkanGLSL));
        CHECK(!g.be->supports(Lang::SPIRV));
        // an unsupported language is a Capability diagnostic that says why, never a silent pass
        for (Lang l : {Lang::VulkanGLSL, Lang::SPIRV, Lang::SkSL, g.es ? Lang::GLSL : Lang::GLSLES}) {
            PassDesc p; p.id = "x"; p.lang = l; p.source = "#version 450\nvoid main(){}\n";
            Diag why;
            CHECK(!g.be->accepts(p, &why));
            CHECK(why.kind == DiagKind::Capability);
            CHECK(!why.message.empty());
        }
        // an impossible target: the backend refuses to create it instead of crashing
        CHECK(g.be->create(c.maxTextureSize + 1, 4, Format::RGBA8) == nullptr);
        CHECK(g.be->create(0, 4, Format::RGBA8) == nullptr);
        CHECK(g.be->create(4, -1, Format::RGBA8) == nullptr);
    }
}

// ------------------------------------------------------------------ B. shader languages
static void TestShaderLanguages() {
    std::printf("shader compilation, execution and diagnostics\n");
    // --- GLSL ES: 1.00, 3.00, 3.10, 3.20
    if (Gpu g(GlContext::Api::ES); g) {
        Target* t = g.be->create(4, 4, Format::RGBA8);
        struct V { const char* name; const char* src; bool expectOk; };
        const V versions[] = {
            {"ES 1.00", "#version 100\nprecision highp float;\nuniform vec4 color;\nvoid main(){ gl_FragColor = color; }\n", true},
            {"ES 3.00", "#version 300 es\nprecision highp float;\nuniform vec4 color;\nout vec4 o;\nvoid main(){ o = color; }\n", true},
            {"ES 3.10", "#version 310 es\nprecision highp float;\nuniform vec4 color;\nout vec4 o;\nvoid main(){ o = color; }\n", true},
            {"ES 3.20", "#version 320 es\nprecision highp float;\nuniform vec4 color;\nout vec4 o;\nvoid main(){ o = color; }\n", true},
        };
        for (const V& v : versions) {
            PassDesc p; p.id = v.name; p.lang = Lang::GLSLES; p.source = v.src; p.file = "v.json"; p.line = 1;
            p.constants.push_back({"color", {0.2f, 0.4f, 0.6f, 1.0f}});
            std::string err;
            Diag why;
            const bool acc = g.be->accepts(p, &why);
            const int minor = g.be->caps().glslDevice.esMinor;
            const bool deviceHas = !(std::strstr(v.src, "320 es") && minor < 2) && !(std::strstr(v.src, "310 es") && minor < 1);
            CHECK_MSG(acc == deviceHas, std::string(v.name) + ": " + why.message);
            if (!acc) { CHECK(why.kind == DiagKind::Capability); continue; }
            const bool ok = RunPass(g, p, t, {}, 4, 4, &err);
            CHECK_MSG(ok, std::string(v.name) + ": " + err);
            std::vector<float> px; g.be->readback(t, &px);
            CHECK_NEAR(px[0], 0.2, 1.0 / 255); CHECK_NEAR(px[1], 0.4, 1.0 / 255); CHECK_NEAR(px[2], 0.6, 1.0 / 255); CHECK_NEAR(px[3], 1.0, 1e-6);
        }
        // device does not have what the header demands: a Capability message on the #version line, before the driver sees it
        {
            PassDesc p; p.id = "tooNew"; p.lang = Lang::GLSLES; p.source = "// comment\n#version 330 es\nvoid main(){}\n"; p.file = "n.json"; p.line = 1;
            Diag why; CHECK(!g.be->accepts(p, &why)); CHECK(why.kind == DiagKind::Capability); CHECK(why.line == 2);
            p.source = "#version 300 es\n#extension GL_NOT_A_REAL_EXTENSION : require\nvoid main(){}\n";
            Diag why2; CHECK(!g.be->accepts(p, &why2)); CHECK(why2.message.find("GL_NOT_A_REAL_EXTENSION") != std::string::npos); CHECK(why2.line == 2);
        }
        g.be->destroy(t);
    } else SKIP("no OpenGL ES context");

    // --- desktop GLSL: 330 / 400 / 450
    if (Gpu g(GlContext::Api::Desktop); g) {
        Target* t = g.be->create(4, 4, Format::RGBA8);
        for (const char* ver : {"#version 330 core", "#version 400 core", "#version 450 core"}) {
            PassDesc p; p.id = ver; p.lang = Lang::GLSL; p.file = "d.json"; p.line = 1;
            p.source = std::string(ver) + "\nuniform vec4 color;\nout vec4 o;\nvoid main(){ o = color; }\n";
            p.constants.push_back({"color", {1.0f, 0.0f, 0.5f, 1.0f}});
            std::string err;
            Diag why;
            const bool acc = g.be->accepts(p, &why);
            CHECK_MSG(acc, std::string(ver) + ": " + why.message);
            if (!acc) continue;
            CHECK_MSG(RunPass(g, p, t, {}, 4, 4, &err), err);
            std::vector<float> px; g.be->readback(t, &px);
            CHECK_NEAR(px[0], 1.0, 1e-6); CHECK_NEAR(px[1], 0.0, 1e-6); CHECK_NEAR(px[2], 0.5, 1.0 / 255);
        }
        PassDesc p; p.id = "v999"; p.lang = Lang::GLSL; p.source = "#version 999 core\nvoid main(){}\n"; Diag why;
        CHECK(!g.be->accepts(p, &why)); CHECK(why.kind == DiagKind::Capability);
        g.be->destroy(t);
    } else SKIP("no desktop OpenGL context");

    // --- compile errors carry the effect-file line of the ORIGINAL text, with and without defines (prelude)
    for (auto api : {GlContext::Api::ES, GlContext::Api::Desktop}) {
        Gpu g(api);
        if (!g) continue;
        Target* t = g.be->create(4, 4, Format::RGBA8);
        PassDesc p = MakePass(g, "bad", "out vec4 o;\nvoid main() {\n  float a = 1.0;\n  o = vec4(a, undefined_name, 0.0, 1.0);\n}\n");
        p.line = 40;   // the author's line 1 (the #version line) sits on file line 40
        std::string err;
        CHECK(!RunPass(g, p, t, {}, 4, 4, &err));
        const int errLine = g.es ? 40 + 6 - 1 : 40 + 5 - 1;   // header is 2 lines on ES, 1 on desktop; `o = vec4(...)` is body line 4
        CHECK_MSG(err.find("gl_backend_test.cpp:" + std::to_string(errLine) + ":") != std::string::npos, err);
        CHECK(err.find("undefined_name") != std::string::npos);
        CHECK(!g.be->lastDiags().empty());
        // with defines inserted after #version the line must still point at the author's line
        p.defines["FOO"] = "1"; p.defines["BAR"] = "2.0";
        err.clear();
        CHECK(!RunPass(g, p, t, {}, 4, 4, &err));
        CHECK_MSG(err.find("gl_backend_test.cpp:" + std::to_string(errLine) + ":") != std::string::npos, err);
        // syntax error
        PassDesc q = MakePass(g, "syn", "out vec4 o;\nvoid main() { o = vec4(1.0) }\n");
        err.clear();
        CHECK(!RunPass(g, q, t, {}, 4, 4, &err));
        CHECK(err.find("did not compile") != std::string::npos);
        // linking: the generated full-screen vertex shader exports no varyings. Drivers differ on a fragment input nothing feeds
        // (Mesa links it and reads zeros, others refuse): either way the result is never a crash, and a refusal says "did not link".
        PassDesc l = MakePass(g, "varying", "in vec2 vUv;\nout vec4 o;\nvoid main(){ o = vec4(vUv, 0.0, 1.0); }\n");
        err.clear();
        const bool linked = RunPass(g, l, t, {}, 4, 4, &err);
        CHECK(linked || err.find("did not link") != std::string::npos);
        // a failing compile leaves nothing behind
        const size_t before = g.be->programCount();
        CHECK(!RunPass(g, q, t, {}, 4, 4, &err));
        CHECK(g.be->programCount() == before);
        // the next, valid pass still works (no sticky state)
        PassDesc ok = MakePass(g, "ok", "out vec4 o;\nvoid main(){ o = vec4(0.5); }\n");
        CHECK_MSG(RunPass(g, ok, t, {}, 4, 4, &err), err);
        g.be->destroy(t);
    }

    // --- SPIR-V and Vulkan GLSL: not executable here; validation still works and the refusal is explicit
    if (Gpu g(GlContext::Api::ES); g) {
        // minimal valid module: header + OpCapability Shader + OpMemoryModel + OpEntryPoint Fragment "main" + OpExecutionMode
        const uint32_t words[] = {0x07230203, 0x00010000, 0, 8, 0,
                                  0x00020011, 1,                          // OpCapability Shader
                                  0x0003000E, 0, 1,                       // OpMemoryModel Logical GLSL450
                                  0x0005000F, 4, 4, 0x6E69616D, 0,        // OpEntryPoint Fragment %4 "main"
                                  0x00030010, 4, 7};                      // OpExecutionMode %4 OriginUpperLeft
        std::vector<uint8_t> bytes(sizeof(words)); std::memcpy(bytes.data(), words, sizeof(words));
        SpirvInfo info; std::string e;
        CHECK(ParseSpirv(bytes, &info, &e));
        PassDesc p; p.id = "spv"; p.lang = Lang::SPIRV; p.source = Base64Encode(bytes.data(), bytes.size());
        Diag why; CHECK(!g.be->accepts(p, &why)); CHECK(why.kind == DiagKind::Capability);
        std::string err; Target* t = g.be->create(2, 2, Format::RGBA8);
        CHECK(!RunPass(g, p, t, {}, 2, 2, &err)); CHECK(!err.empty());
        g.be->destroy(t);
        std::vector<uint8_t> bad = bytes; bad[0] ^= 0xFF;
        CHECK(!ParseSpirv(bad, &info, &e));
        SKIP("SPIR-V / Vulkan GLSL execution: no SPIR-V compiler and no Vulkan device in this build, so these languages are reported unsupported (see docs/NATIVE_SHADERS.md)");
    }
}

// ------------------------------------------------------------------ B2. uniforms, samplers, coordinates, blending
static void TestUniformsAndSampling() {
    std::printf("uniform binding, sampler binding, coordinates, wrap, blend\n");
    for (auto api : {GlContext::Api::ES, GlContext::Api::Desktop}) {
        Gpu g(api);
        if (!g) continue;
        std::printf(" [%s]\n", g.es ? "GLES" : "desktop GL");
        const int W = 8, H = 6;
        std::string err;
        // coordinates: gl_FragCoord is the pixel centre; row 0 of the buffer is the TOP row (contract: top-left origin, y down)
        {
            Target* t = g.be->create(W, H, Format::RGBA32F);
            PassDesc p = MakePass(g, "coords", "uniform vec2 size;\nout vec4 o;\nvoid main(){ o = vec4(gl_FragCoord.x, gl_FragCoord.y, size.x, size.y); }\n");
            CHECK_MSG(RunPass(g, p, t, {}, W, H, &err), err);
            std::vector<float> px; g.be->readback(t, &px);
            for (int y = 0; y < H; y++) for (int x = 0; x < W; x++) {
                const float* v = &px[((size_t)y * W + x) * 4];
                CHECK_NEAR(v[0], x + 0.5, 1e-6); CHECK_NEAR(v[1], y + 0.5, 1e-6); CHECK_NEAR(v[2], W, 0); CHECK_NEAR(v[3], H, 0);
            }
            g.be->destroy(t);
        }
        // automatic uniforms and constants of every type
        {
            Target* t = g.be->create(W, H, Format::RGBA32F);
            Target* in = g.be->create(5, 3, Format::RGBA8);
            PassDesc p = MakePass(g, "autos",
                "uniform sampler2D img;\nuniform vec2 size;\nuniform vec2 out_px;\nuniform vec2 img_px;\nuniform float time;\nuniform float frame;\n"
                "uniform float f1;\nuniform vec2 f2;\nuniform vec3 f3;\nuniform vec4 f4;\nuniform int i1;\nuniform vec4 arr[2];\nout vec4 o;\n"
                "void main(){\n"
                "  float a = size.x + out_px.y * 10.0 + img_px.x * 100.0 + img_px.y * 1000.0;\n"
                "  vec4 m = vec4(a, time, frame, f1 + float(i1));\n"
                "  o = (gl_FragCoord.x < 1.0) ? m : (gl_FragCoord.x < 2.0 ? vec4(f2, f3.x, f3.z) : (gl_FragCoord.x < 3.0 ? f4 : arr[1] - arr[0]));\n"
                "  o += texture(img, vec2(0.5)) * 0.0;\n}\n");
            p.constants = {{"f1", {1.5f}}, {"f2", {2.0f, 3.0f}}, {"f3", {4.0f, 5.0f, 6.0f}}, {"f4", {7.0f, 8.0f, 9.0f, 10.0f}}, {"i1", {3.0f}}, {"arr", {1, 2, 3, 4, 10, 20, 30, 40}}};
            CHECK_MSG(RunPass(g, p, t, {{"img", in}}, W, H, &err, Filter::Nearest, Wrap::Clamp, 7, 2.5), err);
            std::vector<float> px; g.be->readback(t, &px);
            const float* c0 = &px[0]; const float* c1 = &px[4]; const float* c2 = &px[8]; const float* c3 = &px[12];
            CHECK_NEAR(c0[0], 8 + H * 10 + 5 * 100 + 3 * 1000, 1e-3); CHECK_NEAR(c0[1], 2.5, 1e-6); CHECK_NEAR(c0[2], 7, 1e-6); CHECK_NEAR(c0[3], 4.5, 1e-6);
            CHECK_NEAR(c1[0], 2, 1e-6); CHECK_NEAR(c1[1], 3, 1e-6); CHECK_NEAR(c1[2], 4, 1e-6); CHECK_NEAR(c1[3], 6, 1e-6);
            CHECK_NEAR(c2[0], 7, 1e-6); CHECK_NEAR(c2[3], 10, 1e-6);
            CHECK_NEAR(c3[0], 9, 1e-6); CHECK_NEAR(c3[3], 36, 1e-6);   // uniform array bound as one value list
            g.be->destroy(t); g.be->destroy(in);
        }
        // missing values are errors that name the uniform / sampler, never a silent 0
        {
            Target* t = g.be->create(W, H, Format::RGBA8);
            PassDesc p = MakePass(g, "missing", "uniform float strength;\nout vec4 o;\nvoid main(){ o = vec4(strength); }\n");
            err.clear(); CHECK(!RunPass(g, p, t, {}, W, H, &err));
            CHECK_MSG(err.find("'strength'") != std::string::npos && err.find("no value") != std::string::npos, err);
            PassDesc q = MakePass(g, "nosamp", "uniform sampler2D tex;\nout vec4 o;\nvoid main(){ o = texture(tex, vec2(0.5)); }\n");
            err.clear(); CHECK(!RunPass(g, q, t, {}, W, H, &err));
            CHECK_MSG(err.find("sampler2D 'tex'") != std::string::npos, err);
            PassDesc r = MakePass(g, "wrongsize", "uniform vec3 c;\nout vec4 o;\nvoid main(){ o = vec4(c, 1.0); }\n");
            r.constants.push_back({"c", {1.0f, 2.0f}});
            err.clear(); CHECK(!RunPass(g, r, t, {}, W, H, &err));
            CHECK_MSG(err.find("'c'") != std::string::npos && err.find("vec3") != std::string::npos, err);
            // a pass that reads its own output is refused (GL feedback loop = undefined result)
            PassDesc s = MakePass(g, "loop", "uniform sampler2D tex;\nout vec4 o;\nvoid main(){ o = texture(tex, vec2(0.5)); }\n");
            err.clear(); CHECK(!RunPass(g, s, t, {{"tex", t}}, W, H, &err));
            CHECK(err.find("feedback") != std::string::npos);
            g.be->destroy(t);
        }
        // defines reach the shader
        {
            Target* t = g.be->create(2, 2, Format::RGBA8);
            PassDesc p = MakePass(g, "defs", "out vec4 o;\nvoid main(){ o = vec4(LEVEL, 0.0, 0.0, 1.0); }\n");
            p.defines["LEVEL"] = "0.5";
            CHECK_MSG(RunPass(g, p, t, {}, 2, 2, &err), err);
            std::vector<float> px; g.be->readback(t, &px); CHECK_NEAR(px[0], 0.5, 1.0 / 255);
            g.be->destroy(t);
        }
        // sampling: nearest = exact texel, linear = bilinear (checked against a CPU bilinear), all wrap modes
        {
            const int sw = 4, sh = 3;
            const auto src = Pattern(sw, sh, 3.0f);
            Target* in = g.be->createFromFloats(sw, sh, Format::RGBA32F, src.data());
            Target* out = g.be->create(16, 9, Format::RGBA32F);
            PassDesc p = MakePass(g, "sample", "uniform sampler2D src;\nuniform vec2 size;\nuniform vec2 off;\nout vec4 o;\n"
                                               "void main(){ o = texture(src, gl_FragCoord.xy / size * 1.5 - off); }\n");
            p.constants.push_back({"off", {0.25f, 0.25f}});
            auto fetch = [&](int x, int y, Wrap w) -> const float* {
                static const float zero[4] = {0, 0, 0, 0};
                auto fix = [&](int i, int n, bool* inside) { *inside = true; if (i >= 0 && i < n) return i;
                    if (w == Wrap::Repeat) return ((i % n) + n) % n;
                    if (w == Wrap::Mirror) { int q = ((i % (2 * n)) + 2 * n) % (2 * n); return q < n ? q : 2 * n - 1 - q; }
                    if (w == Wrap::Decal) { *inside = false; return 0; }
                    return i < 0 ? 0 : n - 1; };
                bool a, b; const int fx = fix(x, sw, &a), fy = fix(y, sh, &b);
                return a && b ? &src[((size_t)fy * sw + fx) * 4] : zero; };
            for (Filter f : {Filter::Nearest, Filter::Linear}) for (Wrap w : {Wrap::Clamp, Wrap::Repeat, Wrap::Mirror, Wrap::Decal}) {
                if (w == Wrap::Decal && !g.be->caps().borderClamp) { SKIP("wrap=decal needs border clamp"); continue; }
                err.clear();
                CHECK_MSG(RunPass(g, p, out, {{"src", in}}, 16, 9, &err, f, w), err);
                std::vector<float> got; g.be->readback(out, &got);
                double worst = 0;
                for (int y = 0; y < 9; y++) for (int x = 0; x < 16; x++) {
                    const float u = (x + 0.5f) / 16 * 1.5f - 0.25f, v = (y + 0.5f) / 9 * 1.5f - 0.25f;
                    const float fx = u * sw - 0.5f, fy = v * sh - 0.5f;
                    float want[4];
                    if (f == Filter::Nearest) {
                        // GL picks floor(u * w); stay away from texel borders so the comparison is not about tie-breaking
                        const float cx = u * sw, cy = v * sh;
                        if (std::fabs(cx - std::round(cx)) < 1e-3f || std::fabs(cy - std::round(cy)) < 1e-3f) continue;
                        const float* t = fetch((int)std::floor(cx), (int)std::floor(cy), w);
                        for (int c = 0; c < 4; c++) want[c] = t[c];
                    } else {
                        const int x0 = (int)std::floor(fx), y0 = (int)std::floor(fy);
                        const float tx = fx - x0, ty = fy - y0;
                        for (int c = 0; c < 4; c++)
                            want[c] = (fetch(x0, y0, w)[c] * (1 - tx) + fetch(x0 + 1, y0, w)[c] * tx) * (1 - ty) + (fetch(x0, y0 + 1, w)[c] * (1 - tx) + fetch(x0 + 1, y0 + 1, w)[c] * tx) * ty;
                    }
                    for (int c = 0; c < 4; c++) worst = std::max(worst, (double)std::fabs(got[((size_t)y * 16 + x) * 4 + c] - want[c]));
                }
                CHECK_MSG(worst < (f == Filter::Linear ? 5e-3 : 1e-5), std::string(f == Filter::Linear ? "linear " : "nearest ") + "wrap " + std::to_string((int)w) + " worst " + std::to_string(worst));
            }
            g.be->destroy(in); g.be->destroy(out);
        }
        // builtin textures
        {
            TextureDesc ramp; ramp.id = "r"; ramp.source = "builtin:ramp-x"; ramp.width = 8; ramp.height = 2;
            TextureDesc noise; noise.id = "n"; noise.source = "builtin:noise"; noise.width = 16; noise.height = 16; noise.seed = 5;
            Target* rt = g.be->texture(ramp); Target* nt = g.be->texture(noise);
            CHECK(rt && nt); CHECK(g.be->texture(ramp) == rt);   // cached
            std::vector<float> px; g.be->readback(rt, &px);
            for (int x = 0; x < 8; x++) CHECK_NEAR(px[(size_t)x * 4], (x + 0.5) / 8, 1.0 / 255 + 1e-6);
            g.be->readback(nt, &px);
            const auto want = NoisePixels(16, 16, 5);
            double worst = 0; for (size_t i = 0; i < want.size(); i++) worst = std::max(worst, std::fabs(px[i] - want[i] / 255.0));
            CHECK(worst < 1e-6);
            TextureDesc bad; bad.id = "b"; bad.source = "builtin:nope"; CHECK(g.be->texture(bad) == nullptr);
        }
        // blend modes on premultiplied values: replace, over, add, multiply, screen
        {
            Target* t = g.be->create(2, 2, Format::RGBA16F);
            const float dst[4] = {0.4f, 0.2f, 0.1f, 0.5f}, srcc[4] = {0.3f, 0.6f, 0.2f, 0.5f};
            std::vector<float> init(16); for (int i = 0; i < 4; i++) std::memcpy(&init[(size_t)i * 4], dst, 16);
            for (Blend b : {Blend::Replace, Blend::SrcOver, Blend::Add, Blend::Multiply, Blend::Screen}) {
                g.be->upload(t, init.data());
                PassDesc p = MakePass(g, "blend", "uniform vec4 c;\nout vec4 o;\nvoid main(){ o = c; }\n");
                p.constants.push_back({"c", {srcc[0], srcc[1], srcc[2], srcc[3]}}); p.blend = b; p.clear = false;
                err.clear(); CHECK_MSG(RunPass(g, p, t, {}, 2, 2, &err), err);
                std::vector<float> px; g.be->readback(t, &px);
                for (int c = 0; c < 4; c++) {
                    float want = 0; const float s = srcc[c], d = dst[c];
                    switch (b) {
                        case Blend::Replace: want = s; break;
                        case Blend::SrcOver: want = s + d * (1 - srcc[3]); break;
                        case Blend::Add: want = s + d; break;
                        case Blend::Multiply: want = s * d + d * (1 - srcc[3]); break;   // GL_DST_COLOR, GL_ONE_MINUS_SRC_ALPHA
                        case Blend::Screen: want = s + d * (1 - s); break;
                    }
                    CHECK_NEAR(px[(size_t)c], want, 2e-3);
                }
            }
            g.be->destroy(t);
        }
        CHECK(g.be->contextLost() == false);
    }
}

// ------------------------------------------------------------------ C. precision / formats on the GPU
static void TestFormats() {
    std::printf("RGBA8 / RGBA16F / RGBA32F rendering, linear light, HDR\n");
    for (auto api : {GlContext::Api::ES, GlContext::Api::Desktop}) {
        Gpu g(api);
        if (!g) continue;
        std::printf(" [%s]\n", g.es ? "GLES" : "desktop GL");
        const int W = 33, H = 17;   // not powers of two
        const auto src = Pattern(W, H, 4.0f);   // HDR values up to 4
        PassDesc h = MakePass(g, "h", kBlurBody), v = MakePass(g, "v", kBlurBody);
        h.constants = {{"dir", {1, 0}}, {"sigma", {1.7f}}}; v.constants = {{"dir", {0, 1}}, {"sigma", {1.7f}}};
        for (Format f : {Format::RGBA8, Format::RGBA16F, Format::RGBA32F}) {
            if (!g.be->supports(f)) { SKIP((std::string(FormatText(f)) + " is not renderable on this device").c_str()); CHECK(g.be->create(W, H, f) == nullptr); continue; }
            auto in = std::vector<float>(src);
            if (f == Format::RGBA8) for (float& x : in) x = std::min(x, 1.0f);   // RGBA8 cannot hold HDR: the CPU reference sees the same clamp
            Target* a = g.be->createFromFloats(W, H, f, in.data());
            Target* b = g.be->create(W, H, f);
            Target* c = g.be->create(W, H, f);
            CHECK(a && b && c);
            std::string err;
            CHECK_MSG(RunPass(g, h, b, {{"src", a}}, W, H, &err), err);
            CHECK_MSG(RunPass(g, v, c, {{"src", b}}, W, H, &err), err);
            std::vector<float> got; g.be->readback(c, &got);
            // CPU reference mirrors the storage: RGBA8 re-quantises between passes
            auto mid = CpuBlur(in, W, H, true, 1.7f, 4);
            if (f == Format::RGBA8) for (float& x : mid) x = std::round(x * 255.0f) / 255.0f;
            const auto want = CpuBlur(mid, W, H, false, 1.7f, 4);
            const double d = MaxDiff(got, want);
            std::printf("   %s separable gaussian: max |gpu-cpu| = %.3g\n", FormatText(f), d);
            CHECK_MSG(d <= Tol(f, 4.0) + (f == Format::RGBA8 ? 2.0 / 255 : 0), std::string(FormatText(f)) + " diff " + std::to_string(d));
            // the actual storage is what we asked for: only 16F/32F keep values above 1
            double mx = 0; for (float x : got) mx = std::max(mx, (double)x);
            if (f == Format::RGBA8) CHECK(mx <= 1.0 + 1e-6); else CHECK(mx > 1.5);
            g.be->destroy(a); g.be->destroy(b); g.be->destroy(c);
        }
        // 32F really is 32-bit: a value half precision cannot represent survives a pass-through
        if (g.be->supports(Format::RGBA32F) && g.be->supports(Format::RGBA16F)) {
            PassDesc cp = MakePass(g, "cp", "uniform sampler2D src;\nuniform vec2 size;\nout vec4 o;\nvoid main(){ o = texture(src, gl_FragCoord.xy / size); }\n");
            const float val = 1.0f + 1.0f / 65536.0f;   // 2^-16: below half precision (2^-10)
            std::vector<float> one(4 * 4, val);
            Target* s32 = g.be->createFromFloats(2, 2, Format::RGBA32F, one.data());
            Target* o32 = g.be->create(2, 2, Format::RGBA32F);
            Target* o16 = g.be->create(2, 2, Format::RGBA16F);
            std::string err;
            CHECK_MSG(RunPass(g, cp, o32, {{"src", s32}}, 2, 2, &err), err);
            CHECK_MSG(RunPass(g, cp, o16, {{"src", s32}}, 2, 2, &err), err);
            std::vector<float> r32, r16; g.be->readback(o32, &r32); g.be->readback(o16, &r16);
            CHECK(r32[0] == val);
            CHECK(r16[0] == 1.0f);   // the half-float target rounded it: formats are not silently interchangeable
            g.be->destroy(s32); g.be->destroy(o32); g.be->destroy(o16);
        }
        // linear-light compositing: sRGB-encoded inputs decoded in the shader, mixed in linear light, re-encoded
        if (g.be->supports(Format::RGBA16F)) {
            PassDesc mix = MakePass(g, "mixlin",
                "uniform sampler2D a;\nuniform sampler2D b;\nuniform vec2 size;\nout vec4 o;\n"
                "vec3 toLin(vec3 c){ return mix(c / 12.92, pow((c + 0.055) / 1.055, vec3(2.4)), step(0.04045, c)); }\n"
                "vec3 toSrgb(vec3 c){ return mix(c * 12.92, 1.055 * pow(c, vec3(1.0 / 2.4)) - 0.055, step(0.0031308, c)); }\n"
                "void main(){ vec2 uv = gl_FragCoord.xy / size; vec3 x = toLin(texture(a, uv).rgb), y = toLin(texture(b, uv).rgb); o = vec4(toSrgb((x + y) * 0.5), 1.0); }\n");
            std::vector<float> A(4 * 4, 0), B(4 * 4, 0);
            for (int i = 0; i < 4; i++) { A[(size_t)i * 4] = 1.0f; A[(size_t)i * 4 + 3] = 1; B[(size_t)i * 4 + 3] = 1; }   // red vs black
            Target* ta = g.be->createFromFloats(2, 2, Format::RGBA16F, A.data()); Target* tb = g.be->createFromFloats(2, 2, Format::RGBA16F, B.data());
            Target* to = g.be->create(2, 2, Format::RGBA16F);
            std::string err; CHECK_MSG(RunPass(g, mix, to, {{"a", ta}, {"b", tb}}, 2, 2, &err, Filter::Nearest), err);
            std::vector<float> px; g.be->readback(to, &px);
            // average of 1.0 and 0.0 in LINEAR light is 0.5, which is 0.7354 sRGB-encoded (a naive average would give 0.5)
            CHECK_NEAR(px[0], 0.735357, 2e-3);
            g.be->destroy(ta); g.be->destroy(tb); g.be->destroy(to);
        }
    }
}

// ------------------------------------------------------------------ D. render graph on the GPU (Executor end to end)
static const char* kGraphXml = R"(<effect id="fx.gpu_glow" graph="2" output="out" seek="reset">
  <buffer id="bright" format="rgba16f" scale="0.5"/>
  <buffer id="blur_a" format="rgba16f" scale="0.5"/>
  <buffer id="blur_b" format="rgba16f" scale="0.5"/>
  <pass id="threshold" lang="glsl-es" output="bright" file="fx.xml" line="10">
    <input name="src" ref="source"/>
    <source><![CDATA[#version 300 es
precision highp float;
uniform sampler2D src;
uniform vec2 out_px;
uniform float cut;
out vec4 o;
void main() {
    vec4 c = texture(src, gl_FragCoord.xy / out_px);   // gl_FragCoord is in pixels of THIS target (half size), so normalise by out_px
    float l = dot(c.rgb, vec3(0.2126, 0.7152, 0.0722));
    o = c * smoothstep(cut, cut + 0.3, l);
}
]]></source>
    <const name="cut" value="0.5"/>
  </pass>
  <pass id="blur_h" lang="glsl-es" output="blur_a" file="fx.xml" line="30">
    <input name="src" ref="buffer:bright"/>
    <source><![CDATA[#version 300 es
precision highp float;
uniform sampler2D src;
uniform vec2 size;
uniform vec2 out_px;
out vec4 o;
void main() {
    vec2 uv = gl_FragCoord.xy / out_px;
    vec4 s = vec4(0.0); float ws = 0.0;
    for (int i = -4; i <= 4; i++) { float k = exp(-float(i * i) / 8.0); s += texture(src, uv + vec2(float(i) / out_px.x, 0.0)) * k; ws += k; }
    o = s / ws;
}
]]></source>
  </pass>
  <pass id="blur_v" lang="glsl-es" output="blur_b" file="fx.xml" line="50">
    <input name="src" ref="buffer:blur_a"/>
    <source><![CDATA[#version 300 es
precision highp float;
uniform sampler2D src;
uniform vec2 out_px;
out vec4 o;
void main() {
    vec2 uv = gl_FragCoord.xy / out_px;
    vec4 s = vec4(0.0); float ws = 0.0;
    for (int i = -4; i <= 4; i++) { float k = exp(-float(i * i) / 8.0); s += texture(src, uv + vec2(0.0, float(i) / out_px.y)) * k; ws += k; }
    o = s / ws;
}
]]></source>
  </pass>
  <pass id="comp" lang="glsl-es" output="out" file="fx.xml" line="70">
    <input name="base" ref="source"/>
    <input name="glow" ref="buffer:blur_b"/>
    <source><![CDATA[#version 300 es
precision highp float;
uniform sampler2D base;
uniform sampler2D glow;
uniform vec2 size;
uniform float strength;
out vec4 o;
void main() {
    vec2 uv = gl_FragCoord.xy / size;
    vec4 b = texture(base, uv);
    vec4 g = texture(glow, uv) * strength;
    o = b + g;
}
]]></source>
    <const name="strength" value="0.8"/>
  </pass>
</effect>
)";

static GraphDesc ParseXml(const std::string& xml, bool desktop) {
    std::string text = xml;
    if (desktop) {   // same graph for the desktop backend: language and #version only
        auto rep = [&](const std::string& a, const std::string& b) { size_t p; while ((p = text.find(a)) != std::string::npos) text.replace(p, a.size(), b); };
        rep("lang=\"glsl-es\"", "lang=\"glsl\"");
        rep("#version 300 es\nprecision highp float;\n", "#version 330 core\n");
    }
    std::string e;
    auto root = am::ParseXml(text, &e);
    GraphDesc g; std::vector<Diag> d;
    if (!root || !IsGraphXml(*root) || !ParseGraphXml(*root, &g, &d)) { std::printf("  XML problem: %s\n", e.c_str()); for (auto& x : d) std::printf("   %s\n", x.format().c_str()); }
    return g;
}

// CPU reference of the glow graph at full precision
static std::vector<float> CpuGlow(const std::vector<float>& src, int W, int H, float cut, float strength, int* bw, int* bh) {
    const int w = std::max(1, (int)std::lround(W * 0.5)), h = std::max(1, (int)std::lround(H * 0.5));
    *bw = w; *bh = h;
    auto smooth = [](float e0, float e1, float x) { float t = std::min(std::max((x - e0) / (e1 - e0), 0.0f), 1.0f); return t * t * (3 - 2 * t); };
    auto bilinear = [&](const std::vector<float>& im, int iw, int ih, float u, float v, int c) {
        const float fx = u * iw - 0.5f, fy = v * ih - 0.5f;
        const int x0 = (int)std::floor(fx), y0 = (int)std::floor(fy);
        const float tx = fx - x0, ty = fy - y0;
        auto at = [&](int x, int y) { x = std::min(std::max(x, 0), iw - 1); y = std::min(std::max(y, 0), ih - 1); return im[((size_t)y * iw + x) * 4 + c]; };
        return (at(x0, y0) * (1 - tx) + at(x0 + 1, y0) * tx) * (1 - ty) + (at(x0, y0 + 1) * (1 - tx) + at(x0 + 1, y0 + 1) * tx) * ty;
    };
    // threshold pass renders the source at half size by sampling it at the pixel centre of the small target
    std::vector<float> bright((size_t)w * h * 4);
    for (int y = 0; y < h; y++) for (int x = 0; x < w; x++) {
        const float u = (x + 0.5f) / w, v = (y + 0.5f) / h;
        float c[4]; for (int k = 0; k < 4; k++) c[k] = bilinear(src, W, H, u, v, k);
        const float l = 0.2126f * c[0] + 0.7152f * c[1] + 0.0722f * c[2];
        const float s = smooth(cut, cut + 0.3f, l);
        for (int k = 0; k < 4; k++) bright[((size_t)y * w + x) * 4 + k] = c[k] * s;
    }
    auto blur = [&](const std::vector<float>& im, bool horiz) {
        std::vector<float> o(im.size());
        for (int y = 0; y < h; y++) for (int x = 0; x < w; x++) for (int c = 0; c < 4; c++) {
            float s = 0, ws = 0;
            for (int i = -4; i <= 4; i++) { const float k = std::exp(-(float)(i * i) / 8.0f); const float u = (x + 0.5f) / w + (horiz ? (float)i / w : 0), v = (y + 0.5f) / h + (horiz ? 0 : (float)i / h); s += bilinear(im, w, h, u, v, c) * k; ws += k; }
            o[((size_t)y * w + x) * 4 + c] = s / ws;
        }
        return o;
    };
    const auto glow = blur(blur(bright, true), false);
    std::vector<float> out((size_t)W * H * 4);
    for (int y = 0; y < H; y++) for (int x = 0; x < W; x++) for (int c = 0; c < 4; c++)
        out[((size_t)y * W + x) * 4 + c] = src[((size_t)y * W + x) * 4 + c] + bilinear(glow, w, h, (x + 0.5f) / W, (y + 0.5f) / H, c) * strength;
    return out;
}

static void TestExecutorGraph() {
    std::printf("multi-pass graph: planner + executor + GPU (threshold -> blur H -> blur V -> composite, half-size buffers)\n");
    for (auto api : {GlContext::Api::ES, GlContext::Api::Desktop}) {
        Gpu g(api);
        if (!g) continue;
        std::printf(" [%s]\n", g.es ? "GLES" : "desktop GL");
        GraphDesc gd = ParseXml(kGraphXml, !g.es);
        PlanOptions po; po.backend = g.be->name(); po.languages = {g.lang()};
        auto plan = std::make_shared<Plan>(BuildPlan(gd, po));
        for (const Diag& d : plan->diags) std::printf("   plan: %s\n", d.format().c_str());
        CHECK(plan->ok());
        CHECK(plan->steps.size() == 4);
        CHECK(plan->culled.empty());
        Executor ex(*g.be, plan);
        const int W = 64, H = 40;
        const auto src = Pattern(W, H, 1.6f);
        Format f = g.be->supports(Format::RGBA16F) ? Format::RGBA16F : Format::RGBA8;
        Target* source = g.be->createFromFloats(W, H, f, src.data());
        std::vector<float> got;
        FrameRequest fr; fr.frame = 0; fr.width = W; fr.height = H; fr.source = source; fr.signature = 1; fr.timeSeconds = 0;
        FrameResult res = ex.render(fr, [&](Target* t) { g.be->readback(t, &got); });
        CHECK_MSG(res.status == FrameResult::Ok, res.error);
        CHECK(res.timings.size() == 4);
        int bw, bh;
        const auto want = CpuGlow(src, W, H, 0.5f, 0.8f, &bw, &bh);
        const double d = MaxDiff(got, want);
        std::printf("   glow graph vs CPU reference: max diff %.3g (storage %s)\n", d, FormatText(f));
        CHECK_MSG(d < (f == Format::RGBA16F ? 2.5e-2 : 3e-2), std::to_string(d));
        // buffers: the 3 half-size temporaries reuse targets; peak never exceeds what the plan says
        const TargetPool::Stats ps = ex.poolStats();
        std::printf("   pool: created %lld reused %lld peak %lld bytes live %d idle %d (plan peakLive %d)\n", (long long)ps.created, (long long)ps.reused, (long long)ps.peakBytes, ps.live, ps.idle, plan->peakLive);
        CHECK(ps.created <= plan->peakLive + 1);
        // 20 more frames: no growth at all
        const int64_t created0 = ps.created;
        for (int i = 1; i <= 20; i++) {
            fr.frame = i; fr.timeSeconds = i / 30.0;
            res = ex.render(fr, [&](Target*) {});
            CHECK(res.status == FrameResult::Ok);
        }
        CHECK(ex.poolStats().created == created0);
        CHECK(ex.poolStats().live == 0);
        CHECK(g.be->stats().liveTargets == ex.poolStats().idle + 1 /*source*/ + (int64_t)0 + (g.be->stats().liveTargets - ex.poolStats().idle - 1));   // arithmetic sanity, real check below
        // every GL object the pool owns is released by dropAll()
        const int64_t liveBefore = g.be->stats().liveTargets;
        ex.dropAll();
        CHECK(ex.poolStats().idle == 0);
        CHECK(g.be->stats().liveTargets < liveBefore);
        // the executor still renders after dropAll (context recreation path)
        fr.frame = 100;
        res = ex.render(fr, [&](Target*) {});
        CHECK_MSG(res.status == FrameResult::Ok, res.error);
        g.be->destroy(source);
    }
}

// ------------------------------------------------------------------ E. temporal effects, frame history, ping-pong
static void TestTemporal() {
    std::printf("temporal feedback (history buffer / ping-pong), seek behaviour\n");
    Gpu g(GlContext::Api::ES);
    if (!g) { SKIP("no GLES context"); return; }
    const char* xml = R"(<effect id="fx.trail" graph="2" output="out" seek="reset">
  <buffer id="trail" format="rgba16f" history="1"/>
  <pass id="acc" lang="glsl-es" output="trail" file="t.xml" line="5">
    <input name="cur" ref="source"/>
    <input name="prev" ref="buffer:trail@1"/>
    <source><![CDATA[#version 300 es
precision highp float;
uniform sampler2D cur;
uniform sampler2D prev;
uniform vec2 size;
uniform float decay;
out vec4 o;
void main() { vec2 uv = gl_FragCoord.xy / size; o = max(texture(cur, uv), texture(prev, uv) * decay); }
]]></source>
    <const name="decay" value="0.5"/>
  </pass>
  <pass id="out" lang="glsl-es" output="out" file="t.xml" line="20">
    <input name="t" ref="buffer:trail"/>
    <source><![CDATA[#version 300 es
precision highp float;
uniform sampler2D t;
uniform vec2 size;
out vec4 o;
void main() { o = texture(t, gl_FragCoord.xy / size); }
]]></source>
  </pass>
</effect>)";
    GraphDesc gd = ParseXml(xml, false);
    PlanOptions po; po.backend = g.be->name(); po.languages = {Lang::GLSLES};
    auto plan = std::make_shared<Plan>(BuildPlan(gd, po));
    for (const Diag& d : plan->diags) std::printf("   plan: %s\n", d.format().c_str());
    CHECK(plan->ok()); CHECK(plan->temporal);
    Executor ex(*g.be, plan);
    const int W = 8, H = 8;
    // frame 0 has a bright pixel, later frames are black: the pixel must decay 1, 0.5, 0.25 ...
    std::vector<float> lit(W * H * 4, 0.0f), dark(W * H * 4, 0.0f);
    lit[0] = 1.0f; lit[3] = 1.0f;
    Target* sLit = g.be->createFromFloats(W, H, Format::RGBA16F, lit.data());
    Target* sDark = g.be->createFromFloats(W, H, Format::RGBA16F, dark.data());
    double expect = 1.0;
    for (int i = 0; i < 6; i++) {
        FrameRequest fr; fr.frame = i; fr.width = W; fr.height = H; fr.source = i == 0 ? sLit : sDark; fr.signature = 7;
        std::vector<float> px;
        FrameResult r = ex.render(fr, [&](Target* t) { g.be->readback(t, &px); });
        CHECK_MSG(r.status == FrameResult::Ok, r.error);
        CHECK_NEAR(px[0], expect, 1e-3);
        CHECK_NEAR(px[4], 0.0, 1e-6);   // a neighbouring pixel stays dark
        expect *= 0.5;
        if (i > 0) CHECK(!r.historyReset);
    }
    // a jump (frame 3 after frame 5) resets history: the trail restarts from the new frame's image
    {
        FrameRequest fr; fr.frame = 3; fr.width = W; fr.height = H; fr.source = sDark; fr.signature = 7;
        std::vector<float> px;
        FrameResult r = ex.render(fr, [&](Target* t) { g.be->readback(t, &px); });
        CHECK(r.status == FrameResult::Ok); CHECK(r.historyReset); CHECK_NEAR(px[0], 0.0, 1e-6);
    }
    // history costs two targets, not one per frame
    CHECK(ex.poolStats().created <= 4);
    // re-rendering the same frame (a property edit in the editor) does not advance history
    {
        FrameRequest fr; fr.frame = 4; fr.width = W; fr.height = H; fr.source = sLit; fr.signature = 7;
        std::vector<float> a, b;
        ex.render(fr, [&](Target* t) { g.be->readback(t, &a); });
        FrameResult r = ex.render(fr, [&](Target* t) { g.be->readback(t, &b); });
        CHECK(r.status == FrameResult::Ok); CHECK_NEAR(a[0], b[0], 1e-6);
    }
    g.be->destroy(sLit); g.be->destroy(sDark);
}

// ------------------------------------------------------------------ F. preview vs export, long runs, 4K, cancellation, resources
static std::vector<float> RenderGlowFrame(Gpu& g, int W, int H, int frame, Format srcFormat, Executor& ex, const std::vector<float>& srcPx) {
    Target* source = g.be->createFromFloats(W, H, srcFormat, srcPx.data());
    FrameRequest fr; fr.frame = frame; fr.width = W; fr.height = H; fr.source = source; fr.signature = 3; fr.timeSeconds = frame / 30.0;
    std::vector<float> got;
    FrameResult r = ex.render(fr, [&](Target* t) { g.be->readback(t, &got); });
    if (r.status != FrameResult::Ok) std::printf("   render failed: %s\n", r.error.c_str());
    g.be->destroy(source);
    return got;
}

static void TestPreviewExport() {
    std::printf("preview / export equivalence, long render, 4K, cancellation, memory\n");
    Gpu preview(GlContext::Api::ES);
    if (!preview) { SKIP("no GLES context"); return; }
    GraphDesc gd = ParseXml(kGraphXml, false);
    PlanOptions po; po.backend = preview.be->name(); po.languages = {Lang::GLSLES};
    auto plan = std::make_shared<Plan>(BuildPlan(gd, po));
    CHECK(plan->ok());

    // 1. preview and export are two separate contexts / backends / executors; same frame, same parameters -> same pixels
    Gpu exportGpu(GlContext::Api::ES);
    preview.ctx->makeCurrent();
    {
        const int W = 96, H = 54;
        const auto src = Pattern(W, H, 1.6f);
        Executor exPreview(*preview.be, plan);
        const auto a = RenderGlowFrame(preview, W, H, 0, Format::RGBA16F, exPreview, src);
        exportGpu.ctx->makeCurrent();
        Executor exExport(*exportGpu.be, plan);
        const auto b = RenderGlowFrame(exportGpu, W, H, 0, Format::RGBA16F, exExport, src);
        CHECK(a.size() == (size_t)W * H * 4 && !a.empty());
        const double d = MaxDiff(a, b);
        std::printf("   preview vs export, same size: max diff %.3g\n", d);
        CHECK_MSG(d == 0.0 || d < 1e-6, std::to_string(d));   // same driver, same code: bit-identical in practice
        preview.ctx->makeCurrent();
    }
    // 2. a preview at half resolution vs an export at full resolution of the SAME content (resolution independent coordinates)
    {
        const int W = 128, H = 72;
        std::vector<float> full((size_t)W * H * 4), half((size_t)(W / 2) * (H / 2) * 4);
        auto content = [](float u, float v, int c) { return c == 3 ? 1.0f : 0.5f + 0.5f * std::sin((c + 1) * 3.0f * u + 2.0f * v); };   // smooth, so scale does not matter
        for (int y = 0; y < H; y++) for (int x = 0; x < W; x++) for (int c = 0; c < 4; c++) full[((size_t)y * W + x) * 4 + c] = content((x + 0.5f) / W, (y + 0.5f) / H, c);
        for (int y = 0; y < H / 2; y++) for (int x = 0; x < W / 2; x++) for (int c = 0; c < 4; c++) half[((size_t)y * (W / 2) + x) * 4 + c] = content((x + 0.5f) / (W / 2), (y + 0.5f) / (H / 2), c);
        Executor e1(*preview.be, plan), e2(*preview.be, plan);
        const auto big = RenderGlowFrame(preview, W, H, 0, Format::RGBA16F, e1, full);
        const auto small = RenderGlowFrame(preview, W / 2, H / 2, 0, Format::RGBA16F, e2, half);
        // The graph's blur radius is a fixed number of BUFFER pixels (a design property of the effect, same as in the Skia backend), so
        // a half-resolution preview is blurrier in image terms than the full-resolution export. What must agree is the content: the
        // mean colour (energy) of both renders, and the unblurred base layer after downsampling stays within a loose band.
        double meanBig = 0, meanSmall = 0;
        for (size_t i = 0; i < big.size(); i += 4) meanBig += big[i] + big[i + 1] + big[i + 2];
        for (size_t i = 0; i < small.size(); i += 4) meanSmall += small[i] + small[i + 1] + small[i + 2];
        meanBig /= (double)(big.size() / 4); meanSmall /= (double)(small.size() / 4);
        std::printf("   preview(1/2 res) vs export(full res), same content: mean colour %.4f vs %.4f\n", meanSmall, meanBig);
        CHECK_NEAR(meanSmall, meanBig, 0.03 * meanBig);
        bool finite = true; for (float v : big) if (!std::isfinite(v)) finite = false; for (float v : small) if (!std::isfinite(v)) finite = false;
        CHECK(finite);
    }
    // 3. long-duration: 600 sequential frames with time advancing; resources constant, no GL error, no new targets after warm-up
    {
        const int W = 160, H = 90;
        const auto src = Pattern(W, H, 1.6f);
        Executor ex(*preview.be, plan);
        Target* source = preview.be->createFromFloats(W, H, Format::RGBA16F, src.data());
        FrameRequest fr; fr.width = W; fr.height = H; fr.source = source; fr.signature = 9; fr.frameSeconds = 1.0 / 30.0;
        int64_t created = -1, liveBytes = -1; int failures = 0;
        for (int i = 0; i < 600; i++) {
            fr.frame = i; fr.timeSeconds = i / 30.0;
            FrameResult r = ex.render(fr, [&](Target*) {});
            if (r.status != FrameResult::Ok) failures++;
            if (i == 2) { created = ex.poolStats().created; liveBytes = preview.be->stats().liveBytes; }
        }
        CHECK(failures == 0);
        CHECK(ex.poolStats().created == created);
        CHECK(preview.be->stats().liveBytes == liveBytes);
        CHECK(preview.be->contextLost() == false);
        std::printf("   600 frames: targets created %lld, GPU bytes held %lld (constant), passes run %lld\n", (long long)created, (long long)liveBytes, (long long)preview.be->stats().passesRun);
        preview.be->destroy(source);
    }
    // 4. 4K (3840x2160) in RGBA16F: allocate, render the multi-pass graph, read a sample back
    {
        const int W = 3840, H = 2160;
        if (!preview.be->supports(Format::RGBA16F) || preview.be->maxTextureSize() < W) { SKIP("4K RGBA16F targets are not available on this device"); }
        else {
            std::vector<float> src((size_t)W * H * 4, 0.25f);
            for (int y = 1000; y < 1100; y++) for (int x = 1800; x < 1900; x++) { float* p = &src[((size_t)y * W + x) * 4]; p[0] = p[1] = p[2] = 3.0f; }
            Executor ex(*preview.be, plan);
            Target* source = preview.be->createFromFloats(W, H, Format::RGBA16F, src.data());
            CHECK(source != nullptr);
            FrameRequest fr; fr.frame = 0; fr.width = W; fr.height = H; fr.source = source; fr.signature = 4;
            std::vector<float> got;
            FrameResult r = ex.render(fr, [&](Target* t) { preview.be->readback(t, &got); });
            CHECK_MSG(r.status == FrameResult::Ok, r.error);
            CHECK(got.size() == (size_t)W * H * 4);
            if (got.size() == (size_t)W * H * 4) {
                const float hot = got[((size_t)1050 * W + 1850) * 4];   // inside the bright square: original 3.0 + glow (at most 0.8 * 3.0); HDR kept
                CHECK(hot > 3.0f && hot <= 5.45f);
                CHECK_NEAR(got[((size_t)100 * W + 100) * 4], 0.25, 1e-3);   // far away: untouched
            }
            int64_t total = 0; for (const auto& t : r.timings) total += t.cpuNs;
            std::printf("   4K frame: 4 passes, %.1f ms wall (software GL), pool peak %.1f MB\n", total / 1e6, ex.poolStats().peakBytes / 1048576.0);
            preview.be->destroy(source);
        }
    }
    // 5. cancellation: the frame stops cleanly, nothing is leaked, the next frame renders
    {
        const int W = 64, H = 64;
        const auto src = Pattern(W, H, 1.0f);
        Executor ex(*preview.be, plan);
        Target* source = preview.be->createFromFloats(W, H, Format::RGBA16F, src.data());
        std::atomic<bool> cancel(true);
        FrameRequest fr; fr.frame = 0; fr.width = W; fr.height = H; fr.source = source; fr.signature = 5; fr.cancel = &cancel;
        FrameResult r = ex.render(fr, [&](Target*) {});
        CHECK(r.status == FrameResult::Cancelled);
        CHECK(ex.poolStats().live == 0);
        cancel = false;
        r = ex.render(fr, [&](Target*) {});
        CHECK(r.status == FrameResult::Ok);
        ex.dropAll();
        CHECK(ex.poolStats().bytes == 0);
        preview.be->destroy(source);
    }
    // 6. resource exhaustion is a clean failed frame, not a crash: budget smaller than one buffer
    {
        const int W = 256, H = 256;
        const auto src = Pattern(W, H, 1.0f);
        Executor ex(*preview.be, plan);
        ex.setBudget(1024);
        Target* source = preview.be->createFromFloats(W, H, Format::RGBA16F, src.data());
        FrameRequest fr; fr.frame = 0; fr.width = W; fr.height = H; fr.source = source; fr.signature = 6;
        FrameResult r = ex.render(fr, [&](Target*) {});
        CHECK(r.status == FrameResult::Failed);
        CHECK(!r.error.empty());
        CHECK(ex.poolStats().live == 0);
        ex.setBudget(0);
        r = ex.render(fr, [&](Target*) {});
        CHECK(r.status == FrameResult::Ok);
        preview.be->destroy(source);
    }
    // 7. GPU out of memory: asking for an absurd target fails cleanly (create returns null), later work is unaffected
    {
        Target* huge = preview.be->create(preview.be->maxTextureSize(), preview.be->maxTextureSize(), Format::RGBA32F);   // 4 GiB+
        if (huge) { SKIP("this device allocated a 16384x16384 RGBA32F target (lazy allocation); out-of-memory path not exercised"); preview.be->destroy(huge); }
        else CHECK(true);
        Target* t = preview.be->create(8, 8, Format::RGBA8);
        CHECK(t != nullptr);
        preview.be->destroy(t);
    }
}

// ------------------------------------------------------------------ G. format negotiation with a device that lacks a format
struct Restricted : GlBackend {
    bool no32 = true, no16 = false;
    using GlBackend::GlBackend;
    bool supports(Format f) const override {
        if (f == Format::RGBA32F && no32) return false;
        if (f == Format::RGBA16F && no16) return false;
        return GlBackend::supports(f);
    }
};

static void TestFormatNegotiation() {
    std::printf("unsupported formats: degrade and report, or fail when precision=required (real GPU, formats restricted by policy)\n");
    std::string err;
    auto ctx = GlContext::Create(GlContext::Api::ES, &err);
    if (!ctx) { SKIP("no GLES context"); return; }
    Restricted be(*ctx);
    if (!be.ok()) { SKIP("backend unusable"); return; }
    auto xmlFor = [](const char* format, const char* precision) {
        return std::string("<effect id=\"fx.fmt\" graph=\"2\" output=\"out\"><buffer id=\"mid\" format=\"") + format + "\" precision=\"" + precision + "\"/>"
               "<pass id=\"a\" lang=\"glsl-es\" output=\"mid\"><input name=\"src\" ref=\"source\"/><source><![CDATA[#version 300 es\nprecision highp float;\nuniform sampler2D src;\nuniform vec2 size;\nout vec4 o;\nvoid main(){ o = texture(src, gl_FragCoord.xy / size) * 2.0; }\n]]></source></pass>"
               "<pass id=\"out\" lang=\"glsl-es\" output=\"out\"><input name=\"m\" ref=\"buffer:mid\"/><source><![CDATA[#version 300 es\nprecision highp float;\nuniform sampler2D m;\nuniform vec2 size;\nout vec4 o;\nvoid main(){ o = texture(m, gl_FragCoord.xy / size); }\n]]></source></pass></effect>";
    };
    std::vector<float> one(8 * 8 * 4, 0.75f);
    Target* source = be.createFromFloats(8, 8, Format::RGBA16F, one.data());
    PlanOptions po; po.backend = be.name(); po.languages = {Lang::GLSLES};
    {   // preferred 32F, device lacks it: degrades to the best it has and SAYS so
        GraphDesc gd = ParseXml(xmlFor("rgba32f", "preferred"), false);
        auto plan = std::make_shared<Plan>(BuildPlan(gd, po));
        Executor ex(be, plan);
        FrameRequest fr; fr.frame = 0; fr.width = 8; fr.height = 8; fr.source = source; fr.signature = 1;
        std::vector<float> px;
        FrameResult r = ex.render(fr, [&](Target* t) { be.readback(t, &px); });
        CHECK_MSG(r.status == FrameResult::Ok, r.error);
        bool told = false; for (const Diag& n : r.notes) { std::printf("   note: %s\n", n.format().c_str()); std::string m = n.message; for (char& ch : m) ch = (char)std::tolower((unsigned char)ch); if (m.find("rgba32f") != std::string::npos) told = true; }
        CHECK(told);                                                 // never a silent downgrade
        CHECK(!px.empty() && std::fabs(px[0] - 1.5f) < 2e-3f);       // and the HDR value 1.5 survived in the format it chose (16F)
    }
    {   // required 32F: the frame fails with the reason, nothing is rendered in a smaller format
        GraphDesc gd = ParseXml(xmlFor("rgba32f", "required"), false);
        auto plan = std::make_shared<Plan>(BuildPlan(gd, po));
        Executor ex(be, plan);
        FrameRequest fr; fr.frame = 0; fr.width = 8; fr.height = 8; fr.source = source; fr.signature = 1;
        int consumed = 0;
        FrameResult r = ex.render(fr, [&](Target*) { consumed++; });
        CHECK(r.status == FrameResult::Failed); CHECK(consumed == 0);
        CHECK_MSG(r.error.find("rgba32f") != std::string::npos && r.error.find("precision=required") != std::string::npos, r.error);
    }
    be.destroy(source);
}

// ------------------------------------------------------------------ H. shader cache
static std::string TempDir() {
    char tmpl[] = "/tmp/em-glcache-XXXXXX";
    char* d = mkdtemp(tmpl);
    return d ? d : "/tmp";
}
static int CountFiles(const std::string& dir) {
    int n = 0;
    if (DIR* d = opendir(dir.c_str())) { while (dirent* e = readdir(d)) if (e->d_name[0] != '.') n++; closedir(d); }
    return n;
}

static void TestShaderCache() {
    std::printf("compiled shader reuse: in-memory and on disk (program binaries)\n");
    const std::string dir = TempDir();
    {
        std::string err;
        auto ctx = GlContext::Create(GlContext::Api::ES, &err);
        if (!ctx) { SKIP("no GLES context"); return; }
        GlOptions o; o.cacheDirectory = dir;
        GlBackend be(*ctx, o);
        Gpu* none = nullptr; (void)none;
        PassDesc p; p.id = "c"; p.lang = Lang::GLSLES; p.file = "c.json"; p.line = 1;
        p.source = "#version 300 es\nprecision highp float;\nuniform vec4 c;\nout vec4 o;\nvoid main(){ o = c; }\n";
        p.constants.push_back({"c", {0.1f, 0.2f, 0.3f, 1.0f}});
        Target* t = be.create(2, 2, Format::RGBA8);
        PassRun r; r.pass = &p; r.output = t; r.areaWidth = 2; r.areaHeight = 2;
        for (int i = 0; i < 5; i++) { std::string e; CHECK(be.run(r, &e)); }
        CHECK(be.stats().shaderCompiles == 1);            // compiled once
        CHECK(be.stats().programMemoryHits == 4);         // reused four times
        if (!be.caps().programBinary) { SKIP("this driver offers no program binaries: disk cache not exercised"); be.destroy(t); return; }
        CHECK(be.stats().programDiskStores == 1);
        CHECK(CountFiles(dir) == 1);
        be.dropPrograms();                                // low-memory: programs freed ...
        std::string e; CHECK(be.run(r, &e));              // ... and brought back from the disk cache, not recompiled
        CHECK(be.stats().programDiskHits == 1);
        CHECK(be.stats().shaderCompiles == 1);
        // a different define is a different program
        p.defines["X"] = "1";
        CHECK(be.run(r, &e));
        CHECK(be.stats().shaderCompiles == 2);
        be.destroy(t);
    }
    {   // a second process start: new context, new backend, same directory
        std::string err;
        auto ctx = GlContext::Create(GlContext::Api::ES, &err);
        GlOptions o; o.cacheDirectory = dir;
        GlBackend be(*ctx, o);
        PassDesc p; p.id = "c"; p.lang = Lang::GLSLES; p.file = "c.json"; p.line = 1;
        p.source = "#version 300 es\nprecision highp float;\nuniform vec4 c;\nout vec4 o;\nvoid main(){ o = c; }\n";
        p.constants.push_back({"c", {0.1f, 0.2f, 0.3f, 1.0f}});
        Target* t = be.create(2, 2, Format::RGBA8);
        PassRun r; r.pass = &p; r.output = t; r.areaWidth = 2; r.areaHeight = 2;
        std::string e; CHECK(be.run(r, &e));
        CHECK(be.stats().programDiskHits == 1);
        CHECK(be.stats().shaderCompiles == 0);
        std::vector<float> px; be.readback(t, &px);
        CHECK_NEAR(px[0], 0.1, 1.0 / 255); CHECK_NEAR(px[2], 0.3, 1.0 / 255);   // the cached program renders correctly
        be.destroy(t);
    }
    {   // damage every cache file: the backend recompiles and rewrites, never uses or crashes on bad data
        if (DIR* d = opendir(dir.c_str())) {
            while (dirent* e = readdir(d)) {
                if (e->d_name[0] == '.') continue;
                const std::string path = dir + "/" + e->d_name;
                if (FILE* f = std::fopen(path.c_str(), "r+b")) { std::fseek(f, 40, SEEK_SET); const char junk[8] = {1, 2, 3, 4, 5, 6, 7, 8}; std::fwrite(junk, 1, 8, f); std::fclose(f); }
            }
            closedir(d);
        }
        std::string err;
        auto ctx = GlContext::Create(GlContext::Api::ES, &err);
        GlOptions o; o.cacheDirectory = dir;
        GlBackend be(*ctx, o);
        PassDesc p; p.id = "c"; p.lang = Lang::GLSLES; p.file = "c.json"; p.line = 1;
        p.source = "#version 300 es\nprecision highp float;\nuniform vec4 c;\nout vec4 o;\nvoid main(){ o = c; }\n";
        p.constants.push_back({"c", {0.1f, 0.2f, 0.3f, 1.0f}});
        Target* t = be.create(2, 2, Format::RGBA8);
        PassRun r; r.pass = &p; r.output = t; r.areaWidth = 2; r.areaHeight = 2;
        std::string e; CHECK_MSG(be.run(r, &e), e);
        CHECK(be.stats().programDiskHits == 0);
        CHECK(be.stats().shaderCompiles == 1);
        be.destroy(t);
    }
    std::string cmd = "rm -rf " + dir; if (std::system(cmd.c_str()) != 0) {}
}

// ------------------------------------------------------------------ I. robustness: threads, context recreation, profiling, leaks
static void TestRobustness() {
    std::printf("thread guard, context recreation, GPU object leaks, profiling\n");
    // thread guard: a call from another thread fails with a message instead of corrupting GL state
    {
        Gpu g(GlContext::Api::ES);
        if (!g) { SKIP("no GLES context"); return; }
        PassDesc p = MakePass(g, "t", "out vec4 o;\nvoid main(){ o = vec4(1.0); }\n");
        Target* t = g.be->create(2, 2, Format::RGBA8);
        std::string err; bool ok = true;
        std::thread th([&] { ok = RunPass(g, p, t, {}, 2, 2, &err); CHECK(g.be->create(2, 2, Format::RGBA8) == nullptr); });
        th.join();
        CHECK(!ok); CHECK(err.find("thread") != std::string::npos);
        CHECK_MSG(RunPass(g, p, t, {}, 2, 2, &err), err);
        g.be->destroy(t);
    }
    // context recreation (what happens after a GPU reset): destroy everything, build a new context and backend, render again
    {
        Executor* keep = nullptr; (void)keep;
        auto plan = std::make_shared<Plan>();
        GraphDesc gd = ParseXml(kGraphXml, false);
        for (int round = 0; round < 3; round++) {
            Gpu g(GlContext::Api::ES);
            if (!g) { SKIP("no GLES context"); return; }
            PlanOptions po; po.backend = g.be->name(); po.languages = {Lang::GLSLES};
            auto pl = std::make_shared<Plan>(BuildPlan(gd, po));
            Executor ex(*g.be, pl);
            const auto src = Pattern(32, 32, 1.0f);
            Target* s = g.be->createFromFloats(32, 32, Format::RGBA16F, src.data());
            FrameRequest fr; fr.frame = 0; fr.width = 32; fr.height = 32; fr.source = s; fr.signature = 1;
            FrameResult r = ex.render(fr, [&](Target*) {});
            CHECK_MSG(r.status == FrameResult::Ok, r.error);
            ex.dropAll();
            g.be->destroy(s);
            // everything the backend created is gone except its own cached builtin textures / blanks
            CHECK(g.be->stats().liveTargets <= 2);
        }
    }
    // leak check on the GL object level: create / destroy many targets, the driver-side count returns to zero
    {
        Gpu g(GlContext::Api::ES);
        if (!g) return;
        const int64_t base = g.be->stats().liveBytes;
        for (int i = 0; i < 300; i++) { Target* t = g.be->create(64 + (i % 7), 48, i % 2 ? Format::RGBA16F : Format::RGBA8); CHECK(t); g.be->destroy(t); }
        CHECK(g.be->stats().liveBytes == base);
        CHECK(g.be->stats().targetsCreated == g.be->stats().targetsDestroyed);
        // destroying a pointer the backend does not own is ignored, never a double free
        Target* t = g.be->create(4, 4, Format::RGBA8);
        g.be->destroy(t); g.be->destroy(t);
        CHECK(g.be->stats().targetsDestroyed == g.be->stats().targetsCreated);
    }
    // profiler: per-pass GPU time, pass count, memory
    {
        GlOptions o; o.profile = true;
        Gpu g(GlContext::Api::ES, o);
        if (!g) return;
        GraphDesc gd = ParseXml(kGraphXml, false);
        PlanOptions po; po.backend = g.be->name(); po.languages = {Lang::GLSLES};
        auto plan = std::make_shared<Plan>(BuildPlan(gd, po));
        Executor ex(*g.be, plan);
        const auto src = Pattern(128, 72, 1.0f);
        Target* s = g.be->createFromFloats(128, 72, Format::RGBA16F, src.data());
        FrameRequest fr; fr.frame = 0; fr.width = 128; fr.height = 72; fr.source = s; fr.signature = 1;
        FrameResult r = ex.render(fr, [&](Target*) {});
        CHECK(r.status == FrameResult::Ok); CHECK(r.timings.size() == 4);
        std::printf("   profile (timer query %s):", g.be->caps().timerQuery ? "available" : "unavailable, glFinish-bracketed wall time");
        for (const PassTiming& t : r.timings) { std::printf(" %s cpu %.2fms gpu %.2fms;", t.pass.c_str(), t.cpuNs / 1e6, t.gpuNs / 1e6); CHECK(t.gpuNs > 0); }
        std::printf("\n   stats: passes %lld, draw calls %lld, shader compiles %lld, peak GPU bytes %lld\n", (long long)g.be->stats().passesRun, (long long)g.be->stats().drawCalls, (long long)g.be->stats().shaderCompiles, (long long)g.be->stats().peakBytes);
        CHECK(g.be->stats().passesRun == 4); CHECK(g.be->stats().shaderCompiles == 4); CHECK(g.be->stats().gpuNanosTotal > 0);
        g.be->destroy(s);
    }
}

int main() {
    TestDevice();
    TestShaderLanguages();
    TestUniformsAndSampling();
    TestFormats();
    TestExecutorGraph();
    TestTemporal();
    TestPreviewExport();
    TestFormatNegotiation();
    TestShaderCache();
    TestRobustness();
    std::printf("\n%d checks, %d failed, %d skipped\n", gChecks, gFailed, gSkipped);
    return gFailed ? 1 : 0;
}

// gpu_selftest.cpp - on-device checks for the native GL backend (+ a Vulkan capability probe).
// Everything marked PASS/FAIL below was produced by the phone's own GPU driver in this run. Nothing is simulated.
#include "gpu_selftest.h"
#include "bridge_selftest.h"

#include "gl_backend.h"
#include "gl_ahb_probe.h"
#include "glsl_compile.h"
#include "vulkan_exec.h"
#include "spirv_util.h"

#include <cmath>
#include <cstdio>
#include <cstring>
#include <cstdlib>
#include <sys/stat.h>
#ifdef __ANDROID__
#include <android/hardware_buffer.h>
#include <cstdint>
#endif

#if __has_include(<vulkan/vulkan.h>)
#include <vulkan/vulkan.h>
#define AM_HAVE_VULKAN 1
#endif

namespace am {
using namespace rg;

namespace {
struct Report {
    std::string text; int pass = 0, fail = 0, skip = 0;
    void line(const std::string& s) { text += s + "\n"; }
    void ok(const std::string& s) { pass++; line("PASS  " + s); }
    void bad(const std::string& s) { fail++; line("FAIL  " + s); }
    void skp(const std::string& s) { skip++; line("SKIP  " + s); }
    void check(bool c, const std::string& s) { if (c) ok(s); else bad(s); }
};

std::string HexText(uint32_t v) { char b[16]; std::snprintf(b, sizeof b, "0x%08x", (unsigned)v); return b; }
std::string Num(double v) { char b[64]; std::snprintf(b, sizeof b, "%.5g", v); return b; }

const char* kHeader = "#version 300 es\nprecision highp float;\n";
// Pass A: horizontal ramp (red), constant green, constant blue (> 1 = HDR, only checked on float formats).
const char* kPassA =
    "uniform vec2 size;\nuniform float hdr;\nout vec4 o;\n"
    "void main() { o = vec4((gl_FragCoord.x) / size.x, 0.25, hdr, 1.0); }\n";
// Pass B: reads A, scales channels. Proves a second pass can sample the first pass's GPU texture.
const char* kPassB =
    "uniform sampler2D src;\nuniform vec2 size;\nout vec4 o;\n"
    "void main() { vec4 s = texture(src, gl_FragCoord.xy / size); o = s * vec4(0.5, 2.0, 1.0, 1.0); }\n";

PassDesc Make(const char* id, const char* body) {
    PassDesc p; p.id = id; p.name = id; p.lang = Lang::GLSLES; p.file = "selftest"; p.line = 1;
    p.source = std::string(kHeader) + body; return p;
}

bool Run(GlBackend& be, const PassDesc& p, Target* out, Target* in, int w, int h, std::string* err, const char* inName = "src") {
    static std::string name; name = inName;
    PassRun r; r.pass = &p; r.output = out; r.areaWidth = w; r.areaHeight = h; r.clear = true;
    if (in) { BoundInput b; b.name = &name; b.target = in; b.filter = Filter::Nearest; b.wrap = Wrap::Clamp; r.inputs.push_back(b); }
    return be.run(r, err);
}

void RenderTest(Report& R, GlBackend& be, Format f) {
    const std::string tag = std::string("two-pass render ") + FormatText(f);
    if (!be.supports(f)) { R.skp(tag + ": format not renderable on this GPU"); return; }
    const int W = 64, H = 8;
    const bool hdr = f != Format::RGBA8;
    Target* a = be.create(W, H, f); Target* b = be.create(W, H, f);
    if (!a || !b) { R.bad(tag + ": could not allocate targets"); if (a) be.destroy(a); if (b) be.destroy(b); return; }
    PassDesc pa = Make("A", kPassA), pb = Make("B", kPassB);
    pa.constants.push_back({"hdr", {hdr ? 2.5f : 0.75f}});
    std::string err;
    if (!Run(be, pa, a, nullptr, W, H, &err)) { R.bad(tag + ": pass A failed: " + err); be.destroy(a); be.destroy(b); return; }
    if (!Run(be, pb, b, a, W, H, &err)) { R.bad(tag + ": pass B failed: " + err); be.destroy(a); be.destroy(b); return; }
    std::vector<float> px;
    if (!be.readback(b, &px)) { R.bad(tag + ": readback failed"); be.destroy(a); be.destroy(b); return; }
    double worst = 0;
    for (int y = 0; y < H; y++) for (int x = 0; x < W; x++) {
        const float* p = &px[((size_t)y * W + x) * 4];
        const double er = 0.5 * ((x + 0.5) / W), eg = 2.0 * 0.25, eb = hdr ? 2.5 : 0.75;
        worst = std::fmax(worst, std::fabs(p[0] - er)); worst = std::fmax(worst, std::fabs(p[1] - eg));
        worst = std::fmax(worst, std::fabs(p[2] - eb) / (hdr ? 2.5 : 1.0));
    }
    const double tol = f == Format::RGBA8 ? 3.0 / 255 : f == Format::RGBA16F ? 2e-3 : 1e-4;
    R.check(worst <= tol, tag + ": GPU output vs CPU expectation, max error " + Num(worst) + " (limit " + Num(tol) + ")");
    be.destroy(a); be.destroy(b);
}

#ifdef __ANDROID__
float HalfToFloat2(uint16_t h) {
    const uint32_t sign = (h >> 15) & 1, e = (h >> 10) & 31, m = h & 1023;
    float v = e == 0 ? std::ldexp((float)m, -24) : std::ldexp((float)(m | 1024), (int)e - 25);
    return sign ? -v : v;
}
uint16_t FloatToHalf(float f) {   // normal-range values only (the test never uses anything else)
    uint32_t b; std::memcpy(&b, &f, 4);
    const uint32_t sign = (b >> 16) & 0x8000;
    const int e = (int)((b >> 23) & 0xFF) - 127 + 15;
    const uint32_t m = b & 0x7FFFFF;
    if (e <= 0 || e >= 31) return (uint16_t)sign;
    return (uint16_t)(sign | ((uint32_t)e << 10) | ((m + 0x1000) >> 13));
}

// Native pass -> shared buffer -> CPU, and CPU -> shared buffer -> native pass: the two hand-offs a Skia bridge is built from.
void SharedTargetTest(Report& R, GlBackend& be, Format f) {
    const std::string tag = std::string("shared-buffer targets ") + FormatText(f);
    if (!be.supports(f)) { R.skp(tag + ": format not renderable"); return; }
    const int W = 64, H = 8;
    const bool half = f == Format::RGBA16F;
    const float hdr = half ? 2.5f : 0.75f;
    // 1) a real shader pass draws INTO a buffer that Skia/Vulkan could read
    AHardwareBuffer* ahb = nullptr;
    Target* out = be.createShared(W, H, f, &ahb, true);
    if (!out || !ahb) { R.bad(tag + ": createShared failed"); return; }
    PassDesc pa = Make("A", kPassA);
    pa.constants.push_back({"hdr", {hdr}});
    std::string err;
    bool good = Run(be, pa, out, nullptr, W, H, &err);
    if (!good) R.bad(tag + ": pass into shared buffer failed: " + err);
    else {
        be.finishShared();
        AHardwareBuffer_Desc d = {}; AHardwareBuffer_describe(ahb, &d);
        void* p = nullptr;
        if (AHardwareBuffer_lock(ahb, AHARDWAREBUFFER_USAGE_CPU_READ_OFTEN, -1, nullptr, &p) != 0 || !p) R.bad(tag + ": cannot lock buffer for reading");
        else {
            double worst = 0;
            for (int y = 0; y < H; y++) for (int x = 0; x < W; x++) {
                float c[3];
                if (half) { const uint16_t* q = (const uint16_t*)p + ((size_t)y * d.stride + x) * 4; for (int i = 0; i < 3; i++) c[i] = HalfToFloat2(q[i]); }
                else { const uint8_t* q = (const uint8_t*)p + ((size_t)y * d.stride + x) * 4; for (int i = 0; i < 3; i++) c[i] = q[i] / 255.0f; }
                worst = std::fmax(worst, std::fabs(c[0] - (x + 0.5) / W)); worst = std::fmax(worst, std::fabs(c[1] - 0.25)); worst = std::fmax(worst, std::fabs(c[2] - hdr) / (half ? 2.5 : 1.0));
            }
            AHardwareBuffer_unlock(ahb, nullptr);
            const double tol = half ? 2e-3 : 3.0 / 255;
            R.check(worst <= tol, tag + ": pass wrote the shared buffer, CPU verified, max error " + Num(worst));
        }
    }
    be.destroy(out);

    // 2) a pass SAMPLES a buffer written by someone else (the CPU stands in for Skia here)
    AHardwareBuffer* src = nullptr;
    Target* srcTarget = be.createShared(W, H, f, &src, true);
    Target* dst = be.create(W, H, f);
    if (!srcTarget || !src || !dst) { R.bad(tag + ": could not create the sampled buffer"); if (srcTarget) be.destroy(srcTarget); if (dst) be.destroy(dst); return; }
    AHardwareBuffer_Desc d = {}; AHardwareBuffer_describe(src, &d);
    void* p = nullptr;
    if (AHardwareBuffer_lock(src, AHARDWAREBUFFER_USAGE_CPU_WRITE_OFTEN, -1, nullptr, &p) != 0 || !p) { R.bad(tag + ": cannot lock buffer for writing"); be.destroy(srcTarget); be.destroy(dst); return; }
    for (int y = 0; y < H; y++) for (int x = 0; x < W; x++) {
        const float v[4] = {(x + 0.5f) / W, 0.25f, hdr, 1.0f};
        if (half) { uint16_t* q = (uint16_t*)p + ((size_t)y * d.stride + x) * 4; for (int i = 0; i < 4; i++) q[i] = FloatToHalf(v[i]); }
        else { uint8_t* q = (uint8_t*)p + ((size_t)y * d.stride + x) * 4; for (int i = 0; i < 4; i++) q[i] = (uint8_t)std::lround(v[i] * 255.0f); }
    }
    AHardwareBuffer_unlock(src, nullptr);
    Target* view = be.wrapShared(src);   // a second GL view of the same buffer, as an importer of Skia's buffer would make
    PassDesc pb = Make("B", kPassB);
    if (!view) R.bad(tag + ": wrapShared failed");
    else if (!Run(be, pb, dst, view, W, H, &err)) R.bad(tag + ": pass sampling the shared buffer failed: " + err);
    else {
        std::vector<float> px;
        if (!be.readback(dst, &px)) R.bad(tag + ": readback failed");
        else {
            double worst = 0;
            for (int y = 0; y < H; y++) for (int x = 0; x < W; x++) {
                const float* q = &px[((size_t)y * W + x) * 4];
                worst = std::fmax(worst, std::fabs(q[0] - 0.5 * (x + 0.5) / W)); worst = std::fmax(worst, std::fabs(q[1] - 0.5)); worst = std::fmax(worst, std::fabs(q[2] - hdr) / (half ? 2.5 : 1.0));
            }
            const double tol = half ? 4e-3 : 4.0 / 255;
            R.check(worst <= tol, tag + ": pass sampled a buffer written elsewhere, max error " + Num(worst));
        }
    }
    if (view) be.destroy(view);
    be.destroy(srcTarget); be.destroy(dst);
}
#endif

void GlTests(Report& R, const std::string& cacheDir) {
    R.line("== OpenGL ES (native GLSL ES, driver-compiled) ==");
    std::string err;
    std::unique_ptr<GlContext> ctx = GlContext::Create(GlContext::Api::ES, &err);
    if (!ctx) { R.bad("could not create an OpenGL ES context: " + err); return; }
    GlOptions opt; opt.cacheDirectory = cacheDir; opt.profile = true;
    std::string cacheSub = cacheDir;
    if (!cacheSub.empty()) { mkdir(cacheSub.c_str(), 0700); }
    {
        GlBackend be(*ctx, opt);
        if (!be.ok()) { R.bad("GL backend unusable: " + be.error()); return; }
        const GlDeviceCaps& c = be.caps();
        R.line(c.describe());
        R.ok("GLSL ES context " + std::to_string(c.major) + "." + std::to_string(c.minor) + " on " + c.renderer);

        PassDesc bad = Make("broken", "out vec4 o;\nvoid main() { o = vec4(1.0) + undefined_symbol; }\n");
        std::string log; const int prog = be.compileProgramForTest(bad, &log);
        R.check(prog == 0 && !log.empty(), "driver rejects a broken shader and reports a message");
        if (!log.empty()) R.line("      driver message: " + log.substr(0, 160));

        RenderTest(R, be, Format::RGBA8);
        RenderTest(R, be, Format::RGBA16F);
        RenderTest(R, be, Format::RGBA32F);

        const GlStats& s = be.stats();
        R.line("stats: passes " + std::to_string(s.passesRun) + ", compiles " + std::to_string(s.shaderCompiles) +
               ", disk stores " + std::to_string(s.programDiskStores) + ", peak GPU bytes " + std::to_string(s.peakBytes));
        R.check(s.liveTargets == 0, "no GPU targets leaked after the tests");
        be.dropPrograms();
        R.check(be.programCount() == 0, "programs freed on memory pressure (dropPrograms)");
        R.check(!be.contextLost(), "context not reported lost");
#ifdef __ANDROID__
        R.line("");
        R.line("== Texture sharing building blocks (AHardwareBuffer / EGLImage) ==");
        { int p = 0, f = 0; R.text += RunAhbInteropProbe(&p, &f); R.pass += p; R.fail += f; }
        R.line("");
        R.line("== Native backend shared-buffer targets (the hand-off for the Skia bridge) ==");
        SharedTargetTest(R, be, Format::RGBA8);
        SharedTargetTest(R, be, Format::RGBA16F);
        R.line("      RGBA32F: not shareable (no AHardwareBuffer format); stays inside the native backend.");
        R.check(be.stats().liveTargets == 0, "no shared targets leaked");
#endif
    }
    if (!cacheDir.empty()) {
        GlBackend be2(*ctx, opt);
        if (be2.ok()) {
            if (!be2.caps().programBinary) R.skp("shader disk cache: driver has no program binary support");
            else {
                PassDesc pa = Make("A", kPassA); pa.constants.push_back({"hdr", {0.75f}});
                Target* t = be2.create(16, 4, Format::RGBA8); std::string e2;
                const bool ran = t && Run(be2, pa, t, nullptr, 16, 4, &e2);
                R.check(ran && be2.stats().programDiskHits >= 1 && be2.stats().shaderCompiles == 0,
                        "second run loads the compiled shader from the disk cache (hits " + std::to_string(be2.stats().programDiskHits) + ")");
                if (t) be2.destroy(t);
            }
        }
    }
}

void VulkanProbe(Report& R) {
    R.line("");
    R.line("== Vulkan (capability probe only) ==");
#ifdef AM_HAVE_VULKAN
    VkApplicationInfo ai = {VK_STRUCTURE_TYPE_APPLICATION_INFO};
    ai.apiVersion = VK_API_VERSION_1_1;
    VkInstanceCreateInfo ici = {VK_STRUCTURE_TYPE_INSTANCE_CREATE_INFO};
    ici.pApplicationInfo = &ai;
    VkInstance inst = VK_NULL_HANDLE;
    if (vkCreateInstance(&ici, nullptr, &inst) != VK_SUCCESS) { R.bad("vkCreateInstance failed: Vulkan 1.1 unavailable"); return; }
    uint32_t n = 0; vkEnumeratePhysicalDevices(inst, &n, nullptr);
    if (n == 0) { R.bad("no Vulkan physical device"); vkDestroyInstance(inst, nullptr); return; }
    std::vector<VkPhysicalDevice> devs(n); vkEnumeratePhysicalDevices(inst, &n, devs.data());
    for (VkPhysicalDevice d : devs) {
        VkPhysicalDeviceProperties pr; vkGetPhysicalDeviceProperties(d, &pr);
        R.ok(std::string("Vulkan device: ") + pr.deviceName + ", API " + std::to_string(VK_VERSION_MAJOR(pr.apiVersion)) + "." +
             std::to_string(VK_VERSION_MINOR(pr.apiVersion)) + "." + std::to_string(VK_VERSION_PATCH(pr.apiVersion)) +
             ", max image " + std::to_string(pr.limits.maxImageDimension2D));
        const struct { VkFormat f; const char* n; } fm[] = {{VK_FORMAT_R8G8B8A8_UNORM, "RGBA8"}, {VK_FORMAT_R16G16B16A16_SFLOAT, "RGBA16F"}, {VK_FORMAT_R32G32B32A32_SFLOAT, "RGBA32F"}};
        for (auto& x : fm) {
            VkFormatProperties p; vkGetPhysicalDeviceFormatProperties(d, x.f, &p);
            const VkFormatFeatureFlags t = p.optimalTilingFeatures;
            const bool att = t & VK_FORMAT_FEATURE_COLOR_ATTACHMENT_BIT, bl = t & VK_FORMAT_FEATURE_COLOR_ATTACHMENT_BLEND_BIT;
            const bool smp = t & VK_FORMAT_FEATURE_SAMPLED_IMAGE_BIT, lin = t & VK_FORMAT_FEATURE_SAMPLED_IMAGE_FILTER_LINEAR_BIT;
            R.line(std::string("      ") + x.n + ": render " + (att ? "yes" : "NO") + ", blend " + (bl ? "yes" : "NO") + ", sample " + (smp ? "yes" : "NO") +
                   ", linear filter " + (lin ? "yes" : "NO"));
        }
    }
    for (VkPhysicalDevice d : devs) {
        uint32_t ne = 0; vkEnumerateDeviceExtensionProperties(d, nullptr, &ne, nullptr);
        std::vector<VkExtensionProperties> ex(ne); vkEnumerateDeviceExtensionProperties(d, nullptr, &ne, ex.data());
        const char* want[] = {"VK_ANDROID_external_memory_android_hardware_buffer", "VK_KHR_external_semaphore_fd", "VK_KHR_external_fence_fd", "VK_KHR_sampler_ycbcr_conversion"};
        for (const char* w : want) {
            bool has = false; for (auto& e : ex) if (std::string(e.extensionName) == w) has = true;
            R.line(std::string("      extension ") + w + ": " + (has ? "present" : "ABSENT"));
        }
    }
    vkDestroyInstance(inst, nullptr);
#else
    R.skp("this build has no Vulkan headers");
#endif
    R.line("NOT IMPLEMENTED in this build: Vulkan effect backend (step 5b-2); SPIR-V execution itself is tested below.");
}

// Step 5a: glslang compiles Vulkan GLSL and desktop GLSL to SPIR-V. Compile only, nothing runs on the GPU here.
void GlslangStage(Report& R) {
    R.line("");
    R.line("== glslang -> SPIR-V (compile only) ==");
    if (!GlslangAvailable()) { R.bad("this build has no glslang"); return; }
    R.line("      glslang: " + GlslangVersionText());
    const char* vulkanFrag =
        "#version 450\n"
        "layout(std140, set = 0, binding = 0) uniform Params { vec4 tint; vec2 size; float gain; } u;\n"
        "layout(set = 0, binding = 1) uniform sampler2D src;\n"
        "layout(location = 0) out vec4 o;\n"
        "void main() { vec4 s = texture(src, gl_FragCoord.xy / u.size); o = vec4(s.rgb * u.gain, s.a) * u.tint; }\n";
    const char* vulkanVert =
        "#version 450\n"
        "void main() { vec2 p = vec2(float((gl_VertexIndex << 1) & 2), float(gl_VertexIndex & 2)); gl_Position = vec4(p * 2.0 - 1.0, 0.0, 1.0); }\n";
    const char* desktopFrag =
        "#version 330\n"
        "uniform float gain;\nuniform vec2 size;\nuniform sampler2D src;\nout vec4 o;\n"
        "void main() { o = texture(src, gl_FragCoord.xy / size) * gain; }\n";
    auto words = [](const GlslCompileResult& c) { std::vector<uint8_t> b(c.words.size() * 4); if (!b.empty()) std::memcpy(b.data(), c.words.data(), b.size()); return b; };

    GlslCompileResult f = CompileGlslToSpirv(vulkanFrag, GlslDialect::Vulkan, GlslStage::Fragment);
    R.check(f.ok, "vulkan-glsl fragment (UBO + sampler) compiles" + (f.ok ? " (" + std::to_string(f.words.size() * 4) + " bytes)" : ": " + f.log));
    if (f.ok) {
        SpirvInfo info; std::string err;
        const bool parsed = ParseSpirv(words(f), &info, &err);
        bool shaderCap = false, fragment = false;
        for (uint32_t c : info.capabilities) if (c == 1) shaderCap = true;   // capability 1 = Shader
        for (auto& e : info.entryPoints) if (e.model == 4) fragment = true;
        R.check(parsed && shaderCap && fragment, "that SPIR-V reads back: version " + HexText(info.version) + ", Shader capability, fragment entry point" + (parsed ? "" : ": " + err));
    }
    GlslCompileResult v = CompileGlslToSpirv(vulkanVert, GlslDialect::Vulkan, GlslStage::Vertex);
    R.check(v.ok, "vulkan-glsl full-screen-triangle vertex shader compiles" + (v.ok ? "" : ": " + v.log));
    GlslCompileResult d = CompileGlslToSpirv(desktopFrag, GlslDialect::OpenGL, GlslStage::Fragment);
    R.check(d.ok, "desktop glsl 330 with loose uniforms parses under OpenGL rules" + (d.ok ? "" : ": " + d.log));
    GlslCompileResult n = CompileGlslToSpirv(desktopFrag, GlslDialect::Vulkan, GlslStage::Fragment);
    R.line(std::string("      INFO  the same desktop source under Vulkan rules: ") + (n.ok ? "accepted" : "refused (loose uniforms need a uniform block, step 5c)"));
    GlslCompileResult bad = CompileGlslToSpirv("#version 450\nlayout(location = 0) out vec4 o;\nvoid main() { o = vec4(1.0) }\n", GlslDialect::Vulkan, GlslStage::Fragment);
    R.check(!bad.ok && !bad.log.empty(), "a shader with a syntax error fails with a message");
}
}  // namespace

std::string RunGpuSelfTest(const std::string& cacheDirectory) {
    Report R;
    R.line("Effects native GPU self-test");
    GlTests(R, cacheDirectory);
    VulkanProbe(R);
    GlslangStage(R);
    R.line("");
    R.line("== Vulkan: glslang SPIR-V executed on the GPU (step 5b-1, standalone) ==");
    RunVulkanExecTest(&R.text, &R.pass, &R.fail, cacheDirectory);
    R.line("");
    RunBridgeSelfTest(&R.text, &R.pass, &R.fail, cacheDirectory);
    R.line("");
    R.line("RESULT: " + std::to_string(R.pass) + " passed, " + std::to_string(R.fail) + " failed, " + std::to_string(R.skip) + " skipped");
    return R.text;
}
}  // namespace am

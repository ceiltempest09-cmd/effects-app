// shader_info.h — what a native shader source asks of the device, read from the text itself (no compiler needed).
//
// A native backend calls CheckGlslHeader() from Backend::accepts() so that "#version 320 es" on a GLES 3.0 device, or
// "#extension GL_EXT_foo : require" without GL_EXT_foo, becomes a Capability diagnostic with the line of the directive,
// instead of an opaque driver compile error (or worse, a different shader being run). Pure C++, host-tested.
#pragma once

#include "render_graph.h"

#include <set>
#include <string>
#include <vector>

namespace am::rg {

struct ShaderHeader {
    enum Profile { None, Core, Compatibility, ES };
    struct Extension { std::string name, behavior; int line = 0; };   // line is 1-based inside the source text
    int version = 0;                    // 0 = no #version directive
    Profile profile = None;
    int versionLine = 0;
    std::vector<Extension> extensions;
    int includeLine = 0;                // first '#include' (0 = none): not supported
    bool ok = true;
    std::string error;                  // malformed header
    int errorLine = 0;
};

// Comments and blank lines may precede #version; any other token before it is an error (the GLSL rule).
ShaderHeader ParseShaderHeader(const std::string& source);

// What the device's GLSL front end accepts. Filled by the backend from the real device.
struct GlslDevice {
    int esMajor = 0, esMinor = 0;            // highest GLSL ES version (3.2 = 3,2); 0 = no ES front end
    int desktopVersion = 0;                  // highest desktop #version (450 ...); 0 = none
    bool vulkanGlsl = false;                 // can compile GLSL for Vulkan (a SPIR-V compiler is linked in AND the device runs SPIR-V)
    std::set<std::string> extensions;        // GL_* extension names usable by #extension
};

// Returns true when the source can be handed to this device's compiler. On false `why` is the Capability message and *line the
// 1-based source line to blame (0 = whole source). `warnings` receives extensions requested with 'enable'/'warn' that the device lacks.
bool CheckGlslHeader(Lang lang, const ShaderHeader& header, const GlslDevice& device, std::string* why, int* line, std::vector<std::string>* warnings = nullptr);

}  // namespace am::rg

import com.effects.motion.effects.graph.*
import org.json.JSONObject
import java.io.File

var checks = 0
var failed = 0
fun check(cond: Boolean, what: String) { checks++; if (!cond) { failed++; println("  FAIL $what") } }
fun section(s: String) = println(s)
fun List<Issue>.errors() = filter { it.error }.joinToString("\n") { it.text }

fun pass(id: String, output: String = "", vararg inputs: Pair<String, String>, src: String = "half4 main(float2 p){return half4(0);}") =
    GraphPass(id, src, output = output, inputs = inputs.map { PassInput(it.first, it.second) }, file = "$id.json", line = 3)

fun preprocessorTests() {
    section("preprocessor")
    val r = GlslPreprocessor.run("""
        #version 300 es
        #define N 3
        #define SQ(x) ((x)*(x))
        #define HALF 0.5 // comment
        float a = SQ(N + 1) * HALF; /* block
        comment */ float b;
        #ifdef GL_ES
        float es;
        #else
        float notes;
        #endif
        #if defined(N) && N > 2 && (N % 2) == 1
        float big;
        #elif N == 3
        float never;
        #endif
        #ifndef MISSING
        float miss;
        #endif
        #undef N
        #ifdef N
        float stillN;
        #endif
        float c = N;
    """.trimIndent())
    check(r.ok, "preprocess ok: ${r.issues.errors()}")
    check(r.version == "300 es", "version captured")
    check(r.text.contains("((3 + 1)*(3 + 1)) * 0.5"), "function and object macros expand: ${r.text.lines().firstOrNull { it.contains("float a") }}")
    check(r.text.contains("float es;") && !r.text.contains("notes"), "#ifdef/#else")
    check(r.text.contains("float big;") && !r.text.contains("never"), "#if with defined, &&, %")
    check(r.text.contains("float miss;") && !r.text.contains("stillN") && r.text.contains("float c = N;"), "#ifndef, #undef")
    val in1 = "#define A 1\nfloat x;\n/* two\nlines */\n#if A\nfloat y;\n#endif\nfloat z;"
    check(GlslPreprocessor.run(in1).text.lines().size == in1.lines().size, "line count is preserved")
    check(GlslPreprocessor.run(in1).text.lines().indexOf("float z;") == 7, "line numbers stay valid")
    check(GlslPreprocessor.run("#define LONG 1 + \\\n 2\nfloat v = LONG;").text.contains("float v = 1 +  2;"), "continuation")
    check(!GlslPreprocessor.run("#include \"x.glsl\"").ok && GlslPreprocessor.run("#include \"x\"").issues[0].kind == IssueKind.UNSUPPORTED, "include unsupported")
    check(GlslPreprocessor.run("#if 1\nfloat a;").issues.any { it.message.contains("#endif") }, "missing #endif")
    check(GlslPreprocessor.run("#error nope").issues.any { it.message.contains("nope") }, "#error")
    check(GlslPreprocessor.run("#if 1/0\n#endif").issues.any { it.message.contains("division by zero") }, "div by zero")
    check(GlslPreprocessor.run("#define M(a,b) a+b\nfloat q = M(1,2,3);").issues.any { it.message.contains("expects 2") }, "macro arity")
    check(GlslPreprocessor.run("#define R R+1\nfloat q = R;").text.contains("float q = R+1;"), "recursive macro stops")
    check(GlslPreprocessor.run("float q = TAPS;", mapOf("TAPS" to "9")).text.contains("float q = 9;"), "pass defines")
}

fun converterTests() {
    section("glsl -> sksl")
    val glsl = """
        #version 300 es
        precision highp float;
        uniform sampler2D image;
        uniform sampler2D map;
        uniform float amount;
        uniform bool flip;
        uniform vec4 tint;
        in vec2 v_uv;
        out vec4 fragColor;
        #define K 2.0
        void main() {
            vec2 d = (texture(map, v_uv).rg - 0.5) * amount * K;
            if (flip) d = -d;
            vec4 c = texture(image, v_uv + d);
            fragColor = vec4(c.rgb * tint.rgb, c.a);
        }
    """.trimIndent()
    val r = GlslToSksl.convert(glsl, listOf("image", "map"), setOf("tint"), "fx.t", "warp", "t.xml", 1)
    check(!r.issues.hasError, "converts: ${r.issues.errors()}")
    check(r.sksl.contains("uniform shader image;") && r.sksl.contains("uniform shader map;") && r.sksl.contains("uniform float2 size;"), "children + size declared")
    check(r.sksl.contains("_tex_map(v_uv)") && r.sksl.contains("_tex_image(v_uv + d)"), "texture() -> input helper: ${r.sksl.lines().first { it.contains("_tex_map(") }}")
    check(r.sksl.contains("float2 d = (_tex_map") || r.sksl.contains("float2 d = ("), "vec2 -> float2")
    check(r.sksl.contains("layout(color) uniform half4 tint;") && r.sksl.contains("uniform float flip;") && r.sksl.contains("(flip > 0.5)"), "color and bool uniforms")
    check(!r.sksl.contains("highp") && !r.sksl.contains("sampler2D") && !r.sksl.contains("#"), "no GLSL leftovers")
    check(r.sksl.contains("half4 main(float2 _fc)") && r.sksl.contains("float2 v_uv = _fc / size;") && r.sksl.contains("_out = float4("), "main wrapper, varying, output")

    fun bad(src: String, inputs: List<String> = listOf("image")) = GlslToSksl.convert(src, inputs, emptySet(), "fx.b", "p", "b.xml", 1)
    var s = bad("uniform sampler2D image;\nout vec4 c;\nvoid main() {\n  vec4 a = texture(image, vec2(0.5));\n  if (a.r > 0.5) discard;\n  c = a;\n}")
    check(s.issues.any { it.message.contains("discard") && it.line == 5 && it.file == "b.xml" && it.pass == "p" }, "discard reported with line 5: ${s.issues.map { it.text }}")
    s = bad("uniform sampler2D image;\nout vec4 c;\nvoid main() {\n  int k = 5 % 2;\n  c = vec4(k);\n}")
    check(s.issues.any { it.message.contains("'%'") && it.line == 4 }, "% reported")
    s = bad("uniform sampler2D image;\nout vec4 c;\nvoid main() {\n  c = textureLod(image, vec2(0.5), 0.0);\n}")
    check(s.issues.any { it.message.contains("textureLod") && it.line == 4 }, "textureLod")
    s = bad("uniform sampler2D other;\nout vec4 c;\nvoid main() {\n  c = texture(other, vec2(0.5));\n}")
    check(s.issues.any { it.message.contains("no <input") } && s.issues.any { it.message.contains("does not read a declared input") }, "undeclared sampler")
    s = bad("out vec4 c;\nvoid main() {\n  c = vec4(1.0)\n")
    check(s.issues.hasError, "unbalanced braces")
    s = bad("uniform sampler2D image;\nout vec4 c;\nvoid main() {\n  uint u = 3u;\n  while (u > 0u) { u--; }\n  c = vec4(1.0);\n}")
    check(s.issues.count { it.error } >= 2, "uint and while")
    s = bad("uniform sampler2D image;\nvoid main() { }")
    check(s.issues.any { it.message.contains("never writes a colour") }, "no output colour")
    check(r.headerLines > 0, "header offset reported")
    val withImplicit = GlslToSksl.convert("uniform sampler2D image;\nout vec4 c;\nvoid main(){ c = texture(image, vec2(0.5)) * gain; }", listOf("image"), emptySet(), implicit = listOf(GlslToSksl.Implicit("gain", "uniform float gain;")))
    check(withImplicit.sksl.contains("uniform float gain;"), "implicit control uniform declared when used")
}

fun validatorTests() {
    section("graph validation")
    fun v(vararg p: GraphPass, buffers: List<GraphBuffer> = emptyList(), textures: List<GraphTexture> = emptyList(), output: String = "") =
        GraphValidator.validate("fx.t", EffectGraph(p.toList(), buffers, textures, output))
    check(!v(pass("a", "", "image" to "source")).hasError, "one pass ok")
    val twoPass = v(pass("a", "mid", "image" to "source"), pass("b", "", "image" to "pass:a"), buffers = listOf(GraphBuffer("mid")))
    check(!twoPass.hasError, "two pass ok: ${twoPass.errors()}")
    val cyc = v(pass("a", "ba", "x" to "buffer:bb"), pass("b", "bb", "x" to "buffer:ba")).errors()
    check(cyc.contains("dependency cycle") && cyc.contains("a -> b -> a") && cyc.contains("@1") && cyc.contains("effect 'fx.t'") && cyc.contains("a.json:3"), "cycle: $cyc")
    check(!v(pass("a", "ba", "x" to "buffer:bb", "p" to "buffer:ba@1"), pass("b", "bb", "x" to "source"), buffers = listOf(GraphBuffer("ba", history = 1))).hasError, "feedback through history is fine")
    check(v(pass("a", "x", "i" to "source"), pass("b", "", "i" to "buffer:xx"), buffers = listOf(GraphBuffer("x"))).errors().contains("Did you mean 'x'"), "suggestion")
    check(v(pass("a", "x", "i" to "buffer:x"), buffers = listOf(GraphBuffer("x"))).errors().contains("hazard"), "self read hazard")
    check(v(pass("a", "x", "i" to "source", "p" to "buffer:x@2"), buffers = listOf(GraphBuffer("x", history = 1))).errors().contains("history >= 2"), "history depth")
    check(v(pass("a", "", "i" to "texture:none")).errors().contains("unknown texture"), "unknown texture")
    check(v(pass("a", "", "i" to "source").copy(lang = "glsl")).errors().contains("cannot run"), "glsl not runnable on skia backend")
    check(v(pass("a", "", "i" to "source").copy(lang = "wgsl")).errors().contains("not sksl, glsl, glsl-es, glsl-vk or spirv"), "unknown language")
    check(v(pass("a", "", "i" to "source"), textures = listOf(GraphTexture("t", "file:x.png"))).errors().contains("builtin:noise"), "texture source")
    check(v(pass("a", "x", "i" to "source"), pass("b", "x", "i" to "source"), buffers = listOf(GraphBuffer("x"))).errors().contains("overwrites buffer"), "double clear write")
    check(v(pass("a", "x", "i" to "source"), pass("b", "x", "i" to "source").copy(clear = false, blend = "add"), buffers = listOf(GraphBuffer("x"))).errors().isEmpty(), "accumulate ok")
    check(v().errors().contains("no passes"), "no passes")
    val culled = v(pass("used", "out", "i" to "source"), pass("dead", "d", "i" to "source"), output = "out")
    check(!culled.hasError && culled.any { !it.error && it.pass == "dead" }, "dead pass warned")
    check(v(pass("a", "", "i" to "source")).none { it.error }, "no spurious errors")
    check(GraphValidator.validate("fx.t", EffectGraph(listOf(pass("a")), requires = GraphRequires(backends = listOf("vulkan-native")))).errors().contains("backend"), "backend requirement")
    check(GraphValidator.validate("fx.t", EffectGraph(listOf(pass("a")), requires = GraphRequires(minSchema = 9))).errors().contains("Update the app"), "newer schema")
}

fun jsonTests(effectsDir: File) {
    section("schema 2 json")
    val one = JSONObject("""{"id":"x","name":"X","category":"color","sksl":"half4 main(float2 p){return half4(1);}","params":[]}""")
    check(!GraphJson.isGraph(one), "one-pass JSON is not a graph (unchanged path)")
    val both = JSONObject("""{"id":"x","sksl":"s","passes":[{"id":"a","source":"half4 main(float2 p){return half4(1);}"}]}""")
    check(GraphJson.parse(both, "fx.x").issues.errors().contains("both"), "sksl + passes rejected")
    check(GraphJson.parse(JSONObject("""{"id":"x","schema":1,"passes":[]}"""), "fx.x").issues.errors().contains("schema"), "old schema with passes rejected")
    check(GraphJson.parse(JSONObject("""{"id":"x","schema":7,"passes":[]}"""), "fx.x").issues.errors().contains("newer"), "newer schema rejected")
    val rich = JSONObject("""{"schema":2,"id":"x","futureKey":{"a":1},"requires":{"backends":["skia"]},
        "textures":[{"id":"n","source":"builtin:noise","vendor":"v"}],"buffers":[{"id":"b","scale":0.5,"history":1,"note":"keep"}],
        "passes":[{"id":"a","source":["half4 main(float2 p) {","  return half4(1);","}"],"inputs":{"image":"source","prev":"buffer:b@1"},"output":"b","mystery":"m","constants":{"k":[1,2]}}],
        "history":{"seek":"replay","maxReplay":30}}""")
    val parsed = GraphJson.parse(rich, "fx.x")
    val g = parsed.graph!!
    check(parsed.issues.isEmpty(), "rich parses: ${parsed.issues.errors()}")
    check(g.passes[0].source.lines().size == 3 && g.seek == "replay" && g.maxReplay == 30 && g.temporal, "array source, history, temporal")
    check(g.extra["futureKey"] == """{"a":1}""" && g.passes[0].extra["mystery"] == "m" && g.buffers[0].extra["note"] == "keep" && g.textures[0].extra["vendor"] == "v", "unknown metadata preserved")
    val back = GraphJson.parse(GraphJson.write(g), "fx.x").graph!!
    check(back.passes == g.passes.map { it.copy() } || back.passes[0].extra == g.passes[0].extra, "round trip passes")
    check(back.buffers == g.buffers && back.textures == g.textures && back.seek == g.seek && back.extra == g.extra, "round trip rest")
    // XML writer
    val xml = GraphXml.write("fx.x", listOf("amount" to "1"), g)
    check(xml.contains("graph=\"2\"") && xml.contains("<buffer id=\"b\"") && xml.contains("ref=\"buffer:b@1\"") && xml.contains("seek=\"replay\"") && xml.contains("mystery=\"m\""), "runtime xml")
    check(xml.contains("half4 main(float2 p) {\n  return half4(1);\n}"), "shader text keeps its newlines")

    section("shipped effects (shared/assets/effects)")
    File("/tmp/em-graph-fixtures").apply { deleteRecursively(); mkdirs() }
    val index = org.json.JSONArray(File(effectsDir, "index.json").readText())
    var graphs = 0
    for (i in 0 until index.length()) {
        val id = index.getString(i)
        val j = JSONObject(File(effectsDir, "$id.json").readText())
        if (!GraphJson.isGraph(j)) continue
        graphs++
        val p = GraphJson.parse(j, "fx.$id")
        val issues = p.issues + GraphValidator.validate("fx.$id", p.graph!!)
        check(!issues.hasError, "$id validates: ${issues.errors()}")
        val params = j.getJSONArray("params")
        val ids = (0 until params.length()).map { params.getJSONObject(it).getString("id") }
        // every uniform a pass declares must be a control, a constant or an engine value
        val engine = setOf("size", "time", "frame")
        for (pass in p.graph.passes) {
            val uniforms = Regex("""uniform\s+(?:float|float2|float3|float4|half4|int)\s+(\w+)\s*;""").findAll(pass.source).map { it.groupValues[1] }
            for (u in uniforms) check(u in ids || u in pass.constants || u in engine || u.endsWith("_px"), "$id/${pass.id}: uniform '$u' has no control, constant or engine value")
            val children = Regex("""uniform\s+shader\s+(\w+)\s*;""").findAll(pass.source).map { it.groupValues[1] }.toSet()
            check(children == pass.inputs.map { it.name }.toSet(), "$id/${pass.id}: shader children $children match inputs ${pass.inputs.map { it.name }}")
        }
        File("/tmp/em-graph-fixtures/$id.xml").writeText(GraphXml.write("fx.$id", ids.map { it to "0" }, p.graph))
    }
    check(graphs >= 5, "at least five shipped graph effects (found $graphs)")
}

fun main(args: Array<String>) {
    val effects = File(args.firstOrNull() ?: "shared/assets/effects")
    preprocessorTests()
    converterTests()
    validatorTests()
    jsonTests(effects)
    ImportTests.run()
    println("\n$checks checks, $failed failed")
    if (failed > 0) System.exit(1)
}

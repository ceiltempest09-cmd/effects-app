package com.effects.motion.editor

import com.effects.motion.model.CROP_ID
import com.effects.motion.model.CropBox
import com.effects.motion.model.Layer
import com.effects.motion.model.Scene
import com.effects.motion.model.addEffect
import com.effects.motion.model.cropIndex
import com.effects.motion.model.effects
import com.effects.motion.model.withCropBox
import com.effects.motion.model.withCropKeyframes
import com.effects.motion.model.withEffect

val Layer.canCrop: Boolean get() = kind !in Uncroppable

private val Uncroppable = setOf("audio", "camera", "nullobj", "model", "light")

fun EditorState.openCrop() {
    val layer = selected ?: return
    val index = layer.cropIndex
    if (index < 0) {
        val crop = engine.effects.value.find(CROP_ID)?.takeIf { it.available } ?: return
        editSelected { it.addEffect(crop.instance()) }
    } else if (layer.effects[index]["hidden"] == "true") {
        editSelected { it.withEffect(index) { e -> e.with("hidden", null) } }
    }
    playing = false
    keypad = null
    easingOpen = false
    cropAspect = null
    panel = EditorPanel.Crop
}

fun EditorState.setCrop(box: CropBox, key: Any? = null) {
    val index = selected?.cropIndex?.takeIf { it >= 0 } ?: return
    editSelected(key) { it.withCropBox(index, box) }
}

fun EditorState.toggleCropKeyframes() {
    val index = selected?.cropIndex?.takeIf { it >= 0 } ?: return
    editSelected { it.withCropKeyframes(index) }
}

fun uncropped(id: Long, index: Int): (Scene) -> Scene = { scene ->
    scene.update(id) { layer -> layer.withEffect(index) { it.with("hidden", "true") } }
}

#include "glsl_wrap.h"

#include <algorithm>
#include <cctype>
#include <set>
#include <vector>

namespace am::rg {
namespace {

std::string Trim(const std::string& s) {
    size_t a = 0, b = s.size();
    while (a < b && std::isspace((unsigned char)s[a])) a++;
    while (b > a && std::isspace((unsigned char)s[b - 1])) b--;
    return s.substr(a, b - a);
}
bool IsIdent(const std::string& s) {
    if (s.empty() || !(std::isalpha((unsigned char)s[0]) || s[0] == '_')) return false;
    return std::all_of(s.begin(), s.end(), [](char c) { return std::isalnum((unsigned char)c) || c == '_'; });
}
std::vector<std::string> Words(const std::string& s) {
    std::vector<std::string> out;
    std::string cur;
    for (char c : s) {
        if (std::isspace((unsigned char)c)) { if (!cur.empty()) { out.push_back(cur); cur.clear(); } }
        else cur += c;
    }
    if (!cur.empty()) out.push_back(cur);
    return out;
}
bool Builtin(const std::string& t, std::string* kind) {
    static const std::set<std::string> ok = {"float", "int", "uint", "bool", "vec2", "vec3", "vec4", "ivec2", "ivec3", "ivec4", "uvec2", "uvec3", "uvec4"};
    *kind = t;
    return ok.count(t) > 0;
}
bool IsPrecision(const std::string& w) { return w == "highp" || w == "mediump" || w == "lowp"; }

// Removes comments from a line, tracking /* */ across lines. Strings do not exist in GLSL.
std::string StripComments(const std::string& line, bool* inBlock) {
    std::string out;
    for (size_t i = 0; i < line.size(); i++) {
        if (*inBlock) {
            if (line[i] == '*' && i + 1 < line.size() && line[i + 1] == '/') { *inBlock = false; i++; out += ' '; }
            continue;
        }
        if (line[i] == '/' && i + 1 < line.size() && line[i + 1] == '/') break;
        if (line[i] == '/' && i + 1 < line.size() && line[i + 1] == '*') { *inBlock = true; i++; continue; }
        out += line[i];
    }
    return out;
}

}  // namespace

GlslWrapResult WrapDesktopGlslForVulkan(const std::string& source, const std::map<std::string, std::string>& defines) {
    GlslWrapResult r;
    std::vector<std::string> lines;
    {
        std::string cur;
        for (char c : source) { if (c == '\n') { lines.push_back(cur); cur.clear(); } else if (c != '\r') cur += c; }
        lines.push_back(cur);
    }
    auto fail = [&](int line, const std::string& msg) { r.ok = false; r.error = msg; r.errorLine = line; return r; };

    // ---- #version
    bool inBlock = false;
    int versionLine = -1, version = 0;
    for (size_t i = 0; i < lines.size(); i++) {
        const std::string code = Trim(StripComments(lines[i], &inBlock));
        if (code.empty()) continue;
        if (code[0] == '#') {
            const std::vector<std::string> w = Words(code.substr(1));
            if (!w.empty() && w[0] == "version") {
                if (w.size() < 2) return fail((int)i + 1, "#version has no number");
                version = std::atoi(w[1].c_str());
                if (w.size() > 2 && w[2] == "es") return fail((int)i + 1, "this is GLSL ES (#version " + w[1] + " es): use lang=\"glsl-es\"");
                versionLine = (int)i;
            }
        }
        break;
    }
    if (versionLine < 0) return fail(1, "desktop GLSL needs a #version line before any other code");
    if (version < 330) return fail(versionLine + 1, "#version " + std::to_string(version) + " is older than 330: legacy GLSL (varying, gl_FragColor, texture2D) is not run natively");

    std::string head = "#version 450\n";
    for (const auto& d : defines) head += "#define " + d.first + " " + d.second + "\n";
    r.lineShift = (int)defines.size() - versionLine;     // new line = original line + lineShift (lines before #version are dropped; defines of a bool uniform add a few more at the block)

    // ---- walk the rest of the source
    std::vector<std::string> out;
    struct Member { std::string type, name, array; bool wasBool = false; int line = 0; };
    std::vector<Member> members;
    int firstUniformOut = -1;
    int depth = 0, nextBinding = 1;
    bool outDone = false;
    inBlock = false;
    for (size_t i = 0; i <= (size_t)versionLine; i++) { StripComments(lines[i], &inBlock); }
    inBlock = false;
    for (size_t i = (size_t)versionLine + 1; i < lines.size(); i++) {
        const std::string raw = lines[i];
        const bool startedInBlock = inBlock;
        std::string code = StripComments(raw, &inBlock);
        const std::string t = Trim(code);
        const int lineNo = (int)i + 1;
        const int before = depth;
        for (char c : code) { if (c == '{') depth++; else if (c == '}') depth--; }
        if (startedInBlock || before != 0 || t.empty() || t[0] == '#') { out.push_back(raw); continue; }

        // optional layout(...) prefix
        std::string rest = t;
        std::string layoutText;
        if (rest.compare(0, 6, "layout") == 0) {
            const size_t open = rest.find('(');
            const size_t close = rest.find(')', open == std::string::npos ? 0 : open);
            if (open == std::string::npos || close == std::string::npos) { out.push_back(raw); continue; }
            layoutText = rest.substr(open + 1, close - open - 1);
            rest = Trim(rest.substr(close + 1));
        }
        const std::vector<std::string> w = Words(rest);
        if (w.empty()) { out.push_back(raw); continue; }

        // out vec4 name;  (first one without a location)
        if (w[0] == "out" && !outDone && layoutText.find("location") == std::string::npos && w.size() >= 3 && rest.back() == ';' && rest.find('{') == std::string::npos) {
            out.push_back("layout(location = 0) " + rest);
            outDone = true;
            continue;
        }
        if (w[0] == "out" || (w[0] != "uniform")) { out.push_back(raw); continue; }

        // uniform [precision] type name[, name2][array] ;
        if (rest.back() != ';') return fail(lineNo, "a uniform declaration must fit on one line ending with ';' so it can be moved into the uniform block");
        if (rest.find('{') != std::string::npos) return fail(lineNo, "a uniform block written in desktop GLSL needs lang=\"glsl-vk\" (set / binding qualifiers)");
        if (rest.find('=') != std::string::npos) return fail(lineNo, "a uniform with an initializer cannot be moved into a uniform block");
        std::vector<std::string> v(w.begin() + 1, w.end());
        v.back().pop_back();    // ';'
        if (v.back().empty()) v.pop_back();
        if (!v.empty() && IsPrecision(v[0])) v.erase(v.begin());
        if (v.size() < 2) return fail(lineNo, "cannot read this uniform declaration");
        const std::string type = v[0];
        std::string names;
        for (size_t k = 1; k < v.size(); k++) names += v[k];
        std::vector<std::string> list;
        { std::string cur; for (char c : names) { if (c == ',') { list.push_back(cur); cur.clear(); } else cur += c; } list.push_back(cur); }
        if (type.compare(0, 7, "sampler") == 0) {
            if (type != "sampler2D") return fail(lineNo, "only sampler2D inputs are supported (got " + type + ")");
            for (const std::string& n : list) {
                if (!IsIdent(n)) return fail(lineNo, "cannot read the sampler name '" + n + "'");
                out.push_back("layout(set = 0, binding = " + std::to_string(nextBinding++) + ") uniform sampler2D " + n + ";");
                r.samplers++;
            }
            continue;
        }
        std::string kind;
        if (!Builtin(type, &kind)) return fail(lineNo, "uniform of type '" + type + "' cannot be moved into the uniform block (supported: float, int, uint, bool, vecN, ivecN, uvecN); use lang=\"glsl-vk\" for structs and matrices");
        for (const std::string& n0 : list) {
            std::string n = n0, array;
            const size_t br = n.find('[');
            if (br != std::string::npos) { array = n.substr(br); n = n.substr(0, br); }
            if (!IsIdent(n)) return fail(lineNo, "cannot read the uniform name '" + n0 + "'");
            if (array.size() < 3 || (!array.empty() && array.back() != ']')) { if (!array.empty()) return fail(lineNo, "cannot read the array size of '" + n + "'"); }
            Member m;
            m.type = type; m.name = n; m.array = array; m.line = lineNo;
            if (type == "bool") { if (!array.empty()) return fail(lineNo, "an array of bool cannot be moved into the uniform block"); m.wasBool = true; m.type = "int"; }
            members.push_back(m);
            r.looseUniforms++;
        }
        if (firstUniformOut < 0) { firstUniformOut = (int)out.size(); out.push_back(std::string()); }   // placeholder for the block
        else out.push_back(std::string());     // keeps every later line number the same
    }

    // ---- the generated block
    if (firstUniformOut >= 0) {
        std::string block = "layout(std140, set = 0, binding = 0) uniform AmLoose {";
        for (const Member& m : members) block += " " + m.type + " " + (m.wasBool ? "am_b_" : "") + m.name + m.array + ";";
        block += " };";
        for (const Member& m : members) if (m.wasBool) block += "\n#define " + m.name + " (am_b_" + m.name + " != 0)";
        out[(size_t)firstUniformOut] = block;
    }

    std::string text = head;
    for (size_t i = 0; i < out.size(); i++) { text += out[i]; text += '\n'; }
    r.ok = true;
    r.text = text;
    return r;
}

}  // namespace am::rg

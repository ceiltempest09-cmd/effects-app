# Skia removal status — migration tracking

## Batch 1: standalone GLSL ES / OpenGL ES render-graph backend

**Status: HOST-VERIFIED; NOT YET THE APPLICATION'S PRIMARY RENDERER.**

The project contains a real EGL/OpenGL ES 3.x backend (`gl_backend.{h,cpp}`) and a backend-neutral render graph (`render_graph.{h,cpp}`). The backend compiles GLSL ES on the device driver, manages render targets and textures, binds uniforms/samplers, executes passes, supports pooling/history, reports capabilities, and records diagnostics/statistics. The render graph plans and executes passes through backend capability selection and explicit inter-backend hand-offs.

### Verification performed on this source upload

- `tests/native/build_gl.sh`: **1,227 checks passed, 0 failed, 1 skipped** on Mesa llvmpipe. It exercised GLES 3.2 and desktop GL 4.5, shader compilation/execution, formats, uniforms/samplers, blending, multi-pass graphs, history, pooling, profiling, and error handling. The skipped test is SPIR-V/Vulkan execution because no SPIR-V compiler/Vulkan backend is available in this host test build.
- `tests/native/run.sh` component tests: render graph **171 passed**; native shader **105 passed**; SPIR-V reflection **22 passed**; GLSL wrapper **22 passed**; history signature **16 passed**; color pipeline **114 passed**. The full script did not complete within the available execution window when it reached its final GPU test; the GPU test was run separately and passed as stated above.
- Fixed a missing `<algorithm>` include in `tests/native/render_graph_test.cpp`, which previously prevented the host test suite from compiling (`std::any_of`).
- Android Gradle/NDK build and Mali-G57 device test: **not run**.

### Critical integration limitation

This completes the **standalone renderer / render-graph foundation only**. It does NOT make the app fully GLSL. `engine.cpp`, scene compositing, shapes, styles, text, video-frame integration, and the current Skia rendering lifecycle still depend on Skia. The app's effect graph adapter and Kotlin importer still have Skia/SkSL integration paths. Do not remove Skia from CMake or GitHub Actions yet; doing so would break the current app renderer.

### Next batch

Batch 2 must connect the native renderer to the real engine frame lifecycle and replace scene/layer compositing and video-frame paths. This requires a concrete engine-to-GPU bridge and correct synchronization/resource ownership; it is not safe to claim the application uses GLSL until that is implemented and tested.

No features were intentionally removed or stubbed in this batch. Package/application identity and signing configuration were not changed.


## Batch 2 continuation — source reconciliation (2026-11-22)

The two supplied archives are complementary, not interchangeable. `overlay.zip` contains the newer integration files and build configuration but omits 49 C++ source/header files that its own CMake configuration references. `Effects.zip` contains those missing implementation files. The working Batch 2 tree was reconciled by adding only files absent from `overlay.zip`; existing overlay files were preserved (including its newer `gl_yuv.cpp` and `gl_yuv.h`). The CMake-referenced `.cpp` source existence check now reports no missing files.

This is source-tree repair, not completion of Batch 2. The current engine still renders through Skia surfaces/canvases, the video YUV path still adapts the native GL texture back into a Skia image, and `GraphRunner` still uses its Skia backend as the source/result adapter. The app's Android build and on-device GLES integration have not yet been verified. Do not mark Batch 2 complete or remove Skia from the build yet.


## Batch 2 continuation — native test runner restored and rerun

Restored the native host test scripts and native shader capability notes into the current `overlay.zip` tree from the supporting `Effects.zip` archive. Ran `tests/native/run.sh` from the project root on Mesa llvmpipe:

- Render graph: 183 passed.
- Native shader: 105 passed.
- SPIR-V reflection: 22 passed.
- GLSL wrapper: 22 passed.
- History signature: 16 passed.
- Color pipeline: 114 passed.
- GLES / desktop GL backend: 1,227 passed, 0 failed, 1 skipped.

The skipped test is SPIR-V / Vulkan execution because this host test build has no SPIR-V compiler or Vulkan device. These are host tests of the standalone native backend, not Android app/device tests. Batch 2 remains open: the app frame lifecycle, Skia-backed scene composition, Ganesh/OpenGL bridge, and video/preview integration still need migration.


## Batch 2 continuation — video GL state isolation (2026-11-22)

`shared/cpp/gl_yuv.cpp` now preserves the calling GL context's state around native YUV-to-RGBA texture conversion. It restores the framebuffer, viewport, program, texture unit and bindings, VAO, array buffer, color mask, and blend/scissor/depth/stencil/cull enables. The converter no longer resets the framebuffer to 0 unconditionally.

The native host test suite passed: 183 render-graph, 105 shader, 22 SPIR-V reflection, 22 GLSL wrapper, 16 history-signature, 114 color-pipeline, and 1,227 GLES/desktop GL backend checks passed (one SPIR-V/Vulkan check skipped due to missing host tools/device). The Android-only YUV converter was not compiled by those host tests.

This is a video-path safety improvement, not completion of video migration: `GlYuv::convert()` still wraps the native texture as a Skia `SkImage` for the current engine. Scene/drawing/text/preview and the engine-owned GL bridge remain to be migrated.


## Batch 2 continuation — Ganesh/OpenGL native graph bridge

The engine GPU bridge now has a Ganesh/OpenGL path in addition to the existing Graphite/Vulkan path:

- `GraphGpuBridge` exposes whether the native backend must adopt the engine's current EGL context and a stable context identity.
- The GLES render-graph backend adopts the engine EGL context for Ganesh instead of creating an unrelated second context.
- Ganesh wraps graph AHardwareBuffers with `SkSurfaces::WrapAndroidHardwareBuffer`; wrappers are cached and invalidated by `forgetBuffer`.
- Ganesh hand-off submits and waits on the same GL queue. Native writes invalidate Ganesh's cached GL state with `resetContext()`.
- The adopted GL backend is released by the engine before EGL teardown, after effect graphs are dropped.

Validation: the native host suite passes (183 render-graph, 105 shader, 22 SPIR-V reflection, 22 GLSL wrapper, 16 history-signature, 114 color-pipeline, and 1,227 GLES/desktop GL checks; one SPIR-V/Vulkan check skipped). These tests do not compile the Android-only `engine.cpp` or validate Ganesh AHardwareBuffer wrapping on a device. Android Gradle/NDK build and physical-device verification are still required. Scene, drawing, text, preview, and the video SkImage adapter remain Skia-backed.


## Batch 2 continuation — YUV converter GL-state isolation (2026-11-22)

The native YUV-to-RGBA converter now preserves independent draw/read framebuffer bindings and texture-unit-0 sampler state, and uses its own VAO so it does not mutate the application's VAO 0 vertex attributes. GL object allocation failures are reported during setup.

The host native suite passed (183 render-graph, 105 shader, 22 SPIR-V reflection, 22 GLSL wrapper, 16 history-signature, 114 color-pipeline, and 1,227 GLES/desktop GL checks; one SPIR-V/Vulkan test skipped). This suite does not compile the Android-only YUV converter. The Android build/device test remains outstanding. Video still flows through the Skia image adapter; this change does not complete video migration.


## Batch 2 continuation — migration audit gate (2026-11-22)

Added `tools/audit_skia_migration.py` for repeatable subsystem-level inventory. On the current overlay source it reports 1,523 matching production C++ lines across 26 files: engine/frame lifecycle (160), scene/path model (194), drawing/shapes/styles/text/preview (798), direct video/image adapter files (8), and other effects/interpolation/geometry code (363). The video dependency is larger than the direct adapter count because `engine.cpp` stores decoded frames as `SkImage`.

`tests/native/run.sh` was rerun successfully: 183 render-graph, 105 shader, 22 SPIR-V reflection, 22 GLSL wrapper, 16 history-signature, 114 color-pipeline, and 1,227 GLES/desktop GL checks passed; one SPIR-V/Vulkan check was skipped due to missing host compiler/device. This validates the standalone native backend only. No Android build or device test was performed. The application renderer remains Skia-backed and Batch 2 remains incomplete.


## SkSL -> GLSL ES migration (2026-11-22)

**Done and host-verified (Mesa llvmpipe, real GLES driver):**
- Every SkSL shader that could be moved off Skia is now GLSL ES 3.00: 12 asset shaders (`gaussianstages`, `feedbacktrails`, `eng3d`, `engcolor`, `engshake`, `engtexture`; the four `eng*` one-pass effects are now schema-2 graphs with one `glsl-es` pass) and the whole optical-flow / datamosh pipeline.
- `shared/cpp/glsl_library.{h,cpp}` (generated by `tools/gen_glsl_library.py` from the old SkSL with `tools/sksl_to_glsl.py`): 46 shaders, ALL compile on a real GLES driver (`tests/native/glsl_library_test.cpp`, 66 checks, GPU output compared with CPU references). It also holds the GLSL ports of the not-yet-wired Skia-paint shaders: puppet, puppet mesh, glow x3, display tone map, gradient, morph, edge, copy tint and the 24 blend modes.
- `shared/cpp/gl_flow.{h,cpp}`: optical flow, frame synthesis, motion blur and datamosh on GL targets. `tests/native/gl_flow_test.cpp` recovers a (3, 2) px translation as (2.95, 1.93) px and its synthesized middle frame has ~5x lower error than a cross-fade.
- `interpolation.cpp` now only moves images between Skia and GL (CPU transfers; flow fields stay on the GL side in a small cache). **This adapter was written without Skia headers and has not been compiled.**
- `gl_backend.cpp` gained `mat2/mat3/mat4` uniforms (full backend suite still 1,227 passed, 0 failed, 1 skipped).
- `effects_graph.cpp`: the Skia SkSL runner is gone; a pass written in `sksl` is rejected with a clear diagnostic. `effects.cpp`: an `sksl` effect attribute is rejected.
- Kotlin: `GlslToSksl.kt` deleted; every importer path produces native GLSL ES; `sksl` is no longer an accepted language; the SkSL import option is gone. **Kotlin was edited without a compiler in this environment and has not been built.**
- `tools/audit_sksl.py` lists what is left (`--strict` fails while anything remains).

**NOT done - still SkSL, because these shaders are Skia paint shaders / blenders / image filters inside `SkCanvas` drawing, not render-graph passes:**
`effects.cpp` (puppet, puppet mesh, glow), `styles.cpp` (layer blend-mode blender, gradient, morph, border edge, copy tint), `engine.cpp` (HDR display tone map), `bridge_selftest.cpp`. Their GLSL versions exist and compile (see above), but they cannot be swapped in until the scene / layer compositing itself runs on the GL backend (Batch 2). Replacing them one by one with CPU round-trips would make the preview unusably slow.

Android Gradle/NDK build and device testing: not run.


## Build fix + continuation (2026-11-23)

**Build failure fixed (GitHub Actions log, run of 2026-11-22):** every C++ file compiled; the link of `libamengine.so` failed with `undefined symbol: am::ReleaseNativeGlForContext(unsigned long)` (referenced from `engine.cpp`). The function was defined inside an anonymous namespace in `effects_graph.cpp`, so it was a different, file-local function from the one declared in `effects_graph.h`. It now has external linkage. Reproduced and confirmed with a two-file replica (same warning, same linker error; fixed shape links). The real Android link was NOT re-run here.

**Kotlin (never compiled before; app/build.gradle.kts treats Kotlin warnings as errors):** the tree mixed old SkSL importer files from `Effects.zip` with GLSL-only files from `overlay.zip`. Fixed by reading: `EffectImporter.kt` (called `GraphConvert.convert(..., native = ...)`, a parameter that no longer exists; SkSL one-pass path removed; default language GLSL; `strictCategory` bug in the GLSL path), `EffectDefinition.kt`, `ImportedEffects.kt`, `ImportUi.kt`, `EffectSources.kt` (`ShaderLang.SKSL` is hidden and reads as GLSL), `LutEffect.kt` (now a GLSL ES pass, requires `gles`), `EffectGraph.kt` (`lutf16:` needs `gles`), and `tests/hostkt/*`. No Kotlin compiler was available: these edits are checked by reading and bracket balance only.

**GL backend:** `lutf16:` textures (baked .cube LUTs) now load in `gl_backend.cpp` (RGBA16F). Previously only the removed Skia path could load them.

**engblur / englight:** rewritten (`tools/gen_engine_graphs.py`) as multi-pass GLSL ES graphs with real blur pyramids. `tests/native/build_engine_graphs.sh` runs them on Mesa llvmpipe: engblur vs a CPU Gaussian (mean error <= 0.015 up to radius 150), focus area, all 8 englight modes, light rays reading the blurred bright copy, and the LUT shader (48 checks, 0 failed).

Still open: steps 3-5 of the migration (Skia paint shaders in effects.cpp/styles.cpp/engine.cpp/bridge_selftest.cpp, the Batch 2 compositor move, removing Skia from CMake/CI). `tools/gen_glow.py` still emits SkSL (the shipped glow.json is already converted; do not re-run the generator). Note: the CI step "Remove the built-in engine" deletes `shared/assets/effects/*.json` except `foreign.json` at build time.


## Step 4 started: GL layer compositor (2026-11-23)

New `shared/cpp/gl_compositor.{h,cpp}` (no Skia types, in CMakeLists): `comp::Compositor::render()` draws layers bottom to top with an affine transform, opacity, alpha / inverted-alpha / luma mask, nearest or bilinear sampling, a 1-canvas-pixel soft edge, and 29 blend modes (the 24 GLSL modes plus normal, screen, mask, exclude, clipping-mask, which Skia used to blend natively). `gradient()` and `toneMap()` run the `style.gradient` and `display.tonemap` shaders.

Verified on Mesa llvmpipe (`tests/native/build_gl_compositor.sh`, part of `run.sh`): 130 checks, 0 failed. Blend results are compared with CPU formulas; the full suite (all earlier counts unchanged) passes.

NOT done: nothing calls the compositor yet. `engine.cpp`, `styles.cpp`, `effects.cpp`, `bridge_selftest.cpp` still use SkSL/Skia, so `audit_sksl.py --strict` and the Skia audit still fail. Still missing: shape tessellation/stroking, glyph-atlas text, video without `SkImage`, engine frame lifecycle, then CMake/CI/third_party removal. No Android build or device test was run.


## Step 4a: shape geometry + GL shape renderer (2026-11-23)

No CI log was attached this time, so no build failure was fixed.

**New, host-tested (Mesa llvmpipe), no Skia types:**
- `shared/cpp/gl_path.{h,cpp}`: `Path` (move/line/quad/cubic/close, arc, rect, oval, round rect), curve flattening with a pixel tolerance, fill triangulation (fan per contour), stroker (butt/round/square caps; miter/round/bevel joins with miter limit; closed contours; dots) and dashes (phase, odd patterns repeat, zero-length dashes keep their direction).
- `shared/cpp/gl_shapes.{h,cpp}`: `ShapeRenderer::fill/stroke/mesh` return anti-aliased coverage for the shape's bounding region (clipped to the canvas). The GPU adds up triangle winding numbers in a 4x4-supersampled RGBA16F target and a resolve pass applies non-zero or even-odd. `tint()` and `paint()` colour it (paint = a canvas-sized gradient from `comp::Compositor::gradient`). Result goes into `comp::Layer` with `Affine::Translate(x, y)`. No readbacks.
- GL backend: `PassRun::geometry` / `geometryVertices` draw a triangle list instead of the full-screen triangle (xy in output pixels, plus a float `in float v_w`). The vertex shader now also passes `v_w` for #version 300+ shaders; the full-screen passes are unaffected (full GL backend suite unchanged: 1,227 passed, 0 failed, 1 skipped).
- `tests/native/gl_shapes_test.cpp` (+ `build_gl_shapes.sh`, added to `run.sh`): 70 checks, 0 failed. Areas of rectangle, circle, round rect, stars, caps (butt 120, square 136, round 132.6), joins (miter 240, round 238.1, bevel 235.5), miter limit, closed stroke, dashes, non-uniform scale and mirrored transforms, fill rules, canvas clipping, off-canvas, tint, paint, AA levels. One tolerance was widened while writing the test: the area of a round-capped dot (polygon approximation of a circle) is accepted within 0.45 px² of the exact value.
- Full `tests/native/run.sh`: exit 0. Counts: 183 render graph, 105 native shader, 22 SPIR-V reflection, 22 GLSL wrapper, 16 history, 114 color, 1,227 GL backend (1 skipped), 66 glsl_library, 16 gl_flow, 48 engine graphs, 130 compositor, 70 shapes.

**Limits / not verified:**
- Nothing calls the shape renderer yet. `shapes.cpp`, `scene.cpp`, `drawing.cpp` still build `SkPath` and draw with `SkCanvas`; they were NOT touched. Porting them (e.g. the path builders in `shapes.cpp`, path booleans from `SkPathOps`, SVG path parsing, `RoundCorners`) onto `path::Path` is the next piece, and `SkPathOps` (union/difference/intersect) has no replacement yet.
- Not done: conic curves, gradient strokes, per-path blend into the compositor, path effects other than dashes (corner/discrete/trim), hairline strokes (width 0), glyph atlas text, video without `SkImage`, engine hookup, steps 3 and 5.
- The cost model is untested on a device: each shape allocates a region-sized 16F target (width x height x 16) and several passes. Tiny/many shapes will need batching or caching.
- Android Gradle/NDK build and device test: not run. `gl_backend.cpp` edits are compiled only by the host build (GLES via Mesa), not by the NDK.
- `audit_skia_migration.py --strict` and `audit_sksl.py --strict` still fail; Skia must stay in CMake/CI/third_party.


## Step 4a/4b continued: boolean ops, TrueType reader, GL text (2026-11-23, second session)

No CI log was attached. The new upload (Effects_1.zip, overlay_1.zip) was the same base plus my previous overlay.

**New, host-tested, no Skia types:**
- `gl_shapes`: `ShapeRenderer::combine(a, b, Op)` = union / intersect / difference / xor of two coverages (replacement for SkPathOps on drawn shapes). Exact away from edges; where two edges cross inside one pixel it is the coverage-product estimate. For an exact union, put both meshes in one `path::Mesh` and use NonZero. Tests: 83 checks, 0 failed (was 70).
- `ttf.{h,cpp}`: own TrueType reader (cmap 4/12, hmtx incl. USE_MY_METRICS composites, glyf simple and composite, loca, TTC index) giving `path::Path` outlines. Decision for step 4b: no FreeType and no Android font API; glyph outlines are drawn by the same GL shape path as every other shape. No new dependency in the app.
- `gl_text.{h,cpp}`: UTF-8 decode (invalid bytes become U+FFFD), line layout (advance, tracking, line height, `\n`) into one `path::Path` per text block.
- Tests (FreeType is a test-only dependency, not in the app):
  - `ttf_test.cpp` (built with ASan + UBSan): all 76 bundled fonts load; glyph ids, advances, ascender/descender, units-per-em and contour counts match FreeType for 8,056 code points; 7,868 outlines built; 68 damaged copies of a font (truncated or with random bytes changed) load or are rejected with no crash and no sanitizer report. 319 checks, 0 failed.
  - `gl_text_test.cpp`: 64 glyphs across 8 fonts at 64 px rendered through gl_shapes vs FreeType's own anti-aliased rendering (no hinting): worst ink-area error 1.03%, worst pixel difference 2.16% of the ink. 132 checks, 0 failed.
- Full `tests/native/run.sh`: exit 0.

**Not supported by the text path (reported, not faked):** CFF/OTTO fonts (rejected with a message), variable-font axes (8 of 76 bundled fonts have axes; only the default instance is drawn, so any weight/width the app sets through Skia axes is not applied yet), GPOS kerning, GSUB ligatures/shaping, bidi and complex scripts, system-font fallback, colour emoji, hinting.

**Still not done:** `text.cpp`/`textanim.cpp` are untouched and still use Skia; nothing calls gl_text yet. No per-glyph cache or atlas yet (each text block rebuilds its outline and triangles; a cache keyed by font, glyph and size is the obvious optimization once it is measured on a device). Steps 4c (video), 4d (engine hookup), 3 and 5 are not started. Android build and device runs: none.

// vulkan_exec.h - step 5b-1: run SPIR-V produced by glslang on the phone's Vulkan driver, standalone (own VkDevice, tiny images).
// Proves execution of Vulkan GLSL (UBO + sampler, two passes, RGBA8 and RGBA16F). It is not wired into effects yet.
#pragma once
#include <string>
namespace am {
// Appends PASS/FAIL lines to *text and counts them. Writes a crumb file in cacheDir while running: if the app dies inside, the next run reports it and skips once.
void RunVulkanExecTest(std::string* text, int* pass, int* fail, const std::string& cacheDir);
}

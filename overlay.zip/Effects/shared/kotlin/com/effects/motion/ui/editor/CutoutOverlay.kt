package com.effects.motion.ui.editor

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import com.effects.motion.ai.CutoutBrush
import com.effects.motion.ai.CutoutSession
import com.effects.motion.editor.EditorPanel
import com.effects.motion.editor.EditorState

private val KeepColor = Color(0xFF3DDC84)
private val EraseColor = Color(0xFFFF5252)

/** Brush layer for the cut-out panel: paints strokes on the layer and shows the AI selection outline. */
@Composable
internal fun CutoutOverlay(state: EditorState, quad: FloatArray?, scale: Float, origin: Offset) {
    val session = CutoutBrush.session
    if (state.panel != EditorPanel.Cutout || quad == null || session == null) return
    val q = List(4) { Offset(quad[2 * it], quad[2 * it + 1]) * scale + origin }
    val corners by rememberUpdatedState(q)
    val paint = remember { android.graphics.Paint().apply { isFilterBitmap = true } }
    Canvas(Modifier.fillMaxSize().pointerInput(session) {
        awaitEachGesture {
            val down = awaitFirstDown(requireUnconsumed = false)
            fun at(p: Offset) = boxFraction(corners, p).let { Offset(it.x.coerceIn(0f, 1f), it.y.coerceIn(0f, 1f)) }
            down.consume()
            session.begin(at(down.position))
            while (true) {
                val change = awaitPointerEvent().changes.firstOrNull { it.id == down.id } ?: break
                change.consume()
                if (!change.pressed) break
                session.extend(at(change.position))
            }
            session.end()
        }
    }) {
        session.overlay?.let { bitmap ->
            val w = bitmap.width.toFloat()
            val h = bitmap.height.toFloat()
            val matrix = android.graphics.Matrix()
            matrix.setPolyToPoly(floatArrayOf(0f, 0f, w, 0f, w, h, 0f, h), 0,
                floatArrayOf(q[0].x, q[0].y, q[1].x, q[1].y, q[2].x, q[2].y, q[3].x, q[3].y), 0, 4)
            drawIntoCanvas { it.nativeCanvas.drawBitmap(bitmap, matrix, paint) }
        }
        for (stroke in session.strokes) drawStroke(q, stroke.points, if (stroke.keep) KeepColor else EraseColor, 0.5f)
        if (session.live.isNotEmpty()) drawStroke(q, session.live, if (session.erase) EraseColor else KeepColor, 0.8f)
    }
}

private fun DrawScope.drawStroke(q: List<Offset>, points: List<Offset>, color: Color, alpha: Float) {
    val width = 12.dp.toPx()
    val screen = points.map { boxPoint(q, it.x, it.y) }
    if (screen.size == 1) {
        drawCircle(color.copy(alpha = alpha), width / 2f, screen[0])
        return
    }
    val path = Path().apply {
        moveTo(screen[0].x, screen[0].y)
        for (i in 1 until screen.size) lineTo(screen[i].x, screen[i].y)
    }
    drawPath(path, color.copy(alpha = alpha), style = Stroke(width, cap = StrokeCap.Round, join = StrokeJoin.Round))
}

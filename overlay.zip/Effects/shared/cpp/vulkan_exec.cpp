#include "vulkan_exec.h"
#include "glsl_compile.h"

#include <cmath>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <functional>
#include <vector>
#include <unistd.h>

#if __has_include(<vulkan/vulkan.h>)
#include <vulkan/vulkan.h>
#define AM_VK_EXEC 1
#endif

namespace am {
namespace {

struct Out {
    std::string* text; int* pass; int* fail;
    void line(const std::string& s) { *text += s + "\n"; }
    void ok(const std::string& s) { (*pass)++; line("PASS  " + s); }
    void bad(const std::string& s) { (*fail)++; line("FAIL  " + s); }
};

#ifdef AM_VK_EXEC

constexpr uint32_t W = 64, H = 64;

float HalfToFloat(uint16_t h) {
    const uint32_t s = (h >> 15) & 1u, e = (h >> 10) & 31u, m = h & 1023u;
    float v;
    if (e == 0) v = std::ldexp((float)m, -24);
    else if (e == 31) v = m ? NAN : INFINITY;
    else v = std::ldexp((float)(m + 1024u), (int)e - 25);
    return s ? -v : v;
}

struct Cleanup {
    std::vector<std::function<void()>> steps;
    void add(std::function<void()> f) { steps.push_back(std::move(f)); }
    ~Cleanup() { for (auto it = steps.rbegin(); it != steps.rend(); ++it) (*it)(); }
};

struct Ctx {
    VkInstance inst = VK_NULL_HANDLE;
    VkPhysicalDevice phys = VK_NULL_HANDLE;
    VkDevice dev = VK_NULL_HANDLE;
    VkQueue queue = VK_NULL_HANDLE;
    uint32_t family = 0;
    VkPhysicalDeviceMemoryProperties mem = {};
    VkCommandPool pool = VK_NULL_HANDLE;
};

bool FindMemory(const Ctx& c, uint32_t bits, VkMemoryPropertyFlags want, uint32_t* index) {
    for (uint32_t i = 0; i < c.mem.memoryTypeCount; i++)
        if ((bits & (1u << i)) && (c.mem.memoryTypes[i].propertyFlags & want) == want) { *index = i; return true; }
    return false;
}

#define NEED(expr, what) do { if ((expr) != VK_SUCCESS) { o.bad(std::string(what) + " failed"); return; } } while (0)

const char* kVert =
    "#version 450\n"
    "void main() { vec2 p = vec2(float((gl_VertexIndex << 1) & 2), float(gl_VertexIndex & 2)); gl_Position = vec4(p * 2.0 - 1.0, 0.0, 1.0); }\n";
// Pass A: horizontal ramp in red, constant green, blue = gain (HDR when gain > 1).
const char* kFragA =
    "#version 450\n"
    "layout(std140, set = 0, binding = 0) uniform Params { vec4 tint; vec2 size; float gain; } u;\n"
    "layout(location = 0) out vec4 o;\n"
    "void main() { o = vec4(gl_FragCoord.x / u.size.x, 0.25, u.gain, 1.0) * u.tint; }\n";
// Pass B: samples pass A's image and scales channels.
const char* kFragB =
    "#version 450\n"
    "layout(std140, set = 0, binding = 0) uniform Params { vec4 tint; vec2 size; float gain; } u;\n"
    "layout(set = 0, binding = 1) uniform sampler2D src;\n"
    "layout(location = 0) out vec4 o;\n"
    "void main() { o = texture(src, gl_FragCoord.xy / u.size) * vec4(0.5, 2.0, 1.0, 1.0) * u.tint; }\n";

void RunFormat(Ctx& c, Out& o, VkFormat fmt, const char* name, float gain, float limit, bool half) {
    Cleanup cl;
    VkDevice d = c.dev;
    const uint32_t bpp = half ? 8 : 4;

    rg::GlslCompileResult cv = rg::CompileGlslToSpirv(kVert, rg::GlslDialect::Vulkan, rg::GlslStage::Vertex);
    rg::GlslCompileResult ca = rg::CompileGlslToSpirv(kFragA, rg::GlslDialect::Vulkan, rg::GlslStage::Fragment);
    rg::GlslCompileResult cb = rg::CompileGlslToSpirv(kFragB, rg::GlslDialect::Vulkan, rg::GlslStage::Fragment);
    if (!cv.ok || !ca.ok || !cb.ok) { o.bad(std::string(name) + ": glslang failed: " + cv.log + ca.log + cb.log); return; }

    auto makeModule = [&](const rg::GlslCompileResult& r, VkShaderModule* out) {
        VkShaderModuleCreateInfo si = {VK_STRUCTURE_TYPE_SHADER_MODULE_CREATE_INFO};
        si.codeSize = r.words.size() * 4; si.pCode = r.words.data();
        const VkResult res = vkCreateShaderModule(d, &si, nullptr, out);
        if (res == VK_SUCCESS) { VkShaderModule made = *out; cl.add([=] { vkDestroyShaderModule(d, made, nullptr); }); }
        return res;
    };
    VkShaderModule vs = VK_NULL_HANDLE, fa = VK_NULL_HANDLE, fb = VK_NULL_HANDLE;
    NEED(makeModule(cv, &vs), "vkCreateShaderModule (vertex)");
    NEED(makeModule(ca, &fa), "vkCreateShaderModule (pass A)");
    NEED(makeModule(cb, &fb), "vkCreateShaderModule (pass B)");

    // Two colour images (A written by pass A and sampled by pass B; B written by pass B and copied out).
    struct Img { VkImage image = VK_NULL_HANDLE; VkDeviceMemory memory = VK_NULL_HANDLE; VkImageView view = VK_NULL_HANDLE; VkFramebuffer fb = VK_NULL_HANDLE; } img[2];
    for (int k = 0; k < 2; k++) {
        VkImageCreateInfo ic = {VK_STRUCTURE_TYPE_IMAGE_CREATE_INFO};
        ic.imageType = VK_IMAGE_TYPE_2D; ic.format = fmt; ic.extent.width = W; ic.extent.height = H; ic.extent.depth = 1;
        ic.mipLevels = 1; ic.arrayLayers = 1; ic.samples = VK_SAMPLE_COUNT_1_BIT; ic.tiling = VK_IMAGE_TILING_OPTIMAL;
        ic.usage = VK_IMAGE_USAGE_COLOR_ATTACHMENT_BIT | VK_IMAGE_USAGE_SAMPLED_BIT | VK_IMAGE_USAGE_TRANSFER_SRC_BIT;
        ic.sharingMode = VK_SHARING_MODE_EXCLUSIVE; ic.initialLayout = VK_IMAGE_LAYOUT_UNDEFINED;
        NEED(vkCreateImage(d, &ic, nullptr, &img[k].image), "vkCreateImage");
        VkImage image = img[k].image;
        cl.add([=] { vkDestroyImage(d, image, nullptr); });
        VkMemoryRequirements mr; vkGetImageMemoryRequirements(d, img[k].image, &mr);
        VkMemoryAllocateInfo ai = {VK_STRUCTURE_TYPE_MEMORY_ALLOCATE_INFO};
        ai.allocationSize = mr.size;
        if (!FindMemory(c, mr.memoryTypeBits, VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT, &ai.memoryTypeIndex) && !FindMemory(c, mr.memoryTypeBits, 0, &ai.memoryTypeIndex)) { o.bad(std::string(name) + ": no memory type for the image"); return; }
        NEED(vkAllocateMemory(d, &ai, nullptr, &img[k].memory), "vkAllocateMemory (image)");
        VkDeviceMemory memory = img[k].memory;
        cl.add([=] { vkFreeMemory(d, memory, nullptr); });
        NEED(vkBindImageMemory(d, img[k].image, img[k].memory, 0), "vkBindImageMemory");
        VkImageViewCreateInfo vi = {VK_STRUCTURE_TYPE_IMAGE_VIEW_CREATE_INFO};
        vi.image = img[k].image; vi.viewType = VK_IMAGE_VIEW_TYPE_2D; vi.format = fmt;
        vi.subresourceRange.aspectMask = VK_IMAGE_ASPECT_COLOR_BIT; vi.subresourceRange.levelCount = 1; vi.subresourceRange.layerCount = 1;
        NEED(vkCreateImageView(d, &vi, nullptr, &img[k].view), "vkCreateImageView");
        VkImageView view = img[k].view;
        cl.add([=] { vkDestroyImageView(d, view, nullptr); });
    }

    // Render passes: A ends readable by a shader, B ends readable by a transfer (the copy to the CPU buffer).
    auto makePass = [&](VkImageLayout finalLayout, VkRenderPass* out) {
        VkAttachmentDescription at = {};
        at.format = fmt; at.samples = VK_SAMPLE_COUNT_1_BIT; at.loadOp = VK_ATTACHMENT_LOAD_OP_CLEAR; at.storeOp = VK_ATTACHMENT_STORE_OP_STORE;
        at.stencilLoadOp = VK_ATTACHMENT_LOAD_OP_DONT_CARE; at.stencilStoreOp = VK_ATTACHMENT_STORE_OP_DONT_CARE;
        at.initialLayout = VK_IMAGE_LAYOUT_UNDEFINED; at.finalLayout = finalLayout;
        VkAttachmentReference ref = {0, VK_IMAGE_LAYOUT_COLOR_ATTACHMENT_OPTIMAL};
        VkSubpassDescription sp = {};
        sp.pipelineBindPoint = VK_PIPELINE_BIND_POINT_GRAPHICS; sp.colorAttachmentCount = 1; sp.pColorAttachments = &ref;
        VkSubpassDependency dep = {};
        dep.srcSubpass = 0; dep.dstSubpass = VK_SUBPASS_EXTERNAL;
        dep.srcStageMask = VK_PIPELINE_STAGE_COLOR_ATTACHMENT_OUTPUT_BIT;
        dep.dstStageMask = VK_PIPELINE_STAGE_FRAGMENT_SHADER_BIT | VK_PIPELINE_STAGE_TRANSFER_BIT;
        dep.srcAccessMask = VK_ACCESS_COLOR_ATTACHMENT_WRITE_BIT;
        dep.dstAccessMask = VK_ACCESS_SHADER_READ_BIT | VK_ACCESS_TRANSFER_READ_BIT;
        VkRenderPassCreateInfo rp = {VK_STRUCTURE_TYPE_RENDER_PASS_CREATE_INFO};
        rp.attachmentCount = 1; rp.pAttachments = &at; rp.subpassCount = 1; rp.pSubpasses = &sp; rp.dependencyCount = 1; rp.pDependencies = &dep;
        const VkResult res = vkCreateRenderPass(d, &rp, nullptr, out);
        if (res == VK_SUCCESS) { VkRenderPass made = *out; cl.add([=] { vkDestroyRenderPass(d, made, nullptr); }); }
        return res;
    };
    VkRenderPass rpA = VK_NULL_HANDLE, rpB = VK_NULL_HANDLE;
    NEED(makePass(VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL, &rpA), "vkCreateRenderPass (A)");
    NEED(makePass(VK_IMAGE_LAYOUT_TRANSFER_SRC_OPTIMAL, &rpB), "vkCreateRenderPass (B)");
    for (int k = 0; k < 2; k++) {
        VkFramebufferCreateInfo fi = {VK_STRUCTURE_TYPE_FRAMEBUFFER_CREATE_INFO};
        fi.renderPass = k == 0 ? rpA : rpB; fi.attachmentCount = 1; fi.pAttachments = &img[k].view; fi.width = W; fi.height = H; fi.layers = 1;
        NEED(vkCreateFramebuffer(d, &fi, nullptr, &img[k].fb), "vkCreateFramebuffer");
        VkFramebuffer fbuf = img[k].fb;
        cl.add([=] { vkDestroyFramebuffer(d, fbuf, nullptr); });
    }

    // One descriptor layout for both passes: binding 0 = uniform block, binding 1 = sampled image.
    VkDescriptorSetLayoutBinding bind[2] = {};
    bind[0].binding = 0; bind[0].descriptorType = VK_DESCRIPTOR_TYPE_UNIFORM_BUFFER; bind[0].descriptorCount = 1; bind[0].stageFlags = VK_SHADER_STAGE_FRAGMENT_BIT;
    bind[1].binding = 1; bind[1].descriptorType = VK_DESCRIPTOR_TYPE_COMBINED_IMAGE_SAMPLER; bind[1].descriptorCount = 1; bind[1].stageFlags = VK_SHADER_STAGE_FRAGMENT_BIT;
    VkDescriptorSetLayoutCreateInfo dl = {VK_STRUCTURE_TYPE_DESCRIPTOR_SET_LAYOUT_CREATE_INFO};
    dl.bindingCount = 2; dl.pBindings = bind;
    VkDescriptorSetLayout setLayout = VK_NULL_HANDLE;
    NEED(vkCreateDescriptorSetLayout(d, &dl, nullptr, &setLayout), "vkCreateDescriptorSetLayout");
    cl.add([=] { vkDestroyDescriptorSetLayout(d, setLayout, nullptr); });
    VkPipelineLayoutCreateInfo pl = {VK_STRUCTURE_TYPE_PIPELINE_LAYOUT_CREATE_INFO};
    pl.setLayoutCount = 1; pl.pSetLayouts = &setLayout;
    VkPipelineLayout pipeLayout = VK_NULL_HANDLE;
    NEED(vkCreatePipelineLayout(d, &pl, nullptr, &pipeLayout), "vkCreatePipelineLayout");
    cl.add([=] { vkDestroyPipelineLayout(d, pipeLayout, nullptr); });

    auto makePipeline = [&](VkShaderModule frag, VkRenderPass rp, VkPipeline* out) {
        VkPipelineShaderStageCreateInfo st[2] = {};
        st[0].sType = VK_STRUCTURE_TYPE_PIPELINE_SHADER_STAGE_CREATE_INFO; st[0].stage = VK_SHADER_STAGE_VERTEX_BIT; st[0].module = vs; st[0].pName = "main";
        st[1].sType = VK_STRUCTURE_TYPE_PIPELINE_SHADER_STAGE_CREATE_INFO; st[1].stage = VK_SHADER_STAGE_FRAGMENT_BIT; st[1].module = frag; st[1].pName = "main";
        VkPipelineVertexInputStateCreateInfo vi = {VK_STRUCTURE_TYPE_PIPELINE_VERTEX_INPUT_STATE_CREATE_INFO};
        VkPipelineInputAssemblyStateCreateInfo ia = {VK_STRUCTURE_TYPE_PIPELINE_INPUT_ASSEMBLY_STATE_CREATE_INFO};
        ia.topology = VK_PRIMITIVE_TOPOLOGY_TRIANGLE_LIST;
        VkPipelineViewportStateCreateInfo vp = {VK_STRUCTURE_TYPE_PIPELINE_VIEWPORT_STATE_CREATE_INFO};
        vp.viewportCount = 1; vp.scissorCount = 1;
        VkPipelineRasterizationStateCreateInfo rs = {VK_STRUCTURE_TYPE_PIPELINE_RASTERIZATION_STATE_CREATE_INFO};
        rs.polygonMode = VK_POLYGON_MODE_FILL; rs.cullMode = VK_CULL_MODE_NONE; rs.frontFace = VK_FRONT_FACE_COUNTER_CLOCKWISE; rs.lineWidth = 1.0f;
        VkPipelineMultisampleStateCreateInfo ms = {VK_STRUCTURE_TYPE_PIPELINE_MULTISAMPLE_STATE_CREATE_INFO};
        ms.rasterizationSamples = VK_SAMPLE_COUNT_1_BIT;
        VkPipelineColorBlendAttachmentState cba = {};
        cba.colorWriteMask = VK_COLOR_COMPONENT_R_BIT | VK_COLOR_COMPONENT_G_BIT | VK_COLOR_COMPONENT_B_BIT | VK_COLOR_COMPONENT_A_BIT;
        VkPipelineColorBlendStateCreateInfo cbs = {VK_STRUCTURE_TYPE_PIPELINE_COLOR_BLEND_STATE_CREATE_INFO};
        cbs.attachmentCount = 1; cbs.pAttachments = &cba;
        VkDynamicState dyn[2] = {VK_DYNAMIC_STATE_VIEWPORT, VK_DYNAMIC_STATE_SCISSOR};
        VkPipelineDynamicStateCreateInfo ds = {VK_STRUCTURE_TYPE_PIPELINE_DYNAMIC_STATE_CREATE_INFO};
        ds.dynamicStateCount = 2; ds.pDynamicStates = dyn;
        VkGraphicsPipelineCreateInfo gp = {VK_STRUCTURE_TYPE_GRAPHICS_PIPELINE_CREATE_INFO};
        gp.stageCount = 2; gp.pStages = st; gp.pVertexInputState = &vi; gp.pInputAssemblyState = &ia; gp.pViewportState = &vp;
        gp.pRasterizationState = &rs; gp.pMultisampleState = &ms; gp.pColorBlendState = &cbs; gp.pDynamicState = &ds;
        gp.layout = pipeLayout; gp.renderPass = rp; gp.subpass = 0;
        const VkResult res = vkCreateGraphicsPipelines(d, VK_NULL_HANDLE, 1, &gp, nullptr, out);
        if (res == VK_SUCCESS) { VkPipeline made = *out; cl.add([=] { vkDestroyPipeline(d, made, nullptr); }); }
        return res;
    };
    VkPipeline pipeA = VK_NULL_HANDLE, pipeB = VK_NULL_HANDLE;
    NEED(makePipeline(fa, rpA, &pipeA), "vkCreateGraphicsPipelines (pass A)");
    NEED(makePipeline(fb, rpB, &pipeB), "vkCreateGraphicsPipelines (pass B)");

    // Host-visible buffers: the uniform block and the read-back copy of image B.
    struct Buf { VkBuffer buffer = VK_NULL_HANDLE; VkDeviceMemory memory = VK_NULL_HANDLE; void* map = nullptr; };
    auto makeBuffer = [&](VkDeviceSize size, VkBufferUsageFlags usage, Buf* b) -> VkResult {
        VkBufferCreateInfo bi = {VK_STRUCTURE_TYPE_BUFFER_CREATE_INFO};
        bi.size = size; bi.usage = usage; bi.sharingMode = VK_SHARING_MODE_EXCLUSIVE;
        VkResult res = vkCreateBuffer(d, &bi, nullptr, &b->buffer);
        if (res != VK_SUCCESS) return res;
        VkBuffer buffer = b->buffer;
        cl.add([=] { vkDestroyBuffer(d, buffer, nullptr); });
        VkMemoryRequirements mr; vkGetBufferMemoryRequirements(d, b->buffer, &mr);
        VkMemoryAllocateInfo ai = {VK_STRUCTURE_TYPE_MEMORY_ALLOCATE_INFO};
        ai.allocationSize = mr.size;
        if (!FindMemory(c, mr.memoryTypeBits, VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT | VK_MEMORY_PROPERTY_HOST_COHERENT_BIT, &ai.memoryTypeIndex)) return VK_ERROR_OUT_OF_DEVICE_MEMORY;
        res = vkAllocateMemory(d, &ai, nullptr, &b->memory);
        if (res != VK_SUCCESS) return res;
        VkDeviceMemory memory = b->memory;
        cl.add([=] { vkFreeMemory(d, memory, nullptr); });
        res = vkBindBufferMemory(d, b->buffer, b->memory, 0);
        if (res != VK_SUCCESS) return res;
        return vkMapMemory(d, b->memory, 0, VK_WHOLE_SIZE, 0, &b->map);
    };
    Buf ubo, readback;
    NEED(makeBuffer(32, VK_BUFFER_USAGE_UNIFORM_BUFFER_BIT, &ubo), "uniform buffer");
    NEED(makeBuffer((VkDeviceSize)W * H * bpp, VK_BUFFER_USAGE_TRANSFER_DST_BIT, &readback), "read-back buffer");
    {   // std140: tint at 0, size at 16, gain at 24
        float block[8] = {1.0f, 1.0f, 1.0f, 1.0f, (float)W, (float)H, gain, 0.0f};
        std::memcpy(ubo.map, block, sizeof block);
    }

    VkSamplerCreateInfo sci = {VK_STRUCTURE_TYPE_SAMPLER_CREATE_INFO};
    sci.magFilter = VK_FILTER_NEAREST; sci.minFilter = VK_FILTER_NEAREST; sci.mipmapMode = VK_SAMPLER_MIPMAP_MODE_NEAREST;
    sci.addressModeU = sci.addressModeV = sci.addressModeW = VK_SAMPLER_ADDRESS_MODE_CLAMP_TO_EDGE;
    VkSampler sampler = VK_NULL_HANDLE;
    NEED(vkCreateSampler(d, &sci, nullptr, &sampler), "vkCreateSampler");
    cl.add([=] { vkDestroySampler(d, sampler, nullptr); });

    VkDescriptorPoolSize sizes[2] = {{VK_DESCRIPTOR_TYPE_UNIFORM_BUFFER, 2}, {VK_DESCRIPTOR_TYPE_COMBINED_IMAGE_SAMPLER, 2}};
    VkDescriptorPoolCreateInfo dpi = {VK_STRUCTURE_TYPE_DESCRIPTOR_POOL_CREATE_INFO};
    dpi.maxSets = 2; dpi.poolSizeCount = 2; dpi.pPoolSizes = sizes;
    VkDescriptorPool descPool = VK_NULL_HANDLE;
    NEED(vkCreateDescriptorPool(d, &dpi, nullptr, &descPool), "vkCreateDescriptorPool");
    cl.add([=] { vkDestroyDescriptorPool(d, descPool, nullptr); });
    VkDescriptorSetLayout layouts[2] = {setLayout, setLayout};
    VkDescriptorSetAllocateInfo dsa = {VK_STRUCTURE_TYPE_DESCRIPTOR_SET_ALLOCATE_INFO};
    dsa.descriptorPool = descPool; dsa.descriptorSetCount = 2; dsa.pSetLayouts = layouts;
    VkDescriptorSet sets[2] = {VK_NULL_HANDLE, VK_NULL_HANDLE};
    NEED(vkAllocateDescriptorSets(d, &dsa, sets), "vkAllocateDescriptorSets");
    VkDescriptorBufferInfo bufInfo = {ubo.buffer, 0, 32};
    VkDescriptorImageInfo imgInfo = {sampler, img[0].view, VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL};
    VkWriteDescriptorSet wr[3] = {};
    for (int k = 0; k < 3; k++) wr[k].sType = VK_STRUCTURE_TYPE_WRITE_DESCRIPTOR_SET;
    wr[0].dstSet = sets[0]; wr[0].dstBinding = 0; wr[0].descriptorCount = 1; wr[0].descriptorType = VK_DESCRIPTOR_TYPE_UNIFORM_BUFFER; wr[0].pBufferInfo = &bufInfo;
    wr[1].dstSet = sets[1]; wr[1].dstBinding = 0; wr[1].descriptorCount = 1; wr[1].descriptorType = VK_DESCRIPTOR_TYPE_UNIFORM_BUFFER; wr[1].pBufferInfo = &bufInfo;
    wr[2].dstSet = sets[1]; wr[2].dstBinding = 1; wr[2].descriptorCount = 1; wr[2].descriptorType = VK_DESCRIPTOR_TYPE_COMBINED_IMAGE_SAMPLER; wr[2].pImageInfo = &imgInfo;
    vkUpdateDescriptorSets(d, 3, wr, 0, nullptr);

    VkCommandBufferAllocateInfo cai = {VK_STRUCTURE_TYPE_COMMAND_BUFFER_ALLOCATE_INFO};
    cai.commandPool = c.pool; cai.level = VK_COMMAND_BUFFER_LEVEL_PRIMARY; cai.commandBufferCount = 1;
    VkCommandBuffer cmd = VK_NULL_HANDLE;
    NEED(vkAllocateCommandBuffers(d, &cai, &cmd), "vkAllocateCommandBuffers");
    cl.add([=] { vkFreeCommandBuffers(d, c.pool, 1, &cmd); });
    VkCommandBufferBeginInfo bi = {VK_STRUCTURE_TYPE_COMMAND_BUFFER_BEGIN_INFO};
    bi.flags = VK_COMMAND_BUFFER_USAGE_ONE_TIME_SUBMIT_BIT;
    NEED(vkBeginCommandBuffer(cmd, &bi), "vkBeginCommandBuffer");

    VkViewport viewport = {0.0f, 0.0f, (float)W, (float)H, 0.0f, 1.0f};
    VkRect2D scissor = {{0, 0}, {W, H}};
    VkClearValue clear = {};
    for (int k = 0; k < 2; k++) {
        VkRenderPassBeginInfo rb = {VK_STRUCTURE_TYPE_RENDER_PASS_BEGIN_INFO};
        rb.renderPass = k == 0 ? rpA : rpB; rb.framebuffer = img[k].fb; rb.renderArea = scissor; rb.clearValueCount = 1; rb.pClearValues = &clear;
        vkCmdBeginRenderPass(cmd, &rb, VK_SUBPASS_CONTENTS_INLINE);
        vkCmdBindPipeline(cmd, VK_PIPELINE_BIND_POINT_GRAPHICS, k == 0 ? pipeA : pipeB);
        vkCmdSetViewport(cmd, 0, 1, &viewport);
        vkCmdSetScissor(cmd, 0, 1, &scissor);
        vkCmdBindDescriptorSets(cmd, VK_PIPELINE_BIND_POINT_GRAPHICS, pipeLayout, 0, 1, &sets[k], 0, nullptr);
        vkCmdDraw(cmd, 3, 1, 0, 0);
        vkCmdEndRenderPass(cmd);
    }
    VkBufferImageCopy region = {};
    region.imageSubresource.aspectMask = VK_IMAGE_ASPECT_COLOR_BIT; region.imageSubresource.layerCount = 1;
    region.imageExtent.width = W; region.imageExtent.height = H; region.imageExtent.depth = 1;
    vkCmdCopyImageToBuffer(cmd, img[1].image, VK_IMAGE_LAYOUT_TRANSFER_SRC_OPTIMAL, readback.buffer, 1, &region);
    VkBufferMemoryBarrier hostBarrier = {VK_STRUCTURE_TYPE_BUFFER_MEMORY_BARRIER};
    hostBarrier.srcAccessMask = VK_ACCESS_TRANSFER_WRITE_BIT; hostBarrier.dstAccessMask = VK_ACCESS_HOST_READ_BIT;
    hostBarrier.srcQueueFamilyIndex = VK_QUEUE_FAMILY_IGNORED; hostBarrier.dstQueueFamilyIndex = VK_QUEUE_FAMILY_IGNORED;
    hostBarrier.buffer = readback.buffer; hostBarrier.offset = 0; hostBarrier.size = VK_WHOLE_SIZE;
    vkCmdPipelineBarrier(cmd, VK_PIPELINE_STAGE_TRANSFER_BIT, VK_PIPELINE_STAGE_HOST_BIT, 0, 0, nullptr, 1, &hostBarrier, 0, nullptr);
    NEED(vkEndCommandBuffer(cmd), "vkEndCommandBuffer");

    VkFenceCreateInfo fci = {VK_STRUCTURE_TYPE_FENCE_CREATE_INFO};
    VkFence fence = VK_NULL_HANDLE;
    NEED(vkCreateFence(d, &fci, nullptr, &fence), "vkCreateFence");
    cl.add([=] { vkDestroyFence(d, fence, nullptr); });
    VkSubmitInfo si = {VK_STRUCTURE_TYPE_SUBMIT_INFO};
    si.commandBufferCount = 1; si.pCommandBuffers = &cmd;
    NEED(vkQueueSubmit(c.queue, 1, &si, fence), "vkQueueSubmit");
    const VkResult waited = vkWaitForFences(d, 1, &fence, VK_TRUE, 5000000000ull);
    if (waited != VK_SUCCESS) { o.bad(std::string(name) + ": the GPU did not finish within 5 s (result " + std::to_string((int)waited) + ")"); vkDeviceWaitIdle(d); return; }

    // CPU expectation for pass B's output: red = ramp * 0.5, green = 0.25 * 2, blue = gain, alpha = 1.
    double worst = 0; int worstX = 0, worstY = 0, worstC = 0;
    const uint8_t* bytes = static_cast<const uint8_t*>(readback.map);
    for (uint32_t y = 0; y < H; y++) for (uint32_t x = 0; x < W; x++) {
        const double expect[4] = {((x + 0.5) / W) * 0.5, 0.5, gain, 1.0};
        for (int ch = 0; ch < 4; ch++) {
            double got;
            if (half) { uint16_t h16; std::memcpy(&h16, bytes + ((size_t)y * W + x) * 8 + ch * 2, 2); got = HalfToFloat(h16); }
            else got = bytes[((size_t)y * W + x) * 4 + ch] / 255.0;
            const double err = std::fabs(got - expect[ch]);
            if (!(err <= worst)) { worst = std::isnan(err) ? 1e9 : err; worstX = (int)x; worstY = (int)y; worstC = ch; }
        }
    }
    char text[200];
    std::snprintf(text, sizeof text, "%s: two Vulkan passes (UBO, then sampled image) match the CPU, max error %.5g (limit %.5g)", name, worst, limit);
    if (worst <= limit) o.ok(text);
    else {
        char at[120]; std::snprintf(at, sizeof at, " at x=%d y=%d channel %d", worstX, worstY, worstC);
        o.bad(std::string(text) + at);
    }
    vkDeviceWaitIdle(d);
}

#endif  // AM_VK_EXEC

}  // namespace

void RunVulkanExecTest(std::string* text, int* pass, int* fail, const std::string& cacheDir) {
    Out o = {text, pass, fail};
#ifndef AM_VK_EXEC
    (void)cacheDir;
    o.line("SKIP  this build has no Vulkan headers");
#else
    if (!rg::GlslangAvailable()) { o.bad("no glslang in this build, so there is nothing to execute"); return; }
    const std::string crumb = cacheDir + "/vkexec.stage";
    if (access(crumb.c_str(), F_OK) == 0) {
        unlink(crumb.c_str());
        o.bad("CRASH in a previous run of this section; skipped once so the rest of the report still appears");
        return;
    }
    if (FILE* f = std::fopen(crumb.c_str(), "w")) { std::fputs("running\n", f); std::fflush(f); fsync(fileno(f)); std::fclose(f); }

    Ctx c;
    {
        Cleanup cl;
        VkApplicationInfo ai = {VK_STRUCTURE_TYPE_APPLICATION_INFO};
        ai.apiVersion = VK_API_VERSION_1_1;
        VkInstanceCreateInfo ici = {VK_STRUCTURE_TYPE_INSTANCE_CREATE_INFO};
        ici.pApplicationInfo = &ai;
        if (vkCreateInstance(&ici, nullptr, &c.inst) != VK_SUCCESS) { o.bad("vkCreateInstance failed"); unlink(crumb.c_str()); return; }
        cl.add([&] { vkDestroyInstance(c.inst, nullptr); });
        uint32_t n = 0;
        vkEnumeratePhysicalDevices(c.inst, &n, nullptr);
        std::vector<VkPhysicalDevice> devs(n);
        if (n) vkEnumeratePhysicalDevices(c.inst, &n, devs.data());
        for (VkPhysicalDevice p : devs) {
            uint32_t qn = 0;
            vkGetPhysicalDeviceQueueFamilyProperties(p, &qn, nullptr);
            std::vector<VkQueueFamilyProperties> qf(qn);
            if (qn) vkGetPhysicalDeviceQueueFamilyProperties(p, &qn, qf.data());
            for (uint32_t i = 0; i < qn && !c.phys; i++)
                if (qf[i].queueFlags & VK_QUEUE_GRAPHICS_BIT) { c.phys = p; c.family = i; }
            if (c.phys) break;
        }
        if (!c.phys) { o.bad("no Vulkan device with a graphics queue"); unlink(crumb.c_str()); return; }
        vkGetPhysicalDeviceMemoryProperties(c.phys, &c.mem);
        VkPhysicalDeviceProperties props;
        vkGetPhysicalDeviceProperties(c.phys, &props);
        o.line(std::string("      device: ") + props.deviceName);

        float priority = 1.0f;
        VkDeviceQueueCreateInfo qi = {VK_STRUCTURE_TYPE_DEVICE_QUEUE_CREATE_INFO};
        qi.queueFamilyIndex = c.family; qi.queueCount = 1; qi.pQueuePriorities = &priority;
        VkDeviceCreateInfo dci = {VK_STRUCTURE_TYPE_DEVICE_CREATE_INFO};
        dci.queueCreateInfoCount = 1; dci.pQueueCreateInfos = &qi;
        if (vkCreateDevice(c.phys, &dci, nullptr, &c.dev) != VK_SUCCESS) { o.bad("vkCreateDevice failed"); unlink(crumb.c_str()); return; }
        cl.add([&] { vkDestroyDevice(c.dev, nullptr); });
        vkGetDeviceQueue(c.dev, c.family, 0, &c.queue);
        VkCommandPoolCreateInfo pi = {VK_STRUCTURE_TYPE_COMMAND_POOL_CREATE_INFO};
        pi.queueFamilyIndex = c.family;
        if (vkCreateCommandPool(c.dev, &pi, nullptr, &c.pool) != VK_SUCCESS) { o.bad("vkCreateCommandPool failed"); unlink(crumb.c_str()); return; }
        cl.add([&] { vkDestroyCommandPool(c.dev, c.pool, nullptr); });

        RunFormat(c, o, VK_FORMAT_R8G8B8A8_UNORM, "RGBA8", 0.5f, 0.011765f, false);
        RunFormat(c, o, VK_FORMAT_R16G16B16A16_SFLOAT, "RGBA16F (blue = 2.0, above 1)", 2.0f, 0.002f, true);
        o.line("      This ran glslang's SPIR-V directly on the Vulkan driver, no conversion. The effect backend that uses it is tested in the bridge section (stage vulkan).");
    }
    unlink(crumb.c_str());
#endif
}

}  // namespace am

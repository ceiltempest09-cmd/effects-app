// Host test for am::HistorySignature (shared/cpp/history_signature.h).
//   g++ -std=c++20 -Wall -Wextra -I shared/cpp tests/native/history_signature_test.cpp -o /tmp/hs && /tmp/hs
#include "history_signature.h"

#include <cmath>
#include <cstdio>
#include <limits>
#include <set>
#include <vector>

static int gFailed = 0, gChecks = 0;
#define CHECK(cond) do { gChecks++; if (!(cond)) { gFailed++; std::printf("  FAIL %s:%d  %s\n", __FILE__, __LINE__, #cond); } } while (0)

using am::HistorySignature;

// A stand-in for LayerEffect: the same fields effects.cpp feeds into the signature, hashed the same way.
struct Key { float t; std::vector<float> v; int easing; };
struct Prop { std::string name, type, text; std::vector<float> value; std::vector<Key> keys; };

static uint64_t Sign(const std::string& id, int w, int h, int start, int end, int fps, const std::vector<Prop>& props) {
    HistorySignature hs;
    hs.str(id).u64((uint64_t)w << 20 | (uint64_t)h).i64(start).i64(end).i64(fps * 1000).u64(props.size());
    for (const Prop& p : props) {
        hs.str(p.name).str(p.type).str(p.text).u64(p.value.size());
        for (float v : p.value) hs.f32(v);
        hs.u64(p.keys.size());
        for (const Key& k : p.keys) { hs.f32(k.t).u64(k.v.size()); for (float v : k.v) hs.f32(v); hs.u64((uint64_t)k.easing); }
    }
    return hs.value();
}

int main() {
    const std::vector<Prop> base = {{"samples", "float", "", {64}, {}}, {"bounce", "float", "", {3}, {{0, {1}, 0}, {2, {5}, 1}}}};
    const uint64_t s0 = Sign("fx.raytraced", 1920, 1080, 0, 5000, 30, base);

    std::printf("signature changes when an edit changes earlier frames\n");
    CHECK(Sign("fx.raytraced", 1920, 1080, 0, 5000, 30, base) == s0);                       // deterministic
    { auto p = base; p[0].value[0] = 65;            CHECK(Sign("fx.raytraced", 1920, 1080, 0, 5000, 30, p) != s0); }   // static value (old code: same!)
    { auto p = base; p[1].keys[1].v[0] = 6;         CHECK(Sign("fx.raytraced", 1920, 1080, 0, 5000, 30, p) != s0); }   // keyframe value
    { auto p = base; p[1].keys[1].t = 2.5f;         CHECK(Sign("fx.raytraced", 1920, 1080, 0, 5000, 30, p) != s0); }   // keyframe time
    { auto p = base; p[1].keys[1].easing = 2;       CHECK(Sign("fx.raytraced", 1920, 1080, 0, 5000, 30, p) != s0); }   // easing curve
    { auto p = base; p[0].text = "x";               CHECK(Sign("fx.raytraced", 1920, 1080, 0, 5000, 30, p) != s0); }
    { auto p = base; p.pop_back();                  CHECK(Sign("fx.raytraced", 1920, 1080, 0, 5000, 30, p) != s0); }
    CHECK(Sign("fx.raytraced", 1280, 720, 0, 5000, 30, base) != s0);                        // render size
    CHECK(Sign("fx.raytraced", 1920, 1080, 100, 5000, 30, base) != s0);                     // clip moved
    CHECK(Sign("fx.raytraced", 1920, 1080, 0, 5000, 60, base) != s0);                       // frame rate
    CHECK(Sign("fx.other", 1920, 1080, 0, 5000, 30, base) != s0);                           // another effect

    std::printf("hash hygiene\n");
    { HistorySignature a, b; a.str("ab").str("c"); b.str("a").str("bc"); CHECK(a.value() != b.value()); }   // length prefix
    { HistorySignature a, b; a.f32(0.0f); b.f32(-0.0f); CHECK(a.value() == b.value()); }                  // -0 == +0
    { const float nan1 = std::numeric_limits<float>::quiet_NaN(), nan2 = -std::numeric_limits<float>::quiet_NaN();
      HistorySignature a, b; a.f32(nan1); b.f32(nan2); CHECK(a.value() == b.value()); }
    { HistorySignature a, b; a.f32(1.0f); b.f32(1.0000001f); CHECK(a.value() != b.value()); }             // one ulp differs
    {   // no collisions over a sweep of small integers (the case the old xor-multiply mix handled worst)
        std::set<uint64_t> seen;
        for (int i = 0; i < 200000; i++) { HistorySignature h; h.u64((uint64_t)i); seen.insert(h.value()); }
        CHECK(seen.size() == 200000);
    }

    std::printf("%d checks, %d failed\n", gChecks, gFailed);
    return gFailed ? 1 : 0;
}

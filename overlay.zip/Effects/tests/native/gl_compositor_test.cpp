// gl_compositor on a real GL driver: transform, opacity, masks, blend modes, gradients, tone map.
#include "gl_compositor.h"
#include "glsl_library.h"

#include <cmath>
#include <cstdio>

using namespace am;
static int gFailed = 0, gChecks = 0;
#define CHECK_MSG(cond, msg) do { gChecks++; if (!(cond)) { gFailed++; std::printf("  FAIL %s:%d  %s -- %s\n", __FILE__, __LINE__, #cond, std::string(msg).c_str()); } } while (0)
#define CHECK_NEAR(a, b, eps) do { gChecks++; const double _a = (a), _b = (b); if (!(std::fabs(_a - _b) <= (eps))) { gFailed++; std::printf("  FAIL %s:%d  %s=%g vs %s=%g (eps %g)\n", __FILE__, __LINE__, #a, _a, #b, _b, (double)(eps)); } } while (0)

static rg::GlBackend* gBe;
static rg::Target* Solid(int w, int h, float r, float g, float b, float a) {   // premultiplied by the caller
    std::vector<float> v((size_t)w * h * 4);
    for (size_t i = 0; i < v.size(); i += 4) { v[i] = r; v[i + 1] = g; v[i + 2] = b; v[i + 3] = a; }
    return gBe->createFromFloats(w, h, rg::Format::RGBA8, v.data());
}
struct Px { float r, g, b, a; };
static Px At(const std::vector<float>& f, int w, int x, int y) { const float* p = &f[((size_t)y * w + x) * 4]; return {p[0], p[1], p[2], p[3]}; }
static void CheckPx(const char* what, Px p, float r, float g, float b, float a, float eps = 0.012f) {
    const bool ok = std::fabs(p.r - r) <= eps && std::fabs(p.g - g) <= eps && std::fabs(p.b - b) <= eps && std::fabs(p.a - a) <= eps;
    gChecks++;
    if (!ok) { gFailed++; std::printf("  FAIL %s: got (%.3f %.3f %.3f %.3f) want (%.3f %.3f %.3f %.3f)\n", what, p.r, p.g, p.b, p.a, r, g, b, a); }
}
static std::vector<float> Read(rg::Target* t) { std::vector<float> f; gBe->readback(t, &f); return f; }

int main() {
    std::string err;
    auto ctx = rg::GlContext::Create(rg::GlContext::Api::ES, &err);
    if (!ctx) { std::printf("SKIP: no GLES (%s)\n", err.c_str()); return 0; }
    rg::GlBackend be(*ctx);
    if (!be.ok()) { std::printf("SKIP: %s\n", be.error().c_str()); return 0; }
    gBe = &be;
    comp::Compositor C(be);
    const int W = 64, H = 48;

    std::printf("affine math\n");
    {
        comp::Affine m = comp::Affine::Scale(2, 3).then(comp::Affine::Translate(5, 7)), inv;
        CHECK_MSG(m.invert(&inv), "invertible");
        const float x = 4, y = 6, X = m.a * x + m.c * y + m.e, Y = m.b * x + m.d * y + m.f;
        CHECK_NEAR(inv.a * X + inv.c * Y + inv.e, x, 1e-4); CHECK_NEAR(inv.b * X + inv.d * Y + inv.f, y, 1e-4);
        comp::Affine z = comp::Affine::Scale(0, 1), zi;
        CHECK_MSG(!z.invert(&zi), "singular matrix refuses");
        comp::Affine r = comp::Affine::Rotate(3.14159265f / 2);
        CHECK_NEAR(r.a * 1 + r.c * 0, 0, 1e-5); CHECK_NEAR(r.b * 1 + r.d * 0, 1, 1e-5);
    }

    std::printf("translate: layer lands where the transform says (top-left origin)\n");
    {
        rg::Target* red = Solid(16, 8, 1, 0, 0, 1);
        comp::Layer L; L.image = red; L.transform = comp::Affine::Translate(10, 20);
        rg::Target* out = C.render(W, H, {L});
        CHECK_MSG(out != nullptr, C.error());
        if (out) {
            const auto f = Read(out);
            CheckPx("inside (12,22)", At(f, W, 12, 22), 1, 0, 0, 1);
            CheckPx("inside (25,27)", At(f, W, 25, 27), 1, 0, 0, 1);
            CheckPx("above (12,18)", At(f, W, 12, 18), 0, 0, 0, 0);
            CheckPx("left (8,22)", At(f, W, 8, 22), 0, 0, 0, 0);
            CheckPx("right (27,22)", At(f, W, 27, 22), 0, 0, 0, 0);
            CheckPx("below (12,29)", At(f, W, 12, 29), 0, 0, 0, 0);
            C.release(out);
        }
        be.destroy(red);
    }

    std::printf("opacity and source-over on a background\n");
    {
        rg::Target* red = Solid(W, H, 1, 0, 0, 1);
        comp::Layer L; L.image = red; L.opacity = 0.5f;
        const float bg[4] = {0, 1, 0, 1};
        rg::Target* out = C.render(W, H, {L}, bg);
        CHECK_MSG(out != nullptr, C.error());
        if (out) { CheckPx("half red over green", At(Read(out), W, 30, 20), 0.5f, 0.5f, 0, 1); C.release(out); }
        be.destroy(red);
    }

    std::printf("rotation by 90 degrees about a translated pivot\n");
    {
        rg::Target* bar = Solid(20, 4, 0, 0, 1, 1);
        comp::Layer L; L.image = bar; L.transform = comp::Affine::Rotate(3.14159265f / 2).then(comp::Affine::Translate(30, 5));
        rg::Target* out = C.render(W, H, {L});
        CHECK_MSG(out != nullptr, C.error());
        if (out) {
            const auto f = Read(out);   // x' = -y + 30 in [26,30], y' = x + 5 in [5,25]
            CheckPx("vertical bar (28,15)", At(f, W, 28, 15), 0, 0, 1, 1);
            CheckPx("beside bar (35,15)", At(f, W, 35, 15), 0, 0, 0, 0);
            CheckPx("below bar (28,30)", At(f, W, 28, 30), 0, 0, 0, 0);
            C.release(out);
        }
        be.destroy(bar);
    }

    std::printf("scale up uses bilinear and a soft edge, nearest keeps hard texels\n");
    {
        std::vector<float> v = {1, 0, 0, 1,  0, 0, 1, 1};   // 2x1: red | blue
        rg::Target* two = be.createFromFloats(2, 1, rg::Format::RGBA8, v.data());
        comp::Layer L; L.image = two; L.transform = comp::Affine::Scale(8, 8); L.smooth = false;
        rg::Target* out = C.render(W, H, {L});
        if (out) { const auto f = Read(out); CheckPx("nearest left", At(f, W, 3, 3), 1, 0, 0, 1); CheckPx("nearest right", At(f, W, 12, 3), 0, 0, 1, 1); C.release(out); }
        L.smooth = true;
        out = C.render(W, H, {L});
        if (out) { const auto f = Read(out); const Px mid = At(f, W, 8, 3); CHECK_MSG(mid.r > 0.2f && mid.r < 0.8f && mid.b > 0.2f && mid.b < 0.8f, "bilinear blends across the texel boundary"); C.release(out); }
        be.destroy(two);
    }

    std::printf("masks\n");
    {
        rg::Target* white = Solid(W, H, 1, 1, 1, 1);
        std::vector<float> m((size_t)W * H * 4, 0.0f);
        for (int y = 0; y < H; y++) for (int x = 0; x < W; x++) if (x < W / 2) { float* p = &m[((size_t)y * W + x) * 4]; p[0] = p[1] = p[2] = p[3] = 1; }
        rg::Target* mask = be.createFromFloats(W, H, rg::Format::RGBA8, m.data());
        comp::Layer L; L.image = white; L.mask = mask; L.maskMode = comp::MaskMode::Alpha;
        rg::Target* out = C.render(W, H, {L});
        if (out) { const auto f = Read(out); CheckPx("alpha mask keeps left", At(f, W, 10, 10), 1, 1, 1, 1); CheckPx("alpha mask removes right", At(f, W, 50, 10), 0, 0, 0, 0); C.release(out); }
        L.maskMode = comp::MaskMode::InvertedAlpha;
        out = C.render(W, H, {L});
        if (out) { const auto f = Read(out); CheckPx("inverted keeps right", At(f, W, 50, 10), 1, 1, 1, 1); CheckPx("inverted removes left", At(f, W, 10, 10), 0, 0, 0, 0); C.release(out); }
        L.maskMode = comp::MaskMode::Luma;
        out = C.render(W, H, {L});
        if (out) { const auto f = Read(out); CheckPx("luma keeps white", At(f, W, 10, 10), 1, 1, 1, 1); CheckPx("luma removes black", At(f, W, 50, 10), 0, 0, 0, 0); C.release(out); }
        be.destroy(mask); be.destroy(white);
    }

    std::printf("blend modes against CPU references\n");
    {
        const float bgc[4] = {0.5f, 0.25f, 0.75f, 1}, sc[3] = {0.8f, 0.5f, 0.2f};
        rg::Target* src = Solid(W, H, sc[0], sc[1], sc[2], 1);
        struct Ref { const char* id; float (*f)(float s, float b); };
        static const Ref refs[] = {
            {"normal", [](float s, float) { return s; }},
            {"screen", [](float s, float b) { return s + b - s * b; }},
            {"multiply", [](float s, float b) { return s * b; }},
            {"diff", [](float s, float b) { return std::fabs(b - s); }},
            {"exclusion", [](float s, float b) { return s + b - 2 * s * b; }},
            {"lighten", [](float s, float b) { return std::fmax(s, b); }},
            {"darken", [](float s, float b) { return std::fmin(s, b); }},
            {"linear-burn", [](float s, float b) { return std::fmax(0.f, s + b - 1); }},
            {"linear-dodge", [](float s, float b) { return std::fmin(1.f, s + b); }},
            {"subtract", [](float s, float b) { return std::fmax(0.f, b - s); }},
            {"hard-light", [](float s, float b) { return s <= 0.5f ? b * 2 * s : 1 - (1 - b) * (2 - 2 * s); }},
            {"overlay", [](float s, float b) { return b <= 0.5f ? s * 2 * b : 1 - (1 - s) * (2 - 2 * b); }},
        };
        for (const Ref& r : refs) {
            comp::Layer L; L.image = src; L.blend = r.id;
            rg::Target* out = C.render(W, H, {L}, bgc);
            CHECK_MSG(out != nullptr, std::string(r.id) + ": " + C.error());
            CHECK_MSG(C.warning().empty(), std::string(r.id) + " warned: " + C.warning());
            if (out) { CheckPx(r.id, At(Read(out), W, 20, 20), r.f(sc[0], bgc[0]), r.f(sc[1], bgc[1]), r.f(sc[2], bgc[2]), 1, 0.015f); C.release(out); }
        }
        // every mode in the library must at least run and keep alpha at 1 over an opaque backdrop
        int ran = 0;
        for (const std::string& id : glsl::BlendModes()) {
            comp::Layer L; L.image = src; L.blend = id;
            rg::Target* out = C.render(W, H, {L}, bgc);
            CHECK_MSG(out != nullptr, id + ": " + C.error());
            if (out) { const Px p = At(Read(out), W, 20, 20); CHECK_NEAR(p.a, 1.0, 0.01); ran++; C.release(out); }
        }
        CHECK_MSG(ran == (int)glsl::BlendModes().size() && ran == 24, "all 24 shader blend modes ran");
        comp::Layer bad; bad.image = src; bad.blend = "no-such-mode";
        rg::Target* out = C.render(W, H, {bad}, bgc);
        CHECK_MSG(out && !C.warning().empty(), "unknown mode warns");
        if (out) { CheckPx("unknown = normal", At(Read(out), W, 5, 5), sc[0], sc[1], sc[2], 1); C.release(out); }
        be.destroy(src);
    }

    std::printf("mask / exclude / clipping-mask blends (alpha operators)\n");
    {
        rg::Target* backdrop = Solid(W, H, 0, 0.5f, 0, 0.5f);    // premultiplied green, alpha 0.5
        rg::Target* top = Solid(W, H, 0.25f, 0, 0, 0.25f);       // premultiplied red, alpha 0.25
        auto run = [&](const char* mode, std::vector<comp::Layer> layers) { (void)mode; return C.render(W, H, layers); };
        comp::Layer base; base.image = backdrop;
        comp::Layer L; L.image = top;
        L.blend = "mask"; if (auto* o = run("mask", {base, L})) { CheckPx("mask DstIn", At(Read(o), W, 9, 9), 0, 0.125f, 0, 0.125f); C.release(o); }
        L.blend = "exclude"; if (auto* o = run("exclude", {base, L})) { CheckPx("exclude DstOut", At(Read(o), W, 9, 9), 0, 0.375f, 0, 0.375f); C.release(o); }
        L.blend = "clipping-mask"; if (auto* o = run("clip", {base, L})) { CheckPx("clipping SrcATop", At(Read(o), W, 9, 9), 0.125f, 0.375f, 0, 0.5f); C.release(o); }
        be.destroy(backdrop); be.destroy(top);
    }

    std::printf("layer stack order and a collapsed layer\n");
    {
        rg::Target* a = Solid(W, H, 1, 0, 0, 1); rg::Target* b = Solid(W, H, 0, 0, 1, 1);
        comp::Layer la; la.image = a; comp::Layer lb; lb.image = b;
        rg::Target* out = C.render(W, H, {la, lb});
        if (out) { CheckPx("top layer wins", At(Read(out), W, 4, 4), 0, 0, 1, 1); C.release(out); }
        lb.transform = comp::Affine::Scale(0, 0);
        out = C.render(W, H, {la, lb});
        if (out) { CheckPx("collapsed layer draws nothing", At(Read(out), W, 4, 4), 1, 0, 0, 1); C.release(out); }
        be.destroy(a); be.destroy(b);
    }

    std::printf("gradients\n");
    {
        comp::Gradient g; g.kind = comp::Gradient::Linear;
        g.c0[0] = 1; g.c0[1] = 0; g.c0[2] = 0; g.c1[0] = 0; g.c1[1] = 0; g.c1[2] = 1;
        g.p0[0] = 0; g.p0[1] = 0; g.p1[0] = 1; g.p1[1] = 0;
        rg::Target* gr = C.gradient(W, H, g);
        CHECK_MSG(gr != nullptr, C.error());
        if (gr) {
            const auto f = Read(gr);
            CheckPx("linear start", At(f, W, 0, 10), 1, 0, 0, 1, 0.03f);
            CheckPx("linear end", At(f, W, W - 1, 10), 0, 0, 1, 1, 0.03f);
            const Px mid = At(f, W, W / 2, 10); CHECK_NEAR(mid.r, 0.5, 0.05); CHECK_NEAR(mid.b, 0.5, 0.05);
            C.release(gr);
        }
        g.kind = comp::Gradient::Radial; g.p0[0] = 0.5f; g.p0[1] = 0.5f; g.p1[0] = 1.0f; g.p1[1] = 0.5f;
        gr = C.gradient(W, H, g);
        if (gr) { const auto f = Read(gr); CheckPx("radial centre", At(f, W, W / 2, H / 2), 1, 0, 0, 1, 0.03f); CheckPx("radial corner", At(f, W, 0, 0), 0, 0, 1, 1, 0.03f); C.release(gr); }
    }

    std::printf("HDR display tone map\n");
    {
        std::vector<float> v((size_t)8 * 8 * 4);
        for (size_t i = 0; i < v.size(); i += 4) { v[i] = 0.25f; v[i + 1] = 0.25f; v[i + 2] = 0.25f; v[i + 3] = 1; }
        rg::Target* src = be.createFromFloats(8, 8, rg::Format::RGBA16F, v.data());
        comp::ToneMap t; t.linearIn = true;
        rg::Target* out = C.toneMap(src, t);
        CHECK_MSG(out != nullptr, C.error());
        if (out) {   // below the knee: only the sRGB transfer function is applied
            const float e = 1.055f * std::pow(0.25f, 1 / 2.4f) - 0.055f;
            CheckPx("sdr value is just encoded", At(Read(out), 8, 3, 3), e, e, e, 1, 0.01f);
            C.release(out);
        }
        be.destroy(src);
        std::vector<float> hv((size_t)8 * 8 * 4);
        for (size_t i = 0; i < hv.size(); i += 4) { hv[i] = 4; hv[i + 1] = 4; hv[i + 2] = 4; hv[i + 3] = 1; }
        rg::Target* hdr = be.createFromFloats(8, 8, rg::Format::RGBA16F, hv.data());
        out = C.toneMap(hdr, t);
        if (out) { const Px p = At(Read(out), 8, 3, 3); CHECK_MSG(p.r <= 1.001f && p.r > 0.9f, "bright HDR rolls off into range"); C.release(out); }
        be.destroy(hdr);
    }

    std::printf("%d checks, %d failed, %d passes\n", gChecks, gFailed, C.passes());
    return gFailed ? 1 : 0;
}

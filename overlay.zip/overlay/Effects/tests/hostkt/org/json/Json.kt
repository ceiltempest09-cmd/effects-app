package org.json

class JSONException(message: String) : Exception(message)

class JSONObject() {
    private val map = LinkedHashMap<String, Any?>()
    constructor(text: String) : this() {
        val v = Parser(text).parseValue()
        if (v !is JSONObject) throw JSONException("not an object")
        v.map.forEach { (k, x) -> map[k] = x }
    }
    fun put(key: String, value: Any?): JSONObject { map[key] = value; return this }
    fun has(key: String) = map.containsKey(key)
    fun remove(key: String): Any? = map.remove(key)
    fun opt(key: String): Any? = map[key]
    fun get(key: String): Any = map[key] ?: throw JSONException("no $key")
    fun keys(): Iterator<String> = map.keys.toList().iterator()
    fun length() = map.size
    fun getString(k: String): String = (map[k] ?: throw JSONException("no $k")).let { if (it is String) it else it.toString() }
    fun optString(k: String, d: String = ""): String = map[k]?.let { if (it is String) it else it.toString() } ?: d
    fun optInt(k: String, d: Int = 0): Int = (map[k] as? Number)?.toInt() ?: (map[k] as? String)?.toIntOrNull() ?: d
    fun optDouble(k: String, d: Double = Double.NaN): Double = (map[k] as? Number)?.toDouble() ?: (map[k] as? String)?.toDoubleOrNull() ?: d
    fun optBoolean(k: String, d: Boolean = false): Boolean = (map[k] as? Boolean) ?: d
    fun optJSONArray(k: String): JSONArray? = map[k] as? JSONArray
    fun optJSONObject(k: String): JSONObject? = map[k] as? JSONObject
    fun getJSONArray(k: String): JSONArray = optJSONArray(k) ?: throw JSONException("no array $k")
    fun getJSONObject(k: String): JSONObject = optJSONObject(k) ?: throw JSONException("no object $k")
    override fun toString(): String = write(this)
}

class JSONArray() {
    private val list = ArrayList<Any?>()
    constructor(items: Collection<*>) : this() { list.addAll(items) }
    constructor(text: String) : this() {
        val v = Parser(text).parseValue()
        if (v !is JSONArray) throw JSONException("not an array")
        list.addAll(v.list)
    }
    fun put(value: Any?): JSONArray { list.add(value); return this }
    fun length() = list.size
    fun opt(i: Int): Any? = list.getOrNull(i)
    fun get(i: Int): Any = list.getOrNull(i) ?: throw JSONException("no $i")
    fun optString(i: Int, d: String = ""): String = list.getOrNull(i)?.let { if (it is String) it else it.toString() } ?: d
    fun getString(i: Int): String = optString(i)
    fun getInt(i: Int): Int = (list[i] as Number).toInt()
    fun getDouble(i: Int): Double = (list[i] as Number).toDouble()
    fun optDouble(i: Int, d: Double = Double.NaN): Double = (list.getOrNull(i) as? Number)?.toDouble() ?: d
    fun optJSONObject(i: Int): JSONObject? = list.getOrNull(i) as? JSONObject
    fun getJSONObject(i: Int): JSONObject = optJSONObject(i) ?: throw JSONException("no object $i")
    fun optJSONArray(i: Int): JSONArray? = list.getOrNull(i) as? JSONArray
    override fun toString(): String = write(this)
}

private fun write(v: Any?): String = when (v) {
    null -> "null"
    is String -> "\"" + v.flatMap { c -> when (c) { '"' -> "\\\"".toList(); '\\' -> "\\\\".toList(); '\n' -> "\\n".toList(); '\r' -> "\\r".toList(); '\t' -> "\\t".toList(); else -> listOf(c) } }.joinToString("") + "\""
    is JSONObject -> v.keys().asSequence().joinToString(",", "{", "}") { write(it) + ":" + write(v.opt(it)) }
    is JSONArray -> (0 until v.length()).joinToString(",", "[", "]") { write(v.opt(it)) }
    else -> v.toString()
}

private class Parser(val s: String) {
    var i = 0
    fun ws() { while (i < s.length && s[i].isWhitespace()) i++ }
    fun parseValue(): Any? {
        ws()
        if (i >= s.length) throw JSONException("unexpected end")
        return when (val c = s[i]) {
            '{' -> { i++; val o = JSONObject(); ws(); if (s[i] == '}') { i++; return o }
                while (true) { ws(); val k = str(); ws(); expect(':'); o.put(k, parseValue()); ws(); if (s[i] == ',') { i++; continue }; expect('}'); break }; o }
            '[' -> { i++; val a = JSONArray(); ws(); if (s[i] == ']') { i++; return a }
                while (true) { a.put(parseValue()); ws(); if (s[i] == ',') { i++; continue }; expect(']'); break }; a }
            '"' -> str()
            't' -> { lit("true"); true }
            'f' -> { lit("false"); false }
            'n' -> { lit("null"); null }
            else -> if (c == '-' || c.isDigit()) num() else throw JSONException("bad char '$c' at $i")
        }
    }
    fun expect(c: Char) { if (i >= s.length || s[i] != c) throw JSONException("expected '$c' at $i"); i++ }
    fun lit(w: String) { if (!s.startsWith(w, i)) throw JSONException("bad literal at $i"); i += w.length }
    fun num(): Any { val st = i; while (i < s.length && (s[i].isDigit() || s[i] in "+-.eE")) i++; val t = s.substring(st, i)
        return t.toLongOrNull()?.let { if (it in Int.MIN_VALUE..Int.MAX_VALUE) it.toInt() else it } ?: t.toDouble() }
    fun str(): String {
        expect('"'); val o = StringBuilder()
        while (s[i] != '"') {
            if (s[i] == '\\') { i++; when (val e = s[i]) { 'n' -> o.append('\n'); 't' -> o.append('\t'); 'r' -> o.append('\r'); 'b' -> o.append('\b'); 'f' -> o.append('\u000c')
                'u' -> { o.append(s.substring(i + 1, i + 5).toInt(16).toChar()); i += 4 }; else -> o.append(e) }; i++ }
            else o.append(s[i++])
        }
        i++; return o.toString()
    }
}

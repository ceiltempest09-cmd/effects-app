package com.effects.motion.effects

import com.effects.motion.platform.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** Imported effects live as one .json file each in filesDir/imported_effects and are added to the catalog on read. */
object ImportedEffects {
    private fun folder(context: Context) = File(context.filesDir, "imported_effects")

    fun save(context: Context, json: JSONObject) {
        val dir = folder(context).apply { mkdirs() }
        val target = File(dir, json.getString("id") + ".json")
        val temp = File(dir, target.name + ".tmp")
        temp.writeText(json.toString())
        if (!temp.renameTo(target)) { target.writeText(json.toString()); temp.delete() }
    }

    fun delete(context: Context, effectId: String) {
        File(folder(context), effectId.removePrefix("fx.") + ".json").delete()
    }

    fun load(context: Context): List<EffectDefinition> =
        folder(context).listFiles { f -> f.name.endsWith(".json") }.orEmpty().sortedBy { it.name }
            .mapNotNull { f -> runCatching { fromJson(JSONObject(f.readText())) }.getOrNull() }

    fun fromJson(json: JSONObject): EffectDefinition {
        val key = json.getString("id")
        val tier = ImportTier.named(json.optString("tier"))
        val source = json.optString("source", EffectSources.Native)
        if (source == EffectSources.Native) return EffectDefinition.parse(json, tier.pack).copy(source = source)
        val params = json.optJSONArray("params") ?: JSONArray()
        return EffectDefinition(
            id = "fx.$key", key = key, name = json.optString("name", key),
            category = json.optString("category", "other"), description = json.optString("description"),
            params = List(params.length()) { EffectParam.parse(params.getJSONObject(it)) },
            sksl = json.getString("sksl"), pack = tier.pack, source = source,
        )
    }
}

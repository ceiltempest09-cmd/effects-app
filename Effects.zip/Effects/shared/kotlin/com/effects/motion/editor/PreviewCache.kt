package com.effects.motion.editor

import android.app.ActivityManager
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Handler
import android.os.HandlerThread
import android.util.Log
import android.widget.Toast
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import com.effects.motion.platform.PlatformFeatures
import com.effects.motion.platform.rawFrameImage
import com.effects.motion.platform.releaseFrameImage
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.effects.motion.R
import com.effects.motion.Tier
import com.effects.motion.engine.EngineThread
import com.effects.motion.export.Smoothing
import com.effects.motion.model.Scene
import java.io.ByteArrayOutputStream
import java.nio.ByteBuffer
import kotlin.math.abs
import kotlin.math.roundToInt
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Deferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.delay

private const val MIB = 1L shl 20
private const val MAX_BUDGET = 256 * MIB
private const val MAX_DISK_BUDGET = 1024 * MIB
private const val DISK_RESERVE = 1024 * MIB
private const val CACHE_PREFIX = "preview-cache-"
private const val MAX_SIDE = 1920
private const val ESTIMATE_PER_MILLE = 150L
private const val QUALITY = 85
private const val AHEAD = 8
private const val POOL = AHEAD + 3
private const val DECODERS = 3
private const val TAG = "AMCache"

fun previewCacheBudget(memoryClassMb: Int, lowRam: Boolean, compatible: Boolean): Long {
    val percent = when { lowRam -> 8; compatible -> 12; else -> 15 }
    return minOf(MAX_BUDGET, memoryClassMb.coerceAtLeast(16) * MIB * percent / 100)
}

fun rawStoreBudget(heapMax: Long): Long = minOf(4096 * MIB, heapMax * 2 / 5)

fun storeBudget(budget: Long, width: Int, height: Int): Long = maxOf(budget / 4, budget - POOL * 4L * width * height)

fun cacheFrameSize(sceneWidth: Int, sceneHeight: Int, fit: Float, divisor: Int): Pair<Int, Int> {
    val longest = maxOf(sceneWidth, sceneHeight, 1)
    val cap = minOf(1f, MAX_SIDE.toFloat() / longest)
    val scale = if (fit > 0f) minOf(fit / divisor.coerceAtLeast(1), cap) else cap / divisor.coerceAtLeast(1)
    return maxOf(1, (sceneWidth * scale).roundToInt()) to maxOf(1, (sceneHeight * scale).roundToInt())
}

fun framesThatFit(budget: Long, width: Int, height: Int): Int =
    (budget / maxOf(1L, width.toLong() * height * ESTIMATE_PER_MILLE / 1000)).coerceIn(1L, Int.MAX_VALUE.toLong()).toInt()

fun renderRange(lastFrame: Int, playhead: Int, maxFrames: Int): IntRange {
    val total = lastFrame.coerceAtLeast(0) + 1
    if (maxFrames >= total) return 0 until total
    val count = maxFrames.coerceAtLeast(1)
    val start = playhead.coerceIn(0, total - count)
    return start until start + count
}

fun previewRange(lastFrame: Int, playhead: Int, budget: Long, width: Int, height: Int): IntRange =
    renderRange(lastFrame, playhead, framesThatFit(budget, width, height))

fun flattenOnChecker(rgba: ByteArray, width: Int, height: Int, cell: Float): Boolean {
    val size = cell.coerceAtLeast(1f)
    var translucent = false
    var i = 3
    for (y in 0 until height) {
        val row = ((height - y - 0.5f) / size).toInt()
        for (x in 0 until width) {
            val a = rgba[i].toInt() and 0xff
            if (a != 0xff) {
                translucent = true
                val base = if ((((x + 0.5f) / size).toInt() + row) and 1 == 1) 0xcc else 0xe5
                for (c in 1..3) rgba[i - c] = (((rgba[i - c].toInt() and 0xff) * a + base * (255 - a) + 127) / 255).toByte()
                rgba[i] = -1
            }
            i += 4
        }
    }
    return translucent
}

class FrameStore(val first: Int, val budget: Long, private val file: java.io.File? = null, val raw: Boolean = false, private val keepFile: Boolean = false) : java.io.Closeable {
    private data class Record(val data: ByteArray?, val offset: Long, val size: Int)
    private val records = java.util.TreeMap<Int, Record>()
    private val disk = file?.let { f -> if (keepFile) java.io.RandomAccessFile(f, "r") else java.io.RandomAccessFile(f, "rw").apply { setLength(0) } }
    private var end = 0L
    private var closed = false
    @Volatile var bytes = 0L
        private set
    @Volatile var count = 0
        private set
    val last: Int get() = synchronized(this) { records.lastKeyOrNull() ?: first - 1 }
    val onDisk: Boolean get() = disk != null

    @Synchronized fun add(frame: ByteArray): Boolean = put(first + count, frame)

    @Synchronized fun put(index: Int, frame: ByteArray): Boolean {
        if (closed || index < first || bytes - (records[index]?.size ?: 0) + frame.size > budget) return false
        val target = disk
        val offset = end
        if (target != null) {
            try { target.seek(offset); target.write(frame) }
            catch (_: java.io.IOException) { return false }
            end += frame.size
        }
        bytes -= records[index]?.size ?: 0
        records[index] = Record(if (target == null) frame else null, offset, frame.size)
        bytes += frame.size
        count = records.size
        return true
    }

    /** Registers a frame that is already stored in the file this store was opened on. */
    @Synchronized fun adopt(index: Int, offset: Long, size: Int) {
        if (closed || index < first) return
        records[index] = Record(null, offset, size)
        bytes += size
        count = records.size
    }

    @Synchronized fun removeWhere(remove: (Int) -> Boolean) {
        val iterator = records.entries.iterator()
        while (iterator.hasNext()) {
            val record = iterator.next()
            if (remove(record.key)) { bytes -= record.value.size; iterator.remove() }
        }
        count = records.size
    }

    @Synchronized fun evictFarther(at: Int, frame: Int): Boolean {
        if (records.isEmpty()) return false
        fun distance(f: Int) = if (f >= at) (f - at).toLong() else 2L * (at - f)
        val victim = if (distance(records.firstKey()) >= distance(records.lastKey())) records.firstKey() else records.lastKey()
        if (distance(victim) <= distance(frame)) return false
        bytes -= records.remove(victim)!!.size
        count = records.size
        return true
    }

    @Synchronized fun runs(): List<IntRange> {
        val out = ArrayList<IntRange>()
        var start = -1
        var end = -2
        for (k in records.keys) {
            if (k != end + 1) { if (start >= 0) out += start..end; start = k }
            end = k
        }
        if (start >= 0) out += start..end
        return out
    }

    @Synchronized operator fun contains(frame: Int): Boolean = !closed && records.containsKey(frame)

    @Synchronized operator fun get(frame: Int): ByteArray? {
        if (closed) return null
        val record = records[frame] ?: return null
        record.data?.let { return it }
        return try {
            ByteArray(record.size).also { disk!!.seek(record.offset); disk.readFully(it) }
        } catch (_: java.io.IOException) { null }
    }

    @Synchronized override fun close() {
        if (closed) return
        closed = true
        runCatching { disk?.close() }
        records.clear()
        bytes = 0L
        count = 0
        if (!keepFile) file?.delete()
    }

    private fun <K, V> java.util.TreeMap<K, V>.lastKeyOrNull(): K? = if (isEmpty()) null else lastKey()
}

fun diskBudget(free: Long): Long = minOf(MAX_DISK_BUDGET, (free - DISK_RESERVE) / 4).coerceAtLeast(0L)

data class CacheKey(val projectId: String, val scene: Scene, val divisor: Int, val androidEmoji: Boolean, val resources: Long = 0, val accurateBlur: Boolean = true, val group: List<Long> = emptyList())

internal fun cacheBarShows(cached: CacheKey, now: CacheKey, catchingUp: Boolean): Boolean =
    cached.projectId == now.projectId && (cached.scene.node === now.scene.node || catchingUp && cached.copy(scene = now.scene) == now)

class FramePlayer internal constructor(private val store: FrameStore, val width: Int, val height: Int) {
    class Shown(val frame: Int, val image: ImageBitmap, val at: Long)
    private class Decoded(val bitmap: Bitmap?, val image: ImageBitmap)

    var shown by mutableStateOf<Shown?>(null)
        private set
    @Volatile var shows = 0L
        private set
    private val pool = java.util.concurrent.Executors.newFixedThreadPool(DECODERS) { r -> Thread(r, "am-cache-decode").apply { isDaemon = true } }
    private val decoded = HashMap<Int, Decoded>()
    private val inflight = HashSet<Int>()
    private val recent = ArrayDeque<Int>()
    @Volatile private var wanted = -1
    @Volatile private var closed = false
    private val epoch = java.util.concurrent.atomic.AtomicLong()

    fun want(frame: Int, playing: Boolean) {
        if (closed) return
        val version = epoch.get()
        wanted = frame
        val ready = synchronized(this) { decoded[frame] }
        if (ready != null) show(frame, ready.image, version)
        schedule(frame, if (playing) AHEAD else 0, version)
    }

    private fun show(frame: Int, image: ImageBitmap, version: Long) {
        synchronized(this) {
            if (closed || epoch.get() != version) return
            if (recent.lastOrNull() != frame) { recent.addLast(frame); shows++ }
            while (recent.size > 2) recent.removeFirst()
            shown = Shown(frame, image, System.nanoTime())
        }
    }

    /** Frames are decoded on several threads, the wanted one first, so decoding keeps up with playback. */
    private fun schedule(target: Int, count: Int, version: Long) {
        for (k in 0..count) {
            val frame = target + k
            val queue = synchronized(this) { frame !in decoded && inflight.add(frame) }
            if (!queue) continue
            try {
                pool.execute { decodeTask(frame, version) }
            } catch (_: java.util.concurrent.RejectedExecutionException) {
                synchronized(this) { inflight.remove(frame) }
            }
        }
    }

    private fun decodeTask(frame: Int, version: Long) {
        try {
            val distance = frame - wanted
            if (closed || epoch.get() != version || distance < 0 || distance > AHEAD) return
            val made = decode(frame, version) ?: return
            if (wanted == frame) show(frame, made.image, version)
        } finally {
            synchronized(this) { inflight.remove(frame) }
        }
    }

    private fun decode(frame: Int, version: Long): Decoded? {
        synchronized(this) { decoded[frame] }?.let { return it }
        val bytes = store[frame] ?: return null
        val reuse = synchronized(this) { victim() }
        val made = if (store.raw) {
            Decoded(null, (try { rawFrameImage(bytes, width, height) } catch (_: OutOfMemoryError) { null }) ?: return null)
        } else {
            val bitmap = decodeEncoded(bytes, reuse) ?: return null
            Decoded(bitmap, bitmap.asImageBitmap())
        }
        synchronized(this) {
            if (closed || version != epoch.get()) return null
            decoded[frame] = made
        }
        return made
    }

    private fun decodeEncoded(bytes: ByteArray, reuse: Bitmap?): Bitmap? {
        val options = BitmapFactory.Options().apply { inMutable = true; inBitmap = reuse }
        val bitmap = try {
            try { BitmapFactory.decodeByteArray(bytes, 0, bytes.size, options) }
            catch (_: IllegalArgumentException) {
                BitmapFactory.decodeByteArray(bytes, 0, bytes.size, BitmapFactory.Options().apply { inMutable = true })
            }
        } catch (_: OutOfMemoryError) { null }
        return bitmap
    }

    private fun victim(): Bitmap? {
        if (decoded.size < POOL) return null
        val target = wanted
        val frame = decoded.keys.filter { it !in recent && it !in target..target + AHEAD }.maxByOrNull { abs(it - target) } ?: return null
        val removed = decoded.remove(frame) ?: return null
        if (store.raw) releaseFrameImage(removed.image)
        return removed.bitmap
    }

    internal fun drop() {
        epoch.incrementAndGet()
        synchronized(this) { decoded.clear(); recent.clear() }
        shown = null
    }

    internal fun close() {
        closed = true
        pool.shutdownNow()
        drop()
    }
}

object PreviewCache {
    enum class Phase { Empty, Rendering, Ready }
    enum class PreRender { None, Rendering, Ready, Outdated }
    private enum class Outcome { Done, Full, Stopped, Failed, NoMemory }

    var phase by mutableStateOf(Phase.Empty)
        private set
    var progress by mutableFloatStateOf(0f)
        private set
    var key by mutableStateOf<CacheKey?>(null)
        private set
    var player by mutableStateOf<FramePlayer?>(null)
        private set
    private var rendered by mutableStateOf<CacheKey?>(null)
    private var gaps = false
    @Volatile private var store: FrameStore? = null
    @Volatile private var stopRequested = false
    @Volatile private var memoryStopped = false
    @Volatile private var building: FrameStore? = null
    private var job: Job? = null
    private var generation = 0
    var revision by mutableLongStateOf(0L)
        private set
    private var revisedNs = 0L
    private fun revise(force: Boolean = false) {
        val now = System.nanoTime()
        if (force || now - revisedNs > 100_000_000L) { revisedNs = now; revision++ }
    }
    /** Key of the render that is being built, so the cache bar can keep showing frames while it runs. */
    @Volatile private var renderKey: CacheKey? = null
    /** Frames of the last finished render that an edit has not touched, worked out once per edit. */
    private var validFor: Pair<Scene, Scene>? = null
    private var validRuns: List<IntRange> = emptyList()

    fun runs(): List<IntRange> = when {
        phase == Phase.Rendering -> building?.runs().orEmpty()
        automatic || phase == Phase.Ready -> store?.runs().orEmpty()
        else -> emptyList()
    }

    fun runsFor(state: EditorState): List<IntRange> {
        val now = keyOf(state)
        if (phase == Phase.Rendering) {
            // The frames already kept and the ones rendered so far stay on the bar; nothing disappears while rendering.
            val rendering = renderKey ?: return emptyList()
            return if (cacheBarShows(rendering, now, catchingUp = false)) runs() else emptyList()
        }
        val cached = key ?: return emptyList()
        if (cacheBarShows(cached, now, automatic)) return runs()
        // A finished render the scene has moved on from: show the part the edit did not touch, since that part needs no new render.
        val kept = store ?: return emptyList()
        if (automatic || phase != Phase.Ready || cached.copy(scene = now.scene) != now) return emptyList()
        val pair = cached.scene to now.scene
        val known = validFor
        if (known == null || known.first !== pair.first || known.second !== pair.second) {
            val dirty = previewDirtyRanges(cached.scene, now.scene)
            validRuns = kept.runs().flatMap { run -> subtract(run, dirty, now.scene.lastFrame) }
            validFor = pair
        }
        return validRuns
    }

    private fun subtract(run: IntRange, dirty: List<IntRange>, last: Int): List<IntRange> {
        var parts = listOf(run.first..minOf(run.last, last))
        for (hole in dirty) {
            parts = parts.flatMap { part ->
                if (hole.last < part.first || hole.first > part.last) listOf(part)
                else listOfNotNull(
                    (part.first until hole.first).takeIf { !it.isEmpty() },
                    ((hole.last + 1)..part.last).takeIf { !it.isEmpty() },
                )
            }
        }
        return parts.filter { !it.isEmpty() }
    }
    var fit by mutableFloatStateOf(0f)
    var checkerCell by mutableFloatStateOf(25f)
    var automatic = false
        private set
    private var preparedCell = 0f
    private var slowUntilNs = 0L
    @Volatile private var interactionNs = 0L
    fun interaction() { interactionNs = System.nanoTime() }
    val idleMs: Long get() = if (PlatformFeatures.desktop) 1_000L else 2_000L
    fun idle(): Boolean = System.nanoTime() - interactionNs >= idleMs * 1_000_000L

    suspend fun follow(next: CacheKey) {
        val previous = key ?: return
        if (!automatic || phase == Phase.Rendering || previous.scene == next.scene || previous.copy(scene = next.scene) != next) return
        val dirty = withContext(Dispatchers.Default) { previewDirtyRanges(previous.scene, next.scene) }
        currentCoroutineContext().ensureActive()
        if (key !== previous) return
        store?.removeWhere { frame -> dirty.any { frame in it } || frame > next.scene.lastFrame }
        if (dirty.isNotEmpty()) player?.drop()
        key = next
        revise(force = true)
    }

    suspend fun prepare(state: EditorState, context: Context, accept: () -> Boolean) {
        if (!accept() || phase == Phase.Rendering || fit <= 0f || !state.settings.backgroundPreview) return
        val next = keyOf(state)
        val at = state.frame
        val cell = checkerCell
        val (width, height) = cacheFrameSize(next.scene.width, next.scene.height, fit, next.divisor)
        val previous = key
        if (!automatic || previous == null || previous.copy(scene = next.scene) != next || player?.width != width || player?.height != height || preparedCell != cell) {
            if (!automatic && previous == next && phase == Phase.Ready) return
            clear()
            val manager = context.applicationContext.getSystemService(ActivityManager::class.java)
            val raw = PlatformFeatures.desktop
            val budget = if (raw) rawStoreBudget(Runtime.getRuntime().maxMemory())
                else storeBudget(previewCacheBudget(manager?.memoryClass ?: 128, manager?.isLowRamDevice == true, Tier.compatible), width, height)
            store = FrameStore(0, budget, raw = raw)
            player = FramePlayer(store!!, width, height)
            automatic = true
            preparedCell = cell
        } else follow(next)
        key = next
        phase = Phase.Ready
        val mine = generation
        fun current() = generation == mine && accept() && key == next && state.engine.mediaRevision.value == next.resources
        if (!current() || System.nanoTime() < slowUntilNs) return
        val built = store ?: return
        val encoder = if (built.raw) null else try { Encoder(width, height) } catch (_: OutOfMemoryError) {
            slowUntilNs = System.nanoTime() + 30_000_000_000L
            return
        }
        try {
            val order = previewOrder(next.scene.lastFrame, at, if (built.raw) 30 else 1)
            var index = 0
            var refused = 0
            while (index < order.size) {
                val frame = order[index]
                currentCoroutineContext().ensureActive()
                if (!current()) return
                if (frame in built) { index++; continue }
                if (!heapRoom(width.toLong() * height * 12)) return
                val started = System.nanoTime()
                val pixels = state.engine.capturePreviewFrame(next.scene, next.scene.frameStart(frame), width, height, next.accurateBlur, ::current)
                if (pixels == null) {
                    if (!built.raw || ++refused >= 20) { refused = 0; index++; continue }
                    delay(50)
                    continue
                }
                refused = 0
                index++
                currentCoroutineContext().ensureActive()
                if (!current()) return
                val stored = withContext(Dispatchers.Default) { if (encoder == null) pixels.also { flattenOnChecker(it, width, height, cell) } else encoder.encode(pixels, cell, true) } ?: return
                if (!current()) return
                while (!built.put(frame, stored)) if (!built.evictFarther(at, frame)) { revise(force = true); return }
                revise()
                if (encoder == null) continue
                val elapsed = System.nanoTime() - started
                if (elapsed > 80_000_000L) { slowUntilNs = System.nanoTime() + 10_000_000_000L; return }
                delay(maxOf(30L, elapsed / 1_000_000))
            }
            revise(force = true)
        } catch (e: CancellationException) {
            throw e
        } catch (_: OutOfMemoryError) {
            slowUntilNs = System.nanoTime() + 30_000_000_000L
        } catch (e: Exception) {
            Log.w(TAG, "automatic preview preparation failed", e)
            slowUntilNs = System.nanoTime() + 10_000_000_000L
        } finally { encoder?.bitmap?.recycle() }
    }

    val first: Int get() = store?.first ?: 0
    val last: Int get() = store?.last ?: -1

    fun covers(frame: Int): Boolean = store?.contains(frame) == true

    fun preRender(state: EditorState, resources: Long = state.engine.mediaRevision.value): PreRender = when {
        phase == Phase.Rendering -> PreRender.Rendering
        phase == Phase.Ready && !automatic && !gaps && key == keyOf(state, resources) -> PreRender.Ready
        rendered?.projectId == state.projectId -> PreRender.Outdated
        else -> PreRender.None
    }

    fun keyOf(state: EditorState, resources: Long = state.engine.mediaRevision.value) =
        CacheKey(state.projectId, state.scene, state.settings.previewQuality.divisor, state.settings.androidEmoji, resources, state.settings.fullMotionBlur, state.groupPath)

    fun render(state: EditorState, context: Context, scope: CoroutineScope) {
        if (phase == Phase.Rendering) return
        val app = context.applicationContext
        val scene = state.scene
        val divisor = state.settings.previewQuality.divisor
        val (width, height) = cacheFrameSize(scene.width, scene.height, fit, divisor)
        val manager = app.getSystemService(ActivityManager::class.java)
        val memory = storeBudget(previewCacheBudget(manager?.memoryClass ?: 128, manager?.isLowRamDevice == true, Tier.compatible), width, height)
        val folder = app.cacheDir
        val onDisk = runCatching { diskBudget(folder.usableSpace) }.getOrDefault(0L)
        val budget = maxOf(memory, onDisk)
        val expected = previewRange(scene.lastFrame, state.frame, budget, width, height)
        val range = expected.first..maxOf(scene.lastFrame, 0)
        val next = keyOf(state)
        val cell = checkerCell
        val before = key
        val kept = store
        // Frames the edit has not touched are always kept (including the ones the background preview already made),
        // so pressing Pre-render only renders what is missing or affected.
        val reuse = kept != null && before != null && !kept.raw && player?.width == width && player?.height == height &&
            (!automatic || preparedCell == cell) && before.copy(scene = next.scene) == next
        val seed = if (reuse) kept else null
        val seedScene = before?.scene
        if (seed != null) store = null
        clear()
        state.playing = false
        val mine = generation
        renderKey = next
        phase = Phase.Rendering
        job = scope.launch {
            var made: FrameStore? = null
            try {
                val started = System.nanoTime()
                val built = withContext(Dispatchers.IO) {
                    folder.listFiles { f -> f.name.startsWith(CACHE_PREFIX) }?.forEach { it.delete() }
                    if (onDisk > memory) runCatching { FrameStore(range.first, budget, java.io.File(folder, CACHE_PREFIX + System.nanoTime() + ".bin")) }.getOrNull() else null
                } ?: FrameStore(range.first, memory)
                made = built
                building = built
                if (seed != null && seedScene != null) {
                    // Keep every frame the edit does not touch; only the affected frames are rendered again.
                    val dirty = withContext(Dispatchers.Default) { previewDirtyRanges(seedScene, scene) }
                    withContext(Dispatchers.IO) {
                        for (frame in maxOf(seed.first, range.first)..minOf(seed.last, range.last)) {
                            if (dirty.any { frame in it }) continue
                            val bytes = seed[frame] ?: continue
                            if (!built.put(frame, bytes)) break
                        }
                    }
                }
                revise(force = true)
                var resources = next.resources
                val outcome = try {
                    withContext(Dispatchers.Default) { renderFrames(state.engine, scene, range, expected.count(), width, height, cell, next.accurateBlur, built) { resources = it } }
                } catch (e: CancellationException) {
                    throw e
                } catch (e: OutOfMemoryError) {
                    Outcome.NoMemory
                } catch (e: Exception) {
                    Log.w(TAG, "preview render failed", e)
                    Outcome.Failed
                }
                if (mine != generation) return@launch
                val ms = (System.nanoTime() - started) / 1e6
                val per = built.count.coerceAtLeast(1)
                Log.i(TAG, "render %s frames=%d of %d size=%dx%d bytes=%d avg=%d budget=%d ms=%.0f perFrame=%.1f still=%.1f encode=%.1f".format(
                    outcome, built.count, range.count(), width, height, built.bytes, built.bytes / per, budget, ms, ms / per, stillNs / 1e6 / per, encodeNs / 1e6 / per))
                finish(app, next.copy(resources = resources), built, width, height, outcome, scene.lastFrame, scene.fps)
                if (phase == Phase.Ready && store === built) persist(app, state, built, scene.lastFrame, width, height, cell, scope)
            } finally {
                if (building === made) building = null
                seed?.close()
            made?.let { if (store !== it) it.close() }
                if (mine == generation && phase == Phase.Rendering) phase = Phase.Empty
            }
        }
    }

    private fun persist(context: Context, state: EditorState, built: FrameStore, lastFrame: Int, width: Int, height: Int, cell: Float, scope: CoroutineScope) {
        if (!state.settings.persistentCache) return
        val saved = key ?: return
        val projectId = state.projectId
        val name = saved.scene.node["title"] ?: projectId
        val limit = state.settings.cacheLimitMb * MIB
        val mode = state.settings.cacheCleanup
        val complete = built.first == 0 && built.last >= lastFrame
        scope.launch(Dispatchers.IO) {
            PersistentCache.save(context, projectId, name, saved, built, width, height, cell, complete, limit, mode)
        }
    }

    /** Brings back a render saved earlier. Frames an edit has not touched are kept; the rest are rendered when you render again. */
    suspend fun restore(state: EditorState, context: Context) {
        if (phase != Phase.Empty || fit <= 0f || !state.settings.persistentCache) return
        val app = context.applicationContext
        val scene = state.scene
        val next = keyOf(state)
        val cell = checkerCell
        val (width, height) = cacheFrameSize(scene.width, scene.height, fit, state.settings.previewQuality.divisor)
        val limit = state.settings.cacheLimitMb * MIB
        val mode = state.settings.cacheCleanup
        val loaded = withContext(Dispatchers.IO) {
            PersistentCache.cleanup(app, limit, mode, state.projectId)
            PersistentCache.load(app, state.projectId, next, cell, width, height)
        } ?: return
        if (phase != Phase.Empty || keyOf(state) != next) {
            loaded.store.close()
            return
        }
        store = loaded.store
        key = next
        rendered = next
        gaps = loaded.pruned
        player = FramePlayer(loaded.store, width, height)
        phase = Phase.Ready
        progress = 1f
        automatic = false
        revise(force = true)
    }

    private class Encoder(private val width: Int, private val height: Int) {
        val bitmap: Bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        private val out = ByteArrayOutputStream(width * height / 4)

        fun encode(pixels: ByteArray, cell: Float, lossless: Boolean = false): ByteArray? {
            flattenOnChecker(pixels, width, height, cell)
            bitmap.copyPixelsFromBuffer(ByteBuffer.wrap(pixels))
            out.reset()
            return if (bitmap.compress(if (lossless) Bitmap.CompressFormat.PNG else Bitmap.CompressFormat.JPEG, QUALITY, out)) out.toByteArray() else null
        }
    }

    @Volatile private var stillNs = 0L
    @Volatile private var encodeNs = 0L

    private suspend fun renderFrames(engine: EngineThread, scene: Scene, range: IntRange, expected: Int, width: Int, height: Int, cell: Float, accurateBlur: Boolean, built: FrameStore,
                                     ready: (Long) -> Unit): Outcome =
        engine.exportSession(scene.toXml(), Smoothing(), scene.fps) {
            ready(engine.mediaRevision.value)
            stillNs = 0L
            encodeNs = 0L
            val encoders = arrayOf(Encoder(width, height), Encoder(width, height))
            try {
                coroutineScope {
                    var pending: Deferred<ByteArray?>? = null
                    var pendingFrame = -1
                    var done = 0
                    var turn = 0
                    val todo = range.count { it !in built }.coerceAtLeast(1)
                    val startBytes = built.bytes
                    suspend fun keep(): Outcome? {
                        val previous = pending ?: return null
                        pending = null
                        val bytes = previous.await() ?: return Outcome.Failed
                        if (!built.put(pendingFrame, bytes)) return Outcome.Full
                        done++
                        revise()
                        val fit = if (built.bytes > startBytes) ((built.budget - startBytes).toDouble() * done / (built.bytes - startBytes)).toInt() else minOf(expected, todo)
                        progress = (done.toFloat() / fit.coerceIn(1, todo)).coerceAtMost(0.99f)
                        return null
                    }
                    for (frame in range) {
                        if (frame in built) continue
                        if (stopRequested) return@coroutineScope keep() ?: Outcome.Stopped
                        if (!heapRoom(width.toLong() * height * 12)) return@coroutineScope keep() ?: Outcome.Full
                        val started = System.nanoTime()
                        val pixels = previewStill(scene.frameStart(frame), width, height, accurateBlur)
                        stillNs += System.nanoTime() - started
                        keep()?.let { return@coroutineScope it }
                        if (pixels == null) return@coroutineScope Outcome.Failed
                        val encoder = encoders[turn and 1]
                        turn++
                        pendingFrame = frame
                        pending = async(Dispatchers.Default) {
                            val began = System.nanoTime()
                            encoder.encode(pixels, cell).also { encodeNs += System.nanoTime() - began }
                        }
                    }
                    keep() ?: Outcome.Done
                }
            } finally {
                encoders.forEach { it.bitmap.recycle() }
            }
        }

    private fun heapRoom(needed: Long): Boolean {
        val runtime = Runtime.getRuntime()
        return runtime.maxMemory() - (runtime.totalMemory() - runtime.freeMemory()) > needed + 24 * MIB
    }

    private fun finish(context: Context, next: CacheKey, built: FrameStore, width: Int, height: Int, outcome: Outcome, lastFrame: Int, fps: Int) {
        if (outcome == Outcome.NoMemory) {
            clear()
            toast(context, context.getString(R.string.preview_cache_no_memory))
            return
        }
        if (built.count == 0) {
            phase = Phase.Empty
            if (outcome == Outcome.Failed) toast(context, context.getString(R.string.preview_cache_failed))
            else if (outcome == Outcome.Full) toast(context, context.getString(R.string.preview_cache_no_memory))
            return
        }
        store = built
        key = next
        rendered = next
        renderKey = null
        validFor = null
        gaps = false
        player = FramePlayer(built, width, height)
        phase = Phase.Ready
        progress = 1f
        revise(force = true)
        when {
            outcome == Outcome.Failed -> toast(context, context.getString(R.string.preview_cache_failed))
            (outcome != Outcome.Stopped || memoryStopped) && (built.first > 0 || built.last < lastFrame) ->
                toast(context, context.getString(R.string.preview_cache_partial, timecode(built.first, fps), timecode(built.last + 1, fps)))
        }
    }

    fun rangeLabel(context: Context, fps: Int): String =
        context.getString(R.string.preview_cache_ready_range, timecode(first, fps), timecode(last + 1, fps))

    private fun timecode(frame: Int, fps: Int): String = com.effects.motion.ui.editor.TimelineMath.timecode(frame, fps)

    fun cancel() {
        if (phase == Phase.Rendering) stopRequested = true
    }

    fun remove() {
        clear()
        rendered = null
    }

    fun clear() {
        renderKey = null
        validFor = null
        generation++
        stopRequested = false
        memoryStopped = false
        job?.cancel()
        job = null
        store?.close()
        store = null
        key = null
        gaps = false
        player?.close()
        player = null
        phase = Phase.Empty
        progress = 0f
        automatic = false
        slowUntilNs = 0L
        revise(force = true)
    }

    fun trim(level: Int) {
        if (level == RUNNING_LOW || level == RUNNING_CRITICAL) {
            if (phase == Phase.Rendering && building?.onDisk != true) {
                memoryStopped = true
                cancel()
                Log.i(TAG, "rendering stopped early at trim level $level")
            }
            return
        }
        if (level < BACKGROUND) {
            if (level >= UI_HIDDEN) player?.drop()
            return
        }
        if (phase == Phase.Empty) return
        clear()
        Log.i(TAG, "cache freed at trim level $level")
    }

    private fun toast(context: Context, text: String) = Toast.makeText(context, text, Toast.LENGTH_LONG).show()

    private const val RUNNING_LOW = 10
    private const val RUNNING_CRITICAL = 15
    private const val UI_HIDDEN = 20
    private const val BACKGROUND = 40
}

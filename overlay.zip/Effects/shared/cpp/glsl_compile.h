// glsl_compile.h - GLSL -> SPIR-V with glslang (ncnn's copy, already built into the app). Step 5a: compile only, nothing runs yet.
// No conversion between languages: Vulkan GLSL stays Vulkan GLSL, desktop GLSL stays desktop GLSL.
#pragma once

#include <cstdint>
#include <string>
#include <vector>

namespace am::rg {

enum class GlslDialect { Vulkan, OpenGL };   // Vulkan = lang "vulkan-glsl" rules; OpenGL = lang "glsl" (desktop) rules
enum class GlslStage { Vertex, Fragment };

struct GlslCompileResult {
    bool ok = false;
    std::vector<uint32_t> words;   // SPIR-V module, native endian
    std::string log;               // glslang info log on failure, or a note when glslang is not in this build
};

bool GlslangAvailable();           // false when the build had no glslang targets
std::string GlslangVersionText();  // "4.60" style text, or "not built"

GlslCompileResult CompileGlslToSpirv(const std::string& source, GlslDialect dialect, GlslStage stage);

}  // namespace am::rg

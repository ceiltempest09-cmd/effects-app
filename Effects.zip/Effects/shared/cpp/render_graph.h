// render_graph.h — backend-neutral multi-pass render graph for Effects Motion.
//
//   GraphDesc  (what an effect declares: passes, named buffers, textures)
//      |  BuildPlan()   validate, detect cycles, order, cull, plan lifetimes
//      v
//   Plan       (immutable; shared by every frame of the effect)
//      |  Executor::render()   runs EVERY live pass through a Backend
//      v
//   Backend    (Skia/SkSL today: effects_graph.cpp. Anything that can create targets and run a pass.)
//
// This file has no Skia, GL or Vulkan dependency so the scheduling, pooling and history rules are
// unit-tested on the host (render_graph_test.cpp). Builds with -fno-exceptions -fno-rtti.
#pragma once

#include <atomic>
#include <cstdint>
#include <deque>
#include <functional>
#include <map>
#include <memory>
#include <string>
#include <vector>

namespace am::rg {

enum class Format : int { Inherit = 0, RGBA8 = 1, RGBA16F = 2, RGBA32F = 3 };
// SkSL runs on the Skia backend. GLSL / GLSLES / VulkanGLSL / SPIRV are meant for native backends (a backend says which it runs
// through Backend::supports(Lang)); nothing translates one language into another at run time.
//   GLSL        desktop-style GLSL (#version 330 / 450 ... as the device accepts it)
//   GLSLES      GLSL ES 1.00 / 3.00 / 3.10 / 3.20
//   VulkanGLSL  GLSL for Vulkan (GL_KHR_vulkan_glsl), compiled to SPIR-V
//   SPIRV       a pre-compiled SPIR-V module (PassDesc::source holds it base64 encoded)
enum class Lang : int { SkSL = 0, GLSL = 1, GLSLES = 2, VulkanGLSL = 3, SPIRV = 4 };
enum class Blend : int { Replace = 0, SrcOver = 1, Add = 2, Multiply = 3, Screen = 4 };
enum class Filter : int { Nearest = 0, Linear = 1 };
enum class Wrap : int { Clamp = 0, Repeat = 1, Mirror = 2, Decal = 3 };
enum class SeekMode : int { Reset = 0, Replay = 1 };
enum class Precision : int { Preferred = 0, Required = 1 };

const char* ToString(Format);
const char* ToString(Lang);
bool ParseFormat(const std::string&, Format*);
bool ParseLang(const std::string&, Lang*);
bool ParseBlend(const std::string&, Blend*);
bool ParseFilter(const std::string&, Filter*);
bool ParseWrap(const std::string&, Wrap*);
int BytesPerPixel(Format f);   // Inherit counts as RGBA8

// What went wrong, in terms an effect author can act on (malformed file vs unsupported feature vs missing GPU capability...).
enum class DiagKind : int { Malformed, Unsupported, Translation, Capability, Validation };
struct Diag {
    bool error = true;
    DiagKind kind = DiagKind::Validation;
    std::string effect, pass, backend, file, message;
    int passIndex = -1, line = 0;
    std::string format() const;   // "error[validation] effect 'x' pass 'blur' (#2) backend skia (x.json:14): message"
};
bool HasError(const std::vector<Diag>&);

class Backend;

// ---------------------------------------------------------------- declaration
struct PassInput { std::string name, ref; };            // shader child name -> "source" | "buffer:id[@n]" | "texture:id" | "pass:id[@n]"
struct Constant { std::string name; std::vector<float> value; };

struct PassDesc {
    std::string id, name;
    Lang lang = Lang::SkSL;
    std::string source;                  // shader text
    std::string file;                    // where the text came from (diagnostics)
    int line = 1;                        // line of the first source line inside `file`
    std::vector<PassInput> inputs;
    std::string output;                  // buffer id; empty = "<pass id>"
    Blend blend = Blend::Replace;
    bool clear = true;                   // clear the target before drawing (forced for a buffer's first writer)
    std::vector<std::string> after;      // extra ordering constraints (pass ids)
    std::vector<Constant> constants;     // fixed uniform values
    std::map<std::string, std::string> defines;   // preprocessor defines applied by the shader compiler
    std::map<std::string, std::string> extra;     // unknown attributes, kept for round-tripping
};

struct BufferDesc {
    std::string id;
    float scale = 1;                     // of the effect area; ignored when width/height are set
    int width = 0, height = 0;           // absolute pixels (0 = use scale)
    Format format = Format::Inherit;     // Inherit = working format of the backend (canvas format)
    Precision precision = Precision::Preferred;   // Required: fail instead of degrading to a smaller format
    Filter filter = Filter::Linear;
    Wrap wrap = Wrap::Clamp;
    int history = 0;                     // frames kept after this one (0 = per-frame temporary; 1 = ping-pong)
    std::map<std::string, std::string> extra;
};

struct TextureDesc {
    std::string id, source;              // "builtin:noise" | "builtin:ramp-x" | "builtin:ramp-y"
    int width = 256, height = 256, seed = 1;
    Filter filter = Filter::Nearest;
    Wrap wrap = Wrap::Repeat;
    std::map<std::string, std::string> extra;
};

struct GraphDesc {
    std::string effectId;
    std::string output;                  // buffer shown as the effect result; empty = output of the last pass
    SeekMode seek = SeekMode::Reset;
    int maxReplay = 120;                 // frames reconstructed on a jump when seek == Replay
    std::vector<PassDesc> passes;
    std::vector<BufferDesc> buffers;
    std::vector<TextureDesc> textures;
    std::map<std::string, std::string> extra;
};

// ---------------------------------------------------------------- plan
struct ResolvedInput {
    enum Kind { Source, Buffer, Texture } kind = Source;
    std::string name;
    int index = -1;                      // buffer / texture index
    int back = 0;                        // frames back (0 = this frame)
};

struct Step {
    int pass = 0;                        // index into Plan::desc.passes
    int output = 0;                      // buffer index
    bool firstWriter = false;            // the buffer is acquired and force-cleared here
    std::vector<ResolvedInput> inputs;
    std::vector<int> releaseAfter;       // temporary buffers whose last use is this step
};

struct PlanOptions {
    std::string backend = "skia";
    std::vector<Lang> languages = {Lang::SkSL};
    int maxTexture = 8192, maxPasses = 64, maxBuffers = 32;
    int maxInputs = 8;
};

struct Plan {
    GraphDesc desc;                      // with implicit buffers added
    std::vector<Diag> diags;             // errors and warnings
    std::vector<Step> steps;             // live passes in execution order
    std::vector<std::string> culled;     // pass ids dropped because nothing reads them
    int finalBuffer = -1;
    int peakLive = 0;                    // most temporary targets alive at once
    bool temporal = false;               // some live pass reads a previous frame
    bool ok() const { return !HasError(diags) && finalBuffer >= 0; }
    int bufferIndex(const std::string& id) const;
};

Plan BuildPlan(const GraphDesc& graph, const PlanOptions& options);

// Pixel size of a buffer for an effect area of w x h.
void BufferSize(const BufferDesc& b, int areaW, int areaH, int* w, int* h);

// Deterministic RGBA8 noise (fully a function of w, h, seed): used by "builtin:noise".
std::vector<uint8_t> NoisePixels(int w, int h, int seed);

// ---------------------------------------------------------------- execution
class Target {
public:
    virtual ~Target() = default;
    int width = 0, height = 0;
    Format format = Format::RGBA8;
    Backend* owner = nullptr;            // set by the pool that created it; null for backend-owned textures and blanks
};

struct BoundInput {
    const std::string* name = nullptr;
    Target* target = nullptr;
    Filter filter = Filter::Linear;
    Wrap wrap = Wrap::Clamp;
    bool source = false;
};

struct PassRun {
    const PassDesc* pass = nullptr;
    int step = 0;
    Target* output = nullptr;
    std::vector<BoundInput> inputs;
    bool clear = true;
    int64_t frame = 0;
    double timeSeconds = 0;              // `time` automatic uniform (FrameRequest::timeSeconds)
    int areaWidth = 0, areaHeight = 0;   // effect area in pixels (the coordinate space shaders work in)
};

class Backend {
public:
    virtual ~Backend() = default;
    virtual const char* name() const = 0;
    virtual bool supports(Lang) const = 0;
    virtual bool supports(Format) const = 0;
    virtual Format workingFormat() const = 0;
    virtual int maxTextureSize() const = 0;
    virtual Target* create(int w, int h, Format f) = 0;          // nullptr when out of memory
    virtual void destroy(Target*) = 0;
    virtual Target* texture(const TextureDesc&) = 0;             // backend-owned, cached
    virtual Target* blank(int w, int h, Format f) = 0;           // backend-owned transparent target
    virtual bool run(const PassRun&, std::string* error) = 0;
    virtual int64_t gpuNanos() { return -1; }                    // GPU time of the last run(), -1 = unknown

    // Finer than supports(Lang): can THIS backend on THIS device run THIS pass (#version, #extension, SPIR-V capabilities ...)?
    // Fill `why` (kind Capability, message only; the executor adds effect/pass/backend/line) and return false when it cannot.
    virtual bool accepts(const PassDesc& pass, Diag* why) { (void)why; return supports(pass.lang); }

    // ---- hand-off of a target between two backends (zero copy; a backend that cannot share storage keeps the defaults)
    // The executor drives these in this order, once per cross-backend use:
    //   holder.release(t, to, ...)            holder = the backend whose work touched t last: finish/submit that work and
    //                                         signal whatever `to` has to wait for (semaphore, fence, flush)
    //   user.acquire(from, t, forWrite, ..)   -> a Target this backend can sample (or render into when forWrite)
    //   user.run(...)
    //   user.release(view, from, ...)         only when forWrite or the view was written: make the result visible to `from`
    //   user.relinquish(view)                 the view is dead
    //   owner.reclaim(t, user)                only after a write through a view
    // Defaults refuse, so a pair of backends that cannot share storage fails with a Capability diagnostic instead of copying
    // through the CPU.
    virtual bool release(Target* t, Backend& to, std::string* error) { (void)t; (void)to; *error = "this backend cannot hand a target to another backend"; return false; }
    virtual Target* acquire(Backend& from, Target* t, bool forWrite, std::string* error) { (void)from; (void)t; (void)forWrite; *error = "this backend cannot use a target owned by another backend"; return nullptr; }
    virtual void relinquish(Target* view) { (void)view; }
    virtual void reclaim(Target* t, Backend& user) { (void)t; (void)user; }
};

class TargetPool {
public:
    struct Stats { int64_t created = 0, destroyed = 0, reused = 0, bytes = 0, peakBytes = 0; int live = 0, idle = 0; };
    explicit TargetPool(Backend& b) : fBackend(b) {}
    ~TargetPool() { trim(true); }
    TargetPool(const TargetPool&) = delete;
    TargetPool& operator=(const TargetPool&) = delete;

    Target* acquire(int w, int h, Format f);       // nullptr when out of memory or over budget
    void release(Target*);
    void tick() { fTick++; }
    void trim(bool all = false, int idleTicks = 8);    // free idle targets (all, or those unused for `idleTicks` frames)
    void setBudget(int64_t bytes) { fBudget = bytes; }
    Stats stats() const;

private:
    struct Entry { Target* t; bool inUse; uint64_t last; };
    Backend& fBackend;
    std::vector<Entry> fEntries;
    Stats fStats;
    uint64_t fTick = 0;
    int64_t fBudget = 0;   // 0 = unlimited
};

struct PassTiming { std::string pass; int step = 0; int64_t cpuNs = 0, gpuNs = -1; };

struct FrameRequest {
    int64_t frame = 0;
    double timeSeconds = 0;                         // presentation time of `frame`; the same value must be used by preview and export
    double frameSeconds = 0;                        // duration of one frame; replayed frames (seek == Replay) get timeSeconds - n * frameSeconds
    int width = 0, height = 0;                      // effect area in pixels
    uint64_t signature = 0;                         // hash of everything that defines earlier frames (properties, size); change => history reset
    Target* source = nullptr;                       // the layer image for `frame`
    Backend* sourceOwner = nullptr;                 // backend that owns `source` (null = the first backend of the executor)
    std::function<Target*(int64_t)> sourceAt;       // layer image at another frame; only used when seek == Replay
    const std::atomic<bool>* cancel = nullptr;
};

struct FrameResult {
    enum Status { Ok, Cancelled, Failed } status = Ok;
    std::string error;
    std::vector<PassTiming> timings;
    bool historyReset = false;                      // history was cleared / rebuilt for this frame
    int64_t replayed = 0;                           // frames re-rendered to rebuild history
    std::vector<Diag> notes;                        // e.g. a buffer format was degraded
};

// Runs a Plan frame after frame. Frames must be consecutive to keep history; anything else follows GraphDesc::seek.
class Executor {
public:
    Executor(Backend& backend, std::shared_ptr<const Plan> plan);
    // Several backends: each pass runs on the first backend (in this order) that supports its language and accepts it. The first
    // backend is the primary one: it owns the layer image and receives the final target. Neither fallback nor translation exists:
    // a pass no backend can run fails the frame with a Capability diagnostic.
    Executor(std::vector<Backend*> backends, std::shared_ptr<const Plan> plan);
    ~Executor();

    // `consume` receives the final target and must finish drawing it before returning.
    FrameResult render(const FrameRequest& request, const std::function<void(Target*)>& consume);

    void dropAll();                    // device loss / low memory / context recreation: free every target and history
    void trimIdle();
    void setBudget(int64_t bytes) { fBudget = bytes; }          // 0 = unlimited, counted over all backends; acquire fails cleanly beyond it
    TargetPool::Stats poolStats() const;
    int64_t heldBytes() const { return poolStats().bytes; }
    int backendOfStep(int step) const { return step >= 0 && step < (int)fRoute.size() ? fRoute[step] : -1; }   // valid after the first render
    const Plan& plan() const { return *fPlan; }

private:
    bool runOne(const FrameRequest& r, int64_t frame, Target* source, const std::function<void(Target*)>* consume, FrameResult* out);
    void commit();
    void reset();
    void sizeOf(int bufferIndex, int w, int h, int* ow, int* oh) const;
    bool resolveRoutes(FrameResult* out);     // pass -> backend, buffer home, formats (after capability checks)
    Target* acquireTarget(int backend, int w, int h, Format f);
    void release(Target* t);                  // back to the pool of the backend that owns it

    std::vector<Backend*> fBackends;
    std::shared_ptr<const Plan> fPlan;
    std::vector<std::unique_ptr<TargetPool>> fPools;   // one per backend
    std::vector<int> fRoute;                      // per step: index into fBackends
    std::vector<int> fHome;                       // per buffer: index into fBackends of the backend that owns its targets
    int64_t fBudget = 0;
    std::vector<Format> fFormats;                 // per buffer, after capability resolution
    std::vector<std::deque<Target*>> fCommitted;  // per history buffer: frames up to lastFrame-1, newest first
    std::vector<Target*> fPending;                // output of `lastFrame`, not yet part of history
    int64_t fLastFrame = -1;
    uint64_t fSignature = 0;
    int fW = 0, fH = 0;
    bool fFormatsDone = false;
};

}  // namespace am::rg

package com.effects.motion.ui.editor.panels

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.effects.motion.R
import com.effects.motion.ai.AiAction
import com.effects.motion.ai.AiTools
import com.effects.motion.ai.CutoutSession
import com.effects.motion.ai.MatteEdge
import com.effects.motion.ai.backgroundMark
import com.effects.motion.editor.EditorPanel
import com.effects.motion.editor.EditorState
import com.effects.motion.ui.editor.LocalEditorScope
import com.effects.motion.ui.editor.PanelHeight
import com.effects.motion.ui.editor.PanelIcons
import com.effects.motion.ui.editor.effects.AiProgressDialog
import com.effects.motion.ui.theme.Am

/** Remove-background panel: brush over the object on the canvas, then Apply. Replaces the old pop-up for photos. */
@Composable
internal fun CutoutPanel(state: EditorState, modifier: Modifier) {
    val layer = state.selected ?: return
    val context = LocalContext.current
    val scope = LocalEditorScope.current
    val mark = layer.backgroundMark
    val source = mark?.original ?: layer.node["fillImage"]
    if (source == null) {
        androidx.compose.runtime.LaunchedEffect(Unit) { state.panel = EditorPanel.Tools }
        return
    }
    val turn = (state.scene.media(source) ?: mark?.media)?.orientation ?: 0
    val preparing = stringResource(R.string.cutout_preparing)
    val failed = stringResource(R.string.ai_model_failed)
    val session = remember(layer.id, source) { CutoutSession(layer.id, source, turn) }
    DisposableEffect(session) {
        com.effects.motion.ai.CutoutBrush.session = session
        session.start(context, preparing, failed)
        onDispose {
            if (com.effects.motion.ai.CutoutBrush.session === session) com.effects.motion.ai.CutoutBrush.session = null
            session.close()
        }
    }
    val ai = remember(state, context, scope) { AiTools(context.applicationContext, state, scope) }
    var edge by remember { mutableStateOf(MatteEdge()) }
    val ready = session.phase == CutoutSession.Phase.Ready
    val canApply = ready && session.hasKeep && ai.running == null
    fun apply() {
        val points = session.points()
        ai.subject = points.filter { it.keep }.map { it.u to it.v }
        ai.avoid = points.filter { !it.keep }.map { it.u to it.v }
        ai.edge = edge
        ai.precisePick = true
        ai.apply(AiAction.Background, confirmed = true)
    }
    Row(modifier.background(Am.Panel)) {
        Column(Modifier.width(168.px).heightIn(max = PanelHeight).fillMaxHeight()) {
            Box(Modifier.weight(1f).fillMaxWidth().clickable { state.panel = EditorPanel.Tools }, contentAlignment = Alignment.Center) {
                PanelIcon(PanelIcons.Back, Am.OnDark, description = stringResource(R.string.topbar_back))
            }
            Spacer(Modifier.weight(3f))
        }
        Column(Modifier.weight(1f).fillMaxHeight().background(Am.PanelInset).verticalScroll(rememberScrollState()).padding(horizontal = 8.dp, vertical = 6.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(Modifier.fillMaxWidth().height(48.dp), Arrangement.spacedBy(6.dp)) {
                BrushChip(stringResource(R.string.cutout_keep), Color(0xFF3DDC84), !session.erase, Modifier.weight(1f)) { session.erase = false }
                BrushChip(stringResource(R.string.cutout_erase), Color(0xFFFF5252), session.erase, Modifier.weight(1f)) { session.erase = true }
                BrushChip(stringResource(R.string.cutout_undo), Am.OnDark, false, Modifier.weight(1f), session.strokes.isNotEmpty()) { session.undo() }
                BrushChip(stringResource(R.string.cutout_clear), Am.OnDark, false, Modifier.weight(1f), session.strokes.isNotEmpty()) { session.clear() }
            }
            Text(
                when {
                    session.phase == CutoutSession.Phase.Failed -> session.message
                    !ready -> session.message.ifEmpty { preparing }
                    session.busy -> stringResource(R.string.cutout_working)
                    else -> stringResource(R.string.cutout_brush_hint)
                },
                color = Am.Caption, fontSize = 12.sp, lineHeight = 16.sp,
            )
            EdgeSlider(stringResource(R.string.cutout_softness), edge.softness, 0..MatteEdge.MAX_SOFTNESS) { edge = edge.copy(softness = it) }
            EdgeSlider(stringResource(R.string.cutout_grow_shrink), edge.grow, -MatteEdge.MAX_GROW..MatteEdge.MAX_GROW) { edge = edge.copy(grow = it) }
            Box(Modifier.fillMaxWidth().height(48.dp).clip(PanelShape).background(if (canApply) Am.Accent else Am.Button)
                .clickable(enabled = canApply, role = Role.Button) { apply() }, contentAlignment = Alignment.Center) {
                Text(stringResource(R.string.apply), color = if (canApply) Color.Black else Am.Caption, fontSize = 15.sp, maxLines = 1)
            }
        }
    }
    AiProgressDialog(ai)
}

@Composable
private fun BrushChip(label: String, color: Color, chosen: Boolean, modifier: Modifier, enabled: Boolean = true, onClick: () -> Unit) {
    Box(modifier.fillMaxHeight().widthIn(min = 52.dp).clip(PanelShape).background(if (chosen) PanelDark else Am.Field)
        .clickable(enabled = enabled, role = Role.Button, onClick = onClick).padding(horizontal = 6.dp), contentAlignment = Alignment.Center) {
        Text(label, color = if (enabled) color else Am.Caption, fontSize = 14.sp, maxLines = 1)
    }
}

package com.effects.motion

import android.app.Application
import android.util.Log
import kotlin.system.exitProcess

class EffectsApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        if (!SecurityGuard.allowLaunch(this)) {
            Log.e("EffectsApplication", "Release integrity check failed; stopping app process")
            android.os.Process.killProcess(android.os.Process.myPid())
            exitProcess(10)
        }
    }
}

package com.effects.motion.editor

import com.effects.motion.model.Pt
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.sin
import kotlin.math.sqrt

// 3x3 matrices are row-major DoubleArray(9).
internal val M3_IDENTITY: DoubleArray get() = doubleArrayOf(1.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 1.0)

internal fun m3mul(a: DoubleArray, b: DoubleArray) = DoubleArray(9) { i -> (0..2).sumOf { k -> a[i / 3 * 3 + k] * b[k * 3 + i % 3] } }

internal fun m3t(a: DoubleArray) = DoubleArray(9) { a[it % 3 * 3 + it / 3] }

internal fun m3inv(a: DoubleArray): DoubleArray? {
    val c0 = a[4] * a[8] - a[5] * a[7]
    val c1 = a[5] * a[6] - a[3] * a[8]
    val c2 = a[3] * a[7] - a[4] * a[6]
    val det = a[0] * c0 + a[1] * c1 + a[2] * c2
    if (abs(det) < 1e-14 || !det.isFinite()) return null
    return doubleArrayOf(
        c0 / det, (a[2] * a[7] - a[1] * a[8]) / det, (a[1] * a[5] - a[2] * a[4]) / det,
        c1 / det, (a[0] * a[8] - a[2] * a[6]) / det, (a[2] * a[3] - a[0] * a[5]) / det,
        c2 / det, (a[1] * a[6] - a[0] * a[7]) / det, (a[0] * a[4] - a[1] * a[3]) / det,
    )
}

internal fun solveLinear(a: Array<DoubleArray>, b: DoubleArray): DoubleArray? {
    val n = b.size
    for (c in 0 until n) {
        var p = c
        for (r in c + 1 until n) if (abs(a[r][c]) > abs(a[p][c])) p = r
        if (abs(a[p][c]) < 1e-12) return null
        if (p != c) { val t = a[p]; a[p] = a[c]; a[c] = t; val tb = b[p]; b[p] = b[c]; b[c] = tb }
        for (r in c + 1 until n) {
            val f = a[r][c] / a[c][c]
            for (k in c until n) a[r][k] -= f * a[c][k]
            b[r] -= f * b[c]
        }
    }
    val x = DoubleArray(n)
    for (r in n - 1 downTo 0) {
        var v = b[r]
        for (k in r + 1 until n) v -= a[r][k] * x[k]
        x[r] = v / a[r][r]
    }
    return if (x.all { it.isFinite() }) x else null
}

private fun normalizer(p: List<Pt>): DoubleArray {
    val cx = p.sumOf { it.x.toDouble() } / p.size
    val cy = p.sumOf { it.y.toDouble() } / p.size
    val d = p.sumOf { hypot(it.x - cx, it.y - cy) } / p.size
    val s = if (d > 1e-9) sqrt(2.0) / d else 1.0
    return doubleArrayOf(s, 0.0, -s * cx, 0.0, s, -s * cy, 0.0, 0.0, 1.0)
}

/** The perspective map that carries the four [from] points onto the four [to] points. */
internal fun homographyOf(from: List<Pt>, to: List<Pt>): DoubleArray? {
    if (from.size != 4 || to.size != 4) return null
    val ts = normalizer(from)
    val td = normalizer(to)
    val a = Array(8) { DoubleArray(8) }
    val b = DoubleArray(8)
    for (i in 0 until 4) {
        val x = ts[0] * from[i].x + ts[2]
        val y = ts[4] * from[i].y + ts[5]
        val u = td[0] * to[i].x + td[2]
        val v = td[4] * to[i].y + td[5]
        a[2 * i] = doubleArrayOf(x, y, 1.0, 0.0, 0.0, 0.0, -u * x, -u * y)
        b[2 * i] = u
        a[2 * i + 1] = doubleArrayOf(0.0, 0.0, 0.0, x, y, 1.0, -v * x, -v * y)
        b[2 * i + 1] = v
    }
    val h = solveLinear(a, b) ?: return null
    val hn = doubleArrayOf(h[0], h[1], h[2], h[3], h[4], h[5], h[6], h[7], 1.0)
    val back = m3inv(td) ?: return null
    return m3mul(back, m3mul(hn, ts))
}

internal fun homographyMap(h: DoubleArray, p: Pt): Pt? {
    val w = h[6] * p.x + h[7] * p.y + h[8]
    if (abs(w) < 1e-12) return null
    return Pt(((h[0] * p.x + h[1] * p.y + h[2]) / w).toFloat(), ((h[3] * p.x + h[4] * p.y + h[5]) / w).toFloat())
}

internal class Pose3(val x: Double, val y: Double, val z: Double, val turn: DoubleArray)

private fun rodrigues(w: DoubleArray): DoubleArray {
    val th = sqrt(w[0] * w[0] + w[1] * w[1] + w[2] * w[2])
    if (th < 1e-12) return M3_IDENTITY
    val kx = w[0] / th; val ky = w[1] / th; val kz = w[2] / th
    val k = doubleArrayOf(0.0, -kz, ky, kz, 0.0, -kx, -ky, kx, 0.0)
    val k2 = m3mul(k, k)
    val s = sin(th); val c = 1 - cos(th)
    return DoubleArray(9) { (if (it % 4 == 0) 1.0 else 0.0) + s * k[it] + c * k2[it] }
}

private fun nearestRotation(m: DoubleArray): DoubleArray? {
    var r = m
    repeat(14) { val inv = m3inv(r) ?: return null; val t = m3t(inv); r = DoubleArray(9) { 0.5 * (r[it] + t[it]) } }
    return r
}

/**
 * Finds where a flat layer must sit and how it must be turned so that, seen through the scene camera, the
 * reference corners [ref] land on [cur]. [anchor] is the layer's pivot in scene space, [focal] the camera's
 * focal length in pixels and (cx, cy) the middle of the frame.
 */
internal fun solvePose(ref: List<Pt>, cur: List<Pt>, anchor: Pt, focal: Double, cx: Double, cy: Double, previous: Pose3?): Pose3? {
    val h = homographyOf(ref, cur) ?: return null
    val toCentre = doubleArrayOf(1.0, 0.0, -cx, 0.0, 1.0, -cy, 0.0, 0.0, 1.0)
    val toAnchor = doubleArrayOf(1.0, 0.0, anchor.x.toDouble(), 0.0, 1.0, anchor.y.toDouble(), 0.0, 0.0, 1.0)
    val g = m3mul(doubleArrayOf(1 / focal, 0.0, 0.0, 0.0, 1 / focal, 0.0, 0.0, 0.0, 1.0), m3mul(toCentre, m3mul(h, toAnchor)))
    val n1 = sqrt(g[0] * g[0] + g[3] * g[3] + g[6] * g[6])
    val n2 = sqrt(g[1] * g[1] + g[4] * g[4] + g[7] * g[7])
    if (n1 + n2 < 1e-12) return null
    var mu = 2.0 / (n1 + n2)
    if (mu * g[8] < 0) mu = -mu
    val r1 = doubleArrayOf(mu * g[0], mu * g[3], mu * g[6])
    val r2 = doubleArrayOf(mu * g[1], mu * g[4], mu * g[7])
    val r3 = doubleArrayOf(r1[1] * r2[2] - r1[2] * r2[1], r1[2] * r2[0] - r1[0] * r2[2], r1[0] * r2[1] - r1[1] * r2[0])
    val r0 = nearestRotation(doubleArrayOf(r1[0], r2[0], r3[0], r1[1], r2[1], r3[1], r1[2], r2[2], r3[2])) ?: return null
    val l0 = doubleArrayOf(mu * g[2] + cx, mu * g[5] + cy, mu * g[8] - focal)
    val d = ref.map { doubleArrayOf((it.x - anchor.x).toDouble(), (it.y - anchor.y).toDouble()) }

    fun residual(r: DoubleArray, l: DoubleArray): DoubleArray {
        val out = DoubleArray(8)
        for (i in 0 until 4) {
            val wx = l[0] + r[0] * d[i][0] + r[1] * d[i][1]
            val wy = l[1] + r[3] * d[i][0] + r[4] * d[i][1]
            val wz = l[2] + r[6] * d[i][0] + r[7] * d[i][1]
            val k = focal / (wz + focal)
            out[2 * i] = cx + (wx - cx) * k - cur[i].x
            out[2 * i + 1] = cy + (wy - cy) * k - cur[i].y
        }
        return out
    }

    class Fit(val r: DoubleArray, val l: DoubleArray, val cost: Double)

    fun refine(r0: DoubleArray, l0: DoubleArray): Fit {
        var r = r0; var l = l0
        var res = residual(r, l)
        var cost = res.sumOf { it * it }
        var lambda = 1e-3
        repeat(30) {
            val jac = Array(8) { DoubleArray(6) }
            val eps = 1e-6
            for (k in 0 until 6) {
                val dw = DoubleArray(3); val dl = l.copyOf()
                if (k < 3) dw[k] = eps else dl[k - 3] += eps
                val moved = residual(m3mul(rodrigues(dw), r), dl)
                for (i in 0 until 8) jac[i][k] = (moved[i] - res[i]) / eps
            }
            val a = Array(6) { i -> DoubleArray(6) { j -> (0 until 8).sumOf { jac[it][i] * jac[it][j] } } }
            val g = DoubleArray(6) { i -> -(0 until 8).sumOf { jac[it][i] * res[it] } }
            for (i in 0 until 6) a[i][i] += lambda * (a[i][i] + 1e-9)
            val step = solveLinear(a, g)
            if (step == null) { lambda *= 10; return@repeat }
            val r2 = m3mul(rodrigues(doubleArrayOf(step[0], step[1], step[2])), r)
            val l2 = doubleArrayOf(l[0] + step[3], l[1] + step[4], l[2] + step[5])
            if (l2[2] + focal <= 1) { lambda *= 10; return@repeat }
            val res2 = residual(r2, l2)
            val cost2 = res2.sumOf { it * it }
            if (cost2 < cost) { r = r2; l = l2; res = res2; cost = cost2; lambda = max(lambda / 3, 1e-9) } else lambda *= 5
        }
        return Fit(r, l, cost)
    }

    val fresh = refine(r0, l0)
    val pick = previous?.let { p ->
        val kept = refine(p.turn, doubleArrayOf(p.x, p.y, p.z))
        if (kept.cost <= max(fresh.cost * 1.5, 1.0)) kept else fresh
    } ?: fresh
    return Pose3(pick.l[0], pick.l[1], pick.l[2], pick.r)
}

internal fun median3(v: List<Double>): List<Double> = List(v.size) { i ->
    if (i == 0 || i == v.size - 1) v[i] else listOf(v[i - 1], v[i], v[i + 1]).sorted()[1]
}

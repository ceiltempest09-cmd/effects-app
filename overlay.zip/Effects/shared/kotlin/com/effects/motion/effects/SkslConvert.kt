package com.effects.motion.effects

import org.json.JSONArray
import org.json.JSONObject

class Converted(val sksl: String, val params: JSONArray, val notes: List<String>, val problems: List<String>) {
    val ok: Boolean get() = problems.isEmpty()
}

/**
 * Turns the GLSL of an Alight Motion effect into SkSL that EffectRuntime.load accepts (`glsl = false`), or into a native GLSL ES 3.00 pass
 * for the OpenGL ES backend (`glsl = true`, the "GLSL" shader language of the import dialog). The GLSL pass keeps the shader's own types and
 * functions, reads and writes in the engine's float pipeline and follows the native contract (docs/EFFECT_FORMAT.md section 9):
 * premultiplied output, `gl_FragCoord`, `size` and `time`, uniforms by name. In SkSL mode:
 * uniform shader image + uniform float2 size / float time, controls become uniforms with the same name.
 * One-pass effects only (multi-pass graphs go through graph/GraphConvert.kt). Preprocessor directives are expanded by the real
 * GlslPreprocessor. Anything it cannot convert is reported, never faked.
 */
object SkslConvert {
    private val Reserved = setOf(
        "image", "size", "time", "layer", "fromLayer", "toLayer", "duration", "orient", "visible", "screen",
        "beat", "beatTime", "beatIndex", "paletteSize", "paletteSpread", "swatches", "glyphCount", "glyphColumns",
        "glyphCell", "input", "output", "sample", "buffer", "shared", "filter", "common", "active", "partition",
        "resource", "layout", "uniform", "half", "float", "int", "bool", "main",
    )
    private val Ident = Regex("[A-Za-z_][A-Za-z0-9_]*")

    fun convert(fx: AmEffect, glsl: Boolean = false): Converted {
        val problems = linkedSetOf<String>()
        val notes = mutableListOf<String>()
        if (fx.isGraph) problems += "Uses ${fx.passList.size.coerceAtLeast(fx.passes)} render passes. This is the one-pass converter; multi-pass effects are converted by GraphConvert (EffectImporter routes them there)."
        if (fx.hasScript) problems += "Has a JavaScript animate() script, which is not supported."
        val content = fx.params.firstOrNull { it.tag == "texture" && it.srcType == "content" }?.id
        fx.params.filter { it.tag == "texture" && it.srcType != "content" }
            .forEach { problems += "Texture '${it.id}' (${it.srcType ?: "unknown"}) is not supported." }

        val json = JSONArray()
        val decls = mutableListOf<String>()
        val helpers = mutableListOf<String>()
        val swap = linkedMapOf<String, String>()
        val seen = hashSetOf<String>()
        fun num(s: String?, d: Double) = s?.trim()?.toDoubleOrNull() ?: d
        fun scalar(id: String, label: String, p: AmParam, kind: String) = JSONObject()
            .put("id", id).put("label", label).put("type", kind).put("default", num(p.default, 0.0)).apply {
                p.min?.toDoubleOrNull()?.let { put("min", it) }
                p.max?.toDoubleOrNull()?.let { put("max", it) }
                put("step", num(p.step, 0.01))
                if (p.type == "percent") put("percent", true)
            }

        for (p in fx.params) {
            if (p.tag == "texture" || p.tag == "section") continue
            if (!Ident.matches(p.id)) { problems += "Control id '${p.id}' is not a valid name."; continue }
            if (!seen.add(p.id)) { problems += "Control id '${p.id}' appears twice."; continue }
            val name = if (p.id in Reserved) p.id + "_p" else p.id
            if (name != p.id) swap[p.id] = name
            when (p.tag) {
                "slider", "spinner" -> {
                    json.put(scalar(name, p.label, p, if (p.type == "angle") "angle" else "float"))
                    decls += "uniform float $name;"
                }
                "switch" -> {
                    json.put(JSONObject().put("id", name).put("label", p.label).put("type", "switch")
                        .put("default", p.default.equals("true", true) || p.default == "1"))
                    decls += "uniform float $name;"
                    swap[p.id] = "($name > 0.5)"
                }
                "selector" -> {
                    if (p.choices.isEmpty()) { problems += "Selector '${p.id}' has no choices."; continue }
                    val values = p.choices.map { it.value }
                    val direct = values == values.indices.toList()
                    val jsonId = if (direct) name else name + "_i"
                    val at = values.indexOf(p.default.trim().toIntOrNull()).coerceAtLeast(0)
                    json.put(JSONObject().put("id", jsonId).put("label", p.label).put("type", "choice")
                        .put("default", at).put("options", JSONArray(p.choices.map { it.label })))
                    decls += "uniform int $jsonId;"
                    if (!direct) {
                        helpers += "int ${name}_map(int i) {\n" +
                            values.dropLast(1).mapIndexed { i, v -> "  if (i == $i) return $v;\n" }.joinToString("") +
                            "  return ${values.last()};\n}"
                        swap[p.id] = "${name}_map($jsonId)"
                    }
                }
                "point" -> {
                    val xy = p.default.split(',').map { num(it, 0.0) } + listOf(0.0, 0.0)
                    json.put(JSONObject().put("id", name).put("label", p.label).put("type", "point")
                        .put("default", JSONArray().put(xy[0]).put(xy[1])))
                    decls += if (glsl) "uniform vec2 $name;" else "uniform float2 $name;"
                }
                "xyz" -> {
                    val v = p.default.split(',').map { num(it, 0.0) } + listOf(0.0, 0.0, 0.0)
                    listOf("x", "y", "z").forEachIndexed { i, axis ->
                        json.put(scalar("${name}_$axis", "${p.label} ${axis.uppercase()}", p, "float").put("default", v[i]))
                        decls += "uniform float ${name}_$axis;"
                    }
                    swap[p.id] = (if (glsl) "vec3" else "float3") + "(${name}_x, ${name}_y, ${name}_z)"
                }
                "color" -> {
                    val c = p.default.trim().lowercase().takeIf { Regex("#[0-9a-f]{6}|#[0-9a-f]{8}").matches(it) } ?: "#ff000000"
                    json.put(JSONObject().put("id", name).put("label", p.label).put("type", "color").put("default", c))
                    decls += if (glsl) "uniform vec4 $name;" else "layout(color) uniform half4 $name;"
                }
                else -> notes += "Skipped unknown control <${p.tag}>."
            }
        }

        val pre = com.effects.motion.effects.graph.GlslPreprocessor.run(fx.shader, effect = fx.id, file = fx.id)
        pre.issues.filter { it.error }.forEach { problems += "Line ${it.line}: ${it.message}" }
        var src = stripComments(pre.text)
        src = src.replace(Regex("""(?m)^\s*#\s*version.*$"""), "")
            .replace(Regex("""(?m)^\s*precision\s+\w+\s+\w+\s*;"""), "")
            .replace(Regex("""\b(lowp|mediump|highp)\s+"""), "")
        if (Regex("""(?m)^\s*uniform\b""").containsMatchIn(src)) {
            notes += "Removed uniform lines from the shader (controls come from the params list)."
            src = src.replace(Regex("""(?m)^\s*uniform\b[^;]*;"""), "")
        }
        if (!glsl) src = src.replace(Regex("""\bmat([234])\b""")) { "float${it.groupValues[1]}x${it.groupValues[1]}" }
            .replace(Regex("""\bivec([234])\b""")) { "int${it.groupValues[1]}" }
            .replace(Regex("""\bbvec([234])\b""")) { "bool${it.groupValues[1]}" }
            .replace(Regex("""\bvec([234])\b""")) { "float${it.groupValues[1]}" }
        src = Regex("""\b(?:texture2DCv|texture2D|texture)\s*\(\s*(\w+)\.texture\s*,""").replace(src) { m ->
            if (m.groupValues[1] != content) problems += "Samples '${m.groupValues[1]}', which is not the layer image."
            "_tex("
        }
        if (Regex("""\w+\.texture\b""").containsMatchIn(src)) problems += "Uses a texture in a way that is not supported."

        val usesLayer = Regex("""\bacLayer(Size|Center)\b""").containsMatchIn(src)
        if (glsl && usesLayer) problems += "Uses the layer size (acLayerSize / acLayerCenter), which the GLSL pass does not have. Import it as SkSL."
        src = src.replace(Regex("""\bacTime\b"""), "time").replace(Regex("""\bacScreenSize\b"""), "size")
            .replace(Regex("""\bacLayerSize\b"""), "layer").replace(Regex("""\bacLayerCenter\b"""), "(layer * 0.5)")
        if (swap.isNotEmpty()) {
            val pattern = Regex("""(?<![\w.])(""" + swap.keys.joinToString("|") { Regex.escape(it) } + """)(?!\w)""")
            src = pattern.replace(src) { swap.getValue(it.value) }
        }
        src = if (glsl) rewriteGlslMain(src, problems) else rewriteMain(src, problems)
        Regex("""\bac[A-Z]\w*""").findAll(src).map { it.value }.distinct().forEach { problems += "Uses $it, which is not supported yet." }

        notes += "Colors: the layer is read as straight alpha and the result is premultiplied. Check the look and tell me if it is off."
        if (fx.params.any { it.tag == "section" }) notes += "Section headings are flattened (no groups yet)."
        val sksl = if (glsl) buildString {
            append("#version 300 es\nprecision highp float;\nprecision highp int;\nprecision highp sampler2D;\n")
            append("uniform sampler2D image;\nuniform vec2 size;\nuniform float time;\n")
            decls.forEach { append(it).append('\n') }
            append("out vec4 _frag;\nvec4 _out;\n")
            append("vec4 _tex(vec2 p) {\n  vec4 c = texture(image, p);\n  return c.a > 0.0 ? vec4(c.rgb / c.a, c.a) : c;\n}\n")
            helpers.forEach { append(it).append('\n') }
            append(src.trim()).append('\n')
            append("void main() {\n  _am_main();\n  _frag = vec4(_out.rgb * _out.a, _out.a);\n}\n")
        } else buildString {
            append("uniform shader image;\nuniform float2 size;\nuniform float time;\n")
            if (usesLayer) append("uniform float2 layer;\n")
            decls.forEach { append(it).append('\n') }
            append("float4 _tex(float2 p) {\n  half4 c = image.eval(p * size);\n  float a = float(c.a);\n")
            append("  float3 rgb = a > 0.0 ? float3(c.rgb) / a : float3(c.rgb);\n  return float4(rgb, a);\n}\n")
            helpers.forEach { append(it).append('\n') }
            append(src.trim()).append('\n')
        }
        return Converted(sksl, json, notes, problems.toList())
    }

    private fun stripComments(s: String) =
        s.replace(Regex("""/\*.*?\*/""", RegexOption.DOT_MATCHES_ALL), " ").replace(Regex("""//[^\n]*"""), "")

    /** GLSL mode: the shader's main() becomes _am_main() writing the global _out (straight alpha); the generated main() premultiplies it. */
    private fun rewriteGlslMain(s: String, problems: MutableSet<String>): String {
        val m = Regex("""\bvoid\s+main\s*\(\s*(void)?\s*\)\s*\{""").find(s)
        if (m == null) { problems += "The shader has no main() function."; return s }
        var depth = 1
        var i = m.range.last + 1
        while (i < s.length && depth > 0) {
            when (s[i]) { '{' -> depth++; '}' -> depth-- }
            i++
        }
        if (depth != 0) { problems += "Unbalanced braces in main()."; return s }
        val body = s.substring(m.range.last + 1, i - 1)
        if (Regex("""\bdiscard\b""").containsMatchIn(body)) problems += "Uses discard, which is not supported."
        val joined = s.substring(0, m.range.first) + "void _am_main() {\n  _out = vec4(0.0);" + body + "\n}" + s.substring(i)
        return joined.replace(Regex("""\bacScreenNorm\b"""), "(gl_FragCoord.xy / size)").replace(Regex("""\bgl_FragColor\b"""), "_out")
    }

    private fun rewriteMain(s: String, problems: MutableSet<String>): String {
        val m = Regex("""\bvoid\s+main\s*\(\s*(void)?\s*\)\s*\{""").find(s)
        if (m == null) { problems += "The shader has no main() function."; return s }
        var depth = 1
        var i = m.range.last + 1
        while (i < s.length && depth > 0) {
            when (s[i]) { '{' -> depth++; '}' -> depth-- }
            i++
        }
        if (depth != 0) { problems += "Unbalanced braces in main()."; return s }
        val outside = s.substring(0, m.range.first) + s.substring(i)
        if (Regex("""\bgl_Frag\w*|\bacScreenNorm\b""").containsMatchIn(outside)) problems += "gl_FragColor / gl_FragCoord / acScreenNorm are used outside main()."
        var body = s.substring(m.range.last + 1, i - 1)
        if (Regex("""\bdiscard\b""").containsMatchIn(body)) problems += "Uses discard, which is not supported."
        body = body.replace(Regex("""gl_FragCoord\s*\.\s*xy"""), "_fc").replace("gl_FragCoord", "float4(_fc, 0.0, 1.0)")
            .replace(Regex("""\bacScreenNorm\b"""), "(_fc / size)").replace("gl_FragColor", "_out")
            .replace(Regex("""\breturn\s*;"""), "return half4(float4(_out.rgb * _out.a, _out.a));")
        return s.substring(0, m.range.first) + "half4 main(float2 _fc) {\n  float4 _out = float4(0.0);" + body +
            "\n  return half4(float4(_out.rgb * _out.a, _out.a));\n}" + s.substring(i)
    }
}

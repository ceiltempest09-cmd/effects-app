package com.effects.motion.ui.editor.effects

import android.provider.OpenableColumns
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.effects.motion.editor.EditorState
import com.effects.motion.effects.CustomLibraries
import com.effects.motion.effects.EffectImporter
import com.effects.motion.effects.EffectSources
import com.effects.motion.effects.ImportLine
import com.effects.motion.effects.ImportTier
import com.effects.motion.effects.ImportedEffects
import com.effects.motion.effects.ShaderLang
import com.effects.motion.platform.LocalContext
import com.effects.motion.ui.editor.Dropdown
import com.effects.motion.ui.editor.PickRow
import com.effects.motion.ui.theme.Am
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** The small "Import" box in the Effects Library header (red box in photo 3). */
@Composable
internal fun ImportChip(onClick: () -> Unit) {
    Row(
        Modifier.padding(start = 4.dp).height(34.dp).clip(RoundedCornerShape(8.dp)).background(Am.Panel)
            .clickable(onClick = onClick).padding(horizontal = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) { Text("Import", color = Am.Accent, fontSize = 12.sp, maxLines = 1) }
}

/**
 * The library buttons under the header: After Effects and Alight Motion fill the width, the custom libraries the user made follow them and are
 * reached by sliding the row from right to left. Tap the selected one again to go back to Effects Motion.
 */
@Composable
internal fun SourceBar(source: String, libraries: List<Pair<String, String>>, empty: Boolean, onPick: (String) -> Unit) {
    Column(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
        BoxWithConstraints(Modifier.fillMaxWidth()) {
            val each = (maxWidth - 32.dp) / 2
            Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp)) {
                libraries.forEachIndexed { i, (key, label) ->
                    val on = key == source
                    Box(
                        Modifier.padding(start = if (i == 0) 0.dp else 8.dp).width(each).height(44.dp).clip(RoundedCornerShape(8.dp))
                            .background(if (on) Am.Accent.copy(alpha = 0.3f) else Am.Panel)
                            .clickable { onPick(if (on) EffectSources.Native else key) },
                        contentAlignment = Alignment.Center,
                    ) { Text(label, Modifier.padding(horizontal = 8.dp), color = if (on) Am.Accent else Am.OnDark, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis) }
                }
            }
        }
        if (empty && source != EffectSources.Native)
            Text("Nothing here yet. Tap Import to add effects.", Modifier.padding(start = 12.dp, end = 12.dp, top = 10.dp), color = Am.OnDark.copy(alpha = 0.7f), fontSize = 13.sp)
    }
}

/** One row of the import options, in the style of the project settings: name and hint on the left, the white choice box on the right. */
@Composable
private fun OptionRow(label: String, hint: String, value: String, options: @Composable ColumnScope.(close: () -> Unit) -> Unit) {
    Row(Modifier.fillMaxWidth().height(52.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f).padding(end = 8.dp)) {
            Text(label, color = Am.OnDark, fontSize = 15.sp, maxLines = 1)
            Text(hint, color = Am.OnDark.copy(alpha = 0.55f), fontSize = 11.sp, maxLines = 1)
        }
        Box(Modifier.width(150.dp).height(44.dp)) { Dropdown(value, menuColor = Am.Panel, options = options) }
    }
}

/**
 * Import flow: tap Import, pick the files, then one options dialog: Library effect (where the effect is stored, or a new custom library),
 * Bit float (32 / 16 / 8 bit = Heavy effects / Balance / Performance) and Shader language (GLSL or SkSL). Then convert and report.
 * [current] is the library being looked at; it is the starting choice of Library effect. Shows nothing while [open] is false.
 */
@Composable
internal fun EffectImportFlow(state: EditorState, open: Boolean, current: String, onClose: () -> Unit, onShow: (source: String, pack: String) -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val prefs = remember { context.getSharedPreferences("effects", 0) }
    var picked by remember { mutableStateOf<List<android.net.Uri>?>(null) }
    var working by remember { mutableStateOf(false) }
    var tier by remember { mutableStateOf(ImportTier.RAYTRACED) }
    var lang by remember { mutableStateOf(ShaderLang.GLSL) }
    var library by remember { mutableStateOf(EffectSources.Native to EffectSources.label(EffectSources.Native)) }
    var naming by remember { mutableStateOf(false) }
    var typed by remember { mutableStateOf("") }
    var report by remember { mutableStateOf<List<ImportLine>?>(null) }
    fun finish() { picked = null; working = false; report = null; naming = false; typed = ""; onClose() }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isEmpty()) finish() else {
            val known = EffectSources.choices(context)
            library = known.firstOrNull { it.first == current } ?: known.first()
            tier = prefs.getString("import_tier", null)?.let { ImportTier.named(it) } ?: ImportTier.RAYTRACED
            lang = ShaderLang.named(prefs.getString("import_lang", null))
            picked = uris
        }
    }
    LaunchedEffect(open) { if (open) picker.launch(arrayOf("*/*")) }
    if (!open) return

    fun run() {
        val uris = picked ?: return
        val target = library
        val chosen = tier
        val language = lang
        prefs.edit().putString("import_tier", chosen.name).putString("import_lang", language.name).apply()
        working = true
        scope.launch {
            val first = withContext(Dispatchers.IO) {
                val resolver = context.contentResolver
                val named = uris.map { uri ->
                    val label = resolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
                        ?.use { c -> if (c.moveToFirst()) c.getString(0) else null } ?: uri.lastPathSegment ?: "file"
                    label to { resolver.openInputStream(uri) }
                }
                EffectImporter.import(context, target.first, chosen, named, language)
            }
            state.engine.reloadEffects(context).join()
            val catalog = state.engine.effects.value
            var dropped = false
            val checked = first.lines.map { line ->
                val id = line.effectId ?: return@map line
                val status = catalog.find(id)?.status ?: "not registered"
                if (status == "ok") line else {
                    withContext(Dispatchers.IO) { ImportedEffects.delete(context, id) }
                    dropped = true
                    ImportLine(line.file, false, "Converted, but the shader did not compile: " + status.removePrefix("shader error: ") +
                        if (language == ShaderLang.GLSL) "\nTry again with SkSL." else "")
                }
            }
            if (dropped) state.engine.reloadEffects(context).join()
            if (checked.any { it.ok }) CustomLibraries.save(context, target.first, target.second)
            report = checked
            working = false
        }
    }

    when {
        report != null -> AlertDialog(
            onDismissRequest = ::finish, containerColor = Am.Field, titleContentColor = Am.OnDark, textContentColor = Am.OnDark,
            title = { Text(if (report!!.any { it.ok }) "Import finished" else "Nothing imported") },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState())) {
                    report!!.forEach { Text((if (it.ok) "✓ " else "✗ ") + (if (it.file.isBlank()) "" else it.file + ": ") + it.text, Modifier.padding(bottom = 8.dp), fontSize = 13.sp) }
                }
            },
            confirmButton = {
                TextButton({ if (report!!.any { it.ok }) onShow(library.first, tier.pack); finish() }) { Text("OK", color = Am.Accent) }
            },
        )
        working -> AlertDialog(
            onDismissRequest = {}, containerColor = Am.Field, titleContentColor = Am.OnDark, textContentColor = Am.OnDark,
            title = { Text("Importing…") }, text = { Text("Converting and checking the shaders.") }, confirmButton = {},
        )
        picked != null && naming -> AlertDialog(
            onDismissRequest = { naming = false }, containerColor = Am.Field, titleContentColor = Am.OnDark, textContentColor = Am.OnDark,
            title = { Text("Custom library") },
            text = {
                Column {
                    Text("Name the new library. It appears next to Alight Motion; slide the buttons from right to left to see it.", fontSize = 13.sp)
                    val focus = remember { FocusRequester() }
                    LaunchedEffect(Unit) { focus.requestFocus() }
                    Box(Modifier.padding(top = 14.dp).fillMaxWidth().height(44.dp).clip(RoundedCornerShape(10.dp)).background(Am.Card).padding(horizontal = 12.dp), Alignment.CenterStart) {
                        BasicTextField(typed, { typed = it.take(30) }, Modifier.fillMaxWidth().focusRequester(focus), singleLine = true,
                            textStyle = TextStyle(color = Am.Navy, fontSize = 15.sp), cursorBrush = SolidColor(Am.Navy))
                        if (typed.isEmpty()) Text("Library name", color = Am.Navy.copy(alpha = 0.4f), fontSize = 15.sp)
                    }
                }
            },
            confirmButton = {
                TextButton({ if (typed.isNotBlank()) { library = CustomLibraries.resolve(context, typed); naming = false } }) { Text("OK", color = Am.Accent) }
            },
            dismissButton = { TextButton({ naming = false }) { Text("Cancel", color = Am.OnDark) } },
        )
        picked != null -> AlertDialog(
            onDismissRequest = ::finish, containerColor = Am.Field, titleContentColor = Am.OnDark, textContentColor = Am.OnDark,
            title = { Text("Import effects") },
            text = {
                Column {
                    val choices = EffectSources.choices(context)
                    OptionRow("Library effect", "Choose effects library", library.second) { close ->
                        choices.forEach { entry -> PickRow(entry.second, divider = true) { library = entry; close() } }
                        PickRow("Custom…", divider = false) { typed = ""; naming = true; close() }
                    }
                    Spacer(Modifier.height(8.dp))
                    OptionRow("Bit float", "Precision format", tier.bits) { close ->
                        val all = ImportTier.values()
                        all.forEachIndexed { i, t -> PickRow(t.bits, divider = i < all.lastIndex, description = t.tierName) { tier = t; close() } }
                    }
                    Spacer(Modifier.height(8.dp))
                    OptionRow("Shader language", "Choose shader language", lang.label) { close ->
                        val all = ShaderLang.values()
                        all.forEachIndexed { i, l -> PickRow(l.label, divider = i < all.lastIndex, description = l.hint) { lang = l; close() } }
                    }
                }
            },
            confirmButton = { TextButton({ run() }) { Text("Import", color = Am.Accent) } },
            dismissButton = { TextButton(::finish) { Text("Cancel", color = Am.OnDark) } },
        )
    }
}

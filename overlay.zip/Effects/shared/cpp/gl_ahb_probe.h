// gl_ahb_probe.h - Android only. Checks, on the real device, the building blocks for sharing GPU textures between native
// OpenGL ES passes and Skia/Vulkan: AHardwareBuffer <-> EGLImage <-> GL texture <-> framebuffer, plus fence/semaphore extensions.
#pragma once
#include <string>
namespace am {
// Appends report lines; returns the number of failed checks via *failed and passed checks via *passed.
std::string RunAhbInteropProbe(int* passed, int* failed);
}

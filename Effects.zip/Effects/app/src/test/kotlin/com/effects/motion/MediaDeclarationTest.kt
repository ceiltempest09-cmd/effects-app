package com.effects.motion

import com.effects.motion.model.MediaDeclaration
import com.effects.motion.model.XmlNode
import com.effects.motion.model.exifOrientation
import com.effects.motion.model.fpsText
import org.junit.Assert.assertEquals
import org.junit.Test

class MediaDeclarationTest {
    @Test fun aVideosFrameRateIsStoredAsFramesPerSecond() {
        assertEquals("30.00", fpsText(30f))
        assertEquals("29.97", fpsText(29.97f))
        assertEquals(30f, MediaDeclaration(XmlNode("media", mapOf("fps" to fpsText(30f)))).fps)
        assertEquals(null, MediaDeclaration(XmlNode("media", mapOf("fps" to "0.00"))).fps)
    }

    @Test fun everyExifOrientationGivesItsTurnAndMirror() {
        val expected = mapOf(0 to (0 to false), 1 to (0 to false), 2 to (0 to true), 3 to (180 to false), 4 to (180 to true),
            5 to (270 to true), 6 to (90 to false), 7 to (90 to true), 8 to (270 to false), 9 to (0 to false))
        for ((tag, turn) in expected) assertEquals("tag $tag", turn, exifOrientation(tag))
    }
}

// glsl_wrap.h - step 5c: desktop GLSL (lang="glsl") for the Vulkan backend.
// Vulkan has no loose uniforms, so the source is prepared for glslang's Vulkan front end by a TEXT rewrite that changes only declarations:
//   #version N (N >= 330)  ->  #version 450 (the Vulkan front end needs set / binding qualifiers)
//   uniform <scalar/vector> name;   ->  members of one generated std140 block  layout(set=0,binding=0) uniform AmLoose { ... };
//   uniform sampler2D name;         ->  layout(set=0, binding=K) uniform sampler2D name;   (K = 1, 2, ...)
//   out vec4 name;                  ->  layout(location = 0) out vec4 name;
//   uniform bool b;                 ->  an int member plus  #define b (<int> != 0)   (a bool cannot live in a block)
// Statements and expressions are never touched. Anything it cannot express is an error with the source line (no silent guess).
// Pure C++, host-tested (tests/native/glsl_wrap_test.cpp).
#pragma once

#include <map>
#include <string>

namespace am::rg {

struct GlslWrapResult {
    bool ok = false;
    std::string text;       // source for CompileGlslToSpirv(..., GlslDialect::Vulkan, ...)
    std::string error;      // when !ok
    int errorLine = 0;      // 1-based line in the ORIGINAL source (0 = whole source)
    int lineShift = 0;      // lines added in front of original line 1 (add to an original line number to get the new one)
    int samplers = 0, looseUniforms = 0;
};

GlslWrapResult WrapDesktopGlslForVulkan(const std::string& source, const std::map<std::string, std::string>& defines);

}  // namespace am::rg

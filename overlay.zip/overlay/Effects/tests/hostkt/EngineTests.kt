import com.effects.motion.effects.engine.*

private var failures = 0
private fun check(name: String, ok: Boolean) { if (!ok) { failures++; println("FAIL $name") } else println("ok   $name") }
private fun near(a: Double, b: Double) = kotlin.math.abs(a - b) < 1e-6

fun main() {
    val ok = CapabilityCheck.check(listOf("current_frame", "time_access"), setOf(EffectCapability.CurrentFrame))
    check("missing capability reported", ok.missing.size == 1 && !ok.ok)
    check("unknown capability reported", CapabilityCheck.check(listOf("warp_drive"), EffectCapability.entries.toSet()).unknown.size == 1)

    val fwd = TimeMap.constantSpeed(2.0, 10_000.0)
    check("speed x2", near(fwd.sourceMs(1000.0)!!, 2000.0))
    check("same answer when seeking directly", near(fwd.sourceMs(1234.5)!!, fwd.sourceMs(1234.5)!!))
    check("hold past end", near(fwd.sourceMs(60_000.0)!!, 10_000.0))
    val rev = TimeMap.reverse(10_000.0)
    check("reverse start", near(rev.sourceMs(0.0)!!, 10_000.0))
    check("reverse mid", near(rev.sourceMs(2500.0)!!, 7500.0))
    check("reverse speed negative", rev.speedAt(100.0) < 0)
    val frz = TimeMap.freeze(3000.0, 10_000.0)
    check("freeze", near(frz.sourceMs(0.0)!! , 3000.0) && near(frz.sourceMs(99_999.0)!!, 3000.0) && frz.speedAt(5.0) == 0.0)
    check("blank boundary", TimeMap(listOf(TimeKey(0.0, 0.0), TimeKey(1000.0, 1000.0)), 1000.0, Boundary.Blank).sourceMs(1500.0) == null)
    check("loop boundary", near(TimeMap(listOf(TimeKey(0.0, 0.0), TimeKey(1000.0, 1000.0)), 1000.0, Boundary.Loop).sourceMs(1250.0)!!, 250.0))
    check("mirror boundary", near(TimeMap(listOf(TimeKey(0.0, 0.0), TimeKey(1000.0, 1000.0)), 1000.0, Boundary.Mirror).sourceMs(1250.0)!!, 750.0))
    val ramp = TimeMap(listOf(TimeKey(0.0, 0.0), TimeKey(1000.0, 1000.0), TimeKey(2000.0, 3000.0)), 5000.0)
    check("ramp second segment", near(ramp.sourceMs(1500.0)!!, 2000.0) && near(ramp.speedAt(1500.0), 2.0))
    check("unsorted keys rejected", runCatching { TimeMap(listOf(TimeKey(0.0, 0.0), TimeKey(0.0, 5.0)), 1000.0) }.isFailure)

    val stamps = longArrayOf(0, 33_333, 66_667, 100_000)
    check("no frames -> null", FrameLookup.choose(LongArray(0), 10.0) == null)
    check("before first clamps", FrameLookup.choose(stamps, -5.0)!!.isExact)
    check("after last clamps", FrameLookup.choose(stamps, 9999.0)!!.before == 3)
    val mid = FrameLookup.choose(stamps, 50.0)!!
    check("between frames blends", mid.before == 1 && mid.after == 2 && mid.blend > 0.4f && mid.blend < 0.6f)
    check("exact stamp", FrameLookup.choose(stamps, 33.333)!!.let { it.before == 1 && it.after == 2 || it.isExact })
    check("window clamps at clip edge", FrameLookup.window(stamps, 0, intArrayOf(-2, -1, 0, 1)).contentEquals(intArrayOf(0, 1)))
    check("window bounded", runCatching { FrameLookup.window(stamps, 1, IntArray(17)) }.isFailure)

    val cube = buildString {
        append("TITLE \"swap\"\nLUT_3D_SIZE 2\n")
        for (b in 0..1) for (g in 0..1) for (r in 0..1) append("$b $g $r\n")
    }
    val parsed = CubeLut.parse(cube)
    check("cube parses", parsed is CubeLutResult.Ok)
    val lut = (parsed as CubeLutResult.Ok).lut
    val o = lut.apply(1f, 0f, 0f)
    check("cube maps red to blue", near(o[0].toDouble(), 0.0) && near(o[2].toDouble(), 1.0))
    val h = lut.apply(0.5f, 0f, 0f)
    check("cube interpolates", near(h[2].toDouble(), 0.5))
    check("cube wrong row count", CubeLut.parse("LUT_3D_SIZE 2\n0 0 0\n") is CubeLutResult.Error)
    check("cube bad number names line", (CubeLut.parse("LUT_3D_SIZE 2\n0 0 x\n") as CubeLutResult.Error).line == 2)
    check("cube data before size", CubeLut.parse("0 0 0\n") is CubeLutResult.Error)
    check("cube oversize rejected", CubeLut.parse("LUT_3D_SIZE 500\n") is CubeLutResult.Error)
    check("1d lut", (CubeLut.parse("LUT_1D_SIZE 2\n0 0 0\n1 1 1\n") as CubeLutResult.Ok).lut.apply(0.25f, 0.5f, 1f).let { near(it[0].toDouble(), 0.25) && near(it[2].toDouble(), 1.0) })

    // ---- LUT baking (float16 texture file)
    check("half 1.0", LutBake.halfBits(1f) == 0x3C00)
    check("half 0.5", LutBake.halfBits(0.5f) == 0x3800)
    check("half 0", LutBake.halfBits(0f) == 0)
    check("half -2", LutBake.halfBits(-2f) == 0xC000)
    check("half max", LutBake.halfBits(65504f) == 0x7BFF)
    check("half clamps huge", LutBake.halfBits(1e9f) == 0x7BFF && LutBake.halfBits(-1e9f) == 0xFBFF)
    check("half underflow", LutBake.halfBits(1e-9f) == 0)
    check("half NaN is 0", LutBake.halfBits(Float.NaN) == 0)
    check("half round trip", listOf(0.3333f, 0.7071f, 0.0123f, 3.5f, -0.25f, 1.0009765f).all { v -> kotlin.math.abs(LutBake.halfToFloat(LutBake.halfBits(v)) - v) <= kotlin.math.abs(v) * 0.001f + 1e-6f })
    check("half subnormal", LutBake.halfBits(6e-8f) == 1)
    val l33 = LutBake.layout(33); val l2 = LutBake.layout(2); val l129 = LutBake.layout(129)
    check("layout 33", l33.cols == 6 && l33.rows == 6 && l33.width == 198 && l33.height == 198)
    check("layout 2", l2.cols == 2 && l2.rows == 1)
    check("layout 129 fits 2048", l129.width <= 2048 && l129.height <= 2048 && l129.cols * l129.rows >= 129)
    check("1d lut not bakeable", LutBake.problem((CubeLut.parse("LUT_1D_SIZE 2\n0 0 0\n1 1 1\n") as CubeLutResult.Ok).lut) != null)

    val n = 5
    val text = buildString {
        append("TITLE \"gen\"\nLUT_3D_SIZE $n\nDOMAIN_MIN 0 0 0\nDOMAIN_MAX 1 1 1\n")
        for (b in 0 until n) for (g in 0 until n) for (r in 0 until n) append("${r / (n - 1f) * 0.9f} ${g / (n - 1f) * 0.8f + 0.05f} ${(b * 7 + g * 3 + r) % 11 / 10f}\n")
    }
    val gen = (CubeLut.parse(text) as CubeLutResult.Ok).lut
    val baked = LutBake.bake(gen)
    val lay = LutBake.layout(n)
    val bb = java.nio.ByteBuffer.wrap(baked).order(java.nio.ByteOrder.LITTLE_ENDIAN)
    check("bake header", bb.getInt(0) == LutBake.Magic && bb.getInt(4) == lay.width && bb.getInt(8) == lay.height && baked.size == 12 + lay.width * lay.height * 8)
    fun texel(x: Int, y: Int, c: Int) = LutBake.halfToFloat(bb.getShort(12 + (y * lay.width + x) * 8 + c * 2).toInt() and 0xFFFF)
    var storedOk = true
    for (k in 0 until n) for (j in 0 until n) for (i in 0 until n) for (c in 0..2) {
        val x = (k % lay.cols) * n + i; val y = (k / lay.cols) * n + j
        if (kotlin.math.abs(texel(x, y, c) - gen.table[((k * n + j) * n + i) * 3 + c]) > 1e-3f) storedOk = false
    }
    check("every table entry sits where the shader looks", storedOk)
    check("alpha is 1", LutBake.halfToFloat(bb.getShort(12 + 6).toInt() and 0xFFFF) == 1f)
    // the shader's trilinear lookup, replayed on the baked texture, matches CubeLut.apply
    fun shaderLookup(r: Float, g: Float, b: Float, c: Int): Float {
        val v = floatArrayOf(r, g, b).map { it.coerceIn(0f, 1f) * (n - 1) }
        fun slice(k: Int): FloatArray {
            val ox = (k % lay.cols) * n; val oy = (k / lay.cols) * n
            val fx = kotlin.math.floor(v[0]).toInt(); val fy = kotlin.math.floor(v[1]).toInt()
            val tx = v[0] - fx; val ty = v[1] - fy
            val gx = minOf(fx + 1, n - 1); val gy = minOf(fy + 1, n - 1)
            val a = texel(ox + fx, oy + fy, c); val bq = texel(ox + gx, oy + fy, c); val cq = texel(ox + fx, oy + gy, c); val d = texel(ox + gx, oy + gy, c)
            return floatArrayOf((a + (bq - a) * tx) + ((cq + (d - cq) * tx) - (a + (bq - a) * tx)) * ty)
        }
        val kz = kotlin.math.floor(v[2]).toInt()
        val lo = slice(kz)[0]; val hi = slice(minOf(kz + 1, n - 1))[0]
        return lo + (hi - lo) * (v[2] - kz)
    }
    var lookupOk = true
    for (t in 0 until 40) {
        val r = ((t * 37) % 101) / 100f; val g = ((t * 53) % 97) / 96f; val b = ((t * 29) % 89) / 88f
        val ref = gen.apply(r, g, b)
        for (c in 0..2) if (kotlin.math.abs(shaderLookup(r, g, b, c) - ref[c]) > 2e-3f) lookupOk = false
    }
    check("shader-style lookup equals CubeLut.apply", lookupOk)

    if (failures > 0) { println("$failures FAILED"); kotlin.system.exitProcess(1) } else println("all engine tests passed")
}

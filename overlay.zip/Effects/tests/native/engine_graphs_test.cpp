// engblur.json / englight.json as real multi-pass GLSL ES graphs, run end to end on a real GL driver (Mesa llvmpipe on a CPU-only host)
// and compared with CPU references. The runtime XML is made from the .json files by tools/graph_json_to_xml.py (see build_engine_graphs.sh).
#include "gl_backend.h"
#include "render_graph.h"
#include "render_graph_xml.h"
#include "xml.h"

#include <algorithm>
#include <cmath>
#include <cstdio>
#include <cstdint>
#include <fstream>
#include <map>
#include <sstream>

using namespace am::rg;
static int gFailed = 0, gChecks = 0;
#define CHECK_MSG(cond, msg) do { gChecks++; if (!(cond)) { gFailed++; std::printf("  FAIL %s:%d  %s -- %s\n", __FILE__, __LINE__, #cond, std::string(msg).c_str()); } } while (0)
#define CHECK_NEAR(a, b, eps) do { gChecks++; const double _a = (a), _b = (b); if (!(std::fabs(_a - _b) <= (eps))) { gFailed++; std::printf("  FAIL %s:%d  %s=%g vs %s=%g (eps %g)\n", __FILE__, __LINE__, #a, _a, #b, _b, (double)(eps)); } } while (0)

static GraphDesc Load(const std::string& path) {
    std::ifstream f(path); std::stringstream ss; ss << f.rdbuf();
    std::string e; auto root = am::ParseXml(ss.str(), &e);
    GraphDesc g; std::vector<Diag> d;
    if (!root || !IsGraphXml(*root) || !ParseGraphXml(*root, &g, &d)) { std::printf("  XML problem in %s: %s\n", path.c_str(), e.c_str()); for (auto& x : d) std::printf("   %s\n", x.format().c_str()); }
    return g;
}

static std::vector<float> Scene(int w, int h) {   // premultiplied: bright blobs on a dim textured background, one transparent column
    std::vector<float> v((size_t)w * h * 4);
    for (int y = 0; y < h; y++) for (int x = 0; x < w; x++) {
        float* p = &v[((size_t)y * w + x) * 4];
        float a = (x > 90 && x < 100) ? 0.0f : 1.0f;
        float r = 0.15f + 0.1f * std::sin(x * 0.3f), g = 0.15f + 0.1f * std::cos(y * 0.2f), b = 0.2f;
        if ((x - 40) * (x - 40) + (y - 30) * (y - 30) < 100) { r = 1; g = 0.9f; b = 0.7f; }
        if (x >= 70 && x < 74 && y >= 60 && y < 66) { r = g = b = 1; }
        p[0] = r * a; p[1] = g * a; p[2] = b * a; p[3] = a;
    }
    return v;
}

static std::vector<float> CpuGauss(const std::vector<float>& s, int w, int h, double sigma) {
    if (sigma < 1e-3) return s;
    const int R = (int)std::ceil(sigma * 4);
    std::vector<double> k(2 * R + 1); double sum = 0;
    for (int i = -R; i <= R; i++) { k[i + R] = std::exp(-0.5 * i * i / (sigma * sigma)); sum += k[i + R]; }
    for (double& x : k) x /= sum;
    std::vector<float> a(s.size()), b(s.size());
    for (int y = 0; y < h; y++) for (int x = 0; x < w; x++) for (int c = 0; c < 4; c++) {
        double acc = 0; for (int i = -R; i <= R; i++) acc += k[i + R] * s[((size_t)y * w + std::clamp(x + i, 0, w - 1)) * 4 + c];
        a[((size_t)y * w + x) * 4 + c] = (float)acc;
    }
    for (int y = 0; y < h; y++) for (int x = 0; x < w; x++) for (int c = 0; c < 4; c++) {
        double acc = 0; for (int i = -R; i <= R; i++) acc += k[i + R] * a[((size_t)std::clamp(y + i, 0, h - 1) * w + x) * 4 + c];
        b[((size_t)y * w + x) * 4 + c] = (float)acc;
    }
    return b;
}

struct Gpu {
    std::unique_ptr<GlContext> ctx; std::unique_ptr<GlBackend> be;
    Gpu() { std::string e; ctx = GlContext::Create(GlContext::Api::ES, &e); if (ctx) { be.reset(new GlBackend(*ctx)); if (!be->ok()) be.reset(); } }
    ~Gpu() { be.reset(); ctx.reset(); }
};

static std::vector<float> Render(Gpu& g, const GraphDesc& gd, int W, int H, const std::vector<float>& src, const std::map<std::string, std::vector<float>>& ctl, std::string* err, double* ms = nullptr) {
    PlanOptions po; po.backend = g.be->name(); po.languages = {Lang::GLSLES};
    auto plan = std::make_shared<Plan>(BuildPlan(gd, po));
    if (!plan->ok()) { for (auto& d : plan->diags) std::printf("   plan: %s\n", d.format().c_str()); *err = "plan"; return {}; }
    Executor ex(*g.be, plan);
    Target* source = g.be->createFromFloats(W, H, Format::RGBA16F, src.data());
    FrameRequest fr; fr.frame = 0; fr.width = W; fr.height = H; fr.source = source; fr.signature = 1;
    fr.control = [&](const std::string& n, int comps, float* out) {
        auto it = ctl.find(n); if (it == ctl.end() || (int)it->second.size() != comps) return false;
        for (int i = 0; i < comps; i++) out[i] = it->second[i];
        return true;
    };
    std::vector<float> got;
    FrameResult r = ex.render(fr, [&](Target* t) { g.be->readback(t, &got); });
    if (r.status != FrameResult::Ok) *err = r.error;
    if (ms) { *ms = 0; for (auto& t : r.timings) *ms += t.cpuNs / 1e6; }
    g.be->destroy(source);
    return got;
}

int main(int argc, char** argv) {
    const std::string dir = argc > 1 ? argv[1] : "/tmp";
    Gpu g;
    if (!g.be) { std::printf("SKIP: no GL available\n"); return 0; }
    const int W = 128, H = 96;
    const auto src = Scene(W, H);

    std::printf("engblur: plan, passes and Gaussian accuracy\n");
    GraphDesc blur = Load(dir + "/engblur.xml");
    CHECK_MSG(blur.passes.size() == 15, "15 passes: " + std::to_string(blur.passes.size()));
    const std::map<std::string, std::vector<float>> base = {{"amount", {1}}, {"focusOn", {0}}, {"center", {0.5f, 0.5f}}, {"focusRadius", {0.25f}}, {"focusSoft", {0.3f}}, {"invert", {0}}};
    for (float radius : {0.0f, 3.0f, 12.0f, 30.0f, 60.0f, 150.0f}) {
        auto ctl = base; ctl["blur"] = {radius};
        std::string err; double ms = 0;
        auto got = Render(g, blur, W, H, src, ctl, &err, &ms);
        CHECK_MSG(got.size() == src.size(), "render radius " + std::to_string(radius) + ": " + err);
        if (got.size() != src.size()) continue;
        const auto ref = CpuGauss(src, W, H, radius / 3.0);
        double worst = 0, mean = 0; for (size_t i = 0; i < ref.size(); i++) { double d = std::fabs(got[i] - ref[i]); worst = std::max(worst, d); mean += d; }
        mean /= ref.size();
        std::printf("   radius %5.1f px (sigma %.1f): max err %.4f, mean err %.5f, gpu %.2f ms\n", radius, radius / 3.0, worst, mean, ms);
        CHECK_NEAR(mean, 0.0, radius == 0 ? 1e-3 : 0.02);
        CHECK_NEAR(worst, 0.0, radius == 0 ? 2e-3 : 0.12);
    }
    {   // energy: a blur must keep the total (away from clamped edges the mean stays close)
        auto ctl = base; ctl["blur"] = {30};
        std::string err; auto got = Render(g, blur, W, H, src, ctl, &err);
        double a = 0, b = 0; for (size_t i = 0; i < src.size(); i += 4) { a += src[i + 3]; b += got.size() == src.size() ? got[i + 3] : 0; }
        CHECK_NEAR(b / a, 1.0, 0.03);
    }
    std::printf("engblur: focus area keeps the centre sharp\n");
    {
        auto ctl = base; ctl["blur"] = {40}; ctl["focusOn"] = {1}; ctl["center"] = {40.0f / W, 30.0f / H}; ctl["focusRadius"] = {0.2f}; ctl["focusSoft"] = {0.05f};
        std::string err; auto got = Render(g, blur, W, H, src, ctl, &err);
        CHECK_MSG(got.size() == src.size(), err);
        if (got.size() == src.size()) {
            const size_t c = ((size_t)30 * W + 40) * 4, f = ((size_t)80 * W + 110) * 4;   // inside the focus circle / far outside
            CHECK_NEAR(got[c], src[c], 1e-3);
            const auto ref = CpuGauss(src, W, H, 40.0 / 3);
            CHECK_NEAR(got[f], ref[f], 0.05);
        }
    }

    std::printf("englight: plan and every light mode renders\n");
    GraphDesc light = Load(dir + "/englight.xml");
    CHECK_MSG(light.passes.size() == 11, "11 passes: " + std::to_string(light.passes.size()));
    std::vector<float> ray;
    for (int mode = 0; mode < 8; mode++) {
        std::map<std::string, std::vector<float>> ctl = {{"mode", {(float)mode}}, {"threshold", {0.6f}}, {"blur", {6}}, {"intensity", {1.2f}}, {"lightPos", {0.3f, 0.3f}}, {"radius", {0.6f}},
            {"softness", {0.5f}}, {"falloff", {1.2f}}, {"ambient", {0.35f}}, {"angle", {45}}, {"cone", {50}}, {"orbit", {0}}, {"orbitSpeed", {1}}, {"rayLen", {0.8f}}, {"width", {0.6f}},
            {"seed", {1}}, {"lightColor", {1.0f, 0.95f, 0.84f, 1.0f}}};
        std::string err; auto got = Render(g, light, W, H, src, ctl, &err);
        CHECK_MSG(got.size() == src.size(), "mode " + std::to_string(mode) + ": " + err);
        if (got.size() != src.size()) continue;
        bool finite = true; double lit = 0; for (float v : got) { if (!std::isfinite(v)) finite = false; lit += v; }
        CHECK_MSG(finite && lit > 0, "mode " + std::to_string(mode) + " finite and not black");
        if (mode == 4) ray = got;
    }
    std::printf("englight: light rays really read the blurred bright copy\n");
    {   // rays start from the bright blob at (40,30); light sits at the blob, so rays brighten pixels near it versus a threshold above every pixel
        auto mk = [&](float threshold) {
            std::map<std::string, std::vector<float>> ctl = {{"mode", {4}}, {"threshold", {threshold}}, {"blur", {6}}, {"intensity", {2.0f}}, {"lightPos", {40.0f / W, 30.0f / H}}, {"radius", {0.6f}},
                {"softness", {0.5f}}, {"falloff", {1.2f}}, {"ambient", {0.35f}}, {"angle", {45}}, {"cone", {50}}, {"orbit", {0}}, {"orbitSpeed", {1}}, {"rayLen", {0.8f}}, {"width", {0.6f}},
                {"seed", {1}}, {"lightColor", {1, 1, 1, 1}}};
            std::string err; return Render(g, light, W, H, src, ctl, &err);
        };
        auto with = mk(0.6f), none = mk(1.5f);
        double a = 0, b = 0; for (size_t i = 0; i < with.size() && i < none.size(); i++) { a += with[i]; b += none[i]; }
        std::printf("   sum with bright source %.1f, with nothing above threshold %.1f\n", a, b);
        CHECK_MSG(a > b * 1.001 + 1.0, "rays add light only when something is bright");
    }

    std::printf("LUT: lutf16 texture + the GLSL ES LUT shader from LutEffect.kt (channel-swap LUT, trilinear)\n");
    {
        std::ifstream sf(dir + "/lut_shader.glsl"); std::stringstream ss; ss << sf.rdbuf();
        std::string shader = ss.str();
        const int N = 5, COLS = 3, ROWS = 2, LW = COLS * N, LH = ROWS * N;
        const uint16_t halfOf[5] = {0x0000, 0x3400, 0x3800, 0x3A00, 0x3C00};   // 0, .25, .5, .75, 1
        std::vector<uint16_t> px((size_t)LW * LH * 4, 0);
        for (int y = 0; y < LH; y++) for (int x = 0; x < LW; x++) {
            const int k = (y / N) * COLS + (x / N);
            if (k >= N) continue;
            const int r = x % N, gi = y % N, b = k;
            uint16_t* p = &px[((size_t)y * LW + x) * 4];
            p[0] = halfOf[b]; p[1] = halfOf[r]; p[2] = halfOf[gi]; p[3] = 0x3C00;   // out = (b, r, g)
        }
        const std::string path = dir + "/test.lut16";
        { FILE* f = std::fopen(path.c_str(), "wb"); int32_t head[3] = {0x3631464C, LW, LH}; std::fwrite(head, 4, 3, f); std::fwrite(px.data(), 2, px.size(), f); std::fclose(f); }
        std::string xml = "<?xml version=\"1.0\" encoding=\"UTF-8\" ?>\n<effect id=\"fx.lut\" graph=\"2\" output=\"out\">\n  <texture id=\"t\" source=\"lutf16:" + path + "\" width=\"" + std::to_string(LW) + "\" height=\"" + std::to_string(LH) + "\" seed=\"1\" filter=\"nearest\" wrap=\"clamp\" />\n"
            "  <buffer id=\"out\" scale=\"1\" format=\"inherit\" precision=\"preferred\" filter=\"linear\" wrap=\"clamp\" history=\"0\" />\n"
            "  <pass id=\"apply\" name=\"apply\" lang=\"glsl-es\" output=\"out\" blend=\"replace\" clear=\"true\" line=\"1\">\n    <source>";
        for (char c : shader) { if (c == '<') xml += "&lt;"; else if (c == '>') xml += "&gt;"; else if (c == '&') xml += "&amp;"; else xml += c; }
        xml += "</source>\n    <input name=\"image\" ref=\"source\" />\n    <input name=\"lut\" ref=\"texture:t\" />\n"
            "    <const name=\"n\" value=\"5\" />\n    <const name=\"cols\" value=\"3\" />\n    <const name=\"dmin\" value=\"0,0,0\" />\n    <const name=\"dmax\" value=\"1,1,1\" />\n  </pass>\n</effect>\n";
        std::string e; auto root = am::ParseXml(xml, &e);
        GraphDesc gd; std::vector<Diag> d;
        const bool parsed = root && IsGraphXml(*root) && ParseGraphXml(*root, &gd, &d);
        CHECK_MSG(parsed, e);
        if (parsed) {
            std::vector<float> in((size_t)W * H * 4);
            for (int y = 0; y < H; y++) for (int x = 0; x < W; x++) { float* p = &in[((size_t)y * W + x) * 4]; const float a = 0.8f; p[0] = a * (x % 31) / 30.0f; p[1] = a * (y % 17) / 16.0f; p[2] = a * ((x + y) % 23) / 22.0f; p[3] = a; }
            for (float amount : {1.0f, 0.0f, 0.5f}) {
                std::string err; auto got = Render(g, gd, W, H, in, {{"amount", {amount}}}, &err);
                CHECK_MSG(got.size() == in.size(), "lut render: " + err);
                if (got.size() != in.size()) continue;
                double worst = 0;
                for (size_t i = 0; i < in.size(); i += 4) {
                    const float a = in[i + 3], r = in[i] / a, gg = in[i + 1] / a, b = in[i + 2] / a;
                    const float m[3] = {b, r, gg};
                    for (int c = 0; c < 3; c++) worst = std::max<double>(worst, std::fabs(got[i + c] - (r * (c == 0) + gg * (c == 1) + b * (c == 2)) * a * (1 - amount) - m[c] * a * amount));
                    worst = std::max<double>(worst, std::fabs(got[i + 3] - a));
                }
                std::printf("   amount %.1f: max err %.5f\n", amount, worst);
                CHECK_NEAR(worst, 0.0, 2e-3);
            }
        }
    }

    std::printf("%d checks, %d failed\n", gChecks, gFailed);
    return gFailed ? 1 : 0;
}

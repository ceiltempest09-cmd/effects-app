package com.effects.motion.model

import com.effects.motion.engine.bitdepth.BitDepth

/**
 * Project-level colour settings. They are saved as attributes of the `<scene>` element, so they travel with the project file,
 * survive closing and reopening, and are part of the render-cache key (a change makes cached frames stale, as it should).
 *
 * The four settings are deliberately independent of each other:
 *  - [bitDepth]       how many bits every render target and intermediate buffer stores (storage precision).
 *  - [workingSpace]   what the numbers in those buffers MEAN (primaries + transfer function); decides whether blending is linear-light.
 *  - [dynamicRange]   whether values above 1.0 are kept (HDR-capable) or the picture is an SDR picture.
 *  - [previewQuality] how the editor SHOWS the project; it never changes the exported result.
 * 32-bit float is more precise, not "more HDR": a 32-bit SDR project is valid, and so is a 16-bit HDR one.
 */
data class ProjectColor(
    val bitDepth: BitDepth,
    val previewQuality: PreviewQualityMode,
    val workingSpace: WorkingSpace,
    val dynamicRange: DynamicRange,
) {
    /** The native engine gets exactly these values; see color_pipeline.h. */
    val nativeDepth: Int get() = bitDepth.bits

    companion object {
        /** New projects (the recommended defaults). */
        val Default = ProjectColor(BitDepth.BIT16, PreviewQualityMode.High, WorkingSpace.LinearSrgb, DynamicRange.Hdr)

        /** What a project saved before these settings existed has always been: 8-bit, display-referred sRGB, SDR. Rendering is unchanged. */
        val Legacy = ProjectColor(BitDepth.BIT16, PreviewQualityMode.Standard, WorkingSpace.Srgb, DynamicRange.Sdr)

        internal const val BIT_DEPTH = "bitDepth"
        internal const val PREVIEW_QUALITY = "previewQuality"
        internal const val WORKING_SPACE = "colorSpace"
        internal const val DYNAMIC_RANGE = "dynamicRange"

        fun depthOf(id: String?): BitDepth? = when (id?.trim()) {
            "8" -> BitDepth.BIT16
            "16" -> BitDepth.BIT16
            "32" -> BitDepth.BIT16
            else -> null
        }

        fun idOf(depth: BitDepth): String = depth.bits.toString()
    }
}

/** How the editor preview is produced. Export always renders at the project's own precision, whatever this is. */
enum class PreviewQualityMode(val id: String) {
    /** Real-time preview. Keeps the project's precision; fast shutter blur follows the Preview-panel switch. */
    Standard("standard"),

    /** Full-quality shutter blur and dithered output of the floating-point buffers (no banding in gradients). */
    High("high"),

    /** Keeps values above 1.0 and shows them through a highlight-preserving tone map instead of clipping them. */
    Hdr("hdr");

    /** High and HDR previews always use the accurate (full) shutter blur. */
    val forcesAccurateBlur: Boolean get() = this != Standard

    companion object {
        fun of(id: String?): PreviewQualityMode? = entries.firstOrNull { it.id == id?.trim() }
    }
}

/** The colour space the compositing happens in. All are floating-point-friendly; only the first two have a standard transfer curve. */
enum class WorkingSpace(val id: String) {
    /** Linear-light sRGB/Rec.709 primaries: blending and blur follow physical light. */
    LinearSrgb("linear"),

    /** sRGB-encoded numbers: blending in display values, the way 8-bit editors have always worked. */
    Srgb("srgb"),

    /** Linear light with the wide Rec.2020 primaries, for HDR work. */
    Rec2020("rec2020");

    companion object {
        fun of(id: String?): WorkingSpace? = entries.firstOrNull { it.id == id?.trim() }
    }
}

enum class DynamicRange(val id: String) {
    /** The picture is clipped to the displayable range at the end of the pipeline. */
    Sdr("sdr"),

    /** Values above 1.0 (bright highlights, glow, overexposed video) are kept all the way through; needs a floating-point bit depth. */
    Hdr("hdr");

    companion object {
        fun of(id: String?): DynamicRange? = entries.firstOrNull { it.id == id?.trim() }
    }
}

/**
 * What the GPU really does for a project's colour settings. The project keeps what the user asked for; this is only how the request is
 * carried out (32-bit needs a render target a GPU may not have; the display output is always 8-bit SDR, so HDR values are kept inside the
 * pipeline and shown through a tone map).
 */
data class ColorSupport(
    val effective: BitDepth,
    val hdrPreserved: Boolean,
    val hdrOutput: Boolean,
    val float16: Boolean,
    val float32: Boolean,
) {
    fun supports(depth: BitDepth) = when (depth) {
        BitDepth.BIT8 -> true
        BitDepth.BIT16 -> float16
        BitDepth.BIT32 -> float32
    }
}

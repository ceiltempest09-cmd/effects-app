package com.effects.motion.effects

import com.effects.motion.model.Scene
import com.effects.motion.model.XmlNode
import com.effects.motion.model.applyingToChildren
import com.effects.motion.model.appliesToChildren
import com.effects.motion.model.effects
import com.effects.motion.model.hasChildren
import com.effects.motion.model.withEffect
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class EffectParentingTest {
    private val scene = Scene.parse("""<scene width="100" height="100" fps="30" totalTime="1000">
        <shape id="1" startTime="0" endTime="1000"><effect id="fx.invert" hidden="false"/></shape>
        <shape id="2" parent="1" startTime="0" endTime="1000"/>
        <shape id="3" parent="3" startTime="0" endTime="1000"/></scene>""")

    @Test fun onlyLayersWithChildrenOfferTheSwitch() {
        assertTrue(scene.hasChildren(scene.layer(1)!!))
        assertFalse(scene.hasChildren(scene.layer(2)!!))
        assertFalse(scene.hasChildren(scene.layer(3)!!))
    }

    @Test fun theSwitchIsSavedOnTheEffectAndCanBeTurnedOff() {
        val parent = scene.layer(1)!!
        assertFalse(parent.effects[0].appliesToChildren)
        val shared = parent.withEffect(0) { it.applyingToChildren(true) }
        val saved = XmlNode.parse(shared.node.toXml()).children.single { it.name == "effect" }
        assertEquals("true", saved["applyToChildren"])
        assertTrue(saved.appliesToChildren)
        assertNull(shared.withEffect(0) { it.applyingToChildren(false) }.effects[0]["applyToChildren"])
    }
}

#pragma once
// Order-independent-of-platform hash that identifies "everything that defines the frames before this one" for a temporal (history)
// graph effect. When it changes, the executor throws the history away (render_graph.cpp: signature mismatch => reset()).
//
// Why this exists: the old signature only mixed the NUMBER of properties, so editing a control, a keyframe or an easing curve left
// the ping-pong history built with the old values in place. The next frame then mixed old and new history: flicker / corrupted
// frames in a cache that was "rendered", and cached frames that differ from a fresh render of the same frame.
//
// Header-only and free of Skia/GL so it is covered by the host tests (tests/native/history_signature_test.cpp).
#include <cstdint>
#include <cstring>
#include <string>

namespace am {

class HistorySignature {
public:
    HistorySignature& u64(uint64_t v) { return bytes(&v, sizeof v); }
    HistorySignature& i64(int64_t v) { return u64(static_cast<uint64_t>(v)); }
    HistorySignature& boolean(bool v) { return u64(v ? 0x9e3779b97f4a7c15ull : 0x2545f4914f6cdd1dull); }
    // Bit pattern of the float, with every NaN and both zeros folded together so equal-looking values hash equal.
    HistorySignature& f32(float v) {
        uint32_t bits;
        if (v != v) bits = 0x7fc00000u;
        else if (v == 0.0f) bits = 0;
        else std::memcpy(&bits, &v, sizeof bits);
        return u64(bits);
    }
    // Length-prefixed, so ("ab","c") and ("a","bc") differ.
    HistorySignature& str(const std::string& s) { u64(s.size()); return bytes(s.data(), s.size()); }
    HistorySignature& bytes(const void* data, size_t n) {
        const auto* p = static_cast<const uint8_t*>(data);
        for (size_t i = 0; i < n; i++) { fHash ^= p[i]; fHash *= 1099511628211ull; }   // FNV-1a
        return *this;
    }
    uint64_t value() const {
        uint64_t x = fHash;                                                             // splitmix64 finaliser
        x ^= x >> 30; x *= 0xbf58476d1ce4e5b9ull;
        x ^= x >> 27; x *= 0x94d049bb133111ebull;
        x ^= x >> 31;
        return x;
    }
private:
    uint64_t fHash = 1469598103934665603ull;
};

}  // namespace am

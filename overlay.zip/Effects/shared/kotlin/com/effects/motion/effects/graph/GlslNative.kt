package com.effects.motion.effects.graph

/**
 * Effect-XML GLSL (the legacy `lang="glsl"` pass dialect: `v_uv`, straight alpha, `gl_FragColor` or one `out vec4`) -> a native GLSL ES 3.00 pass
 * for the OpenGL ES backend. This is the "GLSL" shader language of the import dialog: the shader keeps its own types and functions and runs in
 * the float pipeline instead of being rewritten for Skia (there is no other path: SkSL is no longer supported).
 *
 * What is rewritten, nothing else: the header (version, precision, input samplers, `size`, `time`, the control uniforms), `v_uv` (= pixel position / area
 * size), `main` -> `_am_main` (a generated `main` premultiplies the result), `texture`/`texture2D` on the inputs (they un-premultiply, as the legacy dialect
 * expects straight alpha) and switch controls (declared float, read as bool).
 */
object GlslNative {
    /** A control that the shader may use without declaring it: `decl` is the GLSL declaration, `bool` marks a switch (declared float, used as bool). */
    class Implicit(val name: String, val decl: String, val bool: Boolean = false)

    class Result(val source: String, val issues: List<Issue>, val headerLines: Int)

    private val Quals = "(?:highp\\s+|mediump\\s+|lowp\\s+)?"

    fun convert(
        glsl: String, inputs: List<String>, implicit: List<Implicit>, effect: String = "", pass: String? = null,
        file: String? = null, firstLine: Int = 1, defines: Map<String, String> = emptyMap(),
    ): Result {
        val pre = GlslPreprocessor.run(glsl, defines, effect, pass, file, firstLine)
        val issues = pre.issues.toMutableList()
        fun bad(msg: String) { issues += Issue(IssueKind.UNSUPPORTED, msg, true, effect, pass, -1, "glsl-es", file, firstLine) }
        if (!pre.ok) return Result("", issues, 0)

        var src = pre.text.replace(Regex("""/\*.*?\*/""", RegexOption.DOT_MATCHES_ALL), " ").replace(Regex("""//[^\n]*"""), "")
        src = src.replace(Regex("""(?m)^\s*#\s*version.*$"""), "").replace(Regex("""(?m)^\s*precision\s+\w+\s+\w+\s*;"""), "")

        // Only uniforms supplied by the graph contract may be removed and re-declared in our header.
        // The old implementation deleted every uniform declaration, silently turning custom uniforms
        // into undeclared identifiers and producing shaders that failed later with an opaque driver error.
        val expectedUniforms = linkedMapOf("size" to "vec2", "time" to "float")
        implicit.forEach { item ->
            val declaration = Regex("""\buniform\s+(\w+)\s+${Regex.escape(item.name)}\b""").find(item.decl)
            if (declaration != null) {
                val type = declaration.groupValues[1]
                expectedUniforms[item.name] = type
            }
        }
        val uniformDecl = Regex("""(?m)^\s*uniform\s+(?:(?:lowp|mediump|highp)\s+)?(\w+)\s+(\w+)(\s*\[[^\]]*\])?\s*;""")
        val declaredUniforms = uniformDecl.findAll(src).toList()
        for (m in declaredUniforms) {
            val type = m.groupValues[1]
            val name = m.groupValues[2]
            val array = m.groupValues[3].isNotEmpty()
            val validInput = type == "sampler2D" && name in inputs && !array
            val expected = expectedUniforms[name]
            if (!validInput && (expected == null || expected != type || array)) {
                bad("uniform '$name' ($type) is not supplied by an effect control or graph input; expose it as a control or input")
            }
        }
        src = uniformDecl.replace(src) { m -> m.value.map { if (it == '\n') '\n' else ' ' }.joinToString("") }
        if (Regex("""\buniform\b""").containsMatchIn(src)) {
            bad("multi-line, block, or unsupported uniform declarations are not supported; use one simple uniform declaration per line")
        }

        val macros = StringBuilder()
        Regex("""(?m)^\s*(?:in|varying)\s+$Quals(\w+)\s+(\w+)\s*;""").findAll(src).forEach { m ->
            if (m.groupValues[1] == "vec2") macros.append("#define ").append(m.groupValues[2]).append(" (gl_FragCoord.xy / size)\n")
            else bad("the input '${m.groupValues[2]}' is a ${m.groupValues[1]}; only a vec2 uv input is supported")
        }
        src = src.replace(Regex("""(?m)^\s*(?:in|varying)\s+$Quals\w+\s+\w+\s*;"""), "")
        Regex("""(?m)^\s*(?:layout\s*\([^)]*\)\s*)?out\s+${Quals}vec4\s+(\w+)\s*;""").findAll(src).forEach { macros.append("#define ").append(it.groupValues[1]).append(" _out\n") }
        src = src.replace(Regex("""(?m)^\s*(?:layout\s*\([^)]*\)\s*)?out\s+${Quals}vec4\s+\w+\s*;"""), "")

        if (Regex("""\bdiscard\b""").containsMatchIn(src)) bad("discard is not supported")
        if (!Regex("""\bvoid\s+main\s*\(\s*(void)?\s*\)""").containsMatchIn(src)) bad("the shader has no main() function")
        src = src.replace(Regex("""\bvoid\s+main\s*\(\s*(void)?\s*\)"""), "void _am_main()")
            .replace(Regex("""\bgl_FragColor\b"""), "_out")
            .replace(Regex("""\bacScreenNorm\b"""), "(gl_FragCoord.xy / size)").replace(Regex("""\bacScreenSize\b"""), "size").replace(Regex("""\bacTime\b"""), "time")
            .replace(Regex("""\btexture2D\s*\("""), "_amTex(").replace(Regex("""\btexture\s*\("""), "_amTex(")
        implicit.filter { it.bool }.forEach { b ->
            src = Regex("""(?<![\w.])${Regex.escape(b.name)}(?!\w)""").replace(src) { "(${b.name} > 0.5)" }
        }

        val head = buildString {
            append("#version 300 es\nprecision highp float;\nprecision highp int;\nprecision highp sampler2D;\n")
            inputs.forEach { append("uniform sampler2D ").append(it).append(";\n") }
            append("uniform vec2 size;\nuniform float time;\n")
            implicit.forEach { append(it.decl).append('\n') }
            append("out vec4 _frag;\nvec4 _out;\n")
            append(macros)
            append("vec4 _amTex(sampler2D s, vec2 uv) {\n  vec4 c = texture(s, uv);\n  return c.a > 0.0 ? vec4(c.rgb / c.a, c.a) : c;\n}\n")
        }
        val text = head + src.trim() + "\nvoid main() {\n  _am_main();\n  _frag = vec4(_out.rgb * _out.a, _out.a);\n}\n"
        return Result(text, issues, head.count { it == '\n' })
    }

}

// gl_backend.cpp — see gl_backend.h.
#include "gl_backend.h"

#include "shader_diag.h"

#include <algorithm>
#include <chrono>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <dlfcn.h>
#ifdef __ANDROID__
#include <android/hardware_buffer.h>
#endif

namespace am::rg {

// ================================================================= GL / EGL constants and entry points
namespace {
enum : unsigned {
    GL_NO_ERROR = 0, GL_OUT_OF_MEMORY = 0x0505,
    GL_TEXTURE_2D = 0x0DE1, GL_RGBA = 0x1908, GL_UNSIGNED_BYTE = 0x1401, GL_FLOAT = 0x1406,
    GL_RGBA8 = 0x8058, GL_RGBA16F = 0x881A, GL_RGBA32F = 0x8814,
    GL_FRAMEBUFFER = 0x8D40, GL_COLOR_ATTACHMENT0 = 0x8CE0, GL_FRAMEBUFFER_COMPLETE = 0x8CD5,
    GL_COLOR_BUFFER_BIT = 0x4000, GL_BLEND = 0x0BE2, GL_SCISSOR_TEST = 0x0C11, GL_DEPTH_TEST = 0x0B71, GL_CULL_FACE = 0x0B44,
    GL_ZERO = 0, GL_ONE = 1, GL_SRC_COLOR = 0x0300, GL_ONE_MINUS_SRC_COLOR = 0x0301, GL_ONE_MINUS_SRC_ALPHA = 0x0303, GL_DST_COLOR = 0x0306,
    GL_TRIANGLES = 0x0004, GL_ARRAY_BUFFER = 0x8892, GL_STATIC_DRAW = 0x88E4,
    GL_VERTEX_SHADER = 0x8B31, GL_FRAGMENT_SHADER = 0x8B30, GL_COMPILE_STATUS = 0x8B81, GL_LINK_STATUS = 0x8B82, GL_INFO_LOG_LENGTH = 0x8B84,
    GL_ACTIVE_UNIFORMS = 0x8B86, GL_ACTIVE_UNIFORM_MAX_LENGTH = 0x8B87,
    GL_VENDOR = 0x1F00, GL_RENDERER = 0x1F01, GL_VERSION = 0x1F02, GL_EXTENSIONS = 0x1F03, GL_SHADING_LANGUAGE_VERSION = 0x8B8C,
    GL_NUM_EXTENSIONS = 0x821D, GL_MAX_TEXTURE_SIZE = 0x0D33, GL_MAX_COLOR_ATTACHMENTS = 0x8CDF, GL_MAX_TEXTURE_IMAGE_UNITS = 0x8872,
    GL_NUM_PROGRAM_BINARY_FORMATS = 0x87FE, GL_PROGRAM_BINARY_RETRIEVABLE_HINT = 0x8257, GL_PROGRAM_BINARY_LENGTH = 0x8741,
    GL_TEXTURE0 = 0x84C0, GL_TEXTURE_MIN_FILTER = 0x2801, GL_TEXTURE_MAG_FILTER = 0x2800, GL_TEXTURE_WRAP_S = 0x2802, GL_TEXTURE_WRAP_T = 0x2803,
    GL_NEAREST = 0x2600, GL_LINEAR = 0x2601, GL_CLAMP_TO_EDGE = 0x812F, GL_REPEAT = 0x2901, GL_MIRRORED_REPEAT = 0x8370, GL_CLAMP_TO_BORDER = 0x812D,
    GL_PACK_ALIGNMENT = 0x0D05, GL_UNPACK_ALIGNMENT = 0x0CF5,
    GL_CONTEXT_FLAGS = 0x821E, GL_NO_RESET_NOTIFICATION = 0x8261, GL_LOSE_CONTEXT_ON_RESET = 0x8252,
    GL_RESET_NOTIFICATION_STRATEGY = 0x8256, GL_GUILTY_CONTEXT_RESET = 0x8253,
    GL_TIME_ELAPSED = 0x88BF, GL_QUERY_RESULT = 0x8866, GL_QUERY_RESULT_AVAILABLE = 0x8867, GL_GPU_DISJOINT_EXT = 0x8FBB,
    GL_FLOAT_VEC2 = 0x8B50, GL_FLOAT_VEC3 = 0x8B51, GL_FLOAT_VEC4 = 0x8B52, GL_INT = 0x1404, GL_UNSIGNED_INT = 0x1405,
    GL_INT_VEC2 = 0x8B53, GL_INT_VEC3 = 0x8B54, GL_INT_VEC4 = 0x8B55, GL_BOOL = 0x8B56, GL_SAMPLER_2D = 0x8B5E,
    GL_MAJOR_VERSION = 0x821B, GL_MINOR_VERSION = 0x821C,
};
enum : int { EGL_NONE = 0x3038, EGL_RENDERABLE_TYPE = 0x3040, EGL_SURFACE_TYPE = 0x3033, EGL_PBUFFER_BIT = 1, EGL_OPENGL_ES3_BIT = 0x40,
             EGL_OPENGL_BIT = 8, EGL_OPENGL_ES_API = 0x30A0, EGL_OPENGL_API = 0x30A2, EGL_CONTEXT_CLIENT_VERSION = 0x3098,
             EGL_CONTEXT_MAJOR_VERSION = 0x3098, EGL_CONTEXT_MINOR_VERSION = 0x30FB, EGL_CONTEXT_OPENGL_PROFILE_MASK = 0x30FD,
             EGL_CONTEXT_OPENGL_CORE_PROFILE_BIT = 1, EGL_WIDTH = 0x3057, EGL_HEIGHT = 0x3056, EGL_RED_SIZE = 0x3024, EGL_GREEN_SIZE = 0x3023,
             EGL_BLUE_SIZE = 0x3022, EGL_ALPHA_SIZE = 0x3021, EGL_PLATFORM_SURFACELESS_MESA = 0x31DD, EGL_EXTENSIONS = 0x3055 };
}  // namespace

struct GlFns {
    // EGL
    void* (*eglGetProcAddress)(const char*) = nullptr;
    void* (*eglGetDisplay)(void*) = nullptr;
    void* (*eglGetPlatformDisplay)(unsigned, void*, const long*) = nullptr;
    unsigned (*eglInitialize)(void*, int*, int*) = nullptr;
    unsigned (*eglBindAPI)(unsigned) = nullptr;
    unsigned (*eglChooseConfig)(void*, const int*, void**, int, int*) = nullptr;
    void* (*eglCreateContext)(void*, void*, void*, const int*) = nullptr;
    void* (*eglCreatePbufferSurface)(void*, void*, const int*) = nullptr;
    unsigned (*eglMakeCurrent)(void*, void*, void*, void*) = nullptr;
    unsigned (*eglDestroyContext)(void*, void*) = nullptr;
    unsigned (*eglDestroySurface)(void*, void*) = nullptr;
    void* (*eglGetCurrentContext)() = nullptr;
    void* (*eglGetCurrentDisplay)() = nullptr;
    int (*eglGetError)() = nullptr;
    // GL
    const unsigned char* (*glGetString)(unsigned) = nullptr;
    const unsigned char* (*glGetStringi)(unsigned, unsigned) = nullptr;
    void (*glGetIntegerv)(unsigned, int*) = nullptr;
    unsigned (*glGetError)() = nullptr;
    void (*glGenTextures)(int, unsigned*) = nullptr;
    void (*glDeleteTextures)(int, const unsigned*) = nullptr;
    void (*glBindTexture)(unsigned, unsigned) = nullptr;
    void (*glTexImage2D)(unsigned, int, int, int, int, int, unsigned, unsigned, const void*) = nullptr;
    void (*glTexSubImage2D)(unsigned, int, int, int, int, int, unsigned, unsigned, const void*) = nullptr;
    void (*glTexParameteri)(unsigned, unsigned, int) = nullptr;
    void (*glActiveTexture)(unsigned) = nullptr;
    void (*glGenFramebuffers)(int, unsigned*) = nullptr;
    void (*glDeleteFramebuffers)(int, const unsigned*) = nullptr;
    void (*glBindFramebuffer)(unsigned, unsigned) = nullptr;
    void (*glFramebufferTexture2D)(unsigned, unsigned, unsigned, unsigned, int) = nullptr;
    unsigned (*glCheckFramebufferStatus)(unsigned) = nullptr;
    void (*glViewport)(int, int, int, int) = nullptr;
    void (*glClearColor)(float, float, float, float) = nullptr;
    void (*glClear)(unsigned) = nullptr;
    void (*glEnable)(unsigned) = nullptr;
    void (*glDisable)(unsigned) = nullptr;
    void (*glBlendFunc)(unsigned, unsigned) = nullptr;
    void (*glReadPixels)(int, int, int, int, unsigned, unsigned, void*) = nullptr;
    void (*glPixelStorei)(unsigned, int) = nullptr;
    void (*glFinish)() = nullptr;
    void (*glFlush)() = nullptr;
    unsigned (*glCreateShader)(unsigned) = nullptr;
    void (*glShaderSource)(unsigned, int, const char* const*, const int*) = nullptr;
    void (*glCompileShader)(unsigned) = nullptr;
    void (*glGetShaderiv)(unsigned, unsigned, int*) = nullptr;
    void (*glGetShaderInfoLog)(unsigned, int, int*, char*) = nullptr;
    void (*glDeleteShader)(unsigned) = nullptr;
    unsigned (*glCreateProgram)() = nullptr;
    void (*glAttachShader)(unsigned, unsigned) = nullptr;
    void (*glBindAttribLocation)(unsigned, unsigned, const char*) = nullptr;
    void (*glLinkProgram)(unsigned) = nullptr;
    void (*glGetProgramiv)(unsigned, unsigned, int*) = nullptr;
    void (*glGetProgramInfoLog)(unsigned, int, int*, char*) = nullptr;
    void (*glDeleteProgram)(unsigned) = nullptr;
    void (*glUseProgram)(unsigned) = nullptr;
    void (*glGetActiveUniform)(unsigned, unsigned, int, int*, int*, unsigned*, char*) = nullptr;
    int (*glGetUniformLocation)(unsigned, const char*) = nullptr;
    void (*glUniform1iv)(int, int, const int*) = nullptr;
    void (*glUniform2iv)(int, int, const int*) = nullptr;
    void (*glUniform3iv)(int, int, const int*) = nullptr;
    void (*glUniform4iv)(int, int, const int*) = nullptr;
    void (*glUniform1fv)(int, int, const float*) = nullptr;
    void (*glUniform2fv)(int, int, const float*) = nullptr;
    void (*glUniform3fv)(int, int, const float*) = nullptr;
    void (*glUniform4fv)(int, int, const float*) = nullptr;
    void (*glUniform1i)(int, int) = nullptr;
    void (*glGenVertexArrays)(int, unsigned*) = nullptr;
    void (*glBindVertexArray)(unsigned) = nullptr;
    void (*glDeleteVertexArrays)(int, const unsigned*) = nullptr;
    void (*glGenBuffers)(int, unsigned*) = nullptr;
    void (*glBindBuffer)(unsigned, unsigned) = nullptr;
    void (*glBufferData)(unsigned, long, const void*, unsigned) = nullptr;
    void (*glDeleteBuffers)(int, const unsigned*) = nullptr;
    void (*glEnableVertexAttribArray)(unsigned) = nullptr;
    void (*glVertexAttribPointer)(unsigned, int, unsigned, unsigned char, int, const void*) = nullptr;
    void (*glDrawArrays)(unsigned, int, int) = nullptr;
    void (*glGenSamplers)(int, unsigned*) = nullptr;
    void (*glDeleteSamplers)(int, const unsigned*) = nullptr;
    void (*glBindSampler)(unsigned, unsigned) = nullptr;
    void (*glSamplerParameteri)(unsigned, unsigned, int) = nullptr;
    void (*glGetProgramBinary)(unsigned, int, int*, unsigned*, void*) = nullptr;
    void (*glProgramBinary)(unsigned, unsigned, const void*, int) = nullptr;
    void (*glProgramParameteri)(unsigned, unsigned, int) = nullptr;
    unsigned (*glGetGraphicsResetStatus)() = nullptr;
    void (*glGenQueries)(int, unsigned*) = nullptr;
    void (*glDeleteQueries)(int, const unsigned*) = nullptr;
    void (*glBeginQuery)(unsigned, unsigned) = nullptr;
    void (*glEndQuery)(unsigned) = nullptr;
    void (*glGetQueryObjectui64v)(unsigned, unsigned, uint64_t*) = nullptr;
    void (*glGetQueryObjectuiv)(unsigned, unsigned, unsigned*) = nullptr;
};

namespace {
void* DlEgl() {
    static void* h = [] {
        const char* names[] = {"libEGL.so.1", "libEGL.so", "libEGL.dylib", nullptr};
        for (int i = 0; names[i]; i++) if (void* x = dlopen(names[i], RTLD_NOW | RTLD_GLOBAL)) return x;
        return (void*)nullptr;
    }();
    return h;
}
void* EglProc(const char* name) {
    void* h = DlEgl();
    return h ? dlsym(h, name) : nullptr;
}
}  // namespace

GetProc DefaultGetProc() {
    auto fn = reinterpret_cast<void* (*)(const char*)>(EglProc("eglGetProcAddress"));
    return fn;
}

namespace {
template <class F> bool Load(GetProc gp, F& slot, const char* name, const char* alt = nullptr, const char* alt2 = nullptr) {
    void* p = gp(name);
    if (!p && alt) p = gp(alt);
    if (!p && alt2) p = gp(alt2);
    slot = reinterpret_cast<F>(p);
    return slot != nullptr;
}

// Loads every entry point. Returns the name of the first REQUIRED one that is missing ("" = all present).
std::string LoadGl(GetProc gp, GlFns* f) {
#define REQ(n) if (!Load(gp, f->n, #n)) return #n
    REQ(glGetString); REQ(glGetIntegerv); REQ(glGetError);
    REQ(glGenTextures); REQ(glDeleteTextures); REQ(glBindTexture); REQ(glTexImage2D); REQ(glTexSubImage2D); REQ(glTexParameteri); REQ(glActiveTexture);
    REQ(glGenFramebuffers); REQ(glDeleteFramebuffers); REQ(glBindFramebuffer); REQ(glFramebufferTexture2D); REQ(glCheckFramebufferStatus);
    REQ(glViewport); REQ(glClearColor); REQ(glClear); REQ(glEnable); REQ(glDisable); REQ(glBlendFunc); REQ(glReadPixels); REQ(glPixelStorei);
    REQ(glFinish); REQ(glFlush);
    REQ(glCreateShader); REQ(glShaderSource); REQ(glCompileShader); REQ(glGetShaderiv); REQ(glGetShaderInfoLog); REQ(glDeleteShader);
    REQ(glCreateProgram); REQ(glAttachShader); REQ(glBindAttribLocation); REQ(glLinkProgram); REQ(glGetProgramiv); REQ(glGetProgramInfoLog);
    REQ(glDeleteProgram); REQ(glUseProgram); REQ(glGetActiveUniform); REQ(glGetUniformLocation);
    REQ(glUniform1iv); REQ(glUniform2iv); REQ(glUniform3iv); REQ(glUniform4iv); REQ(glUniform1fv); REQ(glUniform2fv); REQ(glUniform3fv); REQ(glUniform4fv);
    REQ(glUniform1i);
    REQ(glGenVertexArrays); REQ(glBindVertexArray); REQ(glDeleteVertexArrays); REQ(glGenBuffers); REQ(glBindBuffer); REQ(glBufferData);
    REQ(glDeleteBuffers); REQ(glEnableVertexAttribArray); REQ(glVertexAttribPointer); REQ(glDrawArrays);
    REQ(glGenSamplers); REQ(glDeleteSamplers); REQ(glBindSampler); REQ(glSamplerParameteri);
#undef REQ
    // optional
    Load(gp, f->glGetStringi, "glGetStringi");
    Load(gp, f->glGetProgramBinary, "glGetProgramBinary", "glGetProgramBinaryOES");
    Load(gp, f->glProgramBinary, "glProgramBinary", "glProgramBinaryOES");
    Load(gp, f->glProgramParameteri, "glProgramParameteri");
    Load(gp, f->glGetGraphicsResetStatus, "glGetGraphicsResetStatus", "glGetGraphicsResetStatusKHR", "glGetGraphicsResetStatusEXT");
    Load(gp, f->glGenQueries, "glGenQueries", "glGenQueriesEXT");
    Load(gp, f->glDeleteQueries, "glDeleteQueries", "glDeleteQueriesEXT");
    Load(gp, f->glBeginQuery, "glBeginQuery", "glBeginQueryEXT");
    Load(gp, f->glEndQuery, "glEndQuery", "glEndQueryEXT");
    Load(gp, f->glGetQueryObjectui64v, "glGetQueryObjectui64v", "glGetQueryObjectui64vEXT");
    Load(gp, f->glGetQueryObjectuiv, "glGetQueryObjectuiv", "glGetQueryObjectuivEXT");
    return "";
}

bool HasExt(const std::set<std::string>& s, const char* n) { return s.count(n) != 0; }

unsigned InternalFormat(Format f) { return f == Format::RGBA32F ? GL_RGBA32F : f == Format::RGBA16F ? GL_RGBA16F : GL_RGBA8; }
unsigned ClientType(Format f) { return f == Format::RGBA8 ? GL_UNSIGNED_BYTE : GL_FLOAT; }
Format Concrete(Format f) { return f == Format::Inherit ? Format::RGBA8 : f; }
}  // namespace

const char* FormatText(Format f) {
    switch (f) { case Format::RGBA16F: return "RGBA16F"; case Format::RGBA32F: return "RGBA32F"; case Format::RGBA8: return "RGBA8"; default: return "inherit"; }
}

// ================================================================= GlContext
GlContext::~GlContext() {
    if (!fOwned || !fEgl) return;
    GlFns f;
    auto md = reinterpret_cast<unsigned (*)(void*, void*, void*, void*)>(EglProc("eglMakeCurrent"));
    auto dc = reinterpret_cast<unsigned (*)(void*, void*)>(EglProc("eglDestroyContext"));
    auto ds = reinterpret_cast<unsigned (*)(void*, void*)>(EglProc("eglDestroySurface"));
    if (md) md(fDisplay, nullptr, nullptr, nullptr);
    if (dc && fContext) dc(fDisplay, fContext);
    if (ds && fSurface) ds(fDisplay, fSurface);
}

std::unique_ptr<GlContext> GlContext::Create(Api api, std::string* error) {
    GetProc gp = DefaultGetProc();
    if (!gp) { *error = "no EGL library (libEGL) on this system"; return nullptr; }
    GlFns e;
    auto egl = [&](auto& slot, const char* name) { slot = reinterpret_cast<std::remove_reference_t<decltype(slot)>>(EglProc(name)); return slot != nullptr; };
    if (!egl(e.eglGetDisplay, "eglGetDisplay") || !egl(e.eglInitialize, "eglInitialize") || !egl(e.eglBindAPI, "eglBindAPI") ||
        !egl(e.eglChooseConfig, "eglChooseConfig") || !egl(e.eglCreateContext, "eglCreateContext") || !egl(e.eglMakeCurrent, "eglMakeCurrent") ||
        !egl(e.eglCreatePbufferSurface, "eglCreatePbufferSurface") || !egl(e.eglGetError, "eglGetError")) {
        *error = "libEGL lacks a required entry point";
        return nullptr;
    }
    egl(e.eglGetPlatformDisplay, "eglGetPlatformDisplay");
    void* dpy = nullptr;
#if !defined(__ANDROID__)
    if (e.eglGetPlatformDisplay) dpy = e.eglGetPlatformDisplay(EGL_PLATFORM_SURFACELESS_MESA, nullptr, nullptr);   // no window system needed
#endif
    if (!dpy) dpy = e.eglGetDisplay(nullptr);
    int maj = 0, min = 0;
    if (!dpy || !e.eglInitialize(dpy, &maj, &min)) { *error = "eglInitialize failed (egl error " + std::to_string(e.eglGetError()) + ")"; return nullptr; }
    if (!e.eglBindAPI(api == Api::ES ? EGL_OPENGL_ES_API : EGL_OPENGL_API)) { *error = std::string(api == Api::ES ? "OpenGL ES" : "desktop OpenGL") + " is not available through EGL here"; return nullptr; }
    const int cfgAttr[] = {EGL_SURFACE_TYPE, EGL_PBUFFER_BIT, EGL_RENDERABLE_TYPE, api == Api::ES ? EGL_OPENGL_ES3_BIT : EGL_OPENGL_BIT,
                           EGL_RED_SIZE, 8, EGL_GREEN_SIZE, 8, EGL_BLUE_SIZE, 8, EGL_ALPHA_SIZE, 8, EGL_NONE};
    void* cfg = nullptr; int n = 0;
    if (!e.eglChooseConfig(dpy, cfgAttr, &cfg, 1, &n) || n < 1) { *error = "no EGL config for a pbuffer with an ES3/desktop-GL context"; return nullptr; }

    void* ctx = nullptr;
    if (api == Api::ES) {
        const int ca[] = {EGL_CONTEXT_CLIENT_VERSION, 3, EGL_NONE};
        ctx = e.eglCreateContext(dpy, cfg, nullptr, ca);
    } else {
        static const int versions[][2] = {{4, 6}, {4, 5}, {4, 3}, {4, 1}, {3, 3}};
        for (const auto& v : versions) {
            const int ca[] = {EGL_CONTEXT_MAJOR_VERSION, v[0], EGL_CONTEXT_MINOR_VERSION, v[1], EGL_CONTEXT_OPENGL_PROFILE_MASK, EGL_CONTEXT_OPENGL_CORE_PROFILE_BIT, EGL_NONE};
            ctx = e.eglCreateContext(dpy, cfg, nullptr, ca);
            if (ctx) break;
        }
    }
    if (!ctx) { *error = "eglCreateContext failed (egl error " + std::to_string(e.eglGetError()) + ")"; return nullptr; }
    const int pb[] = {EGL_WIDTH, 1, EGL_HEIGHT, 1, EGL_NONE};
    void* surf = e.eglCreatePbufferSurface(dpy, cfg, pb);
    if (!e.eglMakeCurrent(dpy, surf, surf, ctx)) {
        *error = "eglMakeCurrent failed (egl error " + std::to_string(e.eglGetError()) + ")";
        return nullptr;
    }
    std::unique_ptr<GlContext> c(new GlContext());
    c->fDisplay = dpy; c->fContext = ctx; c->fSurface = surf; c->fApi = api; c->fGetProc = gp; c->fOwned = true; c->fEgl = DlEgl();
    return c;
}

std::unique_ptr<GlContext> GlContext::Adopt(std::string* error) {
    GetProc gp = DefaultGetProc();
    if (!gp) { *error = "no EGL library"; return nullptr; }
    auto cur = reinterpret_cast<void* (*)()>(EglProc("eglGetCurrentContext"));
    if (!cur || !cur()) { *error = "no EGL context is current on this thread"; return nullptr; }
    std::unique_ptr<GlContext> c(new GlContext());
    c->fContext = cur();
    c->fGetProc = gp;
    c->fOwned = false;
    c->fEgl = DlEgl();
    // ES or desktop: ask the driver
    auto gs = reinterpret_cast<const unsigned char* (*)(unsigned)>(gp("glGetString"));
    const char* v = gs ? reinterpret_cast<const char*>(gs(GL_VERSION)) : nullptr;
    c->fApi = v && std::strstr(v, "OpenGL ES") ? Api::ES : Api::Desktop;
    return c;
}

bool GlContext::makeCurrent() {
    if (!fOwned) return true;
    auto mc = reinterpret_cast<unsigned (*)(void*, void*, void*, void*)>(EglProc("eglMakeCurrent"));
    return mc && mc(fDisplay, fSurface, fSurface, fContext);
}

// ================================================================= Targets and programs
class GlBackend::GlTarget : public Target {
public:
    unsigned tex = 0, fbo = 0;
    bool backendOwned = false;
    void* image = nullptr;     // EGLImage (shared buffers only)
    void* ahb = nullptr;       // AHardwareBuffer reference (shared buffers only)
    int64_t bytes() const { return (int64_t)width * height * BytesPerPixel(format); }
};

namespace {
// Releases the EGLImage and the buffer reference of a shared target (the GL texture itself is deleted by the caller first).
void FreeShared(GlFns*, void* image, void* ahb) {
#ifdef __ANDROID__
    if (image) {
        using GetProcAddress = void* (*)(const char*);
        using CurrentDisplay = void* (*)();
        using DestroyImage = unsigned (*)(void*, void*);
        auto getProc = reinterpret_cast<GetProcAddress>(EglProc("eglGetProcAddress"));
        auto display = reinterpret_cast<CurrentDisplay>(EglProc("eglGetCurrentDisplay"));
        auto destroyImage = getProc ? reinterpret_cast<DestroyImage>(getProc("eglDestroyImageKHR")) : nullptr;
        if (destroyImage && display) destroyImage(display(), image);
    }
    if (ahb) AHardwareBuffer_release(static_cast<AHardwareBuffer*>(ahb));
#else
    (void)image; (void)ahb;
#endif
}
}  // namespace

struct GlBackend::Program {
    unsigned id = 0;
    struct Uniform { std::string name; int loc = -1; unsigned type = 0; int size = 1; };
    std::vector<Uniform> uniforms;
    int preludeLines = 0;
    bool fromDisk = false;
};

namespace {
// Version line of the author's text: "#version 300 es" -> the same text is used for the generated vertex shader, because ES
// refuses to link shaders of different versions and desktop GLSL needs `in`/`attribute` to match the version.
struct VersionInfo { bool present = false; int number = 0; bool es = false; std::string line; size_t endOfLine = 0; };

VersionInfo FindVersion(const std::string& src) {
    VersionInfo v;
    size_t pos = 0;
    while (pos < src.size()) {
        size_t eol = src.find('\n', pos);
        if (eol == std::string::npos) eol = src.size();
        std::string line = src.substr(pos, eol - pos);
        size_t i = line.find_first_not_of(" \t\r");
        if (i != std::string::npos && line.compare(i, 8, "#version") == 0) {
            v.present = true;
            v.line = line;
            while (!v.line.empty() && (v.line.back() == '\r')) v.line.pop_back();
            v.number = std::atoi(line.c_str() + i + 8);
            v.es = line.find("es") != std::string::npos;
            v.endOfLine = std::min(src.size(), eol + 1);
            return v;
        }
        pos = eol + 1;
    }
    return v;
}


// Where the backend's own lines go: after #version and after every #extension directive that leads the file (an #extension
// after any other token is an error in GLSL ES 3.00), skipping blank lines and comments on the way.
size_t PreludePoint(const std::string& src, const VersionInfo& v) {
    size_t pos = v.present ? v.endOfLine : 0, at = pos;
    bool inBlock = false;
    while (pos < src.size()) {
        size_t eol = src.find('\n', pos);
        const size_t next = eol == std::string::npos ? src.size() : eol + 1;
        const std::string line = src.substr(pos, next - pos);
        const size_t i = line.find_first_not_of(" \t\r\n");
        if (inBlock) { if (line.find("*/") != std::string::npos) inBlock = false; }
        else if (i == std::string::npos || line.compare(i, 2, "//") == 0) {}
        else if (line.compare(i, 2, "/*") == 0) { if (line.find("*/", i + 2) == std::string::npos) inBlock = true; }
        else if (line.compare(i, 10, "#extension") == 0) at = next;
        else if (line[i] == '#') {}   // #define, #pragma ...: still the preamble
        else break;
        pos = next;
    }
    return at;
}

std::string VertexSource(const VersionInfo& v, bool desktopContext) {
    // No version directive: the language default (ES 1.00 / desktop 1.10); the vertex shader must then also have none.
    const bool legacy = !v.present ? true : (v.es ? v.number < 300 : v.number < 130);
    std::string s;
    if (v.present) s += v.line + "\n";
    (void)desktopContext;
    s += legacy ? "attribute vec2 a_pos;\n" : "in vec2 a_pos;\n";
    s += "void main() { gl_Position = vec4(a_pos, 0.0, 1.0); }\n";
    return s;
}

std::string StripIdx(const std::string& n) {
    const size_t b = n.find('[');
    return b == std::string::npos ? n : n.substr(0, b);
}
int Components(unsigned t) {
    switch (t) {
        case GL_FLOAT: case GL_INT: case GL_UNSIGNED_INT: case GL_BOOL: return 1;
        case GL_FLOAT_VEC2: case GL_INT_VEC2: return 2;
        case GL_FLOAT_VEC3: case GL_INT_VEC3: return 3;
        case GL_FLOAT_VEC4: case GL_INT_VEC4: return 4;
        default: return 0;
    }
}
bool IsFloatType(unsigned t) { return t == GL_FLOAT || t == GL_FLOAT_VEC2 || t == GL_FLOAT_VEC3 || t == GL_FLOAT_VEC4; }
const char* TypeName(unsigned t) {
    switch (t) {
        case GL_FLOAT: return "float"; case GL_FLOAT_VEC2: return "vec2"; case GL_FLOAT_VEC3: return "vec3"; case GL_FLOAT_VEC4: return "vec4";
        case GL_INT: return "int"; case GL_INT_VEC2: return "ivec2"; case GL_INT_VEC3: return "ivec3"; case GL_INT_VEC4: return "ivec4";
        case GL_UNSIGNED_INT: return "uint"; case GL_BOOL: return "bool"; case GL_SAMPLER_2D: return "sampler2D"; default: return "(unsupported type)";
    }
}
std::string FormatDiag(const Diag& d) {
    std::string s = d.file.empty() ? "" : d.file + ":" + std::to_string(d.line) + ": ";
    if (d.file.empty() && d.line) s = "line " + std::to_string(d.line) + ": ";
    return s + (d.error ? "error: " : "warning: ") + d.message;
}
constexpr int kPreludeRevision = 2;
}  // namespace

// ================================================================= GlBackend
GlBackend::GlBackend(GlContext& context, const GlOptions& options) : fContext(context), fOptions(options), fGl(new GlFns()), fThread(std::this_thread::get_id()) {
    const std::string missing = LoadGl(context.getProc(), fGl.get());
    if (!missing.empty()) { fError = "GL entry point missing: " + missing; return; }
    GlFns& g = *fGl;
    auto str = [&](unsigned name) { const unsigned char* s = g.glGetString(name); return s ? std::string(reinterpret_cast<const char*>(s)) : std::string(); };
    fCaps.vendor = str(GL_VENDOR); fCaps.renderer = str(GL_RENDERER); fCaps.version = str(GL_VERSION); fCaps.glsl = str(GL_SHADING_LANGUAGE_VERSION);
    fCaps.es = fCaps.version.find("OpenGL ES") != std::string::npos;
    {   // "OpenGL ES 3.2 Mesa ..." / "4.5 (Core Profile) Mesa ..."
        const char* p = fCaps.version.c_str();
        while (*p && !(*p >= '0' && *p <= '9')) p++;
        fCaps.major = std::atoi(p);
        const char* dot = std::strchr(p, '.');
        fCaps.minor = dot ? std::atoi(dot + 1) : 0;
        if (g.glGetIntegerv) { int a = 0, b = 0; g.glGetIntegerv(GL_MAJOR_VERSION, &a); g.glGetIntegerv(GL_MINOR_VERSION, &b); g.glGetError(); if (a >= 3) { fCaps.major = a; fCaps.minor = b; } }
    }
    if ((fCaps.es && fCaps.major < 3) || (!fCaps.es && (fCaps.major < 3 || (fCaps.major == 3 && fCaps.minor < 3)))) {
        fError = "this context is " + fCaps.version + "; the GL backend needs OpenGL ES 3.0 or desktop GL 3.3";
        return;
    }
    // extensions
    std::set<std::string>& ext = fCaps.glslDevice.extensions;
    if (g.glGetStringi) {
        int n = 0; g.glGetIntegerv(GL_NUM_EXTENSIONS, &n);
        for (int i = 0; i < n; i++) if (const unsigned char* s = g.glGetStringi(GL_EXTENSIONS, (unsigned)i)) ext.insert(reinterpret_cast<const char*>(s));
    }
    g.glGetIntegerv(GL_MAX_TEXTURE_SIZE, &fCaps.maxTextureSize);
    g.glGetIntegerv(GL_MAX_COLOR_ATTACHMENTS, &fCaps.maxColorAttachments);
    g.glGetIntegerv(GL_MAX_TEXTURE_IMAGE_UNITS, &fCaps.maxTextureUnits);
    g.glGetError();
    // GLSL versions the front end takes
    {
        const char* p = fCaps.glsl.c_str();
        while (*p && !(*p >= '0' && *p <= '9')) p++;
        const int a = std::atoi(p);
        const char* dot = std::strchr(p, '.');
        const int b = dot ? std::atoi(dot + 1) : 0;
        if (fCaps.es) { fCaps.glslDevice.esMajor = a; fCaps.glslDevice.esMinor = b; }
        else {
            fCaps.glslDevice.desktopVersion = a * 100 + b;   // 4.50 -> 450 (the "4.50" text has two minor digits)
            if (dot && dot[1] && dot[2] >= '0' && dot[2] <= '9') fCaps.glslDevice.desktopVersion = a * 100 + (dot[1] - '0') * 10 + (dot[2] - '0');
        }
    }
    fCaps.borderClamp = !fCaps.es || HasExt(ext, "GL_EXT_texture_border_clamp") || HasExt(ext, "GL_OES_texture_border_clamp") || (fCaps.major == 3 && fCaps.minor >= 2);
    fCaps.programBinary = false;
    if (g.glGetProgramBinary && g.glProgramBinary) { int n = 0; g.glGetIntegerv(GL_NUM_PROGRAM_BINARY_FORMATS, &n); g.glGetError(); fCaps.programBinary = n > 0; }
    fCaps.timerQuery = g.glGenQueries && g.glBeginQuery && g.glEndQuery && g.glGetQueryObjectui64v && g.glGetQueryObjectuiv &&
                       (fCaps.es ? HasExt(ext, "GL_EXT_disjoint_timer_query") : (HasExt(ext, "GL_ARB_timer_query") || fCaps.major > 3 || (fCaps.major == 3 && fCaps.minor >= 3)));
    fCaps.resetNotification = g.glGetGraphicsResetStatus && (HasExt(ext, "GL_KHR_robustness") || HasExt(ext, "GL_EXT_robustness") || HasExt(ext, "GL_ARB_robustness") || (!fCaps.es && fCaps.major >= 4 && fCaps.minor >= 5));

    // geometry: a full-screen triangle from a vertex buffer (gl_VertexID does not exist in GLSL 1.00 / ES 100 vertex shaders)
    static const float tri[6] = {-1.f, -1.f, 3.f, -1.f, -1.f, 3.f};
    g.glGenVertexArrays(1, &fVao);
    g.glBindVertexArray(fVao);
    g.glGenBuffers(1, &fVbo);
    g.glBindBuffer(GL_ARRAY_BUFFER, fVbo);
    g.glBufferData(GL_ARRAY_BUFFER, sizeof(tri), tri, GL_STATIC_DRAW);
    g.glEnableVertexAttribArray(0);
    g.glVertexAttribPointer(0, 2, GL_FLOAT, 0, 0, nullptr);
    if (g.glGetError() != GL_NO_ERROR) { fError = "could not create the full-screen triangle"; return; }

    if (!probeFormats()) return;
    if (fOptions.working == Format::Inherit) fWorking = (fCaps.rgba16f.renderable && fCaps.rgba16f.linear) ? Format::RGBA16F : Format::RGBA8;
    else fWorking = supports(fOptions.working) ? fOptions.working : Format::RGBA8;
    if (!fOptions.cacheDirectory.empty() && fCaps.programBinary) fDiskCache.reset(new ShaderCache(fOptions.cacheDirectory, fOptions.cacheMaxBytes));
    if (fCaps.timerQuery) g.glGenQueries(1, &fQuery);
    fName = fCaps.es ? "gles" : "gl";
    fOk = true;
}

GlBackend::~GlBackend() {
    if (!fGl || !fGl->glDeleteTextures) return;
    GlFns& g = *fGl;
    for (auto& p : fPrograms) if (p.second->id) g.glDeleteProgram(p.second->id);
    fPrograms.clear();
    for (GlTarget* t : std::vector<GlTarget*>(fLive.begin(), fLive.end())) { if (t->fbo) g.glDeleteFramebuffers(1, &t->fbo); if (t->tex) g.glDeleteTextures(1, &t->tex); FreeShared(fGl.get(), t->image, t->ahb); delete t; }
    fLive.clear();
    for (auto& t : fTextures) (void)t.second.release();   // already deleted through fLive above
    for (auto& t : fBlanks) (void)t.second.release();
    fTextures.clear(); fBlanks.clear();
    for (auto& s : fSamplers) g.glDeleteSamplers(1, &s.second);
    if (fQuery && g.glDeleteQueries) g.glDeleteQueries(1, &fQuery);
    if (fVbo) g.glDeleteBuffers(1, &fVbo);
    if (fVao) g.glDeleteVertexArrays(1, &fVao);
}

bool GlBackend::checkThread(std::string* error) const {
    if (std::this_thread::get_id() == fThread) return true;
    *error = "GL backend used from a thread other than the one that owns the context";
    return false;
}

void GlBackend::noteError(const char* where) {
    const unsigned e = fGl->glGetError();
    if (e != GL_NO_ERROR && fError.empty()) fError = std::string(where) + ": GL error 0x" + [&] { char b[16]; std::snprintf(b, sizeof(b), "%x", e); return std::string(b); }();
}

bool GlBackend::contextLost() {
    if (fLost) return true;
    if (!fCaps.resetNotification) return false;
    if (fGl->glGetGraphicsResetStatus() != GL_NO_ERROR) fLost = true;
    return fLost;
}

bool GlBackend::supports(Lang l) const {
    if (!fOk) return false;
    switch (l) {
        case Lang::GLSLES: return fCaps.es;
        case Lang::GLSL: return !fCaps.es;
        default: return false;   // SkSL belongs to Skia; Vulkan GLSL / SPIR-V need a compiler / loader that is not linked
    }
}
bool GlBackend::supports(Format f) const {
    if (!fOk && fError.empty() == false && !fGl) return f == Format::RGBA8;
    return fCaps.of(Concrete(f)).renderable;
}

// ---------------------------------------------------------------- format probing
bool GlBackend::probeFormat(Format f, GlDeviceCaps::FormatCaps* caps) {
    GlFns& g = *fGl;
    *caps = GlDeviceCaps::FormatCaps();
    g.glGetError();
    const auto& ext = fCaps.glslDevice.extensions;
    unsigned tex = 0, fbo = 0;
    g.glGenTextures(1, &tex);
    g.glBindTexture(GL_TEXTURE_2D, tex);
    g.glTexImage2D(GL_TEXTURE_2D, 0, (int)InternalFormat(f), 2, 2, 0, GL_RGBA, ClientType(f), nullptr);
    g.glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
    g.glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
    g.glGenFramebuffers(1, &fbo);
    g.glBindFramebuffer(GL_FRAMEBUFFER, fbo);
    g.glFramebufferTexture2D(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0, GL_TEXTURE_2D, tex, 0);
    const bool complete = g.glGetError() == GL_NO_ERROR && g.glCheckFramebufferStatus(GL_FRAMEBUFFER) == GL_FRAMEBUFFER_COMPLETE;
    if (!complete) {
        caps->note = f == Format::RGBA8 ? "framebuffer incomplete" : "not renderable (framebuffer incomplete)";
    } else if (f == Format::RGBA8) {
        caps->renderable = true; caps->linear = true; caps->blend = true; caps->exactFloat = false; caps->note = "ok";
    } else {
        // A float target that really keeps floats: write 2.5 / -1 and, for 32F, 1 + 2^-20 (not representable in half precision).
        const float want[4] = {2.5f, -1.0f, f == Format::RGBA32F ? 1.0f + 1.0f / 1048576.0f : 0.25f, 1.0f};
        g.glDisable(GL_BLEND); g.glDisable(GL_SCISSOR_TEST);
        g.glClearColor(want[0], want[1], want[2], want[3]);
        g.glClear(GL_COLOR_BUFFER_BIT);
        float got[4] = {0, 0, 0, 0};
        g.glPixelStorei(GL_PACK_ALIGNMENT, 1);
        g.glReadPixels(0, 0, 1, 1, GL_RGBA, GL_FLOAT, got);
        const bool read = g.glGetError() == GL_NO_ERROR;
        caps->exactFloat = read && got[0] == want[0] && got[1] == want[1] && got[2] == want[2] && got[3] == want[3];
        caps->renderable = caps->exactFloat;
        caps->note = caps->exactFloat ? "ok" : (read ? "renders but clamps or rounds to a smaller precision" : "float read-back refused");
        // linear filtering: half float is core in ES3 / GL3; 32F needs OES_texture_float_linear (core on desktop)
        caps->linear = f == Format::RGBA16F ? true : (!fCaps.es || HasExt(ext, "GL_OES_texture_float_linear"));
        // blending into float targets: 16F with EXT_color_buffer_(half_)float; 32F needs EXT_float_blend on ES (core on desktop)
        caps->blend = f == Format::RGBA16F ? true : (!fCaps.es || HasExt(ext, "GL_EXT_float_blend"));
        if (caps->renderable && f == Format::RGBA16F && fCaps.es && !(HasExt(ext, "GL_EXT_color_buffer_float") || HasExt(ext, "GL_EXT_color_buffer_half_float")))
            caps->note = "ok (complete, though neither colour-buffer extension is advertised)";
    }
    g.glBindFramebuffer(GL_FRAMEBUFFER, 0);
    g.glDeleteFramebuffers(1, &fbo);
    g.glDeleteTextures(1, &tex);
    g.glGetError();
    return true;
}

bool GlBackend::probeFormats() {
    probeFormat(Format::RGBA8, &fCaps.rgba8);
    probeFormat(Format::RGBA16F, &fCaps.rgba16f);
    probeFormat(Format::RGBA32F, &fCaps.rgba32f);
    if (!fCaps.rgba8.renderable) { fError = "RGBA8 render targets are not available: " + fCaps.rgba8.note; return false; }
    return true;
}

std::string GlDeviceCaps::describe() const {
    char b[512];
    std::string s;
    std::snprintf(b, sizeof(b), "%s | %s | %s | GLSL %s\n", vendor.c_str(), renderer.c_str(), version.c_str(), glsl.c_str()); s += b;
    std::snprintf(b, sizeof(b), "max texture %d, color attachments %d, texture units %d\n", maxTextureSize, maxColorAttachments, maxTextureUnits); s += b;
    auto line = [&](const char* n, const FormatCaps& c) {
        std::snprintf(b, sizeof(b), "%-8s renderable=%d linear=%d blend=%d exact=%d  (%s)\n", n, c.renderable, c.linear, c.blend, c.exactFloat, c.note.c_str()); s += b;
    };
    line("RGBA8", rgba8); line("RGBA16F", rgba16f); line("RGBA32F", rgba32f);
    std::snprintf(b, sizeof(b), "programBinary=%d timerQuery=%d resetNotification=%d borderClamp=%d\n", programBinary, timerQuery, resetNotification, borderClamp); s += b;
    return s;
}

// ---------------------------------------------------------------- targets
Target* GlBackend::create(int w, int h, Format f) {
    std::string err;
    if (!fOk || fLost || !checkThread(&err) || w <= 0 || h <= 0 || w > fCaps.maxTextureSize || h > fCaps.maxTextureSize) return nullptr;
    f = Concrete(f);
    if (!supports(f)) return nullptr;
    GlFns& g = *fGl;
    g.glGetError();
    auto* t = new GlTarget();
    t->width = w; t->height = h; t->format = f;
    g.glGenTextures(1, &t->tex);
    g.glBindTexture(GL_TEXTURE_2D, t->tex);
    g.glTexImage2D(GL_TEXTURE_2D, 0, (int)InternalFormat(f), w, h, 0, GL_RGBA, ClientType(f), nullptr);
    g.glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);   // real filtering is done by sampler objects
    g.glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
    g.glGenFramebuffers(1, &t->fbo);
    g.glBindFramebuffer(GL_FRAMEBUFFER, t->fbo);
    g.glFramebufferTexture2D(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0, GL_TEXTURE_2D, t->tex, 0);
    const unsigned e = g.glGetError();
    if (e != GL_NO_ERROR || g.glCheckFramebufferStatus(GL_FRAMEBUFFER) != GL_FRAMEBUFFER_COMPLETE) {
        g.glBindFramebuffer(GL_FRAMEBUFFER, 0);
        g.glDeleteFramebuffers(1, &t->fbo); g.glDeleteTextures(1, &t->tex);
        delete t;
        return nullptr;   // out of memory or an unusable format: the pool reports it and the executor fails the frame cleanly
    }
    g.glBindFramebuffer(GL_FRAMEBUFFER, 0);
    fLive.insert(t);
    fStats.targetsCreated++; fStats.liveTargets++; fStats.liveBytes += t->bytes();
    fStats.peakBytes = std::max(fStats.peakBytes, fStats.liveBytes);
    return t;
}

void GlBackend::destroy(Target* target) {
    auto* t = static_cast<GlTarget*>(target);
    if (!t || !fLive.count(t) || t->backendOwned) return;   // backend-owned textures and blanks live as long as the backend
    GlFns& g = *fGl;
    if (t->fbo) g.glDeleteFramebuffers(1, &t->fbo);
    if (t->tex) g.glDeleteTextures(1, &t->tex);
    FreeShared(fGl.get(), t->image, t->ahb);
    fStats.targetsDestroyed++; fStats.liveTargets--; fStats.liveBytes -= t->bytes();
    fLive.erase(t);
    delete t;
}

#ifdef __ANDROID__
namespace {
bool HardwareFormat(Format f, uint32_t* out) {
    if (f == Format::RGBA8) { *out = AHARDWAREBUFFER_FORMAT_R8G8B8A8_UNORM; return true; }
    if (f == Format::RGBA16F) { *out = AHARDWAREBUFFER_FORMAT_R16G16B16A16_FLOAT; return true; }
    return false;
}
}  // namespace

// Wraps `buffer` (a reference is taken here) in an EGLImage, a texture and a framebuffer. On failure nothing is leaked.
Target* GlBackend::adoptShared(AHardwareBuffer* buffer, Format f, int w, int h) {
    std::string err;
    if (!fOk || fLost || !checkThread(&err) || !buffer || !supports(f)) return nullptr;
    GlFns& g = *fGl;
    using GetProcAddress = void* (*)(const char*);
    using CurrentDisplay = void* (*)();
    auto eglProc = reinterpret_cast<GetProcAddress>(EglProc("eglGetProcAddress"));
    auto currentDisplay = reinterpret_cast<CurrentDisplay>(EglProc("eglGetCurrentDisplay"));
    if (!eglProc || !currentDisplay) return nullptr;
    using CreateImage = void* (*)(void*, void*, unsigned, void*, const int*);
    using GetClient = void* (*)(const void*);
    using ImageTarget = void (*)(unsigned, void*);
    constexpr unsigned kEglNativeBufferAndroid = 0x3140;
    constexpr int kEglImagePreservedKhr = 0x30D2, kEglTrue = 1;
    auto createImage = reinterpret_cast<CreateImage>(eglProc("eglCreateImageKHR"));
    auto getClient = reinterpret_cast<GetClient>(eglProc("eglGetNativeClientBufferANDROID"));
    auto imageTarget = reinterpret_cast<ImageTarget>(eglProc("glEGLImageTargetTexture2DOES"));
    if (!createImage || !getClient || !imageTarget) return nullptr;
    void* display = currentDisplay();
    const int attrs[] = {kEglImagePreservedKhr, kEglTrue, EGL_NONE};
    void* client = getClient(buffer);
    void* image = client ? createImage(display, nullptr, kEglNativeBufferAndroid, client, attrs) : nullptr;
    if (!image) return nullptr;
    g.glGetError();
    auto* t = new GlTarget();
    t->width = w; t->height = h; t->format = f;
    g.glGenTextures(1, &t->tex);
    g.glBindTexture(GL_TEXTURE_2D, t->tex);
    imageTarget(GL_TEXTURE_2D, image);
    g.glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);   // real filtering is done by sampler objects
    g.glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
    g.glGenFramebuffers(1, &t->fbo);
    g.glBindFramebuffer(GL_FRAMEBUFFER, t->fbo);
    g.glFramebufferTexture2D(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0, GL_TEXTURE_2D, t->tex, 0);
    const unsigned e = g.glGetError();
    const bool complete = g.glCheckFramebufferStatus(GL_FRAMEBUFFER) == GL_FRAMEBUFFER_COMPLETE;
    g.glBindFramebuffer(GL_FRAMEBUFFER, 0);
    if (e != GL_NO_ERROR || !complete) {
        g.glDeleteFramebuffers(1, &t->fbo); g.glDeleteTextures(1, &t->tex);
        FreeShared(fGl.get(), image, nullptr);
        delete t;
        return nullptr;
    }
    AHardwareBuffer_acquire(buffer);
    t->image = image;
    t->ahb = buffer;
    fLive.insert(t);
    fStats.targetsCreated++; fStats.liveTargets++; fStats.liveBytes += t->bytes();
    fStats.peakBytes = std::max(fStats.peakBytes, fStats.liveBytes);
    return t;
}

Target* GlBackend::createShared(int w, int h, Format f, AHardwareBuffer** buffer, bool cpuAccess) {
    if (buffer) *buffer = nullptr;
    f = Concrete(f);
    uint32_t hwFormat = 0;
    if (!HardwareFormat(f, &hwFormat) || w <= 0 || h <= 0 || w > fCaps.maxTextureSize || h > fCaps.maxTextureSize) return nullptr;
    AHardwareBuffer_Desc d = {};
    d.width = (uint32_t)w; d.height = (uint32_t)h; d.layers = 1; d.format = hwFormat;
    d.usage = AHARDWAREBUFFER_USAGE_GPU_FRAMEBUFFER | AHARDWAREBUFFER_USAGE_GPU_SAMPLED_IMAGE;
    if (cpuAccess) d.usage |= AHARDWAREBUFFER_USAGE_CPU_READ_OFTEN | AHARDWAREBUFFER_USAGE_CPU_WRITE_OFTEN;
    AHardwareBuffer* b = nullptr;
    if (AHardwareBuffer_allocate(&d, &b) != 0 || !b) return nullptr;
    Target* t = adoptShared(b, f, w, h);
    if (!t) { AHardwareBuffer_release(b); return nullptr; }
    AHardwareBuffer_release(b);                       // the target holds its own reference
    if (buffer) *buffer = static_cast<AHardwareBuffer*>(static_cast<GlTarget*>(t)->ahb);   // borrowed: valid until the target is destroyed
    return t;
}

Target* GlBackend::wrapShared(AHardwareBuffer* buffer) {
    if (!buffer) return nullptr;
    AHardwareBuffer_Desc d = {};
    AHardwareBuffer_describe(buffer, &d);
    Format f = Format::Inherit;
    if (d.format == AHARDWAREBUFFER_FORMAT_R8G8B8A8_UNORM) f = Format::RGBA8;
    else if (d.format == AHARDWAREBUFFER_FORMAT_R16G16B16A16_FLOAT) f = Format::RGBA16F;
    else return nullptr;
    return adoptShared(buffer, f, (int)d.width, (int)d.height);
}

AHardwareBuffer* GlBackend::sharedBuffer(Target* target) const {
    auto* t = static_cast<GlTarget*>(target);
    return t && fLive.count(t) ? static_cast<AHardwareBuffer*>(t->ahb) : nullptr;
}

bool GlBackend::finishShared() {
    std::string err;
    if (!fOk || fLost || !checkThread(&err)) return false;
    fGl->glFinish();
    return true;
}
#else
Target* GlBackend::adoptShared(AHardwareBuffer*, Format, int, int) { return nullptr; }
Target* GlBackend::createShared(int, int, Format, AHardwareBuffer** buffer, bool) { if (buffer) *buffer = nullptr; return nullptr; }
Target* GlBackend::wrapShared(AHardwareBuffer*) { return nullptr; }
AHardwareBuffer* GlBackend::sharedBuffer(Target*) const { return nullptr; }
bool GlBackend::finishShared() { return false; }
#endif

bool GlBackend::uploadRgba8(Target* target, const uint8_t* rgba) {
    auto* t = static_cast<GlTarget*>(target);
    if (!t || !fLive.count(t)) return false;
    GlFns& g = *fGl;
    g.glGetError();
    g.glPixelStorei(GL_UNPACK_ALIGNMENT, 1);
    g.glBindTexture(GL_TEXTURE_2D, t->tex);
    if (t->format == Format::RGBA8) {
        g.glTexSubImage2D(GL_TEXTURE_2D, 0, 0, 0, t->width, t->height, GL_RGBA, GL_UNSIGNED_BYTE, rgba);
    } else {
        std::vector<float> f((size_t)t->width * t->height * 4);
        for (size_t i = 0; i < f.size(); i++) f[i] = rgba[i] / 255.0f;
        g.glTexSubImage2D(GL_TEXTURE_2D, 0, 0, 0, t->width, t->height, GL_RGBA, GL_FLOAT, f.data());
    }
    return g.glGetError() == GL_NO_ERROR;
}

bool GlBackend::upload(Target* target, const float* rgba) {
    auto* t = static_cast<GlTarget*>(target);
    if (!t || !fLive.count(t)) return false;
    GlFns& g = *fGl;
    g.glGetError();
    g.glPixelStorei(GL_UNPACK_ALIGNMENT, 1);
    g.glBindTexture(GL_TEXTURE_2D, t->tex);
    if (t->format == Format::RGBA8) {
        std::vector<uint8_t> b((size_t)t->width * t->height * 4);
        for (size_t i = 0; i < b.size(); i++) b[i] = (uint8_t)std::lround(std::min(1.0f, std::max(0.0f, rgba[i])) * 255.0f);
        g.glTexSubImage2D(GL_TEXTURE_2D, 0, 0, 0, t->width, t->height, GL_RGBA, GL_UNSIGNED_BYTE, b.data());
    } else {
        g.glTexSubImage2D(GL_TEXTURE_2D, 0, 0, 0, t->width, t->height, GL_RGBA, GL_FLOAT, rgba);
    }
    return g.glGetError() == GL_NO_ERROR;
}

Target* GlBackend::createFromFloats(int w, int h, Format f, const float* rgba) {
    Target* t = create(w, h, f);
    if (t && !upload(t, rgba)) { destroy(t); return nullptr; }
    return t;
}

bool GlBackend::readback(Target* target, std::vector<float>* out) {
    auto* t = static_cast<GlTarget*>(target);
    if (!t || !fLive.count(t)) return false;
    GlFns& g = *fGl;
    g.glGetError();
    g.glBindFramebuffer(GL_FRAMEBUFFER, t->fbo);
    g.glPixelStorei(GL_PACK_ALIGNMENT, 1);
    out->assign((size_t)t->width * t->height * 4, 0.0f);
    if (t->format == Format::RGBA8) {
        std::vector<uint8_t> b(out->size());
        g.glReadPixels(0, 0, t->width, t->height, GL_RGBA, GL_UNSIGNED_BYTE, b.data());
        for (size_t i = 0; i < b.size(); i++) (*out)[i] = b[i] / 255.0f;
    } else {
        g.glReadPixels(0, 0, t->width, t->height, GL_RGBA, GL_FLOAT, out->data());
    }
    g.glBindFramebuffer(GL_FRAMEBUFFER, 0);
    return g.glGetError() == GL_NO_ERROR;
}

Target* GlBackend::texture(const TextureDesc& td) {
    const std::string key = td.id + "|" + td.source + "|" + std::to_string(td.width) + "x" + std::to_string(td.height) + "|" + std::to_string(td.seed);
    auto it = fTextures.find(key);
    if (it != fTextures.end()) return it->second.get();
    auto* t = static_cast<GlTarget*>(create(td.width, td.height, Format::RGBA8));
    if (!t) return nullptr;
    std::vector<uint8_t> px((size_t)td.width * td.height * 4);
    if (td.source == "builtin:noise") {
        px = NoisePixels(td.width, td.height, td.seed);
    } else if (td.source == "builtin:ramp-x" || td.source == "builtin:ramp-y") {
        for (int y = 0; y < td.height; y++) for (int x = 0; x < td.width; x++) {
            const float v = td.source == "builtin:ramp-x" ? (x + 0.5f) / td.width : (y + 0.5f) / td.height;
            const uint8_t b = (uint8_t)std::lround(v * 255.0f);
            uint8_t* p = &px[((size_t)y * td.width + x) * 4];
            p[0] = p[1] = p[2] = p[3] = b;
        }
    } else {
        destroy(t);
        return nullptr;   // unknown source: the executor reports "no image"
    }
    uploadRgba8(t, px.data());
    t->backendOwned = true;
    fTextures[key].reset(t);   // owned by the cache from here on; freed with the backend (never by a pool)
    return t;
}

Target* GlBackend::blank(int w, int h, Format f) {
    const std::string key = std::to_string(w) + "x" + std::to_string(h) + FormatText(Concrete(f));
    auto it = fBlanks.find(key);
    if (it != fBlanks.end()) return it->second.get();
    auto* t = static_cast<GlTarget*>(create(w, h, f));
    if (!t) return nullptr;
    GlFns& g = *fGl;
    g.glBindFramebuffer(GL_FRAMEBUFFER, t->fbo);
    g.glDisable(GL_SCISSOR_TEST);
    g.glClearColor(0, 0, 0, 0);
    g.glClear(GL_COLOR_BUFFER_BIT);
    g.glBindFramebuffer(GL_FRAMEBUFFER, 0);
    t->backendOwned = true;
    fBlanks[key].reset(t);
    return t;
}

unsigned GlBackend::sampler(Filter f, Wrap w) {
    const int key = (int)f * 16 + (int)w;
    auto it = fSamplers.find(key);
    if (it != fSamplers.end()) return it->second;
    GlFns& g = *fGl;
    unsigned s = 0;
    g.glGenSamplers(1, &s);
    const int filt = f == Filter::Linear ? (int)GL_LINEAR : (int)GL_NEAREST;
    g.glSamplerParameteri(s, GL_TEXTURE_MIN_FILTER, filt);
    g.glSamplerParameteri(s, GL_TEXTURE_MAG_FILTER, filt);
    const int wrap = w == Wrap::Repeat ? (int)GL_REPEAT : w == Wrap::Mirror ? (int)GL_MIRRORED_REPEAT : w == Wrap::Decal ? (int)GL_CLAMP_TO_BORDER : (int)GL_CLAMP_TO_EDGE;
    g.glSamplerParameteri(s, GL_TEXTURE_WRAP_S, wrap);   // border colour stays (0,0,0,0): exactly Skia's Decal
    g.glSamplerParameteri(s, GL_TEXTURE_WRAP_T, wrap);
    fSamplers[key] = s;
    return s;
}

// ---------------------------------------------------------------- capability check
bool GlBackend::accepts(const PassDesc& pass, Diag* why) {
    if (!supports(pass.lang)) {
        if (why) {
            why->kind = DiagKind::Capability;
            const char* l = ToString(pass.lang);
            why->message = pass.lang == Lang::VulkanGLSL || pass.lang == Lang::SPIRV
                ? std::string("lang=") + l + " needs a SPIR-V compiler / loader that is not part of this backend"
                : pass.lang == Lang::GLSL ? "desktop GLSL needs a desktop OpenGL context; this device exposes OpenGL ES (" + fCaps.version + ")"
                : pass.lang == Lang::GLSLES ? "GLSL ES needs an OpenGL ES context; this one is desktop OpenGL (" + fCaps.version + ")"
                : std::string("this backend does not run lang=") + l;
        }
        return false;
    }
    const ShaderHeader h = ParseShaderHeader(pass.source);
    std::string msg; int line = 0;
    if (!CheckGlslHeader(pass.lang, h, fCaps.glslDevice, &msg, &line)) {
        if (why) { why->kind = DiagKind::Capability; why->message = msg; why->line = line; }
        return false;
    }
    return true;
}

// ---------------------------------------------------------------- compile
bool GlBackend::compileProgram(const PassDesc& pass, Program* out, std::string* error) {
    GlFns& g = *fGl;
    fDiags.clear();
    const VersionInfo v = FindVersion(pass.source);
    std::string frag = pass.source;
    std::string defs;
    int prelude = 0;
    // GLSL ES gives sampler2D the default precision lowp (8-bit-like), which would quantise RGBA16F / RGBA32F inputs inside the
    // shader. Float pipelines need highp samplers, so the backend declares that first; a shader that declares its own
    // `precision <p> sampler2D;` later simply overrides it.
    if (fCaps.es) { defs += "precision highp sampler2D;\n"; prelude++; }
    for (const auto& d : pass.defines) { defs += "#define " + d.first + " " + d.second + "\n"; prelude++; }
    if (!defs.empty()) {
        size_t at = PreludePoint(frag, v);
        if (at > 0 && frag[at - 1] != '\n') { frag.insert(at, "\n"); at++; }   // the directive was the last line and had no newline
        frag.insert(at, defs);
    }
    const std::string vert = VertexSource(v, !fCaps.es);

    const uint64_t key = ShaderCacheKey(pass, fCaps.vendor + "|" + fCaps.version + "|" + fCaps.glsl, fCaps.renderer, kPreludeRevision);
    out->preludeLines = prelude;
    out->id = g.glCreateProgram();
    if (g.glProgramParameteri && fCaps.programBinary) g.glProgramParameteri(out->id, GL_PROGRAM_BINARY_RETRIEVABLE_HINT, 1);

    bool linked = false;
    if (fDiskCache) {
        std::vector<uint8_t> blob;
        if (fDiskCache->load(key, &blob) && blob.size() > 8) {
            uint32_t fmt = 0, len = 0;
            std::memcpy(&fmt, blob.data(), 4); std::memcpy(&len, blob.data() + 4, 4);
            if (len + 8 == blob.size()) {
                g.glGetError();
                g.glProgramBinary(out->id, fmt, blob.data() + 8, (int)len);
                int ok = 0; g.glGetProgramiv(out->id, GL_LINK_STATUS, &ok);
                if (ok && g.glGetError() == GL_NO_ERROR) { linked = true; out->fromDisk = true; fStats.programDiskHits++; }
                else fStats.programDiskRejected++;   // driver updated or blob damaged: recompile and overwrite
            } else fStats.programDiskRejected++;
        }
    }
    if (!linked) {
        auto build = [&](unsigned type, const std::string& src, std::string* log) -> unsigned {
            const unsigned s = g.glCreateShader(type);
            const char* p = src.c_str();
            const int len = (int)src.size();
            g.glShaderSource(s, 1, &p, &len);
            g.glCompileShader(s);
            int ok = 0; g.glGetShaderiv(s, GL_COMPILE_STATUS, &ok);
            int ll = 0; g.glGetShaderiv(s, GL_INFO_LOG_LENGTH, &ll);
            log->assign((size_t)std::max(ll, 1), '\0');
            int got = 0; g.glGetShaderInfoLog(s, ll, &got, &(*log)[0]);
            log->resize((size_t)std::max(got, 0));
            if (!ok) { g.glDeleteShader(s); return 0; }
            return s;
        };
        std::string flog, vlog;
        const unsigned fs = build(GL_FRAGMENT_SHADER, frag, &flog);
        if (!fs) {
            fDiags = MapCompilerLog(pass, -1, "", name(), flog, prelude);
            std::string msg = "fragment shader did not compile";
            for (const Diag& d : fDiags) if (d.error) { msg += "\n  " + FormatDiag(d); }
            if (fDiags.empty()) msg += ": " + flog;
            *error = msg;
            g.glDeleteProgram(out->id); out->id = 0;
            return false;
        }
        if (!flog.empty()) fDiags = MapCompilerLog(pass, -1, "", name(), flog, prelude);   // warnings
        const unsigned vs = build(GL_VERTEX_SHADER, vert, &vlog);
        if (!vs) { g.glDeleteShader(fs); g.glDeleteProgram(out->id); out->id = 0; *error = "internal: generated vertex shader did not compile: " + vlog; return false; }
        g.glAttachShader(out->id, vs);
        g.glAttachShader(out->id, fs);
        g.glBindAttribLocation(out->id, 0, "a_pos");
        g.glLinkProgram(out->id);
        g.glDeleteShader(vs); g.glDeleteShader(fs);
        int ok = 0; g.glGetProgramiv(out->id, GL_LINK_STATUS, &ok);
        if (!ok) {
            int ll = 0; g.glGetProgramiv(out->id, GL_INFO_LOG_LENGTH, &ll);
            std::string log((size_t)std::max(ll, 1), '\0');
            int got = 0; g.glGetProgramInfoLog(out->id, ll, &got, &log[0]);
            log.resize((size_t)std::max(got, 0));
            g.glDeleteProgram(out->id); out->id = 0;
            *error = "shader program did not link: " + log + " (the generated full-screen vertex shader exports no varyings, so a fragment shader that reads `varying`/`in` inputs cannot link; compute positions from gl_FragCoord and `size`)";
            return false;
        }
        fStats.shaderCompiles++;
        if (fDiskCache) {
            int len = 0; g.glGetProgramiv(out->id, GL_PROGRAM_BINARY_LENGTH, &len);
            if (len > 0) {
                std::vector<uint8_t> blob(8 + (size_t)len);
                int got = 0; unsigned fmt = 0;
                g.glGetProgramBinary(out->id, len, &got, &fmt, blob.data() + 8);
                if (got > 0 && g.glGetError() == GL_NO_ERROR) {
                    const uint32_t f32 = fmt, l32 = (uint32_t)got;
                    std::memcpy(blob.data(), &f32, 4); std::memcpy(blob.data() + 4, &l32, 4);
                    blob.resize(8 + (size_t)got);
                    if (fDiskCache->store(key, blob.data(), blob.size())) fStats.programDiskStores++;
                }
            }
        }
    }
    // reflection
    int n = 0, maxLen = 0;
    g.glGetProgramiv(out->id, GL_ACTIVE_UNIFORMS, &n);
    g.glGetProgramiv(out->id, GL_ACTIVE_UNIFORM_MAX_LENGTH, &maxLen);
    std::string nm((size_t)std::max(maxLen, 1), '\0');
    for (int i = 0; i < n; i++) {
        int len = 0, size = 0; unsigned type = 0;
        g.glGetActiveUniform(out->id, (unsigned)i, maxLen, &len, &size, &type, &nm[0]);
        Program::Uniform u;
        u.name = std::string(nm.c_str(), (size_t)len);
        if (u.name.compare(0, 3, "gl_") == 0) continue;
        u.type = type; u.size = size;
        u.loc = g.glGetUniformLocation(out->id, u.name.c_str());
        if (u.loc < 0) continue;   // inside a uniform block: not supported as a loose uniform
        u.name = StripIdx(u.name);
        out->uniforms.push_back(u);
    }
    return true;
}

GlBackend::Program* GlBackend::program(const PassDesc& pass, std::string* error) {
    const uint64_t key = ShaderCacheKey(pass, fCaps.version, fCaps.renderer, kPreludeRevision);
    auto it = fPrograms.find(key);
    if (it != fPrograms.end()) { fStats.programMemoryHits++; return it->second.get(); }
    std::unique_ptr<Program> p(new Program());
    if (!compileProgram(pass, p.get(), error)) return nullptr;
    Program* raw = p.get();
    fPrograms[key] = std::move(p);
    return raw;
}

int GlBackend::compileProgramForTest(const PassDesc& pass, std::string* log) {
    Program tmp;
    std::string err;
    if (!compileProgram(pass, &tmp, &err)) { *log = err; return 0; }
    fGl->glDeleteProgram(tmp.id);
    return (int)tmp.id;
}

void GlBackend::dropPrograms() {
    for (auto& p : fPrograms) if (p.second->id) fGl->glDeleteProgram(p.second->id);
    fPrograms.clear();
}

// ---------------------------------------------------------------- run one pass
bool GlBackend::run(const PassRun& r, std::string* error) {
    if (!fOk) { *error = "GL backend is not usable: " + fError; return false; }
    if (!checkThread(error)) return false;
    if (contextLost()) { *error = "the GL context was lost (driver reset); recreate the context and call Executor::dropAll()"; return false; }
    GlFns& g = *fGl;
    auto* out = static_cast<GlTarget*>(r.output);
    if (!out || !fLive.count(out)) { *error = "output target does not belong to this GL backend"; return false; }
    if (!supports(r.pass->lang)) { Diag d; accepts(*r.pass, &d); *error = d.message; return false; }

    Program* prog = program(*r.pass, error);
    if (!prog) return false;
    g.glGetError();

    // blend
    const Blend blend = r.pass->blend;
    if (blend != Blend::Replace && !fCaps.of(out->format).blend) { *error = std::string("blending into ") + FormatText(out->format) + " is not supported on this device"; return false; }
    // sampling a 32-bit float image with linear filtering needs OES_texture_float_linear
    for (const BoundInput& in : r.inputs) {
        auto* t = static_cast<GlTarget*>(in.target);
        if (!t || !fLive.count(t)) { *error = "input '" + (in.name ? *in.name : std::string("?")) + "' does not belong to this GL backend"; return false; }
        if (in.filter == Filter::Linear && !fCaps.of(t->format).linear) { *error = std::string("input '") + *in.name + "' is " + FormatText(t->format) + ", which this device cannot filter linearly (needs OES_texture_float_linear); use filter=nearest or RGBA16F"; return false; }
        if (in.wrap == Wrap::Decal && !fCaps.borderClamp) { *error = "wrap=decal needs EXT_texture_border_clamp, which this device lacks"; return false; }
        if (t == out) { *error = "pass '" + r.pass->id + "' reads the buffer it renders into (feedback loop); use a history buffer (@1) or another output"; return false; }
    }

    g.glUseProgram(prog->id);

    // bind inputs to texture units 0..n-1
    const int units = std::min((int)r.inputs.size(), std::max(fCaps.maxTextureUnits, 1));
    if ((int)r.inputs.size() > units) { *error = "pass has more inputs than texture units (" + std::to_string(fCaps.maxTextureUnits) + ")"; g.glUseProgram(0); return false; }
    for (int i = 0; i < units; i++) {
        const BoundInput& in = r.inputs[(size_t)i];
        g.glActiveTexture(GL_TEXTURE0 + (unsigned)i);
        g.glBindTexture(GL_TEXTURE_2D, static_cast<GlTarget*>(in.target)->tex);
        g.glBindSampler((unsigned)i, sampler(in.filter, in.wrap));
    }
    auto cleanup = [&] {
        for (int i = 0; i < units; i++) { g.glActiveTexture(GL_TEXTURE0 + (unsigned)i); g.glBindSampler((unsigned)i, 0); g.glBindTexture(GL_TEXTURE_2D, 0); }
        g.glActiveTexture(GL_TEXTURE0);
        g.glUseProgram(0);
        g.glBindFramebuffer(GL_FRAMEBUFFER, 0);
        g.glDisable(GL_BLEND);
    };

    // uniforms, by reflected name and type
    for (const Program::Uniform& u : prog->uniforms) {
        if (u.type == GL_SAMPLER_2D) {
            int unit = -1;
            for (size_t i = 0; i < r.inputs.size(); i++) if (r.inputs[i].name && *r.inputs[i].name == u.name) unit = (int)i;
            if (unit < 0) {
                std::string have;
                for (const BoundInput& in : r.inputs) have += (have.empty() ? "" : ", ") + (in.name ? *in.name : std::string("?"));
                *error = "sampler2D '" + u.name + "' has no input of that name (inputs: " + (have.empty() ? "none" : have) + ")";
                cleanup(); return false;
            }
            g.glUniform1i(u.loc, unit);
            continue;
        }
        const int comps = Components(u.type);
        if (!comps) { *error = std::string("uniform '") + u.name + "' has type " + TypeName(u.type) + ", which is not supported (float/int/bool scalars and vectors, sampler2D)"; cleanup(); return false; }
        std::vector<float> value;
        bool automatic = true;
        int wantComps = comps;   // components the automatic value must have
        if (u.name == "size") value = {(float)r.areaWidth, (float)r.areaHeight};
        else if (u.name == "out_px") value = {(float)out->width, (float)out->height};
        else if (u.name == "time") value = {(float)r.timeSeconds};
        else if (u.name == "frame") value = {(float)r.frame};
        else {
            automatic = false;
            const size_t us = u.name.size();
            if (us > 3 && u.name.compare(us - 3, 3, "_px") == 0) {
                const std::string base = u.name.substr(0, us - 3);
                for (const BoundInput& in : r.inputs) if (in.name && *in.name == base) { automatic = true; value = {(float)in.target->width, (float)in.target->height}; }
            }
            if (!automatic) {
                for (const Constant& c : r.pass->constants) if (c.name == u.name) { value = c.value; automatic = false; wantComps = comps * u.size; goto have; }
                *error = std::string("uniform '") + u.name + "' (" + TypeName(u.type) + ") has no value: it is neither an automatic uniform (size, time, frame, out_px, <input>_px) nor a constant of pass '" + r.pass->id + "'";
                cleanup(); return false;
            }
        }
    have:
        if ((int)value.size() != wantComps && !(automatic && (u.name == "time" || u.name == "frame"))) {
            *error = std::string("uniform '") + u.name + "' is " + TypeName(u.type) + (u.size > 1 ? "[" + std::to_string(u.size) + "]" : "") + " (" + std::to_string(wantComps) + " values) but " + std::to_string(value.size()) + " were given";
            cleanup(); return false;
        }
        if (automatic && comps != (int)value.size()) { *error = std::string("automatic uniform '") + u.name + "' must be " + (value.size() == 2 ? "vec2" : "float") + ", the shader declares " + TypeName(u.type); cleanup(); return false; }
        if (IsFloatType(u.type)) {
            const float* p = value.data();
            switch (comps) { case 1: g.glUniform1fv(u.loc, u.size, p); break; case 2: g.glUniform2fv(u.loc, u.size, p); break; case 3: g.glUniform3fv(u.loc, u.size, p); break; default: g.glUniform4fv(u.loc, u.size, p); }
        } else {
            std::vector<int> iv(value.size());
            for (size_t i = 0; i < value.size(); i++) iv[i] = (int)std::lround(value[i]);
            const int* p = iv.data();
            switch (comps) { case 1: g.glUniform1iv(u.loc, u.size, p); break; case 2: g.glUniform2iv(u.loc, u.size, p); break; case 3: g.glUniform3iv(u.loc, u.size, p); break; default: g.glUniform4iv(u.loc, u.size, p); }
        }
    }

    // target state
    g.glBindFramebuffer(GL_FRAMEBUFFER, out->fbo);
    g.glViewport(0, 0, out->width, out->height);
    g.glDisable(GL_SCISSOR_TEST); g.glDisable(GL_DEPTH_TEST); g.glDisable(GL_CULL_FACE);
    if (r.clear) { g.glClearColor(0, 0, 0, 0); g.glClear(GL_COLOR_BUFFER_BIT); }
    switch (blend) {
        case Blend::Replace: g.glDisable(GL_BLEND); break;
        case Blend::SrcOver: g.glEnable(GL_BLEND); g.glBlendFunc(GL_ONE, GL_ONE_MINUS_SRC_ALPHA); break;
        case Blend::Add: g.glEnable(GL_BLEND); g.glBlendFunc(GL_ONE, GL_ONE); break;
        case Blend::Multiply: g.glEnable(GL_BLEND); g.glBlendFunc(GL_DST_COLOR, GL_ONE_MINUS_SRC_ALPHA); break;
        case Blend::Screen: g.glEnable(GL_BLEND); g.glBlendFunc(GL_ONE, GL_ONE_MINUS_SRC_COLOR); break;
    }
    g.glBindVertexArray(fVao);

    // draw, timed
    const bool timer = fCaps.timerQuery && fQuery && fOptions.profile;
    const auto w0 = std::chrono::steady_clock::now();
    if (timer) g.glBeginQuery(GL_TIME_ELAPSED, fQuery);
    g.glDrawArrays(GL_TRIANGLES, 0, 3);
    if (timer) g.glEndQuery(GL_TIME_ELAPSED);
    fStats.drawCalls++; fStats.passesRun++;
    fLastGpuNs = -1;
    if (fOptions.profile) {
        if (timer) {
            g.glFlush();
            unsigned avail = 0;
            for (int spin = 0; spin < 100000 && !avail; spin++) g.glGetQueryObjectuiv(fQuery, GL_QUERY_RESULT_AVAILABLE, &avail);
            uint64_t ns = 0;
            if (avail) g.glGetQueryObjectui64v(fQuery, GL_QUERY_RESULT, &ns);
            int disjoint = 0;
            if (fCaps.es) { g.glGetIntegerv(GL_GPU_DISJOINT_EXT, &disjoint); g.glGetError(); }
            if (avail && !disjoint) fLastGpuNs = (int64_t)ns;
        }
        if (fLastGpuNs < 0) { g.glFinish(); fLastGpuNs = std::chrono::duration_cast<std::chrono::nanoseconds>(std::chrono::steady_clock::now() - w0).count(); }
        fStats.gpuNanosTotal += fLastGpuNs;
    }
    cleanup();
    const unsigned e = g.glGetError();
    if (e != GL_NO_ERROR) {
        char b[96]; std::snprintf(b, sizeof(b), "GL error 0x%x while drawing pass '%s'%s", e, r.pass->id.c_str(), e == GL_OUT_OF_MEMORY ? " (out of GPU memory)" : "");
        *error = b;
        return false;
    }
    return true;
}

}  // namespace am::rg

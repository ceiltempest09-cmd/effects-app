package com.effects.motion.effects.engine

sealed interface CubeLutResult {
    data class Ok(val lut: CubeLut) : CubeLutResult
    data class Error(val line: Int, val message: String) : CubeLutResult
}

/** Parsed Adobe/Resolve .cube LUT. 3D data: red varies fastest, then green, then blue. */
class CubeLut(val title: String, val size: Int, val is3d: Boolean, val domainMin: FloatArray, val domainMax: FloatArray, val table: FloatArray) {

    /** Returns r,g,b in the LUT's output range for an input in the domain. */
    fun apply(r: Float, g: Float, b: Float, out: FloatArray = FloatArray(3)): FloatArray {
        val x = unit(r, 0)
        val y = unit(g, 1)
        val z = unit(b, 2)
        if (!is3d) {
            for (c in 0..2) out[c] = lerp1d(if (c == 0) x else if (c == 1) y else z, c)
            return out
        }
        val n = size - 1
        val fx = x * n; val fy = y * n; val fz = z * n
        val x0 = fx.toInt().coerceAtMost(n - 1); val y0 = fy.toInt().coerceAtMost(n - 1); val z0 = fz.toInt().coerceAtMost(n - 1)
        val tx = fx - x0; val ty = fy - y0; val tz = fz - z0
        for (c in 0..2) {
            fun at(i: Int, j: Int, k: Int) = table[((k * size + j) * size + i) * 3 + c]
            val c00 = at(x0, y0, z0) * (1 - tx) + at(x0 + 1, y0, z0) * tx
            val c10 = at(x0, y0 + 1, z0) * (1 - tx) + at(x0 + 1, y0 + 1, z0) * tx
            val c01 = at(x0, y0, z0 + 1) * (1 - tx) + at(x0 + 1, y0, z0 + 1) * tx
            val c11 = at(x0, y0 + 1, z0 + 1) * (1 - tx) + at(x0 + 1, y0 + 1, z0 + 1) * tx
            out[c] = (c00 * (1 - ty) + c10 * ty) * (1 - tz) + (c01 * (1 - ty) + c11 * ty) * tz
        }
        return out
    }

    private fun unit(v: Float, c: Int): Float {
        val span = domainMax[c] - domainMin[c]
        return ((v - domainMin[c]) / span).coerceIn(0f, 1f)
    }

    private fun lerp1d(t: Float, c: Int): Float {
        val n = size - 1
        val f = t * n
        val i = f.toInt().coerceAtMost(n - 1)
        val a = table[i * 3 + c]
        val b = table[(i + 1) * 3 + c]
        return a + (b - a) * (f - i)
    }

    companion object {
        const val Max3d = 129
        const val Max1d = 65536

        fun parse(text: String): CubeLutResult {
            var title = ""
            var size = 0
            var is3d = false
            var sizeLine = 0
            var dmin = floatArrayOf(0f, 0f, 0f)
            var dmax = floatArrayOf(1f, 1f, 1f)
            val values = ArrayList<Float>()
            var firstDataLine = 0
            text.lineSequence().forEachIndexed { index, raw ->
                val no = index + 1
                val line = raw.substringBefore('#').trim()
                if (line.isEmpty()) return@forEachIndexed
                val parts = line.split(Regex("\\s+"))
                val key = parts[0]
                try {
                    when {
                        key == "TITLE" -> title = line.removePrefix("TITLE").trim().trim('"')
                        key == "LUT_1D_SIZE" || key == "LUT_3D_SIZE" -> {
                            if (size != 0) return CubeLutResult.Error(no, "LUT size declared twice (first on line $sizeLine)")
                            size = parts.getOrNull(1)?.toIntOrNull() ?: return CubeLutResult.Error(no, "$key needs a whole number")
                            is3d = key == "LUT_3D_SIZE"
                            sizeLine = no
                            val max = if (is3d) Max3d else Max1d
                            if (size !in 2..max) return CubeLutResult.Error(no, "$key must be 2..$max, found $size")
                        }
                        key == "DOMAIN_MIN" || key == "DOMAIN_MAX" -> {
                            if (parts.size != 4) return CubeLutResult.Error(no, "$key needs three numbers")
                            val v = FloatArray(3) { parts[it + 1].toFloat() }
                            if (key == "DOMAIN_MIN") dmin = v else dmax = v
                        }
                        key == "LUT_1D_INPUT_RANGE" || key == "LUT_3D_INPUT_RANGE" -> {
                            if (parts.size != 3) return CubeLutResult.Error(no, "$key needs two numbers")
                            val lo = parts[1].toFloat(); val hi = parts[2].toFloat()
                            dmin = floatArrayOf(lo, lo, lo); dmax = floatArrayOf(hi, hi, hi)
                        }
                        key[0].isLetter() -> return CubeLutResult.Error(no, "Unknown keyword '$key'")
                        else -> {
                            if (parts.size != 3) return CubeLutResult.Error(no, "A data row needs exactly three numbers, found ${parts.size}")
                            if (size == 0) return CubeLutResult.Error(no, "Data appears before LUT_1D_SIZE or LUT_3D_SIZE")
                            if (firstDataLine == 0) firstDataLine = no
                            for (p in parts) {
                                val f = p.toFloat()
                                if (!f.isFinite()) return CubeLutResult.Error(no, "Non-finite value '$p'")
                                values += f
                            }
                        }
                    }
                } catch (e: NumberFormatException) {
                    return CubeLutResult.Error(no, "Not a number: ${e.message?.substringAfter(": ") ?: line}")
                }
            }
            if (size == 0) return CubeLutResult.Error(0, "No LUT_1D_SIZE or LUT_3D_SIZE found")
            val rows = if (is3d) size.toLong() * size * size else size.toLong()
            if (values.size.toLong() != rows * 3) return CubeLutResult.Error(firstDataLine, "Expected $rows data rows, found ${values.size / 3}")
            for (c in 0..2) if (!(dmax[c] > dmin[c])) return CubeLutResult.Error(0, "DOMAIN_MAX must be greater than DOMAIN_MIN on every channel")
            return CubeLutResult.Ok(CubeLut(title, size, is3d, dmin, dmax, values.toFloatArray()))
        }
    }
}

#ifdef __ANDROID__
#include "gl_ahb_probe.h"

#include <EGL/egl.h>
#include <EGL/eglext.h>
#include <GLES3/gl3.h>
#include <GLES2/gl2ext.h>
#include <android/hardware_buffer.h>

#include <cmath>
#include <cstdint>
#include <cstring>
#include <string>

namespace am {
namespace {
float HalfToFloat(uint16_t h) {
    const uint32_t s = (h >> 15) & 1, e = (h >> 10) & 31, m = h & 1023;
    float v;
    if (e == 0) v = std::ldexp((float)m, -24);
    else if (e == 31) v = m ? NAN : INFINITY;
    else v = std::ldexp((float)(m | 1024), (int)e - 25);
    return s ? -v : v;
}

struct Out {
    std::string t; int pass = 0, fail = 0;
    void ok(const std::string& s) { pass++; t += "PASS  " + s + "\n"; }
    void bad(const std::string& s) { fail++; t += "FAIL  " + s + "\n"; }
    void info(const std::string& s) { t += "      " + s + "\n"; }
};

bool HasExt(const char* list, const char* name) { return list && std::strstr(list, name) != nullptr; }

void OneFormat(Out& o, EGLDisplay dpy, uint32_t ahbFormat, const char* label, float r, float g, float b, float tol) {
    const std::string tag = std::string("AHardwareBuffer <-> GL ") + label;
    auto createImage = (PFNEGLCREATEIMAGEKHRPROC)eglGetProcAddress("eglCreateImageKHR");
    auto destroyImage = (PFNEGLDESTROYIMAGEKHRPROC)eglGetProcAddress("eglDestroyImageKHR");
    auto getClient = (PFNEGLGETNATIVECLIENTBUFFERANDROIDPROC)eglGetProcAddress("eglGetNativeClientBufferANDROID");
    auto imageTarget = (PFNGLEGLIMAGETARGETTEXTURE2DOESPROC)eglGetProcAddress("glEGLImageTargetTexture2DOES");
    if (!createImage || !destroyImage || !getClient || !imageTarget) { o.bad(tag + ": EGLImage entry points missing"); return; }

    const int W = 32, H = 8;
    AHardwareBuffer_Desc d = {};
    d.width = W; d.height = H; d.layers = 1; d.format = ahbFormat;
    d.usage = AHARDWAREBUFFER_USAGE_GPU_FRAMEBUFFER | AHARDWAREBUFFER_USAGE_GPU_SAMPLED_IMAGE | AHARDWAREBUFFER_USAGE_CPU_READ_OFTEN;
    AHardwareBuffer* buf = nullptr;
    if (AHardwareBuffer_allocate(&d, &buf) != 0 || !buf) { o.bad(tag + ": AHardwareBuffer_allocate failed (format unsupported for GPU render + CPU read)"); return; }
    AHardwareBuffer_describe(buf, &d);

    EGLClientBuffer cb = getClient(buf);
    const EGLint attrs[] = {EGL_IMAGE_PRESERVED_KHR, EGL_TRUE, EGL_NONE};
    EGLImageKHR img = cb ? createImage(dpy, EGL_NO_CONTEXT, EGL_NATIVE_BUFFER_ANDROID, cb, attrs) : EGL_NO_IMAGE_KHR;
    if (img == EGL_NO_IMAGE_KHR) { o.bad(tag + ": eglCreateImageKHR failed, egl error " + std::to_string(eglGetError())); AHardwareBuffer_release(buf); return; }

    GLuint tex = 0, fbo = 0;
    glGenTextures(1, &tex);
    glBindTexture(GL_TEXTURE_2D, tex);
    imageTarget(GL_TEXTURE_2D, (GLeglImageOES)img);
    glGenFramebuffers(1, &fbo);
    glBindFramebuffer(GL_FRAMEBUFFER, fbo);
    glFramebufferTexture2D(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0, GL_TEXTURE_2D, tex, 0);
    const GLenum status = glCheckFramebufferStatus(GL_FRAMEBUFFER);
    bool good = status == GL_FRAMEBUFFER_COMPLETE;
    if (!good) o.bad(tag + ": framebuffer not complete (0x" + std::to_string(status) + ")");
    else {
        glViewport(0, 0, W, H);
        glClearColor(r, g, b, 1.0f);
        glClear(GL_COLOR_BUFFER_BIT);
        glFinish();   // simple, always-correct hand-off; native fences are a later optimisation
        void* p = nullptr;
        if (AHardwareBuffer_lock(buf, AHARDWAREBUFFER_USAGE_CPU_READ_OFTEN, -1, nullptr, &p) != 0 || !p) o.bad(tag + ": could not lock the buffer for CPU read");
        else {
            double worst = 0;
            const bool half = ahbFormat == AHARDWAREBUFFER_FORMAT_R16G16B16A16_FLOAT;
            for (int y = 0; y < H; y++) for (int x = 0; x < W; x++) {
                float c[3];
                if (half) { const uint16_t* q = (const uint16_t*)p + ((size_t)y * d.stride + x) * 4; for (int i = 0; i < 3; i++) c[i] = HalfToFloat(q[i]); }
                else { const uint8_t* q = (const uint8_t*)p + ((size_t)y * d.stride + x) * 4; for (int i = 0; i < 3; i++) c[i] = q[i] / 255.0f; }
                worst = std::fmax(worst, std::fabs(c[0] - r)); worst = std::fmax(worst, std::fabs(c[1] - g)); worst = std::fmax(worst, std::fabs(c[2] - b));
            }
            AHardwareBuffer_unlock(buf, nullptr);
            char msg[160]; std::snprintf(msg, sizeof msg, ": GL wrote the shared buffer, CPU read it back, max error %.5g (limit %.5g)", worst, tol);
            if (worst <= tol) o.ok(tag + msg); else o.bad(tag + msg);
        }
    }
    glBindFramebuffer(GL_FRAMEBUFFER, 0);
    glDeleteFramebuffers(1, &fbo);
    glDeleteTextures(1, &tex);
    destroyImage(dpy, img);
    AHardwareBuffer_release(buf);
}
}  // namespace

std::string RunAhbInteropProbe(int* passed, int* failed) {
    Out o;
    EGLDisplay dpy = eglGetCurrentDisplay();
    if (dpy == EGL_NO_DISPLAY) { o.bad("no current EGL display"); *passed = o.pass; *failed = o.fail; return o.t; }
    const char* ee = eglQueryString(dpy, EGL_EXTENSIONS);
    const struct { const char* n; } need[] = {{"EGL_ANDROID_get_native_client_buffer"}, {"EGL_KHR_image_base"}, {"EGL_ANDROID_image_native_buffer"}};
    for (auto& e : need) { if (HasExt(ee, e.n)) o.ok(std::string(e.n) + " present"); else o.bad(std::string(e.n) + " missing"); }
    o.info(std::string("EGL_ANDROID_native_fence_sync: ") + (HasExt(ee, "EGL_ANDROID_native_fence_sync") ? "present (GL work can be fenced for Vulkan)" : "absent (glFinish hand-off only)"));
    OneFormat(o, dpy, AHARDWAREBUFFER_FORMAT_R8G8B8A8_UNORM, "RGBA8", 0.25f, 0.5f, 0.75f, 2.0f / 255);
    OneFormat(o, dpy, AHARDWAREBUFFER_FORMAT_R16G16B16A16_FLOAT, "RGBA16F", 2.5f, -1.0f, 0.1f, 2e-3f);
    o.info("RGBA32F has no AHardwareBuffer format: 32-bit float buffers cannot be shared with Skia this way.");
    *passed = o.pass; *failed = o.fail;
    return o.t;
}
}  // namespace am
#endif

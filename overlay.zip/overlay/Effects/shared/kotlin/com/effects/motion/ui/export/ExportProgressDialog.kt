package com.effects.motion.ui.export

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.effects.motion.R
import com.effects.motion.export.Codec
import com.effects.motion.export.ExportLive
import com.effects.motion.export.ExportSettings
import com.effects.motion.export.exportHeatText
import com.effects.motion.export.ThermalLevel
import com.effects.motion.export.audioRate
import com.effects.motion.i18n.UiText
import com.effects.motion.i18n.text
import com.effects.motion.platform.asImageBitmap
import com.effects.motion.platform.makeBitmap
import kotlinx.coroutines.delay
import java.util.Locale

private val PCardBg = Color(0xFF262626)
private val PTileBg = Color(0xFF2E2E2E)
private val PMint = Color(0xFF00FFA8)
private val PMintDark = Color(0xFF1E5043)
private val PDim = Color(0xFF9A9A9A)
private val PTrackBg = Color(0xFF3A3A3A)

/** One snapshot of the real export numbers, read from [ExportLive] and the clock. */
private class Stats(val frame: Int, val frames: Int, val elapsedS: Double, val fps: Double)

/**
 * The export progress dialog for video exports. Every number is measured:
 * frame and total come from the encoder loop, speed is frames done / seconds elapsed,
 * remaining is the same rate applied to the frames left, and resolution / bitrate / codec
 * are the values the encoder was actually opened with.
 */
@Composable
internal fun VideoExportDialog(
    fileName: String, startNs: Long, s: ExportSettings, sceneFps: Int, hasAudio: Boolean,
    progress: Float, heat: ThermalLevel, note: UiText?, onCancel: () -> Unit,
) {
    val stats by produceState(Stats(0, ExportLive.frames, 0.0, 0.0), startNs) {
        while (true) {
            val elapsed = (System.nanoTime() - startNs) / 1e9
            val frame = ExportLive.frame
            value = Stats(frame, ExportLive.frames, elapsed, if (elapsed > 0.2 && frame > 0) frame / elapsed else 0.0)
            delay(200)
        }
    }
    val total = stats.frames.coerceAtLeast(1)
    val shownFrame = stats.frame.coerceIn(0, total)
    val percent = (progress * 100).toInt().coerceIn(0, 100)
    val width = ExportLive.width
    val height = ExportLive.height
    val fps = s.fps
    var audioTab by remember { mutableStateOf(false) }

    Column(
        Modifier.widthIn(max = 420.dp).fillMaxWidth().padding(horizontal = 20.dp).clip(RoundedCornerShape(28.dp)).background(PCardBg).padding(22.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text(stringResource(R.string.export_running_video), color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Medium, textAlign = TextAlign.Center)
        Text(fileName, Modifier.padding(top = 4.dp), color = PDim, fontSize = 14.sp, maxLines = 1)
        Spacer(Modifier.height(14.dp))

        val preview = ExportLive.preview
        val bitmap = remember(preview) {
            preview?.let { p -> makeBitmap(p.width, p.height).also { it.copyPixelsFromBuffer(java.nio.ByteBuffer.wrap(p.rgba)) }.asImageBitmap() }
        }
        Box(
            Modifier.fillMaxWidth().aspectRatio(if (width > 0 && height > 0) width.toFloat() / height else 16f / 9f)
                .clip(RoundedCornerShape(16.dp)).background(Color.Black),
            contentAlignment = Alignment.Center,
        ) {
            if (bitmap != null) Image(bitmap, null, Modifier.fillMaxWidth().fillMaxHeight(), contentScale = ContentScale.Fit)
        }
        Spacer(Modifier.height(16.dp))

        Box(Modifier.fillMaxWidth().height(10.dp).clip(RoundedCornerShape(5.dp)).background(PTrackBg)) {
            Box(Modifier.fillMaxWidth(progress.coerceIn(0f, 1f)).fillMaxHeight().clip(RoundedCornerShape(5.dp)).background(PMint))
        }
        Spacer(Modifier.height(12.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
            Text(stringResource(R.string.export_live_frame, shownFrame, stats.frames), color = Color.White, fontSize = 15.sp)
            Text("$percent%", color = PMint, fontSize = 30.sp, fontWeight = FontWeight.Bold)
            Text(timecode(shownFrame, fps), color = Color.White.copy(alpha = 0.85f), fontSize = 15.sp)
        }
        Spacer(Modifier.height(14.dp))

        val left = if (stats.fps > 0) ((stats.frames - stats.frame) / stats.fps).coerceAtLeast(0.0) else null
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            ProgressTile(stringResource(R.string.export_live_elapsed), clock(stats.elapsedS), false, Modifier.weight(1f))
            ProgressTile(stringResource(R.string.export_live_speed), if (stats.fps > 0) "%.1f fps".format(Locale.ROOT, stats.fps) else "\u2014", true, Modifier.weight(1f))
            ProgressTile(stringResource(R.string.export_live_remaining), left?.let { "~" + clock(it) } ?: "\u2014", false, Modifier.weight(1f))
        }
        Spacer(Modifier.height(14.dp))

        Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(30.dp)).background(PTileBg).padding(4.dp)) {
            ProgressTab(stringResource(R.string.export_live_video), !audioTab, Modifier.weight(1f)) { audioTab = false }
            ProgressTab(stringResource(R.string.export_live_audio), audioTab, Modifier.weight(1f)) { audioTab = true }
        }
        Spacer(Modifier.height(12.dp))
        Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(PTileBg).padding(horizontal = 16.dp, vertical = 6.dp)) {
            if (!audioTab) {
                DetailRow(stringResource(R.string.export_live_resolution), "$width \u00D7 $height  \u00B7  ${minOf(width, height)}p")
                DetailRow(stringResource(R.string.export_live_frame_rate), "$fps fps")
                DetailRow(stringResource(R.string.export_live_bitrate), "%.1f Mbps".format(Locale.ROOT, ExportLive.bitrate / 1_000_000.0))
                DetailRow(stringResource(R.string.export_live_codec), codecName(s.codec))
                DetailRow(stringResource(R.string.export_live_duration), duration(stats.frames, fps))
            } else if (hasAudio) {
                DetailRow(stringResource(R.string.export_live_codec), s.audio.codec.label)
                DetailRow(stringResource(R.string.export_live_bitrate), "${s.audio.bitrateKbps} kbps")
                DetailRow(stringResource(R.string.export_live_sample_rate), "%.1f kHz".format(Locale.ROOT, s.audio.effectiveRate / 1000.0))
                DetailRow(stringResource(R.string.export_live_channels), if (s.audio.channels == 1) stringResource(R.string.export_live_mono) else stringResource(R.string.export_live_stereo))
            } else {
                Text(stringResource(R.string.export_live_no_audio), Modifier.fillMaxWidth().padding(vertical = 18.dp), color = PDim, fontSize = 15.sp, textAlign = TextAlign.Center)
            }
        }

        Box(Modifier.fillMaxWidth().height(52.dp).padding(top = 12.dp), Alignment.Center) {
            val warn = exportHeatText(heat) ?: note
            if (warn != null) Text(warn.text(), color = if (exportHeatText(heat) != null) PMint else PDim, fontSize = 13.sp, lineHeight = 17.sp, textAlign = TextAlign.Center, maxLines = 3)
            else Text("\u26A0  " + stringResource(R.string.keep_effects_open_and_your_screen), color = PDim, fontSize = 13.sp, lineHeight = 17.sp, textAlign = TextAlign.Center, maxLines = 3)
        }
        Spacer(Modifier.height(8.dp))
        Box(
            Modifier.fillMaxWidth().height(56.dp).clip(RoundedCornerShape(28.dp)).background(PTileBg).clickable(onClick = onCancel),
            contentAlignment = Alignment.Center,
        ) { Text(stringResource(R.string.cancel), color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Medium) }
    }
}

@Composable
private fun ProgressTile(label: String, value: String, highlight: Boolean, modifier: Modifier) {
    Column(
        modifier.clip(RoundedCornerShape(16.dp)).background(if (highlight) PMintDark else PTileBg)
            .then(if (highlight) Modifier.border(2.dp, PMint, RoundedCornerShape(16.dp)) else Modifier).padding(vertical = 14.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text(label, color = if (highlight) Color.White.copy(alpha = 0.7f) else PDim, fontSize = 13.sp)
        Text(value, Modifier.padding(top = 4.dp), color = if (highlight) PMint else Color.White, fontSize = 20.sp, fontWeight = FontWeight.Medium, maxLines = 1)
    }
}

@Composable
private fun ProgressTab(label: String, on: Boolean, modifier: Modifier, onClick: () -> Unit) {
    Box(
        modifier.height(46.dp).clip(RoundedCornerShape(26.dp)).background(if (on) PMint else Color.Transparent).clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) { Text(label, color = if (on) Color.Black else PDim, fontSize = 17.sp, fontWeight = FontWeight.Medium) }
}

@Composable
private fun DetailRow(label: String, value: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 13.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.weight(1f), color = PDim, fontSize = 16.sp)
        Text(value, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Medium)
    }
}

private fun clock(seconds: Double): String {
    val t = seconds.toLong().coerceAtLeast(0)
    return "%02d:%02d".format(Locale.ROOT, t / 60, t % 60)
}

/** Project position as MM : SS : FF (frames), like a video timecode. */
private fun timecode(frame: Int, fps: Int): String {
    val f = frame.coerceAtLeast(0)
    val rate = fps.coerceAtLeast(1)
    val seconds = f / rate
    return "%02d : %02d : %02d".format(Locale.ROOT, seconds / 60, seconds % 60, f % rate)
}

private fun duration(frames: Int, fps: Int): String {
    val cs = (frames * 100.0 / fps.coerceAtLeast(1)).toLong()
    return "%02d:%02d.%02d".format(Locale.ROOT, cs / 6000, cs / 100 % 60, cs % 100)
}

private fun codecName(c: Codec): String = when (c) {
    Codec.H264 -> "H.264 (AVC)"
    Codec.Hevc -> "H.265 (HEVC)"
    else -> c.label
}

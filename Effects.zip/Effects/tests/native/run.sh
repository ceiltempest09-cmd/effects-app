#!/bin/bash
# Builds and runs the host tests (no Android SDK/NDK, Skia, GPU or shader compiler needed). Run from anywhere.
set -e
cd "$(dirname "$0")/../.."
CXX=${CXX:-g++}
FLAGS="-std=c++20 -fno-exceptions -fno-rtti -Wall -Wextra -I shared/cpp"
OUT=${OUT:-/tmp/em-native-tests}; mkdir -p "$OUT"
$CXX $FLAGS tests/native/render_graph_test.cpp shared/cpp/render_graph.cpp shared/cpp/render_graph_xml.cpp shared/cpp/xml.cpp -lexpat -o "$OUT/render_graph_test"
$CXX $FLAGS tests/native/native_shader_test.cpp shared/cpp/render_graph.cpp shared/cpp/shader_info.cpp shared/cpp/shader_diag.cpp shared/cpp/shader_cache.cpp shared/cpp/spirv_util.cpp -o "$OUT/native_shader_test"
"$OUT/render_graph_test"
"$OUT/native_shader_test"
# Real-GPU tests (GL backend + executor on the machine's EGL driver). Skipped with a message when there is no libEGL / GL driver.
if ldconfig -p 2>/dev/null | grep -q libEGL; then bash tests/native/build_gl.sh; else echo "SKIP gl_backend_test: no libEGL on this machine"; fi

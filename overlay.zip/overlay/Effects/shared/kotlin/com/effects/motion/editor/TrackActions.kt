package com.effects.motion.editor

import com.effects.motion.R
import com.effects.motion.i18n.AppText
import android.content.Context
import com.effects.motion.media.FrameReader
import com.effects.motion.media.MotionTracker
import com.effects.motion.media.luma
import com.effects.motion.media.trackFactor
import com.effects.motion.model.Layer
import com.effects.motion.model.Pt
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.hypot

internal fun trackStartPoints(width: Int, height: Int, count: Int): List<Pt> = when {
    count < 2 -> listOf(Pt(width / 2f, height / 2f))
    count < 4 -> listOf(Pt(width * 0.35f, height / 2f), Pt(width * 0.65f, height / 2f))
    else -> listOf(Pt(width * 0.35f, height * 0.35f), Pt(width * 0.65f, height * 0.35f), Pt(width * 0.65f, height * 0.65f), Pt(width * 0.35f, height * 0.65f))
}

/** Any layer can be tracked; audio, cameras and lights have nothing to move. */
val Layer.canTrack: Boolean get() = kind != "audio" && kind != "camera" && kind != "light"

private fun EditorState.trackSource(target: Layer): Layer? {
    if (target.mediaFill?.video == true) return target
    val order = scene.layers.indexOfFirst { it.id == target.id }
    val videos = scene.layers.filter { l ->
        l.id != target.id && !l.hidden && l.mediaFill?.video == true && scene.media(l.mediaFill!!.uri)?.let { it.width > 0 && it.height > 0 } == true
    }
    val shown = videos.filter { it.activeAt(timeMs) }.ifEmpty { videos }
    return shown.minByOrNull { kotlin.math.abs(scene.layers.indexOfFirst { l -> l.id == it.id } - order) }
}

/** Starts Track Motion on the selected layer. Returns null when it started, else the string id of why it could not. */
fun EditorState.startTracking(): Int? {
    val layer = selected?.takeIf { it.canTrack } ?: return null
    val video = trackSource(layer) ?: return R.string.track_motion_needs_video
    val fromVideo = video.id == layer.id
    if (!fromVideo && scene.chain(video).any { it.id == layer.id }) return R.string.track_motion_is_parent
    val media = scene.media(video.mediaFill!!.uri)?.takeIf { it.width > 0 && it.height > 0 } ?: return R.string.track_motion_needs_video
    if (!video.activeAt(timeMs)) frame = scene.firstShownFrame(video.startTime)
    selectedId = video.id
    playing = false
    panel = EditorPanel.Tools
    // From a video the result lands on a new null; from anything else it lands on that layer and no null is made.
    drawing = TrackMode(video.id).apply {
        points += trackStartPoints(media.width, media.height, 1)
        if (!fromVideo) { target = layer.id; returnTo = layer.id }
    }
    return null
}

fun EditorState.setTrackPointCount(mode: TrackMode, count: Int) {
    if (mode.running || mode.points.size == count) return
    val media = scene.layer(mode.layerId)?.mediaFill?.uri?.let(scene::media) ?: return
    mode.points.clear()
    mode.points += trackStartPoints(media.width, media.height, count)
    mode.pending = emptyList()
    mode.lostFrame = null
}

fun EditorState.runTracking(context: Context, mode: TrackMode, scope: CoroutineScope, resume: Boolean) {
    if (mode.running) return
    val document = scene
    val video = document.layer(mode.layerId) ?: return
    val uri = video.mediaFill?.uri ?: return
    val media = document.media(uri) ?: return
    val width = media.width
    val height = media.height
    val continuing = resume && mode.pending.isNotEmpty() && mode.apply != null && mode.motion.size > 1
    val runs = if (continuing) {
        listOf(TrackRun(mode.pending.first().frames, mode.points.toList(), mode.pending.first().base, mode.pending.first().baseH)) + mode.pending.drop(1)
    } else {
        document.trackRuns(video, frame, mode.range).map { TrackRun(it, mode.points.toList(), Sim()) }
    }
    val perspective = mode.points.size == 4
    if (mode.points.size == 2 && !continuing && mode.points.let { hypot((it[0].x - it[1].x).toDouble(), (it[0].y - it[1].y).toDouble()) } < 0.06 * hypot(width.toDouble(), height.toDouble())) {
        mode.message = AppText.get(R.string.track_motion_points_close)
        return
    }
    if (runs.isEmpty() || width <= 0 || height <= 0) {
        mode.message = AppText.get(R.string.track_motion_playhead_outside)
        return
    }
    if (!continuing) {
        val f0 = runs.first().frames.first()
        val toScene0 = document.videoToScene(video, f0, width, height)
        val corners = if (perspective) mode.points.mapNotNull { toScene0?.map(it) } else emptyList()
        val anchor = if (perspective && corners.size == 4) Pt(corners.sumOf { it.x.toDouble() }.toFloat() / 4, corners.sumOf { it.y.toDouble() }.toFloat() / 4)
            else toScene0?.map(mode.points.first())
        if (anchor == null) {
            mode.message = AppText.get(R.string.track_motion_no_area)
            return
        }
        val chosen = mode.target?.let(document::layer)
        mode.motion.clear()
        mode.motion[f0] = Sim()
        mode.homs.clear()
        mode.homs[f0] = M3_IDENTITY
        mode.apply = TrackApply(
            chosen?.id ?: Layer.newId(),
            chosen?.let { document.place(it, document.frameStart(f0)) } ?: Place(anchor.x, anchor.y, 0f, 0f, 1f, 1f, 0f),
            mode.points.size > 1,
            perspective, corners,
        )
    }
    val apply = mode.apply ?: return
    mode.pending = emptyList()
    mode.lostFrame = null
    mode.running = true
    mode.progress = 0f
    mode.message = ""
    mode.job = scope.launch {
        var lost = false
        var last: TrackStep? = null
        var partial: (() -> Map<Int, Sim>)? = null
        var partialH: (() -> Map<Int, DoubleArray>)? = null
        try {
            withContext(Dispatchers.IO) {
                FrameReader(context, uri).use { reader ->
                    for ((index, run) in runs.withIndex()) {
                        var shown = 0L
                        val pts = document.framePts(video, run.frames, reader.timestamps)
                        val found = HashMap<Long, List<Pt>>()
                        partial = { document.motionOf(video, trackedSteps(run.frames, pts, found).steps, width, height, run.base) }
                        partialH = { if (perspective) document.perspectiveOf(video, trackedSteps(run.frames, pts, found).steps, width, height, run.baseH)?.second.orEmpty() else emptyMap() }
                        val outcome = trackFrames(
                            run.frames, pts, reader.timestamps, run.points, width, height,
                            read = { batch, deliver -> reader.read(batch) { p, yuv -> deliver(p, yuv.luma(trackFactor(yuv.width, yuv.height))) } },
                            tracker = { MotionTracker(it) }, found = found,
                        ) { step, fraction ->
                            val now = System.nanoTime()
                            if (now - shown > LIVE_NS) {
                                shown = now
                                withContext(Dispatchers.Main) {
                                    mode.live = step.points
                                    frame = step.frame
                                    mode.progress = (index + fraction) / runs.size
                                }
                            }
                        }
                        val motion = document.motionOf(video, outcome.steps, width, height, run.base)
                        val perspectives = if (perspective) document.perspectiveOf(video, outcome.steps, width, height, run.baseH)?.second.orEmpty() else emptyMap()
                        last = outcome.steps.lastOrNull() ?: last
                        withContext(Dispatchers.Main) {
                            mode.motion.putAll(motion)
                            mode.homs.putAll(perspectives)
                            if (motion.size > 1) writeTrack(mode, video, apply)
                        }
                        partial = null
                        partialH = null
                        val at = outcome.lostAt ?: continue
                        val base = outcome.steps.lastOrNull()?.let { mode.motion[it.frame] } ?: run.base
                        val baseH = outcome.steps.lastOrNull()?.let { mode.homs[it.frame] } ?: run.baseH
                        mode.pending = listOf(TrackRun(run.frames.dropWhile { it != at }, emptyList(), base, baseH)) + runs.drop(index + 1)
                        withContext(Dispatchers.Main) {
                            mode.points.clear()
                            mode.points += outcome.lostPoints
                            frame = at
                            mode.lostFrame = at
                            mode.message = if (outcome.steps.isEmpty()) AppText.get(R.string.track_motion_too_little_detail)
                                else AppText.get(R.string.track_motion_lost_at_frame, (at + 1).toString())
                        }
                        lost = true
                        break
                    }
                }
            }
            if (!lost) {
                last?.let { step ->
                    mode.points.clear()
                    mode.points += step.points
                    frame = step.frame
                }
                mode.message = AppText.get(R.string.track_motion_done, mode.motion.size.toString(), scene.layer(apply.targetId)?.label?.ifEmpty { null } ?: AppText.get(R.string.track_motion_target_layer))
            }
        } catch (_: CancellationException) {
            partial?.takeIf { scope.isActive }?.invoke()?.takeIf { it.size > 1 }?.let {
                mode.motion.putAll(it)
                partialH?.invoke()?.let { h -> mode.homs.putAll(h) }
                writeTrack(mode, video, apply)
            }
            mode.message = AppText.get(R.string.track_motion_cancelled)
        } catch (_: LinkageError) {
            mode.message = AppText.get(R.string.track_motion_unavailable)
        } catch (e: Exception) {
            mode.message = com.effects.motion.i18n.failureText(AppText.get(R.string.track_motion_failed), e)
        } finally {
            mode.running = false
            mode.live = null
        }
    }
}

private fun EditorState.writeTrack(mode: TrackMode, video: Layer, apply: TrackApply) {
    edit { s ->
        if (s.layer(video.id) == null) return@edit s
        var next = s
        if (next.layer(apply.targetId) == null) {
            if (mode.target != null) return@edit s
            val name = AppText.get(R.string.model_layer_track)
            val count = next.layers.count { it.kind == "nullobj" && it.label.startsWith("$name ") } + 1
            next = next.add(trackNull(apply.targetId, video, Pt(apply.origin.x, apply.origin.y), "$name $count"))
        }
        if (apply.perspective) next.withTrack3d(apply, mode.homs) else next.withTrack(apply, mode.motion)
    }
}

private const val LIVE_NS = 80_000_000L

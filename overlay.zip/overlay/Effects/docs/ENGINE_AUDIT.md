# Modular effect engines: audit and stage 1

## Already in the project (reused, not duplicated)
- Multi-pass effect graph (schema 2): passes, buffers with up to 8 frames of history, textures, validation, JSON/XML import (`effects/graph`).
- Native backends: Skia SkSL, OpenGL ES, Vulkan (`shared/cpp`), render graph, GPU fences, history signatures.
- Imported-effect storage and UI (`ImportedEffects`, `EffectImporter`, `ImportUi`), sample multi-pass effects (deepglow, feedbacktrails, multidisplace, ...).
- Source-time mapping for video speed/ramps/freeze (`model/VideoTiming.kt`), frame decoding (`media/FrameReader`, `VideoDecoder`), export (`export/Exporter`).

## Gaps against the master prompt
1. Capabilities: the graph only declares `float16`, `float32`, `history`. History holds an effect's own past buffers, not source frames at other timestamps. No declaration for next frame, frame window, time access, mask, depth, motion, geometry or audio.
2. No effect-facing frame provider (frames by clip + timestamp, bounded, cancellable, refcounted).
3. No unified Glow/Warp/Shake/Color engines or Engine Reactor routing layer. Glow exists only as separate sample effects.
4. No LUT (.cube) import.
5. No physics/text-animation engines.

## Added in this stage (`effects/engine`, pure Kotlin, no Android dependencies)
- `Capabilities.kt`: capability vocabulary and `CapabilityCheck` (unknown or unavailable capabilities become explicit errors).
- `TimeMap.kt`: deterministic output-time to source-time map (speed, reverse, freeze, keyframed ramps, Hold/Loop/Mirror/Blank boundaries), `FrameLookup` (variable-frame-rate lookup, clamped, bounded frame windows, max 16).
- `CubeLut.kt`: real .cube parser (1D/3D, domain, line-numbered errors, size limits) with trilinear/linear sampling.
- `tests/hostkt/EngineTests.kt`, wired into `tests/hostkt/run.sh`.

## Status: NOT yet verified
Written without a Kotlin compiler or Android SDK available. Run `tests/hostkt/run.sh` (needs the Gradle lib dir) before relying on it. Nothing here is wired into the renderer, validator, UI or export yet, so no existing behaviour changed.

## Next stages (in order)
1. Wire `CapabilityCheck` into `GraphValidator` once a backend can serve a capability (never accept a capability that is then ignored).
2. Frame provider over `FrameReader`/`VideoDecoder` with a byte budget, cancellation and refcounts; expose `time_access` to native passes.
3. Timewarp/Echo effect on top of `TimeMap`; test scrub/reverse/freeze/export parity on device.
4. Unified Glow engine (pyramid blur + modes) as one schema-2 effect.
5. RGB split, LUT effect (upload `CubeLut` as 3D texture), then Warp, Shake, Physics, Text, Material engines.

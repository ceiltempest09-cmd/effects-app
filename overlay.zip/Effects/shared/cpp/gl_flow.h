// gl_flow.h - optical flow, frame synthesis, motion blur and datamosh on GL targets (the former SkSL pipeline of interpolation.cpp).
// Every pass is a GLSL ES shader from glsl_library.h run by the native GL backend. No Skia types here: the engine adapter
// (interpolation.cpp) moves images in and out. Host-tested against Mesa in tests/native/gl_flow_test.cpp.
// All calls must be made on the thread the GlBackend's context is current on. Returned targets belong to the caller (Flow::release).
#pragma once

#include "gl_backend.h"

#include <vector>

namespace am::flow {

struct Params {
    int divisor = 4, levels = 5, iterations = 6, warps = 1;
    float alpha = 0.15f;
    int fuse = 4;
};
struct MoshParams {
    float intensity = 1, block = 16, decay = 0.05f, glitch = 0.1f, bloom = 0.3f;
    Params flow;
};
struct Stats { int passes = 0; int levels = 0; double ms = 0; };

class Flow {
public:
    explicit Flow(rg::GlBackend& gl) : fGl(gl) {}
    ~Flow() { for (rg::Target* t : fLive) fGl.destroy(t); }
    Flow(const Flow&) = delete;
    Flow& operator=(const Flow&) = delete;

    // Forward / backward flow field at 1/divisor resolution (rgba = fwd.xy, bwd.xy in field pixels). nullptr + error() on failure.
    rg::Target* estimate(rg::Target* a, rg::Target* b, const Params& p, Stats* stats);
    // The frame at time t between a and b: flow warp when `flow`, four-frame cubic blend when before/after, else a cross-fade.
    rg::Target* synthesize(rg::Target* a, rg::Target* b, rg::Target* flow, float t, int divisor, rg::Target* before = nullptr, rg::Target* after = nullptr);
    rg::Target* motionBlur(rg::Target* image, rg::Target* flow, float t, float length, int divisor);
    // One datamosh step. `motion` receives the motion field (caller releases it too).
    rg::Target* moshStep(rg::Target* state, rg::Target* prior, rg::Target* frame, rg::Target* flow, const MoshParams& p, float salt, rg::Target** motion);

    void release(rg::Target* t);
    const std::string& error() const { return fError; }
    // A picture target (RGBA8) and a field target (RGBA16F when the device renders it, else RGBA32F).
    rg::Target* picture(int w, int h) { return make(w, h, rg::Format::RGBA8); }
    rg::Target* field(int w, int h) { return make(w, h, fieldFormat()); }
    rg::Format fieldFormat() const;

private:
    struct In { const char* name; rg::Target* target; rg::Filter filter; };
    rg::Target* make(int w, int h, rg::Format f);
    bool draw(const std::string& id, const std::string& source, rg::Target* out, int areaW, int areaH, const std::vector<In>& inputs,
              const std::vector<rg::Constant>& constants);
    rg::Target* flowLevel(rg::Target* grey, rg::Target* previous, const Params& p, int level);

    rg::GlBackend& fGl;
    std::string fError;
    int fPasses = 0;
    std::vector<rg::Target*> fLive;
    std::vector<rg::PassDesc> fPassCache;   // keeps PassDesc storage alive per draw (sources are re-hashed by the backend's program cache)
};

}  // namespace am::flow

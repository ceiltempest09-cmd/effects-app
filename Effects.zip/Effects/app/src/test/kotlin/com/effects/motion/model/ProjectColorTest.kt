package com.effects.motion.model

import com.effects.motion.engine.bitdepth.BitDepth
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ProjectColorTest {
    private fun scene() = Scene.create("p", 1080, 1920, 60, 0)

    @Test fun aProjectSavedBeforeTheSettingsExistedKeepsItsOldBehaviour() {
        val old = scene()
        assertFalse(old.hasColorSettings)
        assertEquals(ProjectColor.Legacy, old.color)
        assertEquals(BitDepth.BIT8, old.color.bitDepth)
    }

    @Test fun newProjectsGetTheRecommendedDefaults() {
        val fresh = Scene.create("p", 1080, 1920, 60, 0, ProjectColor.Default)
        assertTrue(fresh.hasColorSettings)
        assertEquals(BitDepth.BIT16, fresh.color.bitDepth)
        assertEquals(PreviewQualityMode.High, fresh.color.previewQuality)
        assertEquals(WorkingSpace.LinearSrgb, fresh.color.workingSpace)
        assertEquals(DynamicRange.Hdr, fresh.color.dynamicRange)
    }

    @Test fun everySettingSurvivesSavingAndReopening() {
        for (depth in BitDepth.entries) for (quality in PreviewQualityMode.entries) for (space in WorkingSpace.entries) for (range in DynamicRange.entries) {
            val chosen = ProjectColor(depth, quality, space, range)
            val reopened = Scene.parse(scene().withColor(chosen).toXml())
            assertEquals(chosen, reopened.color)
        }
    }

    @Test fun changingTheColourSettingsLeavesTheRestOfTheProjectAlone() {
        val before = scene()
        val after = before.withColor(ProjectColor.Default)
        assertEquals(before.width, after.width)
        assertEquals(before.height, after.height)
        assertEquals(before.fps, after.fps)
        assertEquals(before.bgColor, after.bgColor)
        assertEquals(before.layers, after.layers)
    }

    @Test fun aDamagedAttributeFallsBackOnItsOwnWithoutBreakingTheOthers() {
        val damaged = Scene(scene().node.with("bitDepth", "64").with("previewQuality", "hdr").with("colorSpace", "lab").with("dynamicRange", "hdr"))
        val color = damaged.color
        assertEquals(BitDepth.BIT8, color.bitDepth)                       // 64 is not a depth
        assertEquals(PreviewQualityMode.Hdr, color.previewQuality)        // the valid ones are kept
        assertEquals(WorkingSpace.Srgb, color.workingSpace)               // lab is not a space
        assertEquals(DynamicRange.Hdr, color.dynamicRange)
    }

    @Test fun idsAreStableBecauseTheyAreWrittenIntoProjectFiles() {
        assertEquals(listOf("standard", "high", "hdr"), PreviewQualityMode.entries.map { it.id })
        assertEquals(listOf("linear", "srgb", "rec2020"), WorkingSpace.entries.map { it.id })
        assertEquals(listOf("sdr", "hdr"), DynamicRange.entries.map { it.id })
        assertEquals(listOf("8", "16", "32"), BitDepth.entries.map { ProjectColor.idOf(it) })
        assertNull(ProjectColor.depthOf("12"))
        assertNull(ProjectColor.depthOf(null))
    }

    @Test fun onlyHighAndHdrPreviewsForceTheFullShutterBlur() {
        assertFalse(PreviewQualityMode.Standard.forcesAccurateBlur)
        assertTrue(PreviewQualityMode.High.forcesAccurateBlur)
        assertTrue(PreviewQualityMode.Hdr.forcesAccurateBlur)
    }

    @Test fun supportReportsWhichDepthsTheGpuCanRender() {
        val noFloat32 = ColorSupport(BitDepth.BIT16, hdrPreserved = true, hdrOutput = false, float16 = true, float32 = false)
        assertTrue(noFloat32.supports(BitDepth.BIT8))
        assertTrue(noFloat32.supports(BitDepth.BIT16))
        assertFalse(noFloat32.supports(BitDepth.BIT32))
    }
}

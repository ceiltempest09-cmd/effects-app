# Skia removal status — in-progress migration

## Current status: NOT Skia-free; phase 1 has a narrow validation fix

This source tree is not a completed Skia-free rewrite. The primary scene renderer, graph source/target adapter, shapes, styles, text, video-frame pipeline, and engine still depend on Skia. Removing the Skia CMake libraries or workflow step at this point would break the app and remove rendering functionality.

## Completed in this patch

- `shared/cpp/effects_graph.cpp`: graph validation now declares the complete set of graph execution languages (SkSL, GLSL ES, desktop GLSL, Vulkan GLSL, and SPIR-V) independently of the legacy native-shader preference. This prevents a valid GLSL-ES pass from being rejected during `BuildPlan` with the misleading `backend skia cannot run it` capability message. Actual per-device/per-context capability remains checked when `GraphRunner` prepares the GL/Vulkan backend.
- The graph's diagnostic backend label is now `skia+gles+vulkan`, reflecting the mixed execution path that still exists. This is diagnostic accuracy, not a claim that Skia has been removed.

## Verification performed

- Compiled `shared/cpp/render_graph.cpp` with host Clang C++17 using `-Wall -Wextra -Werror`.
- Ran a small host test that constructs a GLSL-ES graph and calls `BuildPlan`; it was accepted with one execution step.
- Android APK build and on-device rendering were not run in this environment.

## Remaining migration

1. Finish the standalone GLES renderer and make it own the full scene/render lifecycle.
2. Replace the Skia scene, drawing, preview, engine, and video-frame paths with GLES textures/FBOs and Android buffer interop.
3. Replace Skia point/rect/matrix/path types with project-owned value types, then port shapes, gradients, blur, and text.
4. Port all effects and motion paths to native GLSL; remove SkSL compilation and Skia graph adapters.
5. Remove Skia references from Kotlin, CMake, tools, workflow/cache, tests, and notices only after all source dependencies have been replaced.

## Explicitly not removed or stubbed

No existing feature was deleted or stubbed in this patch. Skia remains in the project and build because the core renderer still requires it. The permanent signing configuration and key fingerprint checks are unchanged.

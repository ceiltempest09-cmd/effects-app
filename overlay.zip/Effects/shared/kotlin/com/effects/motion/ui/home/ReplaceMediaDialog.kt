package com.effects.motion.ui.home

import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.effects.motion.R
import com.effects.motion.editor.keepCopy
import com.effects.motion.library.AppSettings
import com.effects.motion.library.ProjectStore
import com.effects.motion.media.mediaDeclaration
import com.effects.motion.model.Scene
import com.effects.motion.model.replaceMedia
import com.effects.motion.ui.theme.Am
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * After a project XML is imported its photos and videos are usually missing (the XML only names them). This lists every media file the
 * project uses and lets the person pick a replacement for each one, the same way Alight Motion asks for them. A pick is copied into the
 * project (when "keep copies" is on), swapped into every layer that used the old file, and saved straight away.
 */
@Composable
internal fun ReplaceMediaDialog(projectId: String, store: ProjectStore, settings: AppSettings, onClose: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var scene by remember { mutableStateOf<Scene?>(null) }
    var target by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    LaunchedEffect(projectId) { scene = withContext(Dispatchers.IO) { store.load(projectId) } }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        val old = target
        val current = scene
        target = null
        if (uri != null && old != null && current != null) {
            runCatching { context.contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            scope.launch {
                busy = true
                try {
                    val picked = mediaDeclaration(context, uri)
                    if (picked == null) {
                        Toast.makeText(context, context.getString(R.string.import_replace_media_failed), Toast.LENGTH_LONG).show()
                    } else {
                        val kept = keepCopy(context, settings, store, projectId, picked, current)
                        val next = current.replaceMedia(old, kept)
                        withContext(Dispatchers.IO) { store.save(projectId, next) }
                        scene = next
                    }
                } catch (e: java.io.IOException) {
                    Toast.makeText(context, context.getString(R.string.import_replace_media_failed), Toast.LENGTH_LONG).show()
                } finally {
                    busy = false
                }
            }
        }
    }
    val media = scene?.media.orEmpty()
    AlertDialog(
        onDismissRequest = { if (!busy) onClose() },
        title = { Text(stringResource(R.string.import_replace_media_title), color = Am.Navy) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                if (scene != null && media.isEmpty()) Text(stringResource(R.string.import_replace_media_none), color = Am.Navy, fontSize = 14.sp)
                for (item in media) {
                    val missing = item.node["missing"] == "true"
                    Column(
                        Modifier.fillMaxWidth().clickable(enabled = !busy) {
                            target = item.uri
                            val request = if (item.type.isBlank()) ActivityResultContracts.PickVisualMedia.ImageAndVideo
                            else ActivityResultContracts.PickVisualMedia.SingleMimeType(item.type.substringBefore('/', "image") + "/*")
                            picker.launch(PickVisualMediaRequest(request))
                        }.padding(vertical = 10.dp),
                    ) {
                        Text(item.title.ifEmpty { item.uri.substringAfterLast('/') }, color = Am.Navy, fontSize = 15.sp, maxLines = 2)
                        Text(
                            stringResource(if (missing) R.string.import_replace_media_missing else R.string.import_replace_media_tap),
                            color = Am.Navy.copy(alpha = 0.6f), fontSize = 13.sp,
                        )
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onClose, enabled = !busy) { Text(stringResource(R.string.ok), color = Am.Navy) } },
        containerColor = Am.Card,
    )
}

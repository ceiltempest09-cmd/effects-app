package com.effects.motion.effects

import org.w3c.dom.Element
import javax.xml.parsers.DocumentBuilderFactory

class AmChoice(val value: Int, val label: String)

class AmParam(
    val tag: String, val id: String, val label: String, val default: String,
    val min: String?, val max: String?, val step: String?, val type: String?,
    val choices: List<AmChoice>, val srcType: String?,
)

class AmEffect(
    val id: String, val name: String, val description: String, val category: String,
    val params: List<AmParam>, val shader: String, val passes: Int, val hasScript: Boolean,
)

class AmFormatError(message: String) : Exception(message)

/** Reads an Alight Motion style effect file: <effect><params/><shader/></effect>. */
object AmXml {
    const val MAX_CHARS = 1_000_000

    fun parse(raw: String): AmEffect {
        val text = raw.trimStart('\uFEFF', ' ', '\n', '\r', '\t')
        if (text.length > MAX_CHARS) throw AmFormatError("The file is too large.")
        if (text.contains("<!DOCTYPE", true) || text.contains("<!ENTITY", true)) throw AmFormatError("DOCTYPE and ENTITY are not allowed.")
        val root = try {
            DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(text.byteInputStream()).documentElement
        } catch (e: Exception) {
            throw AmFormatError("Not valid XML: ${e.message}")
        }
        if (root.tagName != "effect") throw AmFormatError("The first tag is <${root.tagName}>, expected <effect>.")
        val shader = root.kids().firstOrNull { it.tagName == "shader" }?.textContent?.takeIf { it.isNotBlank() }
            ?: throw AmFormatError("There is no <shader> in this file.")
        val params = root.kids().firstOrNull { it.tagName == "params" }?.kids().orEmpty().map { e ->
            val id = e.attr("id").orEmpty()
            AmParam(
                tag = e.tagName, id = id, label = e.attr("label") ?: e.attr("text") ?: id,
                default = e.attr("default").orEmpty(), min = e.attr("min"), max = e.attr("max"),
                step = e.attr("step"), type = e.attr("type"),
                choices = e.kids().filter { it.tagName == "choice" }.mapIndexed { i, c ->
                    AmChoice(c.attr("value")?.toIntOrNull() ?: i, c.attr("label") ?: "${c.attr("value") ?: i}")
                },
                srcType = e.attr("srcType"),
            )
        }
        val passes = root.kids().firstOrNull { it.tagName == "passes" }?.kids()?.size?.coerceAtLeast(1) ?: 1
        return AmEffect(
            id = root.attr("id").orEmpty(), name = root.attr("name") ?: root.attr("id") ?: "Effect",
            description = root.attr("desc").orEmpty(), category = root.attr("category") ?: "other",
            params = params, shader = shader, passes = passes, hasScript = root.kids().any { it.tagName == "script" },
        )
    }

    private fun Element.kids(): List<Element> = buildList {
        val n = childNodes
        for (i in 0 until n.length) (n.item(i) as? Element)?.let(::add)
    }

    private fun Element.attr(name: String): String? = if (hasAttribute(name)) getAttribute(name) else null
}

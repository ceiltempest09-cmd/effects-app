#include "spirv_util.h"

#include <cstring>

namespace am::rg {

bool Base64Decode(const std::string& text, std::vector<uint8_t>* out) {
    out->clear();
    uint32_t acc = 0;
    int bits = 0, pad = 0, chars = 0;
    for (unsigned char c : text) {
        if (c == ' ' || c == '\n' || c == '\r' || c == '\t') continue;
        int v;
        if (c >= 'A' && c <= 'Z') v = c - 'A';
        else if (c >= 'a' && c <= 'z') v = c - 'a' + 26;
        else if (c >= '0' && c <= '9') v = c - '0' + 52;
        else if (c == '+') v = 62;
        else if (c == '/') v = 63;
        else if (c == '=') { pad++; chars++; continue; }
        else return false;
        if (pad) return false;                       // data after padding
        chars++;
        acc = (acc << 6) | (uint32_t)v;
        bits += 6;
        if (bits >= 8) { bits -= 8; out->push_back((uint8_t)((acc >> bits) & 0xFF)); }
    }
    if (chars % 4 != 0 || pad > 2) return false;
    return true;
}

std::string Base64Encode(const uint8_t* d, size_t n) {
    static const char* t = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    std::string s;
    for (size_t i = 0; i < n; i += 3) {
        const uint32_t v = (uint32_t)d[i] << 16 | (i + 1 < n ? (uint32_t)d[i + 1] << 8 : 0) | (i + 2 < n ? d[i + 2] : 0);
        s += t[(v >> 18) & 63];
        s += t[(v >> 12) & 63];
        s += i + 1 < n ? t[(v >> 6) & 63] : '=';
        s += i + 2 < n ? t[v & 63] : '=';
    }
    return s;
}

static uint32_t Swap(uint32_t v) { return (v >> 24) | ((v >> 8) & 0xFF00) | ((v << 8) & 0xFF0000) | (v << 24); }

bool ParseSpirv(const std::vector<uint8_t>& bytes, SpirvInfo* out, std::string* error) {
    *out = SpirvInfo();
    if (bytes.size() < 20 || bytes.size() % 4 != 0) { *error = "SPIR-V size is not a whole number of 32-bit words (or shorter than the 5-word header)"; return false; }
    std::vector<uint32_t> w(bytes.size() / 4);
    std::memcpy(w.data(), bytes.data(), bytes.size());
    if (w[0] == 0x07230203u) {
    } else if (Swap(w[0]) == 0x07230203u) {
        for (uint32_t& x : w) x = Swap(x);
    } else { *error = "not a SPIR-V module (bad magic number)"; return false; }
    out->version = w[1];
    if (w[1] < 0x00010000u || w[1] > 0x00010600u || (w[1] & 0xFF0000FFu) != 0) { *error = "SPIR-V version word is not 1.0 .. 1.6"; return false; }
    out->bound = w[3];
    if (out->bound == 0) { *error = "SPIR-V id bound is 0"; return false; }
    size_t i = 5;
    while (i < w.size()) {
        const uint32_t count = w[i] >> 16, op = w[i] & 0xFFFF;
        if (count == 0 || i + count > w.size()) { *error = "SPIR-V instruction at word " + std::to_string(i) + " has a bad word count"; return false; }
        auto str = [&](size_t from) {
            std::string s;
            for (size_t k = from; k < i + count; k++)
                for (int b = 0; b < 4; b++) {
                    const char c = (char)((w[k] >> (8 * b)) & 0xFF);
                    if (!c) return s;
                    s += c;
                }
            return s;
        };
        if (op == 17 && count >= 2) out->capabilities.push_back(w[i + 1]);                       // OpCapability
        else if (op == 10 && count >= 2) out->extensions.push_back(str(i + 1));                  // OpExtension
        else if (op == 15 && count >= 4) out->entryPoints.push_back({w[i + 1], str(i + 3)});     // OpEntryPoint model id name
        i += count;
    }
    if (out->entryPoints.empty()) { *error = "SPIR-V module has no OpEntryPoint"; return false; }
    out->words = std::move(w);
    return true;
}

const char* SpirvCapabilityName(uint32_t c) {
    switch (c) {
        case 1: return "Shader";
        case 9: return "Float16";
        case 10: return "Float64";
        case 11: return "Int64";
        case 22: return "Int16";
        case 39: return "Int8";
        case 49: return "StorageImageExtendedFormats";
        case 32: return "ImageQuery";
        case 4: return "Sampled1D";
        case 5: return "Image1D";
        case 20: return "DerivativeControl";
        case 61: return "GroupNonUniform";
        default: return nullptr;
    }
}
std::string SpirvCapabilityText(uint32_t c) { const char* n = SpirvCapabilityName(c); return n ? std::string(n) : "capability #" + std::to_string(c); }

}  // namespace am::rg

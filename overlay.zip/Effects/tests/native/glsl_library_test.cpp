// Tests for glsl_library.cpp: every built-in shader that used to be SkSL now compiles as GLSL ES on a real driver, and the ones
// that can be checked against a CPU reference produce the same pixels. No mocks (Mesa llvmpipe on a CPU-only host).
//   g++ -std=c++20 -fno-exceptions -fno-rtti -I shared/cpp tests/native/glsl_library_test.cpp shared/cpp/glsl_library.cpp
//       shared/cpp/gl_backend.cpp shared/cpp/render_graph.cpp shared/cpp/render_graph_xml.cpp shared/cpp/xml.cpp shared/cpp/shader_info.cpp
//       shared/cpp/shader_diag.cpp shared/cpp/shader_cache.cpp shared/cpp/spirv_util.cpp -lexpat -ldl -lpthread
#include "glsl_library.h"
#include "gl_backend.h"

#include <cmath>
#include <cstdio>
#include <cstring>

using namespace am::rg;

static int gFailed = 0, gChecks = 0;
#define CHECK_MSG(cond, msg) do { gChecks++; if (!(cond)) { gFailed++; std::printf("  FAIL %s:%d  %s -- %s\n", __FILE__, __LINE__, #cond, std::string(msg).c_str()); } } while (0)
#define CHECK_NEAR(a, b, eps) do { gChecks++; const double _a = (a), _b = (b); if (!(std::fabs(_a - _b) <= (eps))) { gFailed++; std::printf("  FAIL %s:%d  %s=%g vs %s=%g (eps %g)\n", __FILE__, __LINE__, #a, _a, #b, _b, (double)(eps)); } } while (0)

struct Gpu {
    std::unique_ptr<GlContext> ctx; std::unique_ptr<GlBackend> be;
    Gpu() {
        std::string err; ctx = GlContext::Create(GlContext::Api::ES, &err);
        if (!ctx) { std::printf("no ES context: %s\n", err.c_str()); return; }
        be.reset(new GlBackend(*ctx));
        if (!be->ok()) { std::printf("backend unusable: %s\n", be->error().c_str()); be.reset(); }
    }
    ~Gpu() { be.reset(); ctx.reset(); }
};

static PassDesc Pass(const std::string& id, const std::string& source) {
    PassDesc p; p.id = id; p.name = id; p.lang = Lang::GLSLES; p.file = id; p.source = source; return p;
}

static std::vector<float> Pattern(int w, int h, float seed) {
    std::vector<float> v((size_t)w * h * 4);
    for (int y = 0; y < h; y++) for (int x = 0; x < w; x++) {
        float* p = &v[((size_t)y * w + x) * 4];
        const float a = 0.35f + 0.65f * (((x * 5 + y * 3 + (int)seed) % 7) / 6.0f);
        p[0] = (((x * 7 + y * 13 + (int)seed) % 17) / 17.0f) * a; p[1] = (((x * 3 + y * 5) % 11) / 11.0f) * a; p[2] = (((x * 11 + y * 2) % 13) / 13.0f) * a; p[3] = a;
    }
    return v;
}

struct Run {
    Gpu& g; std::string error;
    std::vector<float> out;
    bool go(const PassDesc& pass, int w, int h, std::vector<std::pair<std::string, Target*>> inputs, const std::vector<Constant>& constants = {}, Filter f = Filter::Nearest) {
        PassDesc p = pass; p.constants = constants;
        Target* t = g.be->create(w, h, Format::RGBA32F);
        std::vector<std::string> names; for (auto& i : inputs) names.push_back(i.first);
        PassRun r; r.pass = &p; r.output = t; r.areaWidth = w; r.areaHeight = h; r.clear = true;
        for (size_t i = 0; i < inputs.size(); i++) { BoundInput b; b.name = &names[i]; b.target = inputs[i].second; b.filter = f; b.wrap = Wrap::Clamp; r.inputs.push_back(b); }
        bool ok = g.be->run(r, &error);
        if (ok) ok = g.be->readback(t, &out);
        g.be->destroy(t);
        return ok;
    }
};

static float Luma(const float* p) { return 0.2126f * p[0] + 0.7152f * p[1] + 0.0722f * p[2]; }

int main() {
    Gpu g;
    if (!g.be) { std::printf("SKIP: no GL available\n"); return 0; }

    // 1. every library shader compiles on a real GLES driver
    std::printf("compile every library shader\n");
    int count = 0;
    for (const std::string& id : am::glsl::Ids()) {
        std::string log; const int prog = g.be->compileProgramForTest(Pass(id, am::glsl::Source(id)), &log); count++;
        CHECK_MSG(prog != 0, id + ": " + log.substr(0, 400));
    }
    for (int steps : {1, 2, 4}) {
        std::string log; const int prog = g.be->compileProgramForTest(Pass("jacobi", am::glsl::JacobiSource(steps)), &log); count++;
        CHECK_MSG(prog != 0, "jacobi " + std::to_string(steps) + ": " + log.substr(0, 400));
    }
    for (const std::string& m : am::glsl::BlendModes()) {
        std::string log; const int prog = g.be->compileProgramForTest(Pass("blend." + m, am::glsl::BlendSource(m)), &log); count++;
        CHECK_MSG(prog != 0, "blend " + m + ": " + log.substr(0, 400));
    }
    std::printf("   %d shaders compiled\n", count);
    CHECK_MSG(am::glsl::BlendSource("normal").empty(), "normal is blended by the engine itself");

    const int W = 16, H = 12;
    const std::vector<float> A = Pattern(W, H, 1), B = Pattern(W, H, 4);
    Target* a = g.be->createFromFloats(W, H, Format::RGBA32F, A.data());
    Target* b = g.be->createFromFloats(W, H, Format::RGBA32F, B.data());
    Run run{g};

    // 2. interp.blend == mix(a, b, t)
    std::printf("interp.blend equals mix(a, b, t)\n");
    {
        const float t = 0.3f;
        CHECK_MSG(run.go(Pass("blend", am::glsl::Source("interp.blend")), W, H, {{"a", a}, {"b", b}}, {{"t", {t}}}), run.error);
        double worst = 0;
        if (run.out.size() == A.size()) for (size_t i = 0; i < A.size(); i++) worst = std::max<double>(worst, std::fabs(run.out[i] - (A[i] + (B[i] - A[i]) * t)));
        CHECK_NEAR(worst, 0.0, 1e-5);
    }

    // 3. interp.soft == weighted sum of four frames
    std::printf("interp.soft equals the weighted sum\n");
    {
        Target* c = g.be->createFromFloats(W, H, Format::RGBA32F, Pattern(W, H, 9).data());
        Target* d = g.be->createFromFloats(W, H, Format::RGBA32F, Pattern(W, H, 11).data());
        const std::vector<float> C = Pattern(W, H, 9), D = Pattern(W, H, 11);
        const float w4[4] = {0.1f, 0.5f, 0.3f, 0.1f};
        CHECK_MSG(run.go(Pass("soft", am::glsl::Source("interp.soft")), W, H, {{"p", a}, {"a", b}, {"b", c}, {"n", d}}, {{"w", {w4[0], w4[1], w4[2], w4[3]}}}), run.error);
        double worst = 0;
        if (run.out.size() == A.size()) for (size_t i = 0; i < A.size(); i++) worst = std::max<double>(worst, std::fabs(run.out[i] - (A[i] * w4[0] + B[i] * w4[1] + C[i] * w4[2] + D[i] * w4[3])));
        CHECK_NEAR(worst, 0.0, 1e-5);
        g.be->destroy(c); g.be->destroy(d);
    }

    // 4. interp.down: src sampled at 2p with linear filtering = mean of the 2x2 block
    std::printf("interp.down averages 2x2 blocks (linear filter, pixel coordinates)\n");
    {
        CHECK_MSG(run.go(Pass("down", am::glsl::Source("interp.down")), W / 2, H / 2, {{"src", a}}, {}, Filter::Linear), run.error);
        double worst = 0;
        if (run.out.size() == (size_t)(W / 2) * (H / 2) * 4) for (int y = 0; y < H / 2; y++) for (int x = 0; x < W / 2; x++) for (int k = 0; k < 4; k++) {
            float m = 0; for (int dy = 0; dy < 2; dy++) for (int dx = 0; dx < 2; dx++) m += A[((size_t)(2 * y + dy) * W + 2 * x + dx) * 4 + k];
            worst = std::max<double>(worst, std::fabs(run.out[((size_t)y * (W / 2) + x) * 4 + k] - m / 4));
        }
        CHECK_NEAR(worst, 0.0, 2e-4);
    }

    // 5. interp.grey: red = luma of a, green = luma of b (divisor 1 -> offsets of a quarter pixel average four bilinear taps)
    std::printf("interp.grey writes the luma of both frames\n");
    {
        CHECK_MSG(run.go(Pass("grey", am::glsl::Source("interp.grey")), W, H, {{"a", a}, {"b", b}}, {{"d", {1.0f}}}, Filter::Nearest), run.error);
        double worst = 0;
        if (run.out.size() == A.size()) for (int y = 0; y < H; y++) for (int x = 0; x < W; x++) {
            const size_t i = ((size_t)y * W + x) * 4;
            worst = std::max<double>(worst, std::fabs(run.out[i] - Luma(&A[i])));
            worst = std::max<double>(worst, std::fabs(run.out[i + 1] - Luma(&B[i])));
            worst = std::max<double>(worst, std::fabs(run.out[i + 3] - 1.0));
        }
        CHECK_NEAR(worst, 0.0, 1e-5);
    }

    // 6. fx.puppet with identity matrices and no pins returns the input (exercises mat3 uniforms and the vec4[32] array)
    std::printf("fx.puppet with identity transforms is the identity (mat3 + array uniforms)\n");
    {
        const std::vector<float> I = {1, 0, 0, 0, 1, 0, 0, 0, 1};
        std::vector<Constant> k = {{"toLocal", I}, {"fromLocal", I}, {"pins", std::vector<float>(128, 0.0f)}, {"similar", {1, 0, 0, 0}}, {"count", {0}}, {"power", {0.75f}}};
        CHECK_MSG(run.go(Pass("puppet", am::glsl::Source("fx.puppet")), W, H, {{"image", a}}, k), run.error);
        double worst = 0;
        if (run.out.size() == A.size()) for (size_t i = 0; i < A.size(); i++) worst = std::max<double>(worst, std::fabs(run.out[i] - A[i]));
        CHECK_NEAR(worst, 0.0, 1e-4);
    }

    // 7. glow rows: distance to the nearest opaque pixel along the row, normalised by n
    std::printf("fx.glowrows measures the distance to the nearest opaque pixel in the row\n");
    {
        std::vector<float> M((size_t)W * H * 4, 0.0f);
        for (int y = 0; y < H; y++) { float* p = &M[((size_t)y * W + 5) * 4]; p[0] = p[1] = p[2] = p[3] = 1; }
        Target* m = g.be->createFromFloats(W, H, Format::RGBA32F, M.data());
        const float n = 24;
        CHECK_MSG(run.go(Pass("rows", am::glsl::Source("fx.glowrows")), W, H, {{"image", m}}, {{"n", {n}}}), run.error);
        double worst = 0;
        if (run.out.size() == M.size()) for (int y = 0; y < H; y++) for (int x = 0; x < W; x++) worst = std::max<double>(worst, std::fabs(run.out[((size_t)y * W + x) * 4] - std::abs(x - 5) / n));
        CHECK_NEAR(worst, 0.0, 1e-5);
        g.be->destroy(m);
    }

    // 8. blend modes: multiply of two opaque layers = s * b; and the layer below shows through a transparent source
    std::printf("blend modes (multiply / screen-like algebra)\n");
    {
        std::vector<float> S((size_t)W * H * 4, 0.0f), D2((size_t)W * H * 4, 0.0f);
        for (int i = 0; i < W * H; i++) { S[i * 4] = 0.8f; S[i * 4 + 1] = 0.5f; S[i * 4 + 2] = 0.2f; S[i * 4 + 3] = 1; D2[i * 4] = 0.5f; D2[i * 4 + 1] = 0.5f; D2[i * 4 + 2] = 1.0f; D2[i * 4 + 3] = 1; }
        for (int i = 0; i < W; i++) { float* q = &S[(size_t)i * 4]; q[0] = q[1] = q[2] = q[3] = 0; }   // first row: transparent source
        Target* s = g.be->createFromFloats(W, H, Format::RGBA32F, S.data());
        Target* d = g.be->createFromFloats(W, H, Format::RGBA32F, D2.data());
        CHECK_MSG(run.go(Pass("multiply", am::glsl::BlendSource("multiply")), W, H, {{"src", s}, {"dst", d}}), run.error);
        if (run.out.size() == S.size()) {
            const float* top = &run.out[0]; const float* row = &run.out[(size_t)W * 4 + 0];
            CHECK_NEAR(top[0], 0.5, 1e-5); CHECK_NEAR(top[2], 1.0, 1e-5);      // transparent source: destination unchanged
            CHECK_NEAR(row[0], 0.8 * 0.5, 1e-5); CHECK_NEAR(row[1], 0.25, 1e-5); CHECK_NEAR(row[2], 0.2, 1e-5); CHECK_NEAR(row[3], 1.0, 1e-5);
        }
        g.be->destroy(s); g.be->destroy(d);
    }
    g.be->destroy(a); g.be->destroy(b);
    std::printf("\n%d checks, %d failed\n", gChecks, gFailed);
    return gFailed ? 1 : 0;
}

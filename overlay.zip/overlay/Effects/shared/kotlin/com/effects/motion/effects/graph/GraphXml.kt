package com.effects.motion.effects.graph

/**
 * Writes the runtime XML the C++ engine reads (render_graph_xml.cpp):
 *   <effect id= graph="2" output= seek= max_replay=> <param/>* <texture/>* <buffer/>* <pass><source/><input/>*<const/>*<define/>*</pass>+ </effect>
 * Kept free of the app's XmlNode so it runs in host tests. Everything unknown in `extra` is written back out.
 */
object GraphXml {
    fun write(id: String, params: List<Pair<String, String>>, graph: EffectGraph, colors: Set<String> = emptySet()): String = buildString {
        append("<?xml version='1.0' encoding='UTF-8' ?>\n<effect")
        attr("id", id); attr("graph", GRAPH_SCHEMA.toString())
        if (graph.output.isNotEmpty()) attr("output", graph.output)
        if (graph.seek != "reset") attr("seek", graph.seek)
        if (graph.maxReplay != 120) attr("max_replay", graph.maxReplay.toString())
        graph.extra.forEach { (k, v) -> if (validName(k)) attr(k, v) }
        append(">\n")
        for ((name, value) in params) { append("  <param"); attr("name", name); attr("value", value); if (name in colors) attr("type", "color"); append(" />\n") }
        for (t in graph.textures) {
            append("  <texture"); attr("id", t.id); attr("source", t.source); attr("width", t.width.toString()); attr("height", t.height.toString())
            attr("seed", t.seed.toString()); attr("filter", t.filter); attr("wrap", t.wrap); t.extra.forEach { (k, v) -> if (validName(k)) attr(k, v) }; append(" />\n")
        }
        for (b in graph.buffers) {
            append("  <buffer"); attr("id", b.id); attr("scale", num(b.scale))
            if (b.width > 0) attr("width", b.width.toString())
            if (b.height > 0) attr("height", b.height.toString())
            attr("format", b.format); attr("precision", b.precision); attr("filter", b.filter); attr("wrap", b.wrap); attr("history", b.history.toString())
            b.extra.forEach { (k, v) -> if (validName(k)) attr(k, v) }; append(" />\n")
        }
        for (p in graph.passes) {
            append("  <pass"); attr("id", p.id); attr("name", p.name); attr("lang", p.lang)
            if (p.output.isNotEmpty()) attr("output", p.output)
            attr("blend", p.blend); attr("clear", p.clear.toString())
            if (p.after.isNotEmpty()) attr("after", p.after.joinToString(","))
            if (p.file.isNotEmpty()) attr("file", p.file)
            attr("line", p.line.toString())
            p.extra.forEach { (k, v) -> if (validName(k)) attr(k, v) }
            append(">\n    <source>").append(escape(p.source, false)).append("</source>\n")
            for (i in p.inputs) { append("    <input"); attr("name", i.name); attr("ref", i.ref); append(" />\n") }
            for ((k, v) in p.constants) { append("    <const"); attr("name", k); attr("value", v.joinToString(",") { num(it) }); append(" />\n") }
            for ((k, v) in p.defines) { append("    <define"); attr("name", k); attr("value", v); append(" />\n") }
            append("  </pass>\n")
        }
        append("</effect>\n")
    }

    private fun StringBuilder.attr(name: String, value: String) { append(' ').append(name).append("=\"").append(escape(value, true)).append('"') }

    private fun validName(s: String) = s.isNotEmpty() && (s[0].isLetter() || s[0] == '_') && s.all { it.isLetterOrDigit() || it == '_' || it == '-' || it == '.' }

    private fun num(f: Float): String = if (f == Math.rint(f.toDouble()).toFloat() && Math.abs(f) < 1e9f) f.toLong().toString() else f.toString()

    private fun escape(s: String, attribute: Boolean): String = buildString {
        for (c in s) when {
            c == '&' -> append("&amp;")
            c == '<' -> append("&lt;")
            c == '>' -> append("&gt;")
            attribute && c == '"' -> append("&quot;")
            attribute && c == '\n' -> append("&#10;")
            attribute && c == '\r' -> append("&#13;")
            attribute && c == '\t' -> append("&#9;")
            c < ' ' && c != '\n' && c != '\r' && c != '\t' -> {}   // not legal in XML 1.0
            else -> append(c)
        }
    }
}

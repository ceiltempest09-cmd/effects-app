#include "effects_graph.h"
#include "platform_log.h"
#ifndef LOGW
#define LOGW(...) __android_log_print(ANDROID_LOG_WARN, "AMGraph", __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, "AMGraph", __VA_ARGS__)
#endif
#include "render_graph_xml.h"
#include "gl_backend.h"
#include "vulkan_backend.h"

#include "include/core/SkColorSpace.h"
#include "include/core/SkData.h"
#include "include/core/SkImageInfo.h"
#include "include/core/SkPaint.h"
#include "include/core/SkSurface.h"
#include "include/gpu/graphite/Surface.h"   // SkSurfaces::AsImage (live view of a Graphite surface)

#include <algorithm>
#include <atomic>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <map>
#include <mutex>
#include <vector>
#ifdef __ANDROID__
#include <android/hardware_buffer.h>
#endif

namespace am {

namespace {
std::atomic<bool> gNativeShaders{true};   // native GLSL is the default; Skia (SkSL) is no longer the gate
std::atomic<bool> gNativeFences{false};
thread_local GraphGpuBridge* tBridge = nullptr;
}  // namespace

void SetNativeShaders(bool on) { gNativeShaders.store(on); }
bool NativeShadersEnabled() { return gNativeShaders.load(); }
static std::atomic<int> gGraphDepth{0};
void SetGraphWorkingDepth(int bits) { gGraphDepth.store(bits == 8 || bits == 16 || bits == 32 ? bits : 0); }
int GraphWorkingDepth() { return gGraphDepth.load(); }
void SetNativeFences(bool on) { gNativeFences.store(on); }
bool NativeFencesEnabled() { return gNativeFences.load(); }
GraphBridgeScope::GraphBridgeScope(GraphGpuBridge* bridge) : fPrevious(tBridge) { tBridge = bridge; }
GraphBridgeScope::~GraphBridgeScope() { tBridge = fPrevious; }
GraphGpuBridge* CurrentGraphGpuBridge() { return tBridge; }

namespace {

// One OpenGL ES backend per drawing thread: GL objects belong to the thread (and context) that made them. Created on first use.
struct ThreadGl {
    std::unique_ptr<rg::GlContext> context;
    std::unique_ptr<rg::GlBackend> backend;
    std::string error;
    bool tried = false;
    bool adopted = false;
    uintptr_t identity = 0;
    ~ThreadGl() { backend.reset(); context.reset(); }
};
thread_local ThreadGl gThreadGl;
rg::GlBackend* NativeGlForThisThread(const std::string& cacheDirectory, bool adoptCurrent, uintptr_t identity, std::string* why) {
    ThreadGl& holder = gThreadGl;
    // A thread can outlive an engine/context recreation. Never reuse GL objects against a different
    // context; tear them down on this owning thread before creating the replacement backend.
    if (holder.tried && (holder.adopted != adoptCurrent || (adoptCurrent && holder.identity != identity))) {
        holder.backend.reset();
        holder.context.reset();
        holder.error.clear();
        holder.tried = false;
    }
    if (!holder.tried) {
        holder.tried = true;
        holder.adopted = adoptCurrent;
        holder.identity = identity;
        std::string err;
        holder.context = adoptCurrent ? rg::GlContext::Adopt(&err)
                                     : rg::GlContext::Create(rg::GlContext::Api::ES, &err);
        if (!holder.context) {
            holder.error = std::string(adoptCurrent ? "cannot adopt the engine OpenGL ES context (" : "no OpenGL ES context (") + err + ")";
        } else {
            rg::GlOptions options;
            options.cacheDirectory = cacheDirectory;
            holder.backend = std::make_unique<rg::GlBackend>(*holder.context, options);
            if (!holder.backend->ok()) { holder.error = holder.backend->error(); holder.backend.reset(); holder.context.reset(); }
        }
    }
    if (!holder.backend) { *why = holder.error; return nullptr; }
    return holder.backend.get();
}

void ReleaseNativeGlForContext(uintptr_t identity) {
    if (!identity) return;
    ThreadGl& holder = gThreadGl;
    if (!holder.tried || !holder.adopted || holder.identity != identity) return;
    // Called by the engine on the context-owning thread before EGL teardown.
    holder.backend.reset();
    holder.context.reset();
    holder.error.clear();
    holder.tried = false;
    holder.adopted = false;
    holder.identity = 0;
}

// Hardware buffer a Skia surface and the GL backend can both use (RGBA8 / RGBA16F only; there is no AHardwareBuffer format for RGBA32F).
#ifdef __ANDROID__
AHardwareBuffer* AllocateShared(int w, int h, rg::Format f) {
    AHardwareBuffer_Desc d = {};
    d.width = (uint32_t)w; d.height = (uint32_t)h; d.layers = 1;
    d.format = f == rg::Format::RGBA16F ? AHARDWAREBUFFER_FORMAT_R16G16B16A16_FLOAT : AHARDWAREBUFFER_FORMAT_R8G8B8A8_UNORM;
    d.usage = AHARDWAREBUFFER_USAGE_GPU_FRAMEBUFFER | AHARDWAREBUFFER_USAGE_GPU_SAMPLED_IMAGE;
    AHardwareBuffer* b = nullptr;
    return AHardwareBuffer_allocate(&d, &b) == 0 ? b : nullptr;
}
void ReleaseShared(AHardwareBuffer* b) { if (b) AHardwareBuffer_release(b); }
#else
AHardwareBuffer* AllocateShared(int, int, rg::Format) { return nullptr; }
void ReleaseShared(AHardwareBuffer*) {}
#endif



}  // namespace

std::string CompileGraph(const XmlNode& root, const std::set<std::string>& controls, std::shared_ptr<const GraphProgram>* out) {
    rg::GraphDesc desc;
    std::vector<rg::Diag> diags;
    const bool readOk = rg::ParseGraphXml(root, &desc, &diags);
    std::string errors;
    auto addAll = [&](const std::vector<rg::Diag>& list) {
        for (const rg::Diag& d : list) if (d.error) errors += (errors.empty() ? "" : "\n") + d.format();
    };
    if (!readOk) { addAll(diags); return "shader error: " + errors; }

    rg::PlanOptions options;
    // BuildPlan validates against the complete set of execution backends used by GraphRunner.
    // Do not gate GLSL ES acceptance on the legacy native-shader preference: that preference
    // must never make a valid GLSL-ES effect fail early with "backend skia cannot run it".
    // Actual device/context support is checked by GlBackend::accepts when the graph is prepared.
    options.backend = "gles+vulkan";
    options.languages = {rg::Lang::GLSLES, rg::Lang::GLSL, rg::Lang::VulkanGLSL, rg::Lang::SPIRV};
    auto plan = std::make_shared<rg::Plan>(rg::BuildPlan(desc, options));
    addAll(plan->diags);
    if (!plan->ok()) return "shader error: " + (errors.empty() ? std::string("the render graph is not valid") : errors);
    for (const rg::Diag& d : plan->diags) if (!d.error) LOGW("%s", d.format().c_str());

    if (plan->desc.seek == rg::SeekMode::Replay) {
        return "shader error: " + rg::Diag{true, rg::DiagKind::Capability, plan->desc.effectId, "", "skia", "", "seek=\"replay\" needs the engine to re-render the layer at earlier frames, which this build cannot do. Use seek=\"reset\".", -1, 0}.format();
    }

    auto program = std::make_shared<GraphProgram>();
    program->temporal = plan->temporal;
    program->timed = plan->temporal;
    for (const rg::Step& step : plan->steps) {
        const rg::PassDesc& p = plan->desc.passes[step.pass];
        if (p.lang == rg::Lang::SkSL) {
            rg::Diag d;
            d.kind = rg::DiagKind::Capability; d.effect = plan->desc.effectId; d.pass = p.id; d.passIndex = step.pass; d.backend = "gles"; d.file = p.file; d.line = p.line;
            d.message = "SkSL is no longer supported: write the pass as glsl-es (see docs/NATIVE_SHADERS.md)";
            errors += (errors.empty() ? "" : "\n") + d.format();
            continue;
        }
        // The native driver compiles and binds the pass (by reflection) when it runs.
        program->native = true;
        program->timed = true;     // cannot tell whether it reads time/frame without compiling it: redraw every frame
    }
    if (!errors.empty()) return "shader error: " + errors;
    program->plan = plan;
    *out = program;
    return "ok";
}

// ------------------------------------------------------------------ backend
namespace {
SkColorType ColorTypeOf(rg::Format f) {
    switch (f) {
        case rg::Format::RGBA16F: return kRGBA_F16_SkColorType;
        case rg::Format::RGBA32F: return kRGBA_F32_SkColorType;
        default: return kRGBA_8888_SkColorType;
    }
}
}  // namespace

class GraphRunner::SkiaBackend : public rg::Backend {
public:
    struct Image : rg::Target {
        sk_sp<SkSurface> surface;       // render target (null for wrapped images)
        sk_sp<SkImage> wrapped;
        sk_sp<SkImage> snapshot;
        // Storage a native backend can import:
        AHardwareBuffer* ahb = nullptr;          // shared target created here; this Image owns one reference
        AHardwareBuffer* viewAhb = nullptr;      // view of a buffer another backend owns (borrowed; the view owns nothing)
        AHardwareBuffer* stagedAhb = nullptr;    // GPU copy of a private image (the effect's source) made for native passes (borrowed from the backend)
        sk_sp<SkSurface> stagedSurface;
        GraphGpuBridge* bridge = nullptr;        // to forget the buffer when this Image dies
        bool exported = false;                   // handed to another API since Skia last wrote it
        ~Image() override {
            if (ahb) {
                if (bridge) bridge->forgetBuffer(ahb);
                surface.reset();
                snapshot.reset();
                ReleaseShared(ahb);
            }
        }
        AHardwareBuffer* hardwareBuffer() const override { return ahb ? ahb : viewAhb ? viewAhb : stagedAhb; }
        sk_sp<SkImage> image() {
            if (wrapped) return wrapped;
            if (!snapshot && surface) {
                // Graphite's makeImageSnapshot() COPIES the texture and the surface keeps that copy until Skia itself draws on it. A buffer a
                // native backend rewrites (GL writes behind Skia's back) would therefore be read as it was the first time: stale pixels, seen on
                // the phone as a wrong control value and a missing history trail. AsImage() is a live view of the texture instead.
                if (ahb || viewAhb) snapshot = SkSurfaces::AsImage(surface);
                else snapshot = surface->makeImageSnapshot();   // copy-on-write: later writes do not change what was handed out
            }
            return snapshot;
        }
    };

    explicit SkiaBackend(const GraphProgram& program) : fProgram(program) {}

    void begin(SkCanvas* canvas, const GraphFrame* frame, const std::function<sk_sp<SkImage>(const sk_sp<SkImage>&)>* upload) {
        fCanvas = canvas;
        fFrame = frame;
        fUpload = upload;
        if (fBridge != CurrentGraphGpuBridge()) { fBridge = CurrentGraphGpuBridge(); fSharing = -1; }
        sk_sp<SkColorSpace> space = canvas->imageInfo().refColorSpace();
        if (!space) space = SkColorSpace::MakeSRGB();
        if (fSpace && !SkColorSpace::Equals(fSpace.get(), space.get())) {
            fBlanks.clear();
            fTextures.clear();
            fNeedsDrop = true;                               // targets carry the old colour space: the executor drops them
        }
        fSpace = space;
    }
    bool takeDropRequest() { const bool r = fNeedsDrop; fNeedsDrop = false; return r; }
    void forget() { fBlanks.clear(); fTextures.clear(); fSource.reset(); clearStage(); fF16 = fF32 = -1; fCanvas = nullptr; fBridge = nullptr; fSharing = -1; }
    ~SkiaBackend() override { clearStage(); }

    rg::Target* wrapSource(const sk_sp<SkImage>& image) {
        fSource = std::make_unique<Image>();
        fSource->wrapped = image;
        fSource->width = image->width();
        fSource->height = image->height();
        return fSource.get();
    }

    const char* name() const override { return "skia"; }
    bool supports(rg::Lang) const override { return false; }   // Skia only stores the layer image and the result; every pass is native
    bool supports(rg::Format f) const override {
        if (f == rg::Format::RGBA8 || f == rg::Format::Inherit) return true;
        int& cached = f == rg::Format::RGBA16F ? fF16 : fF32;
        if (cached < 0) cached = fCanvas && probe(f) ? 1 : 0;           // ask the real GPU: can it create AND render this format?
        return cached == 1;
    }
    // Intermediates are not quantised to 8 bits when the device can hold half floats.
    rg::Format workingFormat() const override {
        const int depth = GraphWorkingDepth();
        if (depth == 8) return rg::Format::RGBA8;
        if (depth == 32 && supports(rg::Format::RGBA32F)) return rg::Format::RGBA32F;
        return supports(rg::Format::RGBA16F) ? rg::Format::RGBA16F : rg::Format::RGBA8;
    }
    int maxTextureSize() const override { return 8192; }

    rg::Target* create(int w, int h, rg::Format f) override {
        auto* t = new Image();
        t->surface = fCanvas ? fCanvas->makeSurface(SkImageInfo::Make(w, h, ColorTypeOf(f), kPremul_SkAlphaType, fSpace)) : nullptr;
        if (!t->surface) { delete t; return nullptr; }
        t->surface->getCanvas()->clear(SK_ColorTRANSPARENT);
        return t;
    }
    void destroy(rg::Target* t) override { delete static_cast<Image*>(t); }

    // "lutf16:<path>": a baked 3D LUT (see engine/LutBake.kt). Little endian: int32 'LF16', int32 width, int32 height, then width*height RGBA half floats.
    // Stored as RGBA_F16 so no table entry loses precision. Returns nullptr (the pass then fails with "has no image") when the file is missing or wrong.
    rg::Target* lutTexture(const rg::TextureDesc& td) {
        const std::string path = td.source.substr(7);
        FILE* f = fopen(path.c_str(), "rb");
        if (!f) { LOGW("LUT texture '%s': cannot open %s", td.id.c_str(), path.c_str()); return nullptr; }
        int32_t head[3] = {0, 0, 0};
        bool ok = fread(head, 4, 3, f) == 3 && head[0] == 0x3631464C && head[1] >= 1 && head[2] >= 1 && head[1] <= 2048 && head[2] <= 2048
            && head[1] == td.width && head[2] == td.height;
        std::vector<uint8_t> px;
        if (ok) {
            px.resize((size_t)head[1] * head[2] * 8);
            ok = fread(px.data(), 1, px.size(), f) == px.size();
        }
        fclose(f);
        if (!ok) { LOGW("LUT texture '%s': %s is not a valid LF16 file of %dx%d", td.id.c_str(), path.c_str(), td.width, td.height); return nullptr; }
        auto t = std::make_unique<Image>();
        const SkImageInfo info = SkImageInfo::Make(td.width, td.height, kRGBA_F16_SkColorType, kPremul_SkAlphaType, fSpace);
        sk_sp<SkImage> raster = SkImages::RasterFromData(info, SkData::MakeWithCopy(px.data(), px.size()), (size_t)td.width * 8);
        t->wrapped = fUpload && *fUpload ? (*fUpload)(raster) : raster;
        if (!t->wrapped) return nullptr;
        t->width = td.width; t->height = td.height;
        rg::Target* raw = t.get();
        fTextures[td.id] = std::move(t);
        return raw;
    }

    rg::Target* texture(const rg::TextureDesc& td) override {
        auto it = fTextures.find(td.id);
        if (it != fTextures.end()) return it->second.get();
        if (td.source.rfind("lutf16:", 0) == 0) return lutTexture(td);
        auto t = std::make_unique<Image>();
        std::vector<uint8_t> px(td.width * td.height * 4);
        if (td.source == "builtin:noise") px = rg::NoisePixels(td.width, td.height, td.seed);
        else for (int y = 0; y < td.height; y++) for (int x = 0; x < td.width; x++) {
            const uint8_t v = (uint8_t)std::lround(255.0 * (td.source == "builtin:ramp-x" ? (x + 0.5) / td.width : (y + 0.5) / td.height));
            uint8_t* p = &px[((size_t)y * td.width + x) * 4];
            p[0] = p[1] = p[2] = v; p[3] = 255;
        }
        const SkImageInfo info = SkImageInfo::Make(td.width, td.height, kRGBA_8888_SkColorType, kPremul_SkAlphaType, fSpace);
        sk_sp<SkImage> raster = SkImages::RasterFromData(info, SkData::MakeWithCopy(px.data(), px.size()), (size_t)td.width * 4);
        t->wrapped = fUpload && *fUpload ? (*fUpload)(raster) : raster;
        if (!t->wrapped) return nullptr;
        t->width = td.width; t->height = td.height;
        rg::Target* raw = t.get();
        fTextures[td.id] = std::move(t);
        return raw;
    }

    rg::Target* blank(int w, int h, rg::Format f) override {
        const std::string key = std::to_string(w) + "x" + std::to_string(h) + ":" + rg::ToString(f);
        auto it = fBlanks.find(key);
        if (it != fBlanks.end()) return it->second.get();
        std::unique_ptr<rg::Target> t(create(w, h, f));
        if (!t) return nullptr;
        t->width = w; t->height = h; t->format = f;
        rg::Target* raw = t.get();
        fBlanks[key] = std::move(t);
        return raw;
    }

    bool run(const rg::PassRun&, std::string* error) override {
        *error = "the Skia backend runs no passes (SkSL was removed); passes run in the native GL / Vulkan backends";
        return false;
    }

    // ---------------------------------------------------------------- sharing storage with a native backend
    bool canShare(rg::Format f) const override {
        return (f == rg::Format::RGBA8 || f == rg::Format::RGBA16F) && sharing() && supports(f);
    }

    rg::Target* createShared(int w, int h, rg::Format f) override {
        if (!canShare(f)) return nullptr;
        AHardwareBuffer* buffer = AllocateShared(w, h, f);
        if (!buffer) { LOGW("shared target %dx%d: AHardwareBuffer_allocate failed", w, h); return nullptr; }
        std::string error;
        sk_sp<SkSurface> surface = fBridge->surfaceForBuffer(buffer, fSpace, &error);
        if (!surface) { LOGW("shared target %dx%d: %s", w, h, error.c_str()); ReleaseShared(buffer); return nullptr; }
        auto* t = new Image();
        t->surface = std::move(surface);
        t->ahb = buffer;                 // keeps the reference allocate() returned
        t->bridge = fBridge;
        t->surface->getCanvas()->clear(SK_ColorTRANSPARENT);
        return t;
    }

    // Skia finished with `t` and a native backend uses it next: submit everything and wait, so the native side sees final pixels.
    bool release(rg::Target* t, rg::Backend& to, std::string* error) override {
        (void)to;
        auto* img = static_cast<Image*>(t);
        if (!img) { *error = "skia: no target to hand over"; return false; }
        if (!requireSharing(error)) return false;
        if (!img->hardwareBuffer()) {
            if (!stage(img, error)) return false;       // private image (the layer): copy it on the GPU into shared storage
        } else if (img->stagedAhb && !img->ahb && !img->viewAhb && img->exported) {
            return true;                                // staged earlier this frame; nothing new was drawn
        }
        SkSurface* handBack = (img->ahb || img->viewAhb) ? img->surface.get() : img->stagedSurface.get();
        if (NativeFencesEnabled()) {
            int fd = -1;
            if (!fBridge->submitAndSignal(handBack, &fd, error)) return false;
            if (fd >= 0 && !to.waitForeign(fd, error)) return false;       // the GL queue waits for Skia's work; the CPU does not
        } else if (!fBridge->submitAndWait(handBack, error)) {
            return false;
        }
        img->exported = true;
        return true;
    }

    // The native GL queue's fence (a sync fd): Skia's next submit waits for it on the GPU when the bridge can import it, else the CPU waits.
    bool waitForeign(int fd, std::string* error) override {
        if (fd < 0) return true;
        if (fBridge && fBridge->queueForeignWait(fd)) { rg::FenceCounters().skiaGpuWaits++; return true; }
        rg::FenceCounters().skiaCpuWaits++;
        return rg::Backend::waitForeign(fd, error);
    }

    // A Skia surface over a buffer another backend owns (read it, or render into it when forWrite).
    rg::Target* acquire(rg::Backend& from, rg::Target* t, bool forWrite, std::string* error) override {
        (void)forWrite;
        if (!requireSharing(error)) return nullptr;
        AHardwareBuffer* buffer = t ? t->hardwareBuffer() : nullptr;
        if (!buffer) { *error = std::string("skia: the target from backend ") + from.name() + " has no hardware buffer behind it"; return nullptr; }
        sk_sp<SkSurface> surface = fBridge->surfaceForBuffer(buffer, fSpace, error);
        if (!surface) return nullptr;
        fBridge->externallyModified(surface.get());      // the other API wrote it since Skia last looked
        auto* view = new Image();
        view->surface = std::move(surface);
        view->viewAhb = buffer;
        view->width = t->width; view->height = t->height; view->format = t->format;
        return view;
    }

    void relinquish(rg::Target* view) override { delete static_cast<Image*>(view); }

    // A native backend wrote a target Skia owns: what Skia remembers about it (image snapshot, layout) is stale.
    void reclaim(rg::Target* t, rg::Backend& user) override {
        (void)user;
        auto* img = static_cast<Image*>(t);
        img->snapshot.reset();
        img->exported = false;
        if (img->surface && fBridge) fBridge->externallyModified(img->surface.get());
    }

private:
    bool sharing() const {
        if (fSharing < 0) {
            std::string why;
            fSharing = fBridge && fBridge->sharesWithNative(&why) ? 1 : 0;
            fSharingWhy = fBridge ? why : "the engine installed no GPU bridge for the graphs it draws";
        }
        return fSharing == 1;
    }
    bool requireSharing(std::string* error) const {
        if (sharing()) return true;
        *error = "skia cannot share storage with a native backend: " + fSharingWhy;
        return false;
    }

    // GPU copy of a private Skia image into a cached hardware buffer (RGBA8, or RGBA16F for half-float images).
    bool stage(Image* img, std::string* error) {
        sk_sp<SkImage> image = img->image();
        if (!image) { *error = "skia: the image to hand over is not available"; return false; }
        const rg::Format f = image->colorType() == kRGBA_F16_SkColorType ? rg::Format::RGBA16F : rg::Format::RGBA8;
        if (!canShare(f)) { *error = std::string("skia: cannot share ") + rg::ToString(f) + " storage on this device"; return false; }
        const std::string key = std::to_string(image->width()) + "x" + std::to_string(image->height()) + ":" + rg::ToString(f);
        if (fStage.find(key) == fStage.end() && fStage.size() >= 6) clearStage();
        Stage& s = fStage[key];
        if (!s.ahb) {
            AHardwareBuffer* buffer = AllocateShared(image->width(), image->height(), f);
            if (!buffer) { fStage.erase(key); *error = "skia: could not allocate a shared hardware buffer for the layer image"; return false; }
            sk_sp<SkSurface> surface = fBridge->surfaceForBuffer(buffer, fSpace, error);
            if (!surface) { ReleaseShared(buffer); fStage.erase(key); return false; }
            s.ahb = buffer; s.surface = std::move(surface); s.bridge = fBridge;
        }
        SkPaint paint;
        paint.setBlendMode(SkBlendMode::kSrc);
        s.surface->getCanvas()->drawImage(image.get(), 0, 0, SkSamplingOptions(), &paint);
        img->stagedAhb = s.ahb;
        img->stagedSurface = s.surface;
        img->exported = false;
        return true;
    }
    void clearStage() {
        for (auto& e : fStage) {
            e.second.surface.reset();
            if (e.second.bridge && e.second.ahb) e.second.bridge->forgetBuffer(e.second.ahb);
            ReleaseShared(e.second.ahb);
        }
        fStage.clear();
    }

    bool probe(rg::Format f) const {
        sk_sp<SkSurface> s = fCanvas->makeSurface(SkImageInfo::Make(8, 8, ColorTypeOf(f), kPremul_SkAlphaType, fSpace ? fSpace : SkColorSpace::MakeSRGB()));
        if (!s) return false;
        s->getCanvas()->clear(SK_ColorTRANSPARENT);
        return true;
    }

    const GraphProgram& fProgram;
    SkCanvas* fCanvas = nullptr;
    const GraphFrame* fFrame = nullptr;
    const std::function<sk_sp<SkImage>(const sk_sp<SkImage>&)>* fUpload = nullptr;
    sk_sp<SkColorSpace> fSpace;
    mutable int fF16 = -1, fF32 = -1;
    GraphGpuBridge* fBridge = nullptr;
    mutable int fSharing = -1;                    // -1 unknown, 0 no, 1 yes (asked of the bridge once per bridge)
    mutable std::string fSharingWhy;
    struct Stage { AHardwareBuffer* ahb = nullptr; sk_sp<SkSurface> surface; GraphGpuBridge* bridge = nullptr; };
    std::map<std::string, Stage> fStage;
    bool fNeedsDrop = false;
    std::unique_ptr<Image> fSource;
    std::map<std::string, std::unique_ptr<rg::Target>> fBlanks;
    std::map<std::string, std::unique_ptr<Image>> fTextures;
};

GraphRunner::GraphRunner(std::shared_ptr<const GraphProgram> program) : fProgram(std::move(program)) {
    fBackend = std::make_unique<SkiaBackend>(*fProgram);
    if (!fProgram->native) fExecutor = std::make_unique<rg::Executor>(*fBackend, fProgram->plan);   // native graphs build theirs on first use (needs the thread's GL backend)
}

GraphRunner::~GraphRunner() {
    // Targets go back through the backend that made them. GL objects can only be freed on their own thread: from another thread they are
    // left to the process (never touched) rather than risking undefined behaviour.
    if (fExecutor && fProgram->native && fGlThread != std::this_thread::get_id()) {
        LOGW("graph '%s': native targets are released from another thread than they were made on; leaving them to process exit", fProgram->plan->desc.effectId.c_str());
        (void)fExecutor.release();
        return;
    }
    fExecutor.reset();   // returns every target through the backend before it goes away
}

// Builds the executor of a graph with native passes: Skia first (it owns the layer image and receives the result), then the thread's OpenGL ES
// backend when a pass is GLSL ES, then the process-wide Vulkan backend when a pass is desktop GLSL / Vulkan GLSL / SPIR-V. A language no backend
// can run fails the frame with a Capability diagnostic; nothing is translated.
bool GraphRunner::prepareNative(std::string* error) {
    GraphGpuBridge* bridge = CurrentGraphGpuBridge();
    if (!bridge) { *error = "native passes need the engine's GPU bridge, which is not installed for this draw"; return false; }
    std::string why;
    if (!bridge->sharesWithNative(&why)) { *error = "native passes cannot run with this engine: " + why; return false; }
    if (fExecutor) {
        if (fGlThread != std::this_thread::get_id()) { *error = "a graph with native passes must keep drawing on the thread it started on (its GL objects belong to that thread)"; return false; }
        return true;
    }
    bool needGl = false, needVk = false;
    for (const rg::Step& step : fProgram->plan->steps) {
        const rg::Lang l = fProgram->plan->desc.passes[step.pass].lang;
        if (l == rg::Lang::GLSLES) needGl = true;
        else if (l != rg::Lang::SkSL) needVk = true;
    }
    std::vector<rg::Backend*> backends{fBackend.get()};
    if (needGl) {
        rg::GlBackend* gl = NativeGlForThisThread(bridge->nativeCacheDirectory(), bridge->usesCurrentGlContext(), bridge->nativeContextIdentity(), &why);
        if (!gl) { *error = "native GLSL ES passes need OpenGL ES, which is not available here: " + why; return false; }
        fGl = gl;
        backends.push_back(gl);
    }
    if (needVk) {
        rg::Backend* vk = rg::SharedVulkanBackend(&why);
        if (!vk) { *error = "native glsl / glsl-vk / spirv passes need the Vulkan backend, which is not available here: " + why; return false; }
        fVk = vk;
        backends.push_back(vk);
    }
    fGlThread = std::this_thread::get_id();
    fExecutor = std::make_unique<rg::Executor>(backends, fProgram->plan);
    return true;
}

bool GraphRunner::render(SkCanvas* canvas, const sk_sp<SkImage>& source, const GraphFrame& frame,
                         const std::function<sk_sp<SkImage>(const sk_sp<SkImage>&)>& upload, sk_sp<SkImage>* result, std::string* error) {
    if (!canvas || !source) { *error = "no canvas or source image"; return false; }
    fBackend->begin(canvas, &frame, &upload);
    if (fProgram->native) {
        if (!this->prepareNative(error)) { if (*error != fLastError) LOGE("%s", error->c_str()); fLastError = *error; return false; }
        if (fGl) static_cast<rg::GlBackend*>(fGl)->setFenceExport(NativeFencesEnabled());     // GL -> Skia hand-offs use a fence fd when the switch is on
        if (fVk) rg::VulkanBackendSetFences(fVk, NativeFencesEnabled());
        // Native passes rewrite shared buffers in place: every Skia command from earlier frames (which may still be reading them) must have finished.
        // With exactly one native backend its GPU queue waits for Skia's fence; with two, the CPU waits (one fence cannot cover both queues).
        rg::Backend* only = (fGl && !fVk) ? static_cast<rg::Backend*>(static_cast<rg::GlBackend*>(fGl)) : (!fGl && fVk) ? fVk : nullptr;
        if (NativeFencesEnabled() && only) {
            int fd = -1;
            if (!CurrentGraphGpuBridge()->submitAndSignal(nullptr, &fd, error) || (fd >= 0 && !only->waitForeign(fd, error))) { LOGE("%s", error->c_str()); return false; }
        } else if (!CurrentGraphGpuBridge()->submitAndWait(nullptr, error)) { LOGE("%s", error->c_str()); return false; }
    }
    if (fBackend->takeDropRequest()) fExecutor->dropAll();
    rg::FrameRequest request;
    request.frame = frame.frame;
    request.width = frame.width;
    request.height = frame.height;
    request.signature = frame.signature;
    request.control = frame.controlByName;
    request.source = fBackend->wrapSource(source);
    sk_sp<SkImage> image;
    fLast = fExecutor->render(request, [&](rg::Target* t) { image = static_cast<SkiaBackend::Image*>(t)->image(); });
    for (const rg::Diag& d : fLast.notes) LOGW("%s", d.format().c_str());
    if (fLast.status != rg::FrameResult::Ok || !image) {
        *error = fLast.error.empty() ? "the graph produced no image" : fLast.error;
        if (*error != fLastError) LOGE("%s", error->c_str());
        fLastError = *error;
        return false;
    }
    fLastError.clear();
    *result = std::move(image);
    return true;
}

void GraphRunner::drop() {
    if (fExecutor && (!fProgram->native || fGlThread == std::this_thread::get_id())) fExecutor->dropAll();
    fBackend->forget();
}

void GraphRunner::trim() { if (fExecutor && (!fProgram->native || fGlThread == std::this_thread::get_id())) fExecutor->trimIdle(); }

std::string GraphRunner::report() const {
    const rg::TargetPool::Stats s = fExecutor ? fExecutor->poolStats() : rg::TargetPool::Stats();
    std::string out = "{\"effect\":\"" + fProgram->plan->desc.effectId + "\",\"passes\":[";
    for (size_t i = 0; i < fLast.timings.size(); i++) {
        const rg::PassTiming& t = fLast.timings[i];
        out += (i ? "," : "") + std::string("{\"pass\":\"") + t.pass + "\",\"cpuUs\":" + std::to_string(t.cpuNs / 1000) + ",\"gpuUs\":" + std::to_string(t.gpuNs < 0 ? -1 : t.gpuNs / 1000) + "}";
    }
    out += "],\"pool\":{\"created\":" + std::to_string(s.created) + ",\"reused\":" + std::to_string(s.reused) + ",\"live\":" + std::to_string(s.live) +
           ",\"idle\":" + std::to_string(s.idle) + ",\"bytes\":" + std::to_string(s.bytes) + ",\"peakBytes\":" + std::to_string(s.peakBytes) + "}";
    out += ",\"historyReset\":" + std::string(fLast.historyReset ? "true" : "false") + "}";
    return out;
}

}  // namespace am

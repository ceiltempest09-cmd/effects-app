// grade_pass.frag — SAMPLE effect: exposure + lift/gamma/gain, run in linear light.
// Compose with:  ComposeFragment(fx_common, thisFile, prec, bufFmt, manualBilinear)
in highp vec2 v_uv;                       // coordinates are always highp, regardless of FX_PREC
uniform sampler2D u_src;
uniform float u_exposure;                 // stops
uniform vec3  u_lift, u_gamma, u_gain;    // neutral: 0, 1, 1
out vec4 o_color;

void main() {
    vec4 s = fxSample(u_src, v_uv);

    // Premultiplied alpha: grade the colour, not the colour*alpha.
    vec3 rgb = s.a > 0.0 ? s.rgb / s.a : s.rgb;
    vec3 c = fxDecode(rgb) * exp2(u_exposure);              // exposure is a plain multiply in linear

    c = c * u_gain + u_lift;                                  // gain / lift
    c = pow(max(c, 0.0), 1.0 / max(u_gamma, vec3(1e-4)));     // gamma

#ifndef FX_FLOAT_BUFFER
    c = min(c, 1.0);       // RGBA8 can't hold >1.0; float buffers keep highlights for later passes
#endif
    o_color = vec4(fxEncode(c) * s.a, s.a);
}

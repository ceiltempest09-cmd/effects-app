package com.effects.motion.media

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class PrefetchFramesTest {
    private val source = LongArray(10) { it * 33_333L }

    @Test fun aCopyWithTheSameFramesMatches() {
        assertTrue(ProxyRules.sameFramesAligned(source, source.copyOf()))
    }

    @Test fun aCopyThatStartsLaterButKeepsTheSpacingMatches() {
        assertTrue(ProxyRules.sameFramesAligned(source, LongArray(10) { 40_000L + it * 33_333L }))
    }

    @Test fun framesBeforeZeroAreNotExpectedInTheCopy() {
        val withPreRoll = longArrayOf(-66_666L, -33_333L) + source
        assertTrue(ProxyRules.sameFramesAligned(withPreRoll, source))
    }

    @Test fun aCopyWithMissingOrMovedFramesDoesNotMatch() {
        assertFalse(ProxyRules.sameFramesAligned(source, source.copyOf(9)))
        assertFalse(ProxyRules.sameFramesAligned(source, LongArray(10) { if (it == 5) source[it] + 20_000L else source[it] }))
        assertFalse(ProxyRules.sameFramesAligned(longArrayOf(), longArrayOf()))
    }
}

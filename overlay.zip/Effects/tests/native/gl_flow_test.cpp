// gl_flow.cpp on a real GL driver: optical flow of a translated image, frame synthesis, motion blur, datamosh.
#include "gl_flow.h"

#include <cmath>
#include <cstdio>

using namespace am;
static int gFailed = 0, gChecks = 0;
#define CHECK_MSG(cond, msg) do { gChecks++; if (!(cond)) { gFailed++; std::printf("  FAIL %s:%d  %s -- %s\n", __FILE__, __LINE__, #cond, std::string(msg).c_str()); } } while (0)
#define CHECK_NEAR(a, b, eps) do { gChecks++; const double _a = (a), _b = (b); if (!(std::fabs(_a - _b) <= (eps))) { gFailed++; std::printf("  FAIL %s:%d  %s=%g vs %s=%g (eps %g)\n", __FILE__, __LINE__, #a, _a, #b, _b, (double)(eps)); } } while (0)

static float Tex(float x, float y) {   // smooth, non-periodic-looking texture in 0..1
    return 0.5f + 0.25f * std::sin(x * 0.21f + 0.7f) * std::cos(y * 0.17f) + 0.15f * std::sin((x + y) * 0.11f) + 0.1f * std::cos(x * 0.05f - y * 0.09f);
}
static std::vector<float> Image(int w, int h, float dx, float dy) {
    std::vector<float> v((size_t)w * h * 4);
    for (int y = 0; y < h; y++) for (int x = 0; x < w; x++) {
        float* p = &v[((size_t)y * w + x) * 4];
        const float X = x + 0.5f - dx, Y = y + 0.5f - dy;
        p[0] = Tex(X, Y); p[1] = Tex(X * 1.3f + 11, Y * 0.9f); p[2] = Tex(X * 0.7f, Y * 1.1f + 5); p[3] = 1;
    }
    return v;
}

int main() {
    std::string err;
    auto ctx = rg::GlContext::Create(rg::GlContext::Api::ES, &err);
    if (!ctx) { std::printf("SKIP: no GLES (%s)\n", err.c_str()); return 0; }
    rg::GlBackend be(*ctx);
    if (!be.ok()) { std::printf("SKIP: %s\n", be.error().c_str()); return 0; }
    flow::Flow fx(be);

    const int W = 128, H = 96;
    const float SX = 3.0f, SY = 2.0f;                     // b is a moved by (+3, +2) pixels
    const auto A = Image(W, H, 0, 0), B = Image(W, H, SX, SY);
    rg::Target* a = be.createFromFloats(W, H, rg::Format::RGBA8, A.data());
    rg::Target* b = be.createFromFloats(W, H, rg::Format::RGBA8, B.data());

    std::printf("optical flow of a translated image\n");
    flow::Params p; p.divisor = 2; p.levels = 3; p.iterations = 6; p.warps = 2; p.alpha = 0.1f; p.fuse = 4;
    flow::Stats st;
    rg::Target* field = fx.estimate(a, b, p, &st);
    CHECK_MSG(field != nullptr, fx.error());
    if (field) {
        std::printf("   %d passes, %d levels, field %dx%d\n", st.passes, st.levels, field->width, field->height);
        std::vector<float> f;
        CHECK_MSG(be.readback(field, &f), "readback");
        double sx = 0, sy = 0, bx = 0, by = 0; int n = 0;
        for (int y = 8; y < field->height - 8; y++) for (int x = 8; x < field->width - 8; x++) {
            const float* q = &f[((size_t)y * field->width + x) * 4];
            sx += q[0]; sy += q[1]; bx += q[2]; by += q[3]; n++;
        }
        sx /= n; sy /= n; bx /= n; by /= n;
        std::printf("   mean forward flow (%.3f, %.3f), backward (%.3f, %.3f) in field pixels; true motion (%.2f, %.2f)\n", sx, sy, bx, by, SX / 2, SY / 2);
        CHECK_NEAR(std::fabs(sx), SX / 2, 0.45); CHECK_NEAR(std::fabs(sy), SY / 2, 0.45);
        CHECK_MSG(sx * bx < 0 && sy * by < 0, "backward flow points the other way");

        std::printf("frame synthesis at t = 0.5\n");
        rg::Target* mid = fx.synthesize(a, b, field, 0.5f, p.divisor);
        CHECK_MSG(mid != nullptr, fx.error());
        if (mid) {
            std::vector<float> m;
            CHECK_MSG(be.readback(mid, &m), "readback");
            const auto M = Image(W, H, SX / 2, SY / 2);    // ground truth halfway frame
            double err = 0, blend = 0; int c = 0;
            for (int y = 12; y < H - 12; y++) for (int x = 12; x < W - 12; x++) for (int k = 0; k < 3; k++) {
                const size_t i = ((size_t)y * W + x) * 4 + k;
                err += std::fabs(m[i] - M[i]); blend += std::fabs(0.5f * (A[i] + B[i]) - M[i]); c++;
            }
            err /= c; blend /= c;
            std::printf("   mean abs error: flow warp %.4f, plain cross-fade %.4f\n", err, blend);
            CHECK_MSG(err < blend, "the flow warp is closer to the true middle frame than a cross-fade");
            fx.release(mid);
        }
        std::printf("motion blur\n");
        rg::Target* blur = fx.motionBlur(a, field, 0.5f, 1.0f, p.divisor);
        CHECK_MSG(blur != nullptr, fx.error());
        if (blur) {
            std::vector<float> m; CHECK_MSG(be.readback(blur, &m), "readback");
            double diff = 0; for (size_t i = 0; i < m.size(); i++) diff += std::fabs(m[i] - A[i]);
            CHECK_MSG(diff > 1.0, "the blurred frame differs from the source");
            fx.release(blur);
        }
        std::printf("datamosh step\n");
        flow::MoshParams mp; mp.flow = p;
        rg::Target* motion = nullptr;
        rg::Target* mosh = fx.moshStep(a, nullptr, b, field, mp, 3.0f, &motion);
        CHECK_MSG(mosh != nullptr && motion != nullptr, fx.error());
        fx.release(mosh); fx.release(motion);
    }
    std::printf("cross-fade and four-frame blend\n");
    rg::Target* x = fx.synthesize(a, b, nullptr, 0.25f, 2);
    CHECK_MSG(x != nullptr, fx.error());
    if (x) {
        std::vector<float> m; CHECK_MSG(be.readback(x, &m), "readback");
        CHECK_NEAR(m[(size_t)(10 * W + 10) * 4], A[(size_t)(10 * W + 10) * 4] * 0.75 + B[(size_t)(10 * W + 10) * 4] * 0.25, 0.01);
        fx.release(x);
    }
    rg::Target* soft = fx.synthesize(a, b, nullptr, 0.5f, 2, a, b);
    CHECK_MSG(soft != nullptr, fx.error());
    fx.release(soft); fx.release(field);
    be.destroy(a); be.destroy(b);
    std::printf("\n%d checks, %d failed\n", gChecks, gFailed);
    return gFailed ? 1 : 0;
}

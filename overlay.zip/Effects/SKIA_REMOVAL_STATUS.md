# Skia removal status — migration tracking

## Batch 1: standalone GLSL ES / OpenGL ES render-graph backend

**Status: HOST-VERIFIED; NOT YET THE APPLICATION'S PRIMARY RENDERER.**

The project contains a real EGL/OpenGL ES 3.x backend (`gl_backend.{h,cpp}`) and a backend-neutral render graph (`render_graph.{h,cpp}`). The backend compiles GLSL ES on the device driver, manages render targets and textures, binds uniforms/samplers, executes passes, supports pooling/history, reports capabilities, and records diagnostics/statistics. The render graph plans and executes passes through backend capability selection and explicit inter-backend hand-offs.

### Verification performed on this source upload

- `tests/native/build_gl.sh`: **1,227 checks passed, 0 failed, 1 skipped** on Mesa llvmpipe. It exercised GLES 3.2 and desktop GL 4.5, shader compilation/execution, formats, uniforms/samplers, blending, multi-pass graphs, history, pooling, profiling, and error handling. The skipped test is SPIR-V/Vulkan execution because no SPIR-V compiler/Vulkan backend is available in this host test build.
- `tests/native/run.sh` component tests: render graph **171 passed**; native shader **105 passed**; SPIR-V reflection **22 passed**; GLSL wrapper **22 passed**; history signature **16 passed**; color pipeline **114 passed**. The full script did not complete within the available execution window when it reached its final GPU test; the GPU test was run separately and passed as stated above.
- Fixed a missing `<algorithm>` include in `tests/native/render_graph_test.cpp`, which previously prevented the host test suite from compiling (`std::any_of`).
- Android Gradle/NDK build and Mali-G57 device test: **not run**.

### Critical integration limitation

This completes the **standalone renderer / render-graph foundation only**. It does NOT make the app fully GLSL. `engine.cpp`, scene compositing, shapes, styles, text, video-frame integration, and the current Skia rendering lifecycle still depend on Skia. The app's effect graph adapter and Kotlin importer still have Skia/SkSL integration paths. Do not remove Skia from CMake or GitHub Actions yet; doing so would break the current app renderer.

### Next batch

Batch 2 must connect the native renderer to the real engine frame lifecycle and replace scene/layer compositing and video-frame paths. This requires a concrete engine-to-GPU bridge and correct synchronization/resource ownership; it is not safe to claim the application uses GLSL until that is implemented and tested.

No features were intentionally removed or stubbed in this batch. Package/application identity and signing configuration were not changed.


## Batch 2 continuation — source reconciliation (2026-11-22)

The two supplied archives are complementary, not interchangeable. `overlay.zip` contains the newer integration files and build configuration but omits 49 C++ source/header files that its own CMake configuration references. `Effects.zip` contains those missing implementation files. The working Batch 2 tree was reconciled by adding only files absent from `overlay.zip`; existing overlay files were preserved (including its newer `gl_yuv.cpp` and `gl_yuv.h`). The CMake-referenced `.cpp` source existence check now reports no missing files.

This is source-tree repair, not completion of Batch 2. The current engine still renders through Skia surfaces/canvases, the video YUV path still adapts the native GL texture back into a Skia image, and `GraphRunner` still uses its Skia backend as the source/result adapter. The app's Android build and on-device GLES integration have not yet been verified. Do not mark Batch 2 complete or remove Skia from the build yet.


## Batch 2 continuation — native test runner restored and rerun

Restored the native host test scripts and native shader capability notes into the current `overlay.zip` tree from the supporting `Effects.zip` archive. Ran `tests/native/run.sh` from the project root on Mesa llvmpipe:

- Render graph: 183 passed.
- Native shader: 105 passed.
- SPIR-V reflection: 22 passed.
- GLSL wrapper: 22 passed.
- History signature: 16 passed.
- Color pipeline: 114 passed.
- GLES / desktop GL backend: 1,227 passed, 0 failed, 1 skipped.

The skipped test is SPIR-V / Vulkan execution because this host test build has no SPIR-V compiler or Vulkan device. These are host tests of the standalone native backend, not Android app/device tests. Batch 2 remains open: the app frame lifecycle, Skia-backed scene composition, Ganesh/OpenGL bridge, and video/preview integration still need migration.

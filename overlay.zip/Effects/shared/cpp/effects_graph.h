// effects_graph.h — Skia (SkSL) execution of a render graph (render_graph.h).
//
// Every pass is an SkRuntimeEffect drawn into its own offscreen SkSurface that comes from the SAME canvas, hence the same
// Ganesh (GL/Vulkan) or Graphite context the editor already owns: no second Vulkan device, no second EGL context, no CPU readback.
// Skia orders the GPU work and the layout transitions between a pass that renders a surface and the next pass that samples it.
#pragma once

#include "render_graph.h"
#include "xml.h"
#include "include/core/SkCanvas.h"
#include "include/core/SkColorSpace.h"
#include "include/core/SkSurface.h"
#include "include/core/SkImage.h"

#include <atomic>
#include <cstdint>
#include <functional>
#include <memory>
#include <set>
#include <string>
#include <thread>

struct AHardwareBuffer;

namespace am {

// ---------------------------------------------------------------- native (GLSL ES) passes next to SkSL passes
// A graph whose passes use lang="glsl-es" runs those passes in the native OpenGL ES driver and the SkSL passes in Skia, in one frame,
// exchanging buffers through AHardwareBuffer storage (no copy through the CPU). Off by default (SetNativeShaders); with it off a graph
// that has a non-SkSL pass fails to load with a clear "language not supported" message, exactly as before.
void SetNativeShaders(bool on);
// The project bit depth the graph intermediates follow: 8, 16, 32, or 0 = the project has no colour settings and the graph chooses
// (half float where the device can). Set by the engine at the start of every draw; a change drops the cached buffers (EffectRuntime::dropGraphs).
void SetGraphWorkingDepth(int bits);
int GraphWorkingDepth();
bool NativeShadersEnabled();
// Experimental, off by default (own switch, read when the engine starts): hand Skia's finished work to the native GL backend through a GPU
// fence (a Vulkan semaphore exported as a sync fd, waited for by the GL queue) instead of making the CPU wait for the GPU. When the device
// cannot export the fence, every hand-off falls back to the CPU wait, so results never depend on the switch.
void SetNativeFences(bool on);
bool NativeFencesEnabled();
// What the fenced hand-offs actually did is counted in fence_stats.h (rg::FenceCounters()); the GPU Test report prints it.
// Writes the last effect draw failure to <pipeline dir>/last-effect-error.txt (only when it changes), so the GPU Test page can show it. Does nothing without a pipeline dir.
void RecordEffectError(const std::string& text);

// What the engine gives the graphs so Skia and the native backend can share GPU memory. Implemented by the engine that owns the Skia
// GPU context (engine.cpp). All calls happen on the thread that draws.
class GraphGpuBridge {
public:
    virtual ~GraphGpuBridge() = default;
    // Can this engine share buffers with a native GL backend? false + why (e.g. it runs Ganesh on OpenGL, where both would share one EGL context).
    virtual bool sharesWithNative(std::string* why) = 0;
    // True when the native GL backend must adopt the engine's current EGL context instead of creating
    // a second context. Ganesh/OpenGL uses this path so Skia and the native backend share one GL queue.
    virtual bool usesCurrentGlContext() const { return false; }
    // Stable identity for the adopted context; zero for bridge-owned/independent contexts.
    virtual uintptr_t nativeContextIdentity() const { return 0; }
    // A Skia render target (and so a sampleable image) over the hardware buffer. Cached by the bridge per buffer until forgetBuffer().
    virtual sk_sp<SkSurface> surfaceForBuffer(AHardwareBuffer* buffer, const sk_sp<SkColorSpace>& space, std::string* error) = 0;
    virtual void forgetBuffer(AHardwareBuffer* buffer) = 0;
    // Every Skia command recorded so far is submitted AND has finished on the GPU. `handBack` (nullable) is a surface Skia wrote that
    // another API reads next: Skia gives its image up to the foreign queue family in the same submit.
    virtual bool submitAndWait(SkSurface* handBack, std::string* error) = 0;
    // Same contract as submitAndWait, but the CPU does not wait when the device can export a fence: everything submitted is then covered by
    // `*fenceFd` (a sync fd the caller must give to Backend::waitForeign, which closes it). `*fenceFd` = -1 means the work has finished
    // already (waited on the CPU, or the driver reported it done). The default is the CPU wait.
    virtual bool submitAndSignal(SkSurface* handBack, int* fenceFd, std::string* error) { *fenceFd = -1; return submitAndWait(handBack, error); }
    // GL -> Skia: a sync fd that the native GL queue signals when its writes are finished. true = the bridge took the fd (owns it) and every
    // Skia submit from now on waits for it on the GPU; false = not taken, the fd is still the caller's (it waits on the CPU).
    virtual bool queueForeignWait(int fd) { (void)fd; return false; }
    // Another API wrote `surface`'s memory since Skia last used it: Skia must not assume the layout / contents it knew.
    virtual void externallyModified(SkSurface* surface) = 0;
    // Directory for the driver-program disk cache of the native backend ("" = none).
    virtual std::string nativeCacheDirectory() { return std::string(); }
};

// The bridge for the graphs drawn by the current thread (the engine installs it around the effect drawing it triggers).
class GraphBridgeScope {
public:
    explicit GraphBridgeScope(GraphGpuBridge* bridge);
    ~GraphBridgeScope();
    GraphBridgeScope(const GraphBridgeScope&) = delete;
    GraphBridgeScope& operator=(const GraphBridgeScope&) = delete;
private:
    GraphGpuBridge* fPrevious;
};
GraphGpuBridge* CurrentGraphGpuBridge();
// Release a thread's adopted native GL backend while the owning engine context is still current.
void ReleaseNativeGlForContext(uintptr_t identity);

struct GraphProgram {
    std::shared_ptr<const rg::Plan> plan;
    bool timed = false;                            // reads time/frame or history: the result changes without the controls changing
    bool temporal = false;
    bool native = false;                           // some live pass runs in a native backend (all of them now)
};

// Reads an <effect graph="2"> element. Returns "ok" or "shader error: ..." (the same convention as EffectRuntime::load), with every
// problem carrying effect id, pass, backend and source line. `controls` are the effect's control names (uniforms bind by name).
std::string CompileGraph(const XmlNode& root, const std::set<std::string>& controls, std::shared_ptr<const GraphProgram>* out);

struct GraphFrame {
    int64_t frame = 0;                // quantised frame index for temporal graphs, otherwise a running count
    float seconds = 0;                // value of the `time` uniform
    int width = 0, height = 0;        // effect area in pixels
    uint64_t signature = 0;           // changes when anything that defines earlier frames changes (controls, area)
    // The same controls by plain name, for native passes that bind uniforms by reflection: fills `count` floats (components x array size).
    std::function<bool(const std::string& name, int count, float* values)> controlByName;
};

// One per (layer, effect) instance: owns the pooled render targets and the history of temporal graphs.
class GraphRunner {
public:
    explicit GraphRunner(std::shared_ptr<const GraphProgram> program);
    ~GraphRunner();

    // Runs all passes for one frame. `canvas` supplies the GPU context and colour space, `source` is the layer image for this frame.
    // On success `*result` is the final buffer (premultiplied, same colour space, same size as the area).
    bool render(SkCanvas* canvas, const sk_sp<SkImage>& source, const GraphFrame& frame, const std::function<sk_sp<SkImage>(const sk_sp<SkImage>&)>& upload,
                sk_sp<SkImage>* result, std::string* error);

    void drop();                      // device loss, context recreation, low memory
    void trim();
    std::string report() const;       // JSON: pass timings of the last frame and pool statistics
    const GraphProgram& program() const { return *fProgram; }

private:
    class SkiaBackend;
    bool prepareNative(std::string* error);
    std::shared_ptr<const GraphProgram> fProgram;
    std::unique_ptr<SkiaBackend> fBackend;
    std::unique_ptr<rg::Executor> fExecutor;
    void* fGl = nullptr;                 // the thread's rg::GlBackend this executor was built with (graphs with GLSL ES passes only)
    rg::Backend* fVk = nullptr;          // the process-wide Vulkan backend (graphs with glsl / glsl-vk / spirv passes only)
    std::thread::id fGlThread;
    rg::FrameResult fLast;
    std::string fLastError;
};

}  // namespace am

// glsl_library.h - the built-in shaders of the engine, as GLSL ES 3.00 for the native GL backend (gl_backend.h).
// These replace every SkSL runtime effect that used to ship in the engine (interpolation, glow, puppet, display tone map, styles).
// Contract (same as every native pass, docs/NATIVE_SHADERS.md): premultiplied in and out, `gl_FragCoord` in output pixels,
// `uniform sampler2D X` + automatic `uniform vec2 X_px` (size of the bound input), automatic `size` / `time` / `out_px`.
// Pure C++, no Skia, no GL header: host-tested in tests/native/glsl_library_test.cpp.
#pragma once

#include <string>
#include <vector>

namespace am::glsl {

// Full pass source by id ("interp.grey", "interp.warp", "fx.glowmix", "display.tonemap", "style.gradient", ...); nullptr if unknown.
const char* Source(const std::string& id);
std::vector<std::string> Ids();

// The fused Jacobi relaxation pass of the optical-flow solver for `steps` (1, 2 or 4) fused iterations.
std::string JacobiSource(int steps);

// Replacement for the Skia blender of a layer blend mode: a pass that reads `src` and `dst` and writes the blended result.
// Empty string for modes Skia blends natively (normal, screen, mask, ...).
std::string BlendSource(const std::string& id);
std::vector<std::string> BlendModes();

}  // namespace am::glsl

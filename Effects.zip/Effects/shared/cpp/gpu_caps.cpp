// gpu_caps.cpp — startup GPU capability probe for OpenGL ES 3.0+.
// Creates a throw-away 1x1 pbuffer context, checks extensions, then VERIFIES each float format by
// building a framebuffer and reading values back. Extension strings alone are not trusted: some
// budget drivers advertise formats whose framebuffers are incomplete or silently clamp to [0,1].
#include <jni.h>
#include <EGL/egl.h>
#include <GLES3/gl3.h>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <set>
#include <string>

namespace {

std::set<std::string> Extensions() {
    std::set<std::string> out;
    GLint n = 0;
    glGetIntegerv(GL_NUM_EXTENSIONS, &n);
    for (GLint i = 0; i < n; ++i) {
        const char* e = (const char*)glGetStringi(GL_EXTENSIONS, i);
        if (e) out.insert(e);
    }
    return out;
}

// Build a 4x4 FBO with `internalFormat`, clear to known values, read them back as floats.
// 16F: must keep 1.5 and -0.25 (an RGBA8-style clamp would give 1.0 and 0.0).
// 32F: must additionally keep 1.0 + 1e-6, which fp16 cannot represent (that proves real 32-bit storage).
bool VerifyRenderable(GLenum internalFormat, bool needs32BitPrecision) {
    while (glGetError() != GL_NO_ERROR) {}
    GLuint tex = 0, fbo = 0;
    glGenTextures(1, &tex);
    glBindTexture(GL_TEXTURE_2D, tex);
    glTexStorage2D(GL_TEXTURE_2D, 1, internalFormat, 4, 4);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);   // nearest: always legal
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
    glGenFramebuffers(1, &fbo);
    glBindFramebuffer(GL_FRAMEBUFFER, fbo);
    glFramebufferTexture2D(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0, GL_TEXTURE_2D, tex, 0);

    bool ok = glCheckFramebufferStatus(GL_FRAMEBUFFER) == GL_FRAMEBUFFER_COMPLETE;
    if (ok) {
        const float kTiny = 1.0f + 1e-6f;
        glClearColor(1.5f, -0.25f, kTiny, 1.0f);
        glClear(GL_COLOR_BUFFER_BIT);
        float px[4] = {0, 0, 0, 0};
        glReadPixels(0, 0, 1, 1, GL_RGBA, GL_FLOAT, px);
        ok = glGetError() == GL_NO_ERROR &&
             std::fabs(px[0] - 1.5f) < 1e-3f && std::fabs(px[1] + 0.25f) < 1e-3f &&
             (!needs32BitPrecision || px[2] > 1.0f);
    }
    glBindFramebuffer(GL_FRAMEBUFFER, 0);
    glDeleteFramebuffers(1, &fbo);
    glDeleteTextures(1, &tex);
    while (glGetError() != GL_NO_ERROR) {}
    return ok;
}

struct Result {
    std::string renderer = "unknown";
    int major = 3, minor = 0;
    bool f16Render = false, f16Linear = true, f32Render = false, f32Linear = false, f32Blend = false;
};

Result ProbeCurrentContext() {
    Result r;
    if (const char* s = (const char*)glGetString(GL_RENDERER)) r.renderer = s;
    GLint maj = 0, min = 0;
    glGetIntegerv(GL_MAJOR_VERSION, &maj);
    glGetIntegerv(GL_MINOR_VERSION, &min);
    r.major = maj ? maj : 3;
    r.minor = min;

    const auto ext = Extensions();
    auto has = [&](const char* e) { return ext.count(e) > 0; };

    // Renderability: verified by readback. Extensions are only a cheap pre-filter, because
    // GLES 3.2 makes float color buffers core (no extension string listed on some drivers).
    const bool core32 = r.major > 3 || (r.major == 3 && r.minor >= 2);
    const bool maybeFloatRT = core32 || has("GL_EXT_color_buffer_float") || has("GL_EXT_color_buffer_half_float");
    if (maybeFloatRT) r.f16Render = VerifyRenderable(GL_RGBA16F, false);
    if (core32 || has("GL_EXT_color_buffer_float")) r.f32Render = VerifyRenderable(GL_RGBA32F, true);

    r.f16Linear = true;                                   // RGBA16F filtering is core in ES 3.0
    r.f32Linear = r.f32Render && has("GL_OES_texture_float_linear");
    r.f32Blend  = r.f32Render && has("GL_EXT_float_blend");
    return r;
}

}  // namespace

extern "C" JNIEXPORT jstring JNICALL
Java_com_effects_motion_engine_bitdepth_GpuProbe_nativeProbe(JNIEnv* env, jobject) {
    // Remember whatever is current on this thread so we never disturb the engine's context.
    EGLDisplay oldDpy = eglGetCurrentDisplay();
    EGLContext oldCtx = eglGetCurrentContext();
    EGLSurface oldDraw = eglGetCurrentSurface(EGL_DRAW), oldRead = eglGetCurrentSurface(EGL_READ);

    EGLDisplay dpy = eglGetDisplay(EGL_DEFAULT_DISPLAY);
    if (dpy == EGL_NO_DISPLAY || !eglInitialize(dpy, nullptr, nullptr)) return env->NewStringUTF("");

    const EGLint cfgAttr[] = {EGL_RENDERABLE_TYPE, EGL_OPENGL_ES3_BIT_KHR, EGL_SURFACE_TYPE, EGL_PBUFFER_BIT,
                              EGL_RED_SIZE, 8, EGL_GREEN_SIZE, 8, EGL_BLUE_SIZE, 8, EGL_ALPHA_SIZE, 8, EGL_NONE};
    EGLConfig cfg; EGLint n = 0;
    if (!eglChooseConfig(dpy, cfgAttr, &cfg, 1, &n) || n < 1) return env->NewStringUTF("");
    const EGLint ctxAttr[] = {EGL_CONTEXT_CLIENT_VERSION, 3, EGL_NONE};
    EGLContext ctx = eglCreateContext(dpy, cfg, EGL_NO_CONTEXT, ctxAttr);
    const EGLint pbAttr[] = {EGL_WIDTH, 1, EGL_HEIGHT, 1, EGL_NONE};
    EGLSurface pb = eglCreatePbufferSurface(dpy, cfg, pbAttr);

    std::string json;
    if (ctx != EGL_NO_CONTEXT && pb != EGL_NO_SURFACE && eglMakeCurrent(dpy, pb, pb, ctx)) {
        Result r = ProbeCurrentContext();
        char buf[512];
        snprintf(buf, sizeof(buf),
                 "{\"renderer\":\"%s\",\"major\":%d,\"minor\":%d,\"f16Render\":%s,\"f16Linear\":%s,"
                 "\"f32Render\":%s,\"f32Linear\":%s,\"f32Blend\":%s}",
                 r.renderer.c_str(), r.major, r.minor, r.f16Render ? "true" : "false",
                 r.f16Linear ? "true" : "false", r.f32Render ? "true" : "false",
                 r.f32Linear ? "true" : "false", r.f32Blend ? "true" : "false");
        json = buf;
        eglMakeCurrent(dpy, EGL_NO_SURFACE, EGL_NO_SURFACE, EGL_NO_CONTEXT);
    }
    if (pb != EGL_NO_SURFACE) eglDestroySurface(dpy, pb);
    if (ctx != EGL_NO_CONTEXT) eglDestroyContext(dpy, ctx);
    if (oldCtx != EGL_NO_CONTEXT) eglMakeCurrent(oldDpy, oldDraw, oldRead, oldCtx);
    return env->NewStringUTF(json.c_str());
}

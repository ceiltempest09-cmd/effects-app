// Host test for spirv_reflect: a hand-built module (no compiler needed). Build: g++ -std=c++20 -I../../shared/cpp spirv_reflect_test.cpp ../../shared/cpp/spirv_reflect.cpp
#include "spirv_reflect.h"
#include <cstdio>
#include <cstring>

using namespace am::rg;
static int gFail = 0, gChecks = 0;
#define CHECK(c) do { gChecks++; if (!(c)) { gFail++; std::printf("FAIL line %d: %s\n", __LINE__, #c); } } while (0)

static void Emit(std::vector<uint32_t>& w, uint32_t op, std::vector<uint32_t> operands) { w.push_back(((uint32_t)operands.size() + 1u) << 16 | op); w.insert(w.end(), operands.begin(), operands.end()); }
static std::vector<uint32_t> StrWords(const char* s) { std::vector<uint32_t> v((std::strlen(s) + 4) / 4, 0); std::memcpy(v.data(), s, std::strlen(s)); return v; }
static void Name(std::vector<uint32_t>& w, uint32_t id, const char* s) { auto v = StrWords(s); v.insert(v.begin(), id); Emit(w, 5, v); }
static void MemberName(std::vector<uint32_t>& w, uint32_t id, uint32_t m, const char* s) { auto v = StrWords(s); v.insert(v.begin(), m); v.insert(v.begin(), id); Emit(w, 6, v); }

int main() {
    std::vector<uint32_t> w = {0x07230203u, 0x00010300u, 0, 100, 0};
    // ids: 1 float, 2 vec4, 3 vec2, 4 uint, 5 const 3, 6 float[3], 7 struct Params, 8 ptr(Uniform,7), 9 var ubo, 10 image, 11 sampledImage, 12 ptr(UC,11), 13 var src, 14 ptr(Output,2), 15 var out, 16 int, 17 ivec2? skip
    Name(w, 7, "Params"); MemberName(w, 7, 0, "tint"); MemberName(w, 7, 1, "size"); MemberName(w, 7, 2, "gain"); MemberName(w, 7, 3, "arr"); MemberName(w, 7, 4, "count");
    Name(w, 13, "src"); Name(w, 9, "u");
    Emit(w, 71, {7, 2});                              // Block
    Emit(w, 72, {7, 0, 35, 0}); Emit(w, 72, {7, 1, 35, 16}); Emit(w, 72, {7, 2, 35, 24}); Emit(w, 72, {7, 3, 35, 32}); Emit(w, 72, {7, 4, 35, 80});
    Emit(w, 71, {6, 6, 16});                          // ArrayStride 16
    Emit(w, 71, {9, 34, 0}); Emit(w, 71, {9, 33, 0}); Emit(w, 71, {13, 34, 0}); Emit(w, 71, {13, 33, 1}); Emit(w, 71, {15, 30, 0});
    Emit(w, 22, {1, 32}); Emit(w, 23, {2, 1, 4}); Emit(w, 23, {3, 1, 2}); Emit(w, 21, {4, 32, 0}); Emit(w, 43, {4, 5, 3});
    Emit(w, 28, {6, 1, 5}); Emit(w, 21, {16, 32, 1});
    Emit(w, 30, {7, 2, 3, 1, 6, 16});
    Emit(w, 32, {8, 2, 7}); Emit(w, 59, {8, 9, 2});
    Emit(w, 25, {10, 1, 1, 0, 0, 0, 1, 0}); Emit(w, 27, {11, 10}); Emit(w, 32, {12, 0, 11}); Emit(w, 59, {12, 13, 0});
    Emit(w, 32, {14, 3, 2}); Emit(w, 59, {14, 15, 3});

    SpirvReflection r; std::string err;
    CHECK(ReflectSpirv(w, &r, &err));
    CHECK(r.blocks.size() == 1);
    if (r.blocks.size() == 1) {
        const SpirvBlock& b = r.blocks[0];
        CHECK(b.name == "Params" && b.set == 0 && b.binding == 0);
        CHECK(b.members.size() == 5);
        if (b.members.size() == 5) {
            CHECK(b.members[0].name == "tint" && b.members[0].rows == 4 && b.members[0].offset == 0 && b.members[0].base == SpirvMember::Float);
            CHECK(b.members[1].name == "size" && b.members[1].rows == 2 && b.members[1].offset == 16);
            CHECK(b.members[2].name == "gain" && b.members[2].rows == 1 && b.members[2].offset == 24);
            CHECK(b.members[3].name == "arr" && b.members[3].arrayLength == 3 && b.members[3].arrayStride == 16 && b.members[3].offset == 32);
            CHECK(b.members[4].name == "count" && b.members[4].base == SpirvMember::Int && b.members[4].offset == 80);
        }
        CHECK(b.size == 96);
    }
    CHECK(r.samplers.size() == 1 && r.samplers[0].name == "src" && r.samplers[0].binding == 1);
    CHECK(r.outputCount == 1);
    CHECK(!r.pushConstants && !r.storageBuffers && !r.otherResources);

    // fragment inputs: a user 'in' is counted, a built-in (gl_FragCoord, BuiltIn 15) is not
    {
        std::vector<uint32_t> v = w;
        Emit(v, 32, {20, 1, 2}); Emit(v, 59, {20, 21, 1});           // ptr(Input, vec4), var 21 (user input)
        Emit(v, 59, {20, 22, 1}); Emit(v, 71, {22, 11, 15});          // var 22 decorated BuiltIn FragCoord
        SpirvReflection ri; std::string e2;
        CHECK(ReflectSpirv(v, &ri, &e2));
        CHECK(ri.inputCount == 1);
        CHECK(r.inputCount == 0);                                     // the base module has none
    }
    // push constants and storage buffers are reported (the backend rejects them with a message)
    {
        std::vector<uint32_t> v = w;
        Emit(v, 32, {23, 9, 7}); Emit(v, 59, {23, 24, 9});
        SpirvReflection rp; std::string e2;
        CHECK(ReflectSpirv(v, &rp, &e2) && rp.pushConstants && !rp.storageBuffers);
        std::vector<uint32_t> u = w;
        Emit(u, 32, {25, 12, 7}); Emit(u, 59, {25, 26, 12});
        SpirvReflection rs;
        CHECK(ReflectSpirv(u, &rs, &e2) && rs.storageBuffers && !rs.pushConstants);
    }
    // a uniform block member without an Offset decoration is refused with a message, a wrong version/short header is refused
    {
        std::vector<uint32_t> shortHeader(w.begin(), w.begin() + 4);
        SpirvReflection rh; std::string e2;
        CHECK(!ReflectSpirv(shortHeader, &rh, &e2) && !e2.empty());
        std::vector<uint32_t> overrun = w; overrun.push_back((50u << 16) | 71);   // instruction claims 50 words, none follow
        CHECK(!ReflectSpirv(overrun, &rh, &e2) && !e2.empty());
    }

    std::vector<uint32_t> bad = {1, 2, 3};
    CHECK(!ReflectSpirv(bad, &r, &err));
    std::vector<uint32_t> trunc = w; trunc[5] = (0u << 16) | 5;   // zero word count
    CHECK(!ReflectSpirv(trunc, &r, &err));

    std::printf("spirv_reflect_test: %d checks, %d failed\n", gChecks, gFail);
    return gFail ? 1 : 0;
}

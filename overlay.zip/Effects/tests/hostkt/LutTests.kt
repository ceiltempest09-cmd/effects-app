import com.effects.motion.effects.LutEffect
import com.effects.motion.effects.engine.CubeLut
import com.effects.motion.effects.engine.CubeLutResult
import com.effects.motion.effects.graph.*
import org.json.JSONObject

object LutTests {
    fun run() {
        section("lut effect")
        val text = "TITLE \"Test LUT\"\nLUT_3D_SIZE 2\n" + (0 until 8).joinToString("\n") { i -> "${i and 1} ${(i shr 1) and 1} ${(i shr 2) and 1}" } + "\n"
        val lut = (CubeLut.parse(text) as CubeLutResult.Ok).lut
        val hash = LutEffect.hash(text.toByteArray())
        check(hash.length == 10 && hash == LutEffect.hash(text.toByteArray()), "hash is stable")
        val built = LutEffect.build("Test LUT", lut, hash, "/data/x/luts/$hash.lut16")
        check(built.key == "lut_test_lut_$hash", "key ${built.key}")
        val json = JSONObject(built.json.toString())
        check(GraphJson.isGraph(json), "is a graph effect")
        val parsed = GraphJson.parse(json, "fx.${built.key}")
        val issues = parsed.issues + GraphValidator.validate("fx.${built.key}", parsed.graph!!)
        check(!issues.hasError, "validates: ${issues.errors()}")
        val g = parsed.graph
        check(g.textures.size == 1 && g.textures[0].source.startsWith("lutf16:") && g.textures[0].width == 4 && g.textures[0].height == 2, "texture is the 2x1 tiled layout (4x2): ${g.textures.map { it.width to it.height }}")
        val params = json.getJSONArray("params")
        val ids = (0 until params.length()).map { params.getJSONObject(it).getString("id") }
        for (pass in g.passes) {
            val uniforms = Regex("""uniform\s+(?:float|float2|float3|float4|half4|int)\s+(\w+)\s*;""").findAll(pass.source).map { it.groupValues[1] }
            for (u in uniforms) check(u in ids || u in pass.constants || u in setOf("size", "time", "frame") || u.endsWith("_px"), "uniform '$u' has a value")
            val children = Regex("""uniform\s+shader\s+(\w+)\s*;""").findAll(pass.source).map { it.groupValues[1] }.toSet()
            check(children == pass.inputs.map { it.name }.toSet(), "children $children match inputs")
        }
        check(g.passes[0].constants["n"] == listOf(2f) && g.passes[0].constants["cols"] == listOf(2f) && g.passes[0].constants["dmax"] == listOf(1f, 1f, 1f), "constants carry size, columns and domain")
        // a LUT texture without the skia backend must be refused, not silently run elsewhere
        val noSkia = JSONObject(built.json.toString()); noSkia.getJSONObject("requires").put("backends", org.json.JSONArray())
        val p2 = GraphJson.parse(noSkia, "fx.x")
        check((p2.issues + GraphValidator.validate("fx.x", p2.graph!!)).hasError, "LUT file without skia backend is an error")
        check(runCatching { LutEffect.build("x", (CubeLut.parse("LUT_1D_SIZE 2\n0 0 0\n1 1 1\n") as CubeLutResult.Ok).lut, hash, "/x") }.isFailure, "1D LUT refused")
    }
}

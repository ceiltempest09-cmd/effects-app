package com.effects.motion.media

import com.effects.motion.model.Scene

internal data class PreviewVideoStamp(val scene: Scene, val timeMs: Int, val playing: Boolean, val uri: String? = null) {
    fun matches(scene: Scene, timeMs: Int, playing: Boolean): Boolean =
        this.scene == scene && if (playing) this.playing || this.timeMs == timeMs else this.timeMs == timeMs
}

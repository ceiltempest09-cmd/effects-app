package com.effects.motion.engine.bitdepth

import android.content.Context
import android.os.Build
import org.json.JSONObject

/**
 * Result of the native GPU probe (see gpu_caps.cpp). Fields are *verified* by creating
 * framebuffers and reading values back, not just by looking at extension strings.
 */
data class GpuCapabilities(
    val renderer: String = "unknown",
    val glMajor: Int = 3, val glMinor: Int = 0,
    val rgba16fRenderable: Boolean = false,
    val rgba16fLinear: Boolean = true,      // core in ES 3.0
    val rgba32fRenderable: Boolean = false,
    val rgba32fLinear: Boolean = false,     // OES_texture_float_linear
    val rgba32fBlend: Boolean = false,      // EXT_float_blend
    val probeOk: Boolean = false
) {
    companion object {
        /** Safe-mode result: 8-bit only. Used if the probe fails or crashed last time. */
        val SAFE = GpuCapabilities()

        fun fromJson(s: String): GpuCapabilities = runCatching {
            val j = JSONObject(s)
            GpuCapabilities(
                j.optString("renderer", "unknown"), j.optInt("major", 3), j.optInt("minor", 0),
                j.optBoolean("f16Render"), j.optBoolean("f16Linear", true),
                j.optBoolean("f32Render"), j.optBoolean("f32Linear"), j.optBoolean("f32Blend"),
                probeOk = true
            )
        }.getOrDefault(SAFE)
    }
}

object GpuProbe {
    private const val PREFS = "gpu_probe"

    init { System.loadLibrary("amengine") }     // or add gpu_caps.cpp to your existing native lib
    private external fun nativeProbe(): String

    /**
     * Call once at app start. Cached per driver build, so it normally runs once per OS update.
     * The "inProgress" marker means: if a previous probe hard-crashed in a buggy driver, we never
     * try again for that build and stay in 8-bit safe mode.
     */
    fun get(ctx: Context): GpuCapabilities {
        val p = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val key = Build.FINGERPRINT
        if (p.getString("key", null) == key) {
            if (p.getBoolean("inProgress", false)) return GpuCapabilities.SAFE
            p.getString("json", null)?.let { return GpuCapabilities.fromJson(it) }
        }
        p.edit().putString("key", key).putBoolean("inProgress", true).commit()   // sync write
        val json = runCatching { nativeProbe() }.getOrDefault("")
        val caps = if (json.isEmpty()) GpuCapabilities.SAFE else GpuCapabilities.fromJson(json)
        p.edit().putString("json", json).putBoolean("inProgress", false).apply()
        return caps
    }
}

/** Resolved once, then handed to the UI and the renderer. */
class RenderDepthController(ctx: Context) {
    val caps = GpuProbe.get(ctx)
    val policy = BitDepthPolicy(caps)
    var settings = BitDepthSettings.load(ctx)
        private set

    /** What the renderer must allocate right now. Pass isExport=true from the exporter. */
    fun workingDepth(isExport: Boolean): BitDepth = policy.effective(settings.requested(isExport))

    /** Settings UI calls this. Unsupported choices are rejected (UI also greys them out). */
    fun setEditDepth(ctx: Context, d: BitDepth): Boolean {
        if (!policy.isSupported(d)) return false
        settings = settings.copy(editDepth = d).also { it.save(ctx) }
        return true
    }
}

// Host tests for the backend-neutral parts of native shader execution: #version/#extension checks, compiler-log -> file:line,
// pre-compiled SPIR-V reading, the persistent shader cache. No GPU and no shader compiler is involved (none exists on the host).
//   g++ -std=c++20 -fno-exceptions -fno-rtti -I shared/cpp tests/native/native_shader_test.cpp shared/cpp/render_graph.cpp
//       shared/cpp/shader_info.cpp shared/cpp/shader_diag.cpp shared/cpp/shader_cache.cpp shared/cpp/spirv_util.cpp
#include "shader_cache.h"
#include "shader_diag.h"
#include "shader_info.h"
#include "spirv_util.h"

#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <unistd.h>

using namespace am::rg;

static int gFailed = 0, gChecks = 0;
#define CHECK(cond) do { gChecks++; if (!(cond)) { gFailed++; std::printf("  FAIL %s:%d  %s\n", __FILE__, __LINE__, #cond); } } while (0)
static bool Has(const std::string& s, const char* n) { return s.find(n) != std::string::npos; }

static GlslDevice Es(int major, int minor) { GlslDevice d; d.esMajor = major; d.esMinor = minor; d.extensions = {"GL_OES_standard_derivatives", "GL_EXT_color_buffer_float"}; return d; }

static void TestHeader() {
    std::printf("#version / #extension parsing and device checks\n");
    std::string why; int line = 0;
    {
        const auto h = ParseShaderHeader("// c\n/* multi\nline */\n#version 300 es\nprecision highp float;\n#extension GL_EXT_color_buffer_float : require\nvoid main(){}");
        CHECK(h.ok && h.version == 300 && h.profile == ShaderHeader::ES && h.versionLine == 4);
        CHECK(h.extensions.size() == 1 && h.extensions[0].line == 6 && h.extensions[0].behavior == "require");
        CHECK(CheckGlslHeader(Lang::GLSLES, h, Es(3, 0), &why, &line));
    }
    {   // ES 3.2 on a 3.1 device -> blames the #version line
        const auto h = ParseShaderHeader("\n#version 320 es\nvoid main(){}");
        CHECK(!CheckGlslHeader(Lang::GLSLES, h, Es(3, 1), &why, &line) && line == 2 && Has(why, "3.2") && Has(why, "3.1"));
    }
    {   // 3.00 needs the 'es' profile word
        const auto h = ParseShaderHeader("#version 300\nvoid main(){}");
        CHECK(!CheckGlslHeader(Lang::GLSLES, h, Es(3, 2), &why, &line) && Has(why, "es") && line == 1);
    }
    {   // no #version = GLSL ES 1.00
        const auto h = ParseShaderHeader("precision mediump float;\nvoid main(){}");
        CHECK(h.ok && h.version == 0 && CheckGlslHeader(Lang::GLSLES, h, Es(3, 0), &why, &line));
    }
    {   // required extension missing -> that line; 'enable' only warns
        const auto h = ParseShaderHeader("#version 310 es\n#extension GL_EXT_nope : enable\n#extension GL_EXT_gone : require\nvoid main(){}");
        std::vector<std::string> warn;
        CHECK(!CheckGlslHeader(Lang::GLSLES, h, Es(3, 1), &why, &line, &warn) && line == 3 && Has(why, "GL_EXT_gone"));
        const auto h2 = ParseShaderHeader("#version 310 es\n#extension GL_EXT_nope : enable\nvoid main(){}");
        warn.clear();
        CHECK(CheckGlslHeader(Lang::GLSLES, h2, Es(3, 1), &why, &line, &warn) && warn.size() == 1 && Has(warn[0], "line 2"));
    }
    {   // code before #version, #include, malformed directives
        CHECK(!ParseShaderHeader("float x;\n#version 300 es\n").ok);
        CHECK(ParseShaderHeader("float x;\n#version 300 es\n").errorLine == 2);
        const auto inc = ParseShaderHeader("#version 450\n#include \"a.glsl\"\n");
        CHECK(inc.ok && inc.includeLine == 2);
        CHECK(!CheckGlslHeader(Lang::VulkanGLSL, inc, [] { GlslDevice d; d.vulkanGlsl = true; return d; }(), &why, &line) && line == 2 && Has(why, "#include"));
        CHECK(!ParseShaderHeader("#version abc\n").ok && !ParseShaderHeader("#extension X require\n").ok && !ParseShaderHeader("#version 300 es\n#version 300 es\n").ok);
    }
    {   // desktop GLSL: a GLES/Vulkan-only device cannot accept it as written; es-source under lang=glsl is a language mistake
        const auto h = ParseShaderHeader("#version 330 core\nvoid main(){}");
        CHECK(!CheckGlslHeader(Lang::GLSL, h, Es(3, 2), &why, &line) && Has(why, "no desktop GLSL"));
        GlslDevice d; d.desktopVersion = 450;
        CHECK(CheckGlslHeader(Lang::GLSL, h, d, &why, &line));
        CHECK(!CheckGlslHeader(Lang::GLSL, ParseShaderHeader("#version 460\n"), d, &why, &line) && Has(why, "460"));
        CHECK(!CheckGlslHeader(Lang::GLSL, ParseShaderHeader("#version 300 es\n"), d, &why, &line) && Has(why, "glsl-es"));
    }
    {   // Vulkan GLSL needs a compiler + version 450/460 or 310/320 es
        GlslDevice off; GlslDevice on; on.vulkanGlsl = true;
        CHECK(!CheckGlslHeader(Lang::VulkanGLSL, ParseShaderHeader("#version 450\n"), off, &why, &line) && Has(why, "cannot compile Vulkan GLSL"));
        CHECK(CheckGlslHeader(Lang::VulkanGLSL, ParseShaderHeader("#version 450\n"), on, &why, &line));
        CHECK(CheckGlslHeader(Lang::VulkanGLSL, ParseShaderHeader("#version 310 es\n"), on, &why, &line));
        CHECK(!CheckGlslHeader(Lang::VulkanGLSL, ParseShaderHeader("#version 330\n"), on, &why, &line));
        CHECK(!CheckGlslHeader(Lang::VulkanGLSL, ParseShaderHeader("void main(){}\n"), on, &why, &line) && Has(why, "#version"));
    }
}

static void TestLogMapping() {
    std::printf("compiler log -> file:line of the original source\n");
    PassDesc p; p.id = "blur"; p.file = "fx/blur.json"; p.line = 30;      // author's line 1 sits on line 30 of the file
    {   // glslang / shaderc; the backend added 5 prelude lines
        const std::string log = "ERROR: 0:12: 'foo' : undeclared identifier\nERROR: 0:14: '' : compilation terminated\nERROR: 2 compilation errors.  No code generated.\n";
        const auto d = MapCompilerLog(p, 1, "fx.blur", "vulkan/glslang", log, 5);
        CHECK(d.size() >= 2 && d[0].line == 30 + (12 - 5) - 1 && d[0].file == "fx/blur.json" && Has(d[0].message, "undeclared identifier") && d[0].pass == "blur");
        CHECK(d[1].line == 30 + (14 - 5) - 1);
        CHECK(d[0].format().find("fx/blur.json:36") != std::string::npos && Has(d[0].format(), "backend vulkan/glslang"));
    }
    {   // Mesa / Android Mesa-like
        const auto e = ParseCompilerLog("0:7(12): error: `x' undeclared\n0:9(1): warning: unused\n");
        CHECK(e.size() == 2 && e[0].error && e[0].line == 7 && e[0].column == 12 && Has(e[0].message, "undeclared") && !e[1].error && e[1].line == 9);
    }
    {   // vendor GLES drivers, with and without a column, and a continuation line
        const auto e = ParseCompilerLog("ERROR: 0:3: 'gl_FragColor' : undeclared identifier\n  (use an out variable)\nWARNING: 0:8:5: something\n");
        CHECK(e.size() == 2 && e[0].line == 3 && Has(e[0].message, "gl_FragColor") && Has(e[0].message, "out variable") && !e[1].error && e[1].line == 8 && e[1].column == 5);
    }
    {   // "file:line: error:" form and SkSL-like "error: N: msg"
        const auto e = ParseCompilerLog("blur.frag:21: error: syntax error\nerror: 4: bad token\n");
        CHECK(e.size() == 2 && e[0].line == 21 && e[1].line == 4 && Has(e[1].message, "bad token"));
    }
    {   // a log line without a number points at the pass' first line, and a line inside the prelude never goes above it
        const auto d = MapCompilerLog(p, 0, "fx", "b", "ERROR: link failed\nERROR: 0:2: in prelude\n", 5);
        CHECK(d.size() == 2 && d[0].line == 30 && d[1].line == 30);
    }
}

static std::vector<uint8_t> Module(bool swapped, uint32_t version = 0x00010000u, bool entry = true) {
    std::vector<uint32_t> w = {0x07230203u, version, 0, 12, 0};
    w.push_back(2u << 16 | 17); w.push_back(1);                                 // OpCapability Shader
    w.push_back(2u << 16 | 17); w.push_back(9);                                 // OpCapability Float16
    w.push_back(2u << 16 | 10); w.push_back(0);                                 // OpExtension "" (one empty string word)
    if (entry) { w.push_back(5u << 16 | 15); w.push_back(4); w.push_back(1); w.push_back(0x6e69616du); w.push_back(0); }   // OpEntryPoint Fragment %1 "main"
    std::vector<uint8_t> b;
    for (uint32_t v : w) {
        if (swapped) v = (v >> 24) | ((v >> 8) & 0xFF00) | ((v << 8) & 0xFF0000) | (v << 24);
        b.insert(b.end(), (uint8_t*)&v, (uint8_t*)&v + 4);
    }
    return b;
}

static void TestSpirv() {
    std::printf("pre-compiled SPIR-V: transport and validation\n");
    SpirvInfo info; std::string err;
    CHECK(ParseSpirv(Module(false), &info, &err) && info.version == 0x00010000u && info.entryPoints.size() == 1 && info.entryPoints[0].name == "main" && info.entryPoints[0].model == 4);
    CHECK(info.capabilities.size() == 2 && SpirvCapabilityText(info.capabilities[1]) == "Float16" && SpirvCapabilityText(9999) == "capability #9999");
    CHECK(ParseSpirv(Module(true), &info, &err) && info.entryPoints.size() == 1);                // other byte order
    CHECK(!ParseSpirv(Module(false, 0x00020000u), &info, &err) && Has(err, "version"));
    CHECK(!ParseSpirv(Module(false, 0x00010000u, false), &info, &err) && Has(err, "OpEntryPoint"));
    std::vector<uint8_t> bad = Module(false); bad[0] = 0;
    CHECK(!ParseSpirv(bad, &info, &err) && Has(err, "magic"));
    std::vector<uint8_t> cut = Module(false); cut.resize(cut.size() - 2);
    CHECK(!ParseSpirv(cut, &info, &err) && Has(err, "32-bit"));
    std::vector<uint8_t> run = Module(false); run[20] = 0; run[21] = 0; run[22] = 0; run[23] = 0;   // an instruction with word count 0
    CHECK(!ParseSpirv(run, &info, &err) && Has(err, "word count"));
    std::vector<uint8_t> over = Module(false); over[22] = 0x40;                                      // word count larger than the module
    CHECK(!ParseSpirv(over, &info, &err));

    const std::vector<uint8_t> m = Module(false);
    const std::string text = Base64Encode(m.data(), m.size());
    std::vector<uint8_t> back;
    CHECK(Base64Decode(text, &back) && back == m);
    CHECK(Base64Decode(std::string("TWFu\nTWE=\n"), &back) && back.size() == 5 && std::memcmp(back.data(), "ManMa", 5) == 0);
    CHECK(!Base64Decode("TWF$", &back) && !Base64Decode("TWF", &back) && !Base64Decode("TQ==TQ==", &back));
    for (size_t n = 0; n < 12; n++) { std::vector<uint8_t> v(n, 0xAB), r; CHECK(Base64Decode(Base64Encode(v.data(), v.size()), &r) && r == v); }
}

static void TestCache() {
    std::printf("shader cache: key, round trip, corruption, eviction\n");
    char tmpl[] = "/tmp/amsc-XXXXXX";
    const std::string dir = mkdtemp(tmpl);
    PassDesc a; a.lang = Lang::GLSLES; a.source = "void main(){}"; a.defines = {{"A", "1"}, {"B", "2"}};
    PassDesc b = a; b.defines = {{"B", "2"}, {"A", "1"}};
    const uint64_t k = ShaderCacheKey(a, "glslang-14.3", "vulkan:Adreno 740:512.7", 1);
    CHECK(k == ShaderCacheKey(b, "glslang-14.3", "vulkan:Adreno 740:512.7", 1));
    PassDesc c = a; c.source += " ";
    PassDesc d = a; d.lang = Lang::GLSL;
    PassDesc e = a; e.defines["A"] = "2";
    CHECK(k != ShaderCacheKey(c, "glslang-14.3", "vulkan:Adreno 740:512.7", 1) && k != ShaderCacheKey(d, "glslang-14.3", "vulkan:Adreno 740:512.7", 1) &&
          k != ShaderCacheKey(e, "glslang-14.3", "vulkan:Adreno 740:512.7", 1) && k != ShaderCacheKey(a, "glslang-14.4", "vulkan:Adreno 740:512.7", 1) &&
          k != ShaderCacheKey(a, "glslang-14.3", "vulkan:Adreno 740:512.8", 1) && k != ShaderCacheKey(a, "glslang-14.3", "vulkan:Adreno 740:512.7", 2));

    ShaderCache cache(dir, 4096);
    std::vector<uint8_t> payload(300), got;
    for (size_t i = 0; i < payload.size(); i++) payload[i] = (uint8_t)(i * 7);
    CHECK(!cache.load(k, &got));
    CHECK(cache.store(k, payload.data(), payload.size()) && cache.load(k, &got) && got == payload);
    char name[64]; std::snprintf(name, sizeof(name), "/%016llx.amsc", (unsigned long long)k);
    {   // flip one payload byte: checksum fails, the entry is removed and reported as a miss
        FILE* f = std::fopen((dir + name).c_str(), "r+b"); std::fseek(f, 40, SEEK_SET); std::fputc(0xEE, f); std::fclose(f);
        CHECK(!cache.load(k, &got) && access((dir + name).c_str(), F_OK) != 0);
    }
    CHECK(cache.store(k, payload.data(), payload.size()));
    {   // truncated (torn) file
        FILE* f = std::fopen((dir + name).c_str(), "r+b"); CHECK(ftruncate(fileno(f), 100) == 0); std::fclose(f);
        CHECK(!cache.load(k, &got) && access((dir + name).c_str(), F_OK) != 0);
    }
    CHECK(!ShaderCache("", 100).store(k, payload.data(), 1) && !cache.store(7, payload.data(), 5000));     // no dir / larger than the budget
    cache.clear();
    for (uint64_t i = 1; i <= 40; i++) { CHECK(cache.store(i, payload.data(), payload.size())); }            // 40 x 332 bytes > 4096
    CHECK(cache.bytes() <= 4096 && cache.bytes() > 0);
    CHECK(cache.load(40, &got) && got == payload);                                                          // newest survives
    cache.clear();
    CHECK(cache.bytes() == 0);
    rmdir(dir.c_str());
}

int main() {
    TestHeader();
    TestLogMapping();
    TestSpirv();
    TestCache();
    std::printf("\n%d checks, %d failed\n", gChecks, gFailed);
    return gFailed ? 1 : 0;
}

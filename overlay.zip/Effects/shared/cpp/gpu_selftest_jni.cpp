#include <jni.h>
#include <string>
#include "gpu_selftest.h"

extern "C" JNIEXPORT jstring JNICALL Java_com_effects_motion_engine_GpuSelfTest_nativeRun(JNIEnv* env, jclass, jstring cacheDir) {
    const char* c = cacheDir ? env->GetStringUTFChars(cacheDir, nullptr) : nullptr;
    std::string dir = c ? c : "";
    if (c) env->ReleaseStringUTFChars(cacheDir, c);
    return env->NewStringUTF(am::RunGpuSelfTest(dir).c_str());
}

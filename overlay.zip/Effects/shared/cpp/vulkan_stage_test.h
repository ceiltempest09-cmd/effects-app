// vulkan_stage_test.h - phase 5B GPU Test stage for the Vulkan effect backend (see vulkan_stage_test.cpp).
#pragma once
#include <string>
namespace am {
// Appends PASS/FAIL/SKIP lines to *text and counts them. Crumb file <cacheDir>/vkstage.stage guards against a crash inside.
void RunVulkanStageTests(std::string* text, int* pass, int* fail, const std::string& cacheDir);
}

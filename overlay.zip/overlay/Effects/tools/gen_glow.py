#!/usr/bin/env python3
"""Generates shared/assets/effects/glow.json (unified Glow engine, effect schema 2). Run from the Effects folder."""
import json, os

LEVELS = 5  # scales 1/2 .. 1/32
SC = [0.5 ** (i + 1) for i in range(LEVELS)]
MODES = ["Cinematic Bloom", "Soft Glow", "Diffusion", "Highlight", "Atmospheric", "Neon", "Edge-aware", "Multi-scale", "Anamorphic"]
BLENDS = ["Add", "Screen", "Lighten"]

def lines(s): return s.strip("\n").split("\n")

BRIGHT = lines("""
uniform shader image;
uniform float2 size;
uniform float2 image_px;
uniform float threshold;
uniform float softness;
uniform float mode;
float luma(half4 c) { return max(c.r, max(c.g, c.b)); }
half4 main(float2 p) {
  float2 t = (size / image_px) * 0.5;
  half4 c = (image.eval(p + t * float2(-1.0, -1.0)) + image.eval(p + t * float2(1.0, -1.0))
           + image.eval(p + t * float2(-1.0, 1.0)) + image.eval(p + t * float2(1.0, 1.0))) * 0.25;
  float m = smoothstep(threshold, threshold + max(softness, 0.001), luma(c));
  if (mode == 6.0) {
    float2 e = (size / image_px) * 1.5;
    float l0 = luma(image.eval(p));
    float g = abs(luma(image.eval(p + float2(e.x, 0.0))) - l0) + abs(luma(image.eval(p - float2(e.x, 0.0))) - l0)
            + abs(luma(image.eval(p + float2(0.0, e.y))) - l0) + abs(luma(image.eval(p - float2(0.0, e.y))) - l0);
    m *= 0.2 + 0.8 * smoothstep(0.02, 0.3, g);
  }
  return c * half(m);
}
""")

DOWN = lines("""
uniform shader image;
uniform float2 size;
uniform float2 image_px;
half4 main(float2 p) {
  float2 t = (size / image_px) * 0.5;
  half4 c = image.eval(p + t * float2(-1.0, -1.0)) + image.eval(p + t * float2(1.0, -1.0))
          + image.eval(p + t * float2(-1.0, 1.0)) + image.eval(p + t * float2(1.0, 1.0));
  return c * 0.25;
}
""")

def blur(horizontal):
    d = "float2(1.0, 0.0)" if horizontal else "float2(0.0, 1.0)"
    stretch = "(mode == 8.0 ? 1.0 + stretch : 1.0)" if horizontal else "(mode == 8.0 ? 0.35 : 1.0)"
    return lines(f"""
uniform shader image;
uniform float2 size;
uniform float2 image_px;
uniform float spread;
uniform float stretch;
uniform float mode;
half4 main(float2 p) {{
  float2 t = (size / image_px) * {d} * spread * {stretch};
  half4 c = image.eval(p) * 0.2270270270;
  c += (image.eval(p + t * 1.3846153846) + image.eval(p - t * 1.3846153846)) * 0.3162162162;
  c += (image.eval(p + t * 3.2307692308) + image.eval(p - t * 3.2307692308)) * 0.0702702703;
  return c;
}}
""")

LV = "\n".join(f"uniform shader l{i};" for i in range(LEVELS))
SUM = "\n".join(f"  w[{i}] = exp(-pow((float({i}) - ctr) / sig, 2.0));" for i in range(LEVELS))
ACC = "\n".join(f"  g += l{i}.eval(p).rgb * half(w[{i}] / ws);" for i in range(LEVELS))
MIX = lines(f"""
uniform shader image;
{LV}
uniform float mode;
uniform float intensity;
uniform float radius;
uniform float protect;
uniform float srcAmount;
uniform float blend;
layout(color) uniform half4 tint;
half4 main(float2 p) {{
  half4 s = image.eval(p);
  float ctr = radius * {LEVELS - 1}.0;
  float sig = 1.5;
  if (mode == 0.0) {{ sig = 1.6; }}
  else if (mode == 1.0) {{ sig = 1.2; }}
  else if (mode == 2.0) {{ sig = 2.6; }}
  else if (mode == 3.0) {{ sig = 0.9; }}
  else if (mode == 4.0) {{ ctr = max(ctr, 2.5); sig = 1.4; }}
  else if (mode == 5.0) {{ ctr = min(ctr, 1.0); sig = 0.7; }}
  else if (mode == 6.0) {{ sig = 1.2; }}
  else if (mode == 7.0) {{ sig = 100.0; }}
  else {{ sig = 1.6; }}
  float w[{LEVELS}];
{SUM}
  float ws = 0.0001;
  for (int i = 0; i < {LEVELS}; i++) {{ ws += w[i]; }}
  half3 g = half3(0.0);
{ACC}
  g *= tint.rgb * half(intensity);
  half pr = half(protect);
  g = g * (1.0 + pr) / (1.0 + pr * g);
  half sl = max(s.r, max(s.g, s.b));
  g *= 1.0 - 0.5 * pr * clamp(sl, 0.0, 1.0);
  s *= half(srcAmount);
  half3 outc;
  if (blend == 1.0) {{ half3 gc = clamp(g, 0.0, 1.0); outc = s.rgb + gc - s.rgb * gc; }}
  else if (blend == 2.0) {{ outc = max(s.rgb, g); }}
  else {{ outc = s.rgb + g; }}
  half a = clamp(max(s.a, max(g.r, max(g.g, g.b))), 0.0, 1.0);
  return half4(min(outc, half3(a)), a);
}}
""")

def f(i, label, d, lo, hi, step, **kw):
    return dict(id=i, label=label, type="float", default=d, min=lo, max=hi, step=step, **kw)

params = [
    dict(id="mode", label="Mode", type="choice", default=0, options=MODES),
    f("threshold", "Threshold", 0.55, 0, 1, 0.01, percent=True),
    f("softness", "Softness", 0.2, 0, 1, 0.01, percent=True),
    f("intensity", "Intensity", 1.4, 0, 4, 0.05),
    f("radius", "Radius", 0.5, 0, 1, 0.01, percent=True),
    f("spread", "Spread", 1.0, 0.25, 3, 0.05),
    dict(f("stretch", "Streak length", 3.0, 0, 8, 0.1), when={"mode": [8]}),
    f("protect", "Highlight protection", 0.5, 0, 4, 0.05),
    f("srcAmount", "Source amount", 1.0, 0, 1, 0.01, percent=True),
    dict(id="blend", label="Blend", type="choice", default=0, options=BLENDS),
    dict(id="tint", label="Glow color", type="color", default="#ffffff"),
]

buffers, passes = [], []
def buf(i, scale): buffers.append(dict(id=i, scale=scale, format="rgba16f", filter="linear"))
buf("a0", SC[0])
passes.append(dict(id="bright", lang="sksl", source=BRIGHT, inputs={"image": "source"}, output="a0"))
for i in range(1, LEVELS):
    buf(f"a{i}", SC[i])
    passes.append(dict(id=f"down{i}", lang="sksl", source=DOWN, inputs={"image": f"buffer:a{i-1}"}, output=f"a{i}"))
for i in range(LEVELS):
    buf(f"h{i}", SC[i]); buf(f"l{i}", SC[i])
    passes.append(dict(id=f"blurh{i}", lang="sksl", source=blur(True), inputs={"image": f"buffer:a{i}"}, output=f"h{i}"))
    passes.append(dict(id=f"blurv{i}", lang="sksl", source=blur(False), inputs={"image": f"buffer:h{i}"}, output=f"l{i}"))
buffers.append(dict(id="out", scale=1.0, format="rgba16f", filter="linear"))
inputs = {"image": "source"}; inputs.update({f"l{i}": f"buffer:l{i}" for i in range(LEVELS)})
passes.append(dict(id="mix", lang="sksl", source=MIX, inputs=inputs, output="out"))

fx = dict(schema=2, id="glow", name="Glow", category="stylize",
          description="Unified glow engine: nine modes (bloom, soft, diffusion, highlight, atmospheric, neon, edge-aware, multi-scale, anamorphic) on a five-level pyramid with separable blur, soft threshold, highlight roll-off, tint and blend.",
          requires=dict(backends=["skia"], features=["float16"]),
          params=params, buffers=buffers, passes=passes, output="out")
path = "shared/assets/effects/glow.json"
json.dump(fx, open(path, "w"), indent=1)
print("wrote", path, len(passes), "passes", len(buffers), "buffers")

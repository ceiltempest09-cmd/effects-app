#include "glsl_compile.h"

#ifdef AM_HAVE_GLSLANG
#include <glslang/Public/ShaderLang.h>
#include <SPIRV/GlslangToSpv.h>
#include <mutex>
#endif

namespace am::rg {

#ifdef AM_HAVE_GLSLANG
namespace {
std::once_flag gInit;

void EnsureInit() { std::call_once(gInit, [] { glslang::InitializeProcess(); }); }

// Limits of a normal desktop/mobile GPU (the numbers glslang's own default table uses). A zeroed table would reject everything.
TBuiltInResource Resources() {
    TBuiltInResource r = {};
    r.maxLights = 32; r.maxClipPlanes = 6; r.maxTextureUnits = 32; r.maxTextureCoords = 32; r.maxVertexAttribs = 64;
    r.maxVertexUniformComponents = 4096; r.maxVaryingFloats = 64; r.maxVertexTextureImageUnits = 32;
    r.maxCombinedTextureImageUnits = 80; r.maxTextureImageUnits = 32; r.maxFragmentUniformComponents = 4096;
    r.maxDrawBuffers = 32; r.maxVertexUniformVectors = 128; r.maxVaryingVectors = 8; r.maxFragmentUniformVectors = 16;
    r.maxVertexOutputVectors = 16; r.maxFragmentInputVectors = 15; r.minProgramTexelOffset = -8; r.maxProgramTexelOffset = 7;
    r.maxClipDistances = 8;
    r.maxComputeWorkGroupCountX = 65535; r.maxComputeWorkGroupCountY = 65535; r.maxComputeWorkGroupCountZ = 65535;
    r.maxComputeWorkGroupSizeX = 1024; r.maxComputeWorkGroupSizeY = 1024; r.maxComputeWorkGroupSizeZ = 64;
    r.limits.nonInductiveForLoops = true; r.limits.whileLoops = true; r.limits.doWhileLoops = true;
    r.limits.generalUniformIndexing = true; r.limits.generalAttributeMatrixVectorIndexing = true;
    r.limits.generalVaryingIndexing = true; r.limits.generalSamplerIndexing = true;
    r.limits.generalVariableIndexing = true; r.limits.generalConstantMatrixVectorIndexing = true;
    return r;
}
}  // namespace

bool GlslangAvailable() { return true; }

std::string GlslangVersionText() {
    EnsureInit();
    const char* v = glslang::GetGlslVersionString();
    return v ? std::string("GLSL ") + v : std::string("unknown");
}

GlslCompileResult CompileGlslToSpirv(const std::string& source, GlslDialect dialect, GlslStage stage) {
    GlslCompileResult out;
    EnsureInit();
    const EShLanguage lang = stage == GlslStage::Vertex ? EShLangVertex : EShLangFragment;
    const bool vulkan = dialect == GlslDialect::Vulkan;
    glslang::TShader shader(lang);
    const char* text = source.c_str();
    shader.setStrings(&text, 1);
    if (vulkan) {
        shader.setEnvInput(glslang::EShSourceGlsl, lang, glslang::EShClientVulkan, 100);
        shader.setEnvClient(glslang::EShClientVulkan, glslang::EShTargetVulkan_1_1);
        shader.setEnvTarget(glslang::EshTargetSpv, glslang::EShTargetSpv_1_3);
    } else {
        shader.setEnvInput(glslang::EShSourceGlsl, lang, glslang::EShClientOpenGL, 100);
        shader.setEnvClient(glslang::EShClientOpenGL, glslang::EShTargetOpenGL_450);
        shader.setEnvTarget(glslang::EshTargetSpv, glslang::EShTargetSpv_1_0);
    }
    const EShMessages messages = static_cast<EShMessages>(EShMsgSpvRules | (vulkan ? EShMsgVulkanRules : 0));
    const TBuiltInResource resources = Resources();
    if (!shader.parse(&resources, 450, false, messages)) {
        out.log = std::string(shader.getInfoLog()) + shader.getInfoDebugLog();
        if (out.log.empty()) out.log = "glslang parse failed";
        return out;
    }
    glslang::TProgram program;
    program.addShader(&shader);
    if (!program.link(messages)) {
        out.log = std::string(program.getInfoLog()) + program.getInfoDebugLog();
        if (out.log.empty()) out.log = "glslang link failed";
        return out;
    }
    const glslang::TIntermediate* intermediate = program.getIntermediate(lang);
    if (!intermediate) { out.log = "glslang produced no intermediate tree"; return out; }
    std::vector<unsigned int> spirv;
    glslang::SpvOptions options;
    glslang::GlslangToSpv(*intermediate, spirv, &options);
    if (spirv.empty()) { out.log = "glslang produced an empty SPIR-V module"; return out; }
    out.words.assign(spirv.begin(), spirv.end());
    out.ok = true;
    return out;
}

#else

bool GlslangAvailable() { return false; }
std::string GlslangVersionText() { return "not built"; }
GlslCompileResult CompileGlslToSpirv(const std::string&, GlslDialect, GlslStage) {
    GlslCompileResult out;
    out.log = "this build has no glslang";
    return out;
}

#endif

}  // namespace am::rg

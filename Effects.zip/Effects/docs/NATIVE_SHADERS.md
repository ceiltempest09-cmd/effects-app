# Native shader execution: design, decision and status

**Status in this repository: GLSL ES and desktop GLSL now execute for real through `gl_backend.{h,cpp}` (an `rg::Backend` over EGL + OpenGL ES 3.x / desktop GL 3.3+), tested on the host against Mesa llvmpipe (`tests/native/build_gl.sh`: 1188 checks, GPU results compared with CPU references). Vulkan GLSL and SPIR-V still have NO execution backend and are reported as unsupported. The GL backend is NOT yet linked into `amengine`, not wired to the Skia engine (no shared textures with Skia), and has not been built or run on Android.**

## GL backend (`gl_backend.cpp`) — what is verified
* Languages: `glsl-es` on ES contexts, `glsl` on desktop contexts; anything else is a Capability diagnostic. Driver compiles; errors map to `file:line` of the effect file (with and without backend-added lines).
* Formats: RGBA8 / RGBA16F / RGBA32F are *probed* (create, attach, clear to 2.5 / -1, and 1+2^-20 for 32F, read back); `supports()` reflects that, not extension names.
* Uniforms by reflection: `size`, `out_px`, `time`, `frame`, `<input>_px`, constants (float/int/vec/arrays); a uniform or sampler with no value is an error naming it. Samplers use sampler objects (filter + wrap per input).
* Two contract points that differ from SkSL and are now explicit: (1) `gl_FragCoord` is in pixels of the OUTPUT target, so a pass writing a scaled buffer must normalise with `out_px`, not `size`; (2) GLSL ES defaults `sampler2D` to lowp, so the backend declares `precision highp sampler2D;` before the author's code (found by the tests: without it float inputs were quantised to ~8 bits).
* Program reuse: in-memory per pass, and on disk as driver program binaries through `ShaderCache` (damaged entries are rejected and rebuilt).
* Other: float-blend and float-linear checks per format, per-pass GPU time (timer query, else glFinish bracket), stats, thread guard, context-loss query (`contextLost()`), `dropPrograms()` / `Executor::dropAll()`.
* Not verified: any real phone GPU driver; actual GPU context loss (cannot be provoked on llvmpipe); Skia interop; the Kotlin importer still translates glsl/glsl-es to SkSL.
* To link it: add `gl_backend.cpp shader_info.cpp shader_diag.cpp shader_cache.cpp spirv_util.cpp` to `amengine` in `shared/cpp/CMakeLists.txt` (EGL is already linked; `dl` is needed for the loader).

## What exists (verified on the host, g++ 13, C++20, `-fno-exceptions -fno-rtti`)
| File | Role |
|---|---|
| `render_graph.{h,cpp}` | `Lang` now has `GLSL`, `GLSLES`, `VulkanGLSL`, `SPIRV`. `Executor` takes several backends: each step runs on the first backend that `supports(Lang)` and `accepts(pass)`; buffers have a home backend; a pass on another backend gets the target through `release / acquire / relinquish / reclaim` (zero copy, ordered, default = refuse). A pass or hand-off nobody can do fails the frame with `Diag{kind=Capability}` (effect, pass, backend, file:line). Formats are negotiated over every backend that touches a buffer; the memory budget counts all backends together; `dropAll()` empties every pool. |
| `shader_info.{h,cpp}` | Reads `#version`, profile, `#extension`, `#include` from the text; `CheckGlslHeader()` turns "needs ES 3.2 on a 3.1 device" or a missing required extension into a Capability message with the line. |
| `shader_diag.{h,cpp}` | Parses glslang/shaderc, Mesa, vendor GLES and `file:line: error:` logs; maps them to the pass' `file:line` after a backend prelude. |
| `spirv_util.{h,cpp}` | Base64 transport for `lang=spirv`; validates header/instruction stream (either byte order), lists capabilities, extensions, entry points. No reflection. |
| `shader_cache.{h,cpp}` | Persistent blob cache: key = language + source + defines + compiler + target + prelude revision; checksummed, atomic writes, corrupt entry = miss + delete, size-capped oldest-first eviction. |

None of these is linked into `amengine` yet (nothing calls them), so the Android build is unchanged except for `render_graph.cpp`/`.h`, which `effects_graph.cpp` already uses.

## Findings from the real code that drive the design
* `engine.cpp` starts **Graphite on Vulkan 1.1** by default, **Ganesh on Vulkan** and **Ganesh on GL (EGL, ES 3)** as fallbacks (`fBackend`). It owns one `VkInstance/VkDevice/VkQueue` (`fQueue`, family `fQueueFamily`, queue 0) and passes them to Skia through `skgpu::VulkanBackendContext`.
* Effects get only an `SkCanvas*`; the engine's `GpuContext` (`{graphite, recorder, ganesh}`) and `fDevice`/`fQueue` never reach `EffectRuntime::drawGraphs`. A native backend needs a new bridge object passed the way `LayerEffects::upload` is.
* Under Graphite, Skia work is only *recorded* until `fRecorder->snap()` + `insertRecording` + `submit`. `EngineImpl::flushPartial()` already does exactly that mid-frame (it is used for layer breaks), so a mid-frame submit is an existing, exercised pattern.
* `gpu_caps.cpp` probes a throw-away **GLES** context even when the engine renders through Vulkan, so its answers are not the Vulkan device's. `render_targets.cpp` is GL-only and unused.
* Skia stays opaque about the queue: the engine must keep every `vkQueueSubmit` for this device on the thread that already submits Skia's work (external synchronisation). Not verified in this pass whether preview and export ever submit from two threads.

## Decision: how a native pass shares textures with Skia
**Vulkan engines (Graphite and Ganesh/Vulkan): a native Vulkan backend on the same `VkDevice` and queue.** Reasons: no second device (no cross-device memory export), no CPU readback, Skia already supports wrapping external images (`BackendTextures::MakeVulkan` / `GrBackendTextures::MakeVk`) and the engine already does so for swapchain images and AHardwareBuffers.
* Targets: `VkImage` created by the native backend (`COLOR_ATTACHMENT | SAMPLED | TRANSFER_SRC`), format `R8G8B8A8_UNORM`, `R16G16B16A16_SFLOAT`, `R32G32B32A32_SFLOAT`, wrapped as Skia backend textures so SkSL passes sample them.
* Sync: before a native pass, flush Skia (`flushPartial` pattern, with a signal semaphore in `InsertRecordingInfo`); the native `vkQueueSubmit` waits on it and signals another; the next Skia recording waits on that through `fWaitSemaphores`. Same queue, so submission order plus semaphores and image barriers are enough; the native pass leaves images in `SHADER_READ_ONLY_OPTIMAL` and tells Skia that layout/queue family when wrapping.
* Format support: `vkGetPhysicalDeviceFormatProperties` must report `COLOR_ATTACHMENT`, `COLOR_ATTACHMENT_BLEND` and (for sampling with `filter=linear`) `SAMPLED_IMAGE_FILTER_LINEAR` per format; otherwise the buffer degrades (or fails for `precision=required`) through the executor logic already tested.
* Compile: glslang or shaderc → SPIR-V, cached in `ShaderCache`; `spirv` modules go straight to `vkCreateShaderModule` after `ParseSpirv` and a capability check against the enabled device features.

**GLES engine (Ganesh/GL): GLSL ES runs natively in the shared EGL ES 3.x context** (the driver compiles it), hand-off by `AHardwareBuffer` + `EGLImage` or by sharing the texture through the same context, ordered with `EGL_ANDROID_native_fence_sync` fences; Skia's GL state must be reset (`resetContext`) after raw GL calls. Desktop GLSL, Vulkan GLSL and SPIR-V are not available there (GLES has no SPIR-V entry) and fail with Capability.

## Not designed away, not implemented
Vulkan backend, GLES backend, glslang/shaderc vendoring and CMake wiring, the engine-to-effects GPU bridge, a SPIR-V reflector for binding uniforms by name (needed for `lang=spirv`), a Vulkan-aware replacement for the GLES-only `gpu_caps.cpp`, and the Kotlin importer changes (it still translates `glsl`/`glsl-es` to SkSL, and rejects `glsl-vk`/`spirv`).

## Extension point for other languages
Other languages are meant to be importers that produce one of the five `Lang` values before planning (WGSL, HLSL, Metal → SPIR-V by an offline compiler such as Tint/DXC/SPIRV-Cross; Shadertoy → a GLSL ES wrapper). **None is implemented**; adding one needs a real compiler step that can be tested, which this environment does not have.

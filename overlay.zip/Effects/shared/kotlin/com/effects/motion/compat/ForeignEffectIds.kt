package com.effects.motion.compat

object ForeignEffectIds {
    const val TEXT_SPACING = "com.alightcreative.effects.textspacing"
}

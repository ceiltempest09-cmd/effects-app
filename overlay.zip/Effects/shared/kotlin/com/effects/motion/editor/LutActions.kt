package com.effects.motion.editor

import android.net.Uri
import android.provider.OpenableColumns
import com.effects.motion.effects.EffectImporter
import com.effects.motion.effects.EffectSources
import com.effects.motion.effects.ImportTier
import com.effects.motion.effects.ImportedEffects
import com.effects.motion.model.addEffect
import com.effects.motion.model.effects
import com.effects.motion.platform.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** Result text for the toast. ok = the LUT is now an effect on the selected layer. */
class LutOutcome(val ok: Boolean, val text: String)

/**
 * Picked .cube file -> imported effect (same storage as other imported effects, so it saves and reopens with the project) ->
 * added to the selected layer. Nothing is added when parsing, baking or the shader check fails.
 */
suspend fun EditorState.importLutAndApply(context: Context, uri: Uri): LutOutcome {
    val resolver = context.contentResolver
    val name = withContext(Dispatchers.IO) {
        resolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c -> if (c.moveToFirst()) c.getString(0) else null }
    } ?: uri.lastPathSegment ?: "lut.cube"
    if (!name.lowercase().endsWith(".cube")) return LutOutcome(false, "Choose a .cube LUT file ($name is not one).")
    val result = withContext(Dispatchers.IO) { EffectImporter.import(context, EffectSources.Native, ImportTier.DEFAULT, listOf(name to { resolver.openInputStream(uri) })) }
    val line = result.lines.firstOrNull() ?: return LutOutcome(false, "Nothing was imported.")
    val id = line.effectId
    if (!line.ok || id == null) return LutOutcome(false, line.text)
    engine.reloadEffects(context).join()
    val def = engine.effects.value.find(id)
    if (def == null || def.status != "ok") {
        withContext(Dispatchers.IO) { ImportedEffects.delete(context, id) }
        engine.reloadEffects(context).join()
        return LutOutcome(false, "The LUT converted but the effect did not load: " + (def?.status ?: "not registered"))
    }
    if (selected == null) return LutOutcome(false, "Select a layer first. The LUT was saved in the Effects library.")
    editSelected { layer -> layer.addEffect(def.instance(null, layer.endTime - layer.startTime)) }
    effectIndex = (selected?.effects?.size ?: 0) - 1
    return LutOutcome(true, line.text)
}

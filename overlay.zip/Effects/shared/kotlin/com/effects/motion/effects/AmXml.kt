package com.effects.motion.effects

import org.w3c.dom.Element
import javax.xml.parsers.DocumentBuilderFactory

class AmChoice(val value: Int, val label: String)

class AmParam(
    val tag: String, val id: String, val label: String, val default: String,
    val min: String?, val max: String?, val step: String?, val type: String?,
    val choices: List<AmChoice>, val srcType: String?,
)

/** One `<pass>` of a multi-pass effect file (EM pass dialect, see docs/EFFECT_FORMAT.md). Unknown attributes/children are kept in [extra]. */
class AmPass(
    val id: String, val name: String, val lang: String, val shader: String, val inputs: List<Pair<String, String>>,
    val output: String, val blend: String, val clear: Boolean, val after: List<String>,
    val constants: Map<String, List<Float>>, val defines: Map<String, String>, val extra: Map<String, String>,
)

class AmBuffer(val id: String, val attrs: Map<String, String>)

class AmEffect(
    val id: String, val name: String, val description: String, val category: String,
    val params: List<AmParam>, val shader: String, val passes: Int, val hasScript: Boolean,
    val passList: List<AmPass> = emptyList(), val buffers: List<AmBuffer> = emptyList(),
    val attrs: Map<String, String> = emptyMap(), val history: Map<String, String> = emptyMap(),
    val unknownChildren: Map<String, String> = emptyMap(),
) {
    /** A real pass graph: more than one pass, or any buffer/history declaration. One pass with the file's own <shader> stays a one-pass effect. */
    val isGraph: Boolean get() = passList.size > 1 || buffers.isNotEmpty() || history.isNotEmpty() || (passList.size == 1 && shader.isBlank())
}

class AmFormatError(message: String) : Exception(message)

/** Reads an Alight Motion style effect file: <effect><params/><shader/></effect>. */
object AmXml {
    const val MAX_CHARS = 1_000_000

    fun parse(raw: String): AmEffect {
        val text = raw.trimStart('\uFEFF', ' ', '\n', '\r', '\t')
        if (text.length > MAX_CHARS) throw AmFormatError("The file is too large.")
        if (text.contains("<!DOCTYPE", true) || text.contains("<!ENTITY", true)) throw AmFormatError("DOCTYPE and ENTITY are not allowed.")
        val root = try {
            DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(text.byteInputStream()).documentElement
        } catch (e: Exception) {
            throw AmFormatError("Not valid XML: ${e.message}")
        }
        if (root.tagName != "effect") throw AmFormatError("The first tag is <${root.tagName}>, expected <effect>.")
        val passElements = root.kids().firstOrNull { it.tagName == "passes" }?.kids().orEmpty().filter { it.tagName == "pass" }
        val shader = root.kids().firstOrNull { it.tagName == "shader" }?.textContent?.takeIf { it.isNotBlank() }
            ?: if (passElements.any { p -> p.kids().any { it.tagName == "shader" || it.tagName == "source" } }) ""
            else throw AmFormatError("There is no <shader> in this file.")
        val params = root.kids().firstOrNull { it.tagName == "params" }?.kids().orEmpty().map { e ->
            val id = e.attr("id").orEmpty()
            AmParam(
                tag = e.tagName, id = id, label = e.attr("label") ?: e.attr("text") ?: id,
                default = e.attr("default").orEmpty(), min = e.attr("min"), max = e.attr("max"),
                step = e.attr("step"), type = e.attr("type"),
                choices = e.kids().filter { it.tagName == "choice" }.mapIndexed { i, c ->
                    AmChoice(c.attr("value")?.toIntOrNull() ?: i, c.attr("label") ?: "${c.attr("value") ?: i}")
                },
                srcType = e.attr("srcType"),
            )
        }
        val passes = root.kids().firstOrNull { it.tagName == "passes" }?.kids()?.size?.coerceAtLeast(1) ?: 1
        val passList = passElements.mapIndexed { i, e -> readPass(e, i) }
        val known = setOf("params", "passes", "shader", "script", "buffers", "history")
        val unknown = root.kids().filter { it.tagName !in known }.associate { it.tagName to it.textContent.orEmpty() }
        return AmEffect(
            id = root.attr("id").orEmpty(), name = root.attr("name") ?: root.attr("id") ?: "Effect",
            description = root.attr("desc").orEmpty(), category = root.attr("category") ?: "other",
            params = params, shader = shader, passes = passes, hasScript = root.kids().any { it.tagName == "script" },
            passList = passList,
            buffers = root.kids().firstOrNull { it.tagName == "buffers" }?.kids().orEmpty().filter { it.tagName == "buffer" }.map { b ->
                AmBuffer(b.attr("id").orEmpty(), b.attributeMap().filterKeys { it != "id" })
            },
            attrs = root.attributeMap().filterKeys { it !in setOf("id", "name", "desc", "category") },
            history = root.kids().firstOrNull { it.tagName == "history" }?.attributeMap().orEmpty(),
            unknownChildren = unknown,
        )
    }

    private fun readPass(e: Element, index: Int): AmPass {
        val id = e.attr("id") ?: "pass$index"
        val shader = e.kids().firstOrNull { it.tagName == "shader" || it.tagName == "source" }?.textContent.orEmpty()
        val inputs = linkedMapOf<String, String>()
        e.attr("input")?.split(',')?.map { it.trim() }?.filter { it.isNotEmpty() }?.forEach { part ->
            val eq = part.indexOf('=')
            if (eq > 0) inputs[part.substring(0, eq).trim()] = part.substring(eq + 1).trim() else inputs[part] = part
        }
        e.kids().filter { it.tagName == "input" }.forEach { inputs[it.attr("name").orEmpty()] = it.attr("ref") ?: it.attr("name").orEmpty() }
        val constants = linkedMapOf<String, List<Float>>()
        e.kids().filter { it.tagName == "const" }.forEach { c ->
            constants[c.attr("name").orEmpty()] = c.attr("value").orEmpty().split(',').map { it.trim().toFloatOrNull() ?: Float.NaN }
        }
        val defines = e.kids().filter { it.tagName == "define" }.associate { it.attr("name").orEmpty() to it.attr("value").orEmpty() }
        val knownAttrs = setOf("id", "name", "lang", "output", "blend", "clear", "after", "input")
        val extra = linkedMapOf<String, String>()
        e.attributeMap().forEach { (k, v) -> if (k !in knownAttrs) extra[k] = v }
        e.kids().filter { it.tagName !in setOf("shader", "source", "input", "const", "define") }.forEach { extra["child:" + it.tagName] = it.textContent.orEmpty() }
        return AmPass(
            id = id, name = e.attr("name") ?: id, lang = e.attr("lang") ?: "glsl", shader = shader, inputs = inputs.toList(),
            output = e.attr("output").orEmpty(), blend = e.attr("blend") ?: "replace", clear = e.attr("clear")?.equals("false", true) != true,
            after = e.attr("after")?.split(',')?.map { it.trim() }?.filter { it.isNotEmpty() }.orEmpty(), constants = constants, defines = defines, extra = extra,
        )
    }

    private fun Element.attributeMap(): Map<String, String> = buildMap {
        val a = attributes
        for (i in 0 until a.length) put(a.item(i).nodeName, a.item(i).nodeValue)
    }

    private fun Element.kids(): List<Element> = buildList {
        val n = childNodes
        for (i in 0 until n.length) (n.item(i) as? Element)?.let(::add)
    }

    private fun Element.attr(name: String): String? = if (hasAttribute(name)) getAttribute(name) else null
}

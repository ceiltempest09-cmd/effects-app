#!/bin/bash
# Compiles the Android-free Kotlin sources + tests with the Kotlin compiler bundled in Gradle's lib dir and runs them.
set -e
ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
L=${GRADLE_LIB:-/opt/gradle-8.14.3/lib}
STD=$(ls $L/kotlin-stdlib-[0-9]*.jar | grep -v -E "sources|common|jdk" | head -1)
[ -n "$STD" ] || { echo "no kotlin-stdlib jar in $L"; exit 2; }
OUT=${OUT:-/tmp/hostkt-out}
CP=$(ls $L/kotlin-compiler-embeddable-*.jar $STD $L/kotlin-script-runtime-*.jar $L/kotlin-reflect-*.jar $L/kotlin-daemon-embeddable-*.jar $L/trove4j*.jar $L/annotations-*.jar $L/kotlinx-coroutines-core-jvm-*.jar | tr '\n' ':')
rm -rf "$OUT"; mkdir -p "$OUT"
SRC="$ROOT/shared/kotlin/com/effects/motion/effects/graph $ROOT/tests/hostkt/org $ROOT/tests/hostkt/GraphTests.kt $ROOT/tests/hostkt/ImportTests.kt $ROOT/tests/hostkt/LutTests.kt $ROOT/shared/kotlin/com/effects/motion/effects/LutEffect.kt $ROOT/shared/kotlin/com/effects/motion/effects/engine $ROOT/shared/kotlin/com/effects/motion/effects/AmXml.kt $ROOT/shared/kotlin/com/effects/motion/effects/SkslConvert.kt"
java -cp "$CP" org.jetbrains.kotlin.cli.jvm.K2JVMCompiler -no-stdlib -no-reflect -cp $STD $SRC "$@" -d "$OUT" 2>&1 | { grep -v "^Picked up" || true; }
java -cp "$OUT:$STD" GraphTestsKt
ENG="$ROOT/shared/kotlin/com/effects/motion/effects/engine"
java -cp "$CP" org.jetbrains.kotlin.cli.jvm.K2JVMCompiler -no-stdlib -no-reflect -cp $STD "$ENG" "$ROOT/tests/hostkt/EngineTests.kt" -d "$OUT/engine" 2>&1 | { grep -v "^Picked up" || true; }
java -cp "$OUT/engine:$STD" EngineTestsKt

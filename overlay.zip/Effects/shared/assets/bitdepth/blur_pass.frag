// blur_pass.frag — SAMPLE separable Gaussian. Run twice (u_dir = (1,0) then (0,1)) via ping-pong.
// Blurring happens in linear light on purpose: that is the physically correct result, and it is
// free on float buffers (fxDecode is the identity there).
in highp vec2 v_uv;
uniform sampler2D u_src;
uniform highp vec2 u_dir;      // one texel step along the blur axis: (1/w, 0) or (0, 1/h)
uniform float u_sigma;         // pixels
uniform int   u_radius;        // taps each side, <= 32
out vec4 o_color;

void main() {
    FX_ACC vec4  sum = vec4(0.0);          // accumulator never drops below mediump
    FX_ACC float wsum = 0.0;
    float inv2s2 = 1.0 / (2.0 * max(u_sigma, 1e-3) * max(u_sigma, 1e-3));

    for (int i = -32; i <= 32; ++i) {
        if (i < -u_radius || i > u_radius) continue;
        float w = exp(-float(i * i) * inv2s2);
        vec4 t = fxSample(u_src, v_uv + u_dir * float(i));
        sum  += vec4(fxDecode(t.rgb), t.a) * w;   // decode each tap, then accumulate linearly
        wsum += w;
    }
    vec4 c = sum / wsum;
    o_color = vec4(fxEncode(c.rgb), c.a);
}

#!/bin/bash
# Builds and runs the GLSL library tests on whatever EGL / GLES driver the machine has (Mesa llvmpipe on a CPU-only host).
set -e
cd "$(dirname "$0")/../.."
CXX=${CXX:-g++}
OUT=${OUT:-/tmp/em-native-tests}; mkdir -p "$OUT"
$CXX -std=c++20 -fno-exceptions -fno-rtti -Wall -Wextra -O1 -I shared/cpp tests/native/glsl_library_test.cpp shared/cpp/glsl_library.cpp shared/cpp/gl_backend.cpp \
  shared/cpp/render_graph.cpp shared/cpp/render_graph_xml.cpp shared/cpp/xml.cpp shared/cpp/shader_info.cpp shared/cpp/shader_diag.cpp \
  shared/cpp/shader_cache.cpp shared/cpp/spirv_util.cpp -lexpat -ldl -lpthread -o "$OUT/glsl_library_test"
stdbuf -o0 "$OUT/glsl_library_test"

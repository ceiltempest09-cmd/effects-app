package com.effects.motion.ui.editor

import androidx.annotation.StringRes
import androidx.compose.runtime.Composable
import androidx.compose.ui.res.stringResource
import com.effects.motion.R
import com.effects.motion.engine.bitdepth.BitDepth
import com.effects.motion.model.ColorSupport
import com.effects.motion.model.DynamicRange
import com.effects.motion.model.PreviewQualityMode
import com.effects.motion.model.ProjectColor
import com.effects.motion.model.WorkingSpace

/** One entry of a colour setting's dropdown: what it is called and the one-line description shown under it. */
internal class ColorChoice<T>(val value: T, @StringRes val label: Int, @StringRes val description: Int)

internal val BitDepthChoices = listOf(
    ColorChoice(BitDepth.BIT16, R.string.proj_bd_16, R.string.proj_bd_16_desc),
)

internal val PreviewQualityChoices = listOf(
    ColorChoice(PreviewQualityMode.Standard, R.string.proj_pq_standard, R.string.proj_pq_standard_desc),
    ColorChoice(PreviewQualityMode.High, R.string.proj_pq_high, R.string.proj_pq_high_desc),
    ColorChoice(PreviewQualityMode.Hdr, R.string.proj_pq_hdr, R.string.proj_pq_hdr_desc),
)

internal val WorkingSpaceChoices = listOf(
    ColorChoice(WorkingSpace.LinearSrgb, R.string.proj_cs_linear, R.string.proj_cs_linear_desc),
    ColorChoice(WorkingSpace.Srgb, R.string.proj_cs_srgb, R.string.proj_cs_srgb_desc),
    ColorChoice(WorkingSpace.Rec2020, R.string.proj_cs_rec2020, R.string.proj_cs_rec2020_desc),
)

internal val DynamicRangeChoices = listOf(
    ColorChoice(DynamicRange.Sdr, R.string.proj_range_sdr, R.string.proj_range_sdr_desc),
    ColorChoice(DynamicRange.Hdr, R.string.proj_range_hdr, R.string.proj_range_hdr_desc),
)

@StringRes
internal fun bitDepthLabel(depth: BitDepth): Int = BitDepthChoices.first { it.value == depth }.label

/**
 * The one thing worth telling the person about their current combination, or null. The four settings are independent, so some
 * combinations quietly do less than they say: this is where that is spelled out (the settings are never changed behind their back).
 */
@Composable
internal fun colorNote(color: ProjectColor, support: ColorSupport?): String? {
    if (support != null && !support.supports(color.bitDepth)) {
        return stringResource(R.string.proj_bd_fallback, stringResource(bitDepthLabel(color.bitDepth)), stringResource(bitDepthLabel(support.effective)))
    }
    return when {
        color.previewQuality == PreviewQualityMode.Hdr && color.dynamicRange == DynamicRange.Sdr -> stringResource(R.string.proj_pq_hdr_needs_range)
        color.dynamicRange == DynamicRange.Hdr && color.bitDepth == BitDepth.BIT8 -> stringResource(R.string.proj_range_needs_float)
        color.bitDepth == BitDepth.BIT8 && color.workingSpace != WorkingSpace.Srgb -> stringResource(R.string.proj_bd_8_linear)
        color.previewQuality == PreviewQualityMode.Hdr -> stringResource(R.string.proj_pq_hdr_display)
        else -> null
    }
}

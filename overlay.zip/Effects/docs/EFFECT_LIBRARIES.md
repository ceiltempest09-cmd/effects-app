# Effect libraries in the repo

Not compiled or run here: the Kotlin below is untested until the first CI build; `tools/fxconvert.py` was run on the uploaded zips.

Upload as zips to the repo root (the workflow unzips whichever exist): `pack.zip` (-> `pack/`), `aligthmotion.zip` (-> `aligthmotion/`), `glsl.zip`, `emx.zip`.

| Folder | Files | Library (picker name) |
|---|---|---|
| `effects/`, `pack/` | `.json` (+ the pack's `index.json`, `releases.json`, `foreign.json`) | Performance (was Default) |
| `glsl/` | `.glsl` | Balance (was Vibrant HQS) |
| `emx/` | `.emx` | Heavy effects (was RayTraced VFX) |
| `aligthmotion/` | `.xml`, pictures in `thumb/` | Alight Motion source |
| After Effects `.aex` | no longer importable (a compiled desktop plug-in has no shader the app can run). The After Effects library stays and can hold effects converted from `.xml` | - |

Alight Motion: `fxconvert.py` puts each xml in `assets/alightmotion/am_<name>.xml`, sets its `category` to one of the 11 cards (Color & Light, Drawing & Edge,
Blur, Distortion/Warp, Procedural, 3D, Move/Transform, Repeat, Matte/Mask/Key, Opacity/Visibility, Text; no PNKJ, no Custom), shrinks its picture to
`thumb/am_<name>.webp`, and writes `alightmotion/index.json`. Files that need an image texture are skipped (the app does not load texture files).
On the first start after an install/update the app converts the files in the background (`ImportedEffects.installBundledInBackground`) into the Performance
pack under the Alight Motion source; the effects appear the next time the library is opened. Files the converter rejects are skipped (see the `Effects` log tag).

## Import dialog

Effects Library > Import opens the file picker first (`.xml`, `.json`, `.cube` or a zip of them), then one options dialog in the style of the project settings:

| Option | Choices | What it does |
|---|---|---|
| Library effect | Effects Motion, After Effects, Alight Motion, your custom libraries, `Custom...` | Where the effect is stored. `Custom...` asks for a name; the new library sits next to Alight Motion and is reached by sliding the library buttons from right to left. Starts on the library being viewed. |
| Bit float | 32 bit / 16 bit / 8 bit | Heavy effects / Balance / Performance. Nothing is upgraded automatically; a device that cannot do the depth falls back to the nearest it can. |
| Shader language | GLSL / SkSL | Changes how the effect is built. GLSL keeps the shader as a native OpenGL ES pass (`glsl-es`) that runs in the float pipeline at the chosen depth: the better picture. SkSL converts it for Skia only (8-bit path, lower quality). To upgrade an effect, import it again as GLSL. |

The last Bit float and Shader language choices are remembered. Defaults: 32 bit, GLSL. A GLSL import that the device's compiler refuses is reported with the compiler message and can be imported as SkSL instead.

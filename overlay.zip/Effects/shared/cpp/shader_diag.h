// shader_diag.h — compiler logs -> Diag with the line of the ORIGINAL pass source.
//
// A native backend may put lines in front of the author's text (a prelude with #defines, the automatic-uniform block ...).
// It tells MapCompilerLog() how many, and every message comes back with file:line of the effect file, which is what the
// importer UI shows. Understands glslang / shaderc ("ERROR: 0:12: ..."), Mesa ("0:12(3): error: ..."), Android vendor
// drivers (Qualcomm/ARM/PowerVR print "ERROR: 0:12: ..."), and the "file.frag:12: error: ..." form.
#pragma once

#include "render_graph.h"

#include <string>
#include <vector>

namespace am::rg {

struct LogEntry {
    bool error = true;
    int line = 0;               // line inside the compiled text as the compiler counted it; 0 = the log gave none
    int column = 0;
    std::string message;
};

std::vector<LogEntry> ParseCompilerLog(const std::string& log);

// `preludeLines`: lines the backend added before the author's first line. Returns one Diag per entry (errors and warnings);
// entries without a line number point at the pass' first line.
std::vector<Diag> MapCompilerLog(const PassDesc& pass, int passIndex, const std::string& effect, const std::string& backend,
                                 const std::string& log, int preludeLines);

}  // namespace am::rg

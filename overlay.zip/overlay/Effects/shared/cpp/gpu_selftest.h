// gpu_selftest.h - runs real GPU checks on the device it executes on and returns a plain-text report.
#pragma once
#include <string>
namespace am { std::string RunGpuSelfTest(const std::string& cacheDirectory); }

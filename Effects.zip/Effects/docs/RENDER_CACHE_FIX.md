# Render-cache glitches, frame corruption, freezes and scrubbing: what was found and fixed

Verified here: C++ host tests (history signature; the existing render graph / GL suite still passes, 1227 checks, 0 failed) and a randomised
model check of the new render order (3000 scenes). NOT verified here (no Android SDK, Kotlin compiler, Skia, Vulkan or device in the sandbox):
compilation of the Kotlin and `effects.cpp` edits, and any on-device rendering or scrubbing. The first CI build is the real compile.

## Root causes
| Symptom | Cause | Where |
|---|---|---|
| 1. Flicker / corrupted frames in cached video | The history of temporal (ping-pong, feedback, accumulation) effects survives only across consecutive frames; after any jump the executor starts it empty (`Executor::render`). The cache render drew from the playhead and skipped cached frames, so each frame's history depended on where the render started and which neighbours existed. Cached frames of one run did not match frames of another: visible pops at the seams. Live playback capture had the same problem. | `PreviewCache.renderFrames`, `capturePlayback` |
| 1b. Mixed old/new history after an edit | The history signature only mixed the number of properties, not their values, keyframes or easing. Editing a control left history built with the old values. | `effects.cpp` `drawGraphs` |
| 1c. Tearing while scrubbing | A decoded bitmap was reused (`inBitmap`) for the next decode as soon as it had left the last 2 shown frames. The compositor draws on its own thread, so a bitmap shown moments ago could still be read while being overwritten. | `FramePlayer.victim` |
| 3/4. Freeze / stutter with cache present | (a) Playback capture re-rendered a temporal layer at capture size between preview frames; the size is part of the signature, so history was thrown away and rebuilt every frame. (b) Reading a frame from the cache file held the store lock, blocking the render that writes new frames and the UI that wants the next one. | `capturePlayback`/`EngineThread.tapFrame`, `FrameStore.get` |
| Old caches | Frames saved by the previous ordering are not reproducible and were still loaded. | `PersistentCache` |
| 2. Wrong / repeated frame | Not reproduced as a cause: `frameStart`/`frameAt` round-trip exactly for every integer fps 1..240 and 200000 frames (checked). The preview path is latest-wins (`pendingView`, `renderPosted`), and `FramePlayer` already tags work with an epoch and `wanted`. | no change |

## Changes
- `shared/cpp/history_signature.h` (new) + `effects.cpp`: signature covers effect id and definition, area, layer span, fps, and every property as authored
  (values, keyframes, easing, lead key, links). Animated values are hashed as authored, so playing never changes it and any edit does.
- `FrameRenderPlan.kt` (new): `temporalSpans`, `renderPlan`. Frames inside a temporal span are reached by an unbroken ascending run from the span start;
  cached frames in the run are drawn again, not stored. Spans without history effects keep the old playhead-first order.
- `PreviewCache.kt`: ordered render using the plan; no live capture of frames inside temporal spans (left to the ordered render); lock-free positional
  disk reads with a layout version (retry, then locked fallback); 250 ms bitmap reuse guard (bounded: ignored when the pool is 6+ over size); `warmup=` in the render log line.
- `PersistentCache.kt`: VERSION 2 -> 3; incompatible folders are deleted on load.

## Cache-key and invalidation notes
Unchanged and already sound: `CacheKey` (project, scene, quality divisor, emoji, media revision, blur, group), `previewDirtyRanges` (layer span plus dependents),
persistent env hash (version, install stamp, divisor, emoji, blur, group, checker cell), CRC check, commit by renaming meta last. Media replacement is covered
through the scene's `media` declarations (size, infoUpdated). Quality is untouched: no resolution, sample, pass, precision or codec change anywhere.

## Tests
- `tests/native/history_signature_test.cpp` (in `tests/native/run.sh`): 16 checks, 0 failed.
- `tests/tools/render_plan_check.py`: 3000 scenes, new plan 0 wrong frames; old order 10245 wrong frames.
- Not written (needs a device or Kotlin toolchain): scrub/seek/undo/pause-resume/surface-recreation tests, pixel comparison against a reference, profiling before/after.

## Limits and follow-ups
- Only graph effects with `@n` history are treated as temporal. Legacy effects that depend on earlier frames (e.g. datamosh) are not covered.
- Warm-up frames are read back like stored ones; a native "draw without readback" call would cut that cost.
- A long temporal span re-renders from its start when a gap inside it is missing; it is O(span), never O(span^2).
- Seek=replay is still unsupported on the Skia path; `fx` with that mode is rejected as before.
- Fences, texture formats and Vulkan/GL hand-offs were read, not changed: `GraphRunner::render` already waits for Skia before native passes rewrite shared buffers.

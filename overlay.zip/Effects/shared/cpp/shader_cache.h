// shader_cache.h — persistent compiled-shader cache (SPIR-V words, driver pipeline blobs ...) across runs.
//
// A file per entry: 24-byte header (magic "AMSC", format, key, payload size, FNV-1a checksum), then the payload. A short, torn
// or checksum-failing file is deleted and reported as a miss, never returned. Writes go to a temp file and rename() into place,
// so a crash cannot leave a half-written entry. The directory is kept under maxBytes by deleting the oldest entries.
#pragma once

#include "render_graph.h"

#include <cstdint>
#include <string>
#include <vector>

namespace am::rg {

// Everything that can change the compiled output goes in the key: the author's text, the defines, the language, the
// compiler (name + version), the target (backend + device + driver) and the layout of the prelude the backend adds.
uint64_t ShaderCacheKey(const PassDesc& pass, const std::string& compiler, const std::string& target, int preludeRevision);

class ShaderCache {
public:
    ShaderCache(std::string directory, int64_t maxBytes) : fDir(std::move(directory)), fMax(maxBytes) {}
    bool load(uint64_t key, std::vector<uint8_t>* payload) const;     // false = miss (or corrupt entry, which is removed)
    bool store(uint64_t key, const uint8_t* data, size_t size) const; // false = not stored (no directory, too large, I/O error)
    void trim() const;                                                // enforce maxBytes (oldest first)
    int64_t bytes() const;
    void clear() const;
private:
    std::string path(uint64_t key) const;
    std::string fDir;
    int64_t fMax;
};

}  // namespace am::rg

// spirv_util.h — reading pre-compiled SPIR-V passes (lang="spirv"): base64 transport, header and instruction-stream validation,
// and the list of capabilities / extensions / entry points the module declares, so a backend can refuse a module the device
// cannot run BEFORE handing it to the driver. This does not compile, optimise or reflect SPIR-V.
#pragma once

#include <cstdint>
#include <string>
#include <vector>

namespace am::rg {

bool Base64Decode(const std::string& text, std::vector<uint8_t>* out);   // whitespace allowed; false on any invalid character or padding
std::string Base64Encode(const uint8_t* data, size_t size);

struct SpirvInfo {
    uint32_t version = 0;                          // 0x00010000 = 1.0, 0x00010300 = 1.3 ...
    uint32_t bound = 0;
    std::vector<uint32_t> words;                   // native-endian module
    std::vector<uint32_t> capabilities;            // OpCapability operands
    std::vector<std::string> extensions;           // OpExtension names
    struct EntryPoint { uint32_t model = 0; std::string name; };   // model: 0 vertex, 4 fragment, 5 GLCompute
    std::vector<EntryPoint> entryPoints;
};

// Accepts either byte order (the magic number tells). Fails with a message on: size not a multiple of 4, bad magic, version
// outside 1.0..1.6, instruction with word count 0 or running past the end, id bound 0, no OpEntryPoint.
bool ParseSpirv(const std::vector<uint8_t>& bytes, SpirvInfo* out, std::string* error);

const char* SpirvCapabilityName(uint32_t capability);   // "Shader", "Float16" ... or "capability #N" in a static buffer-free form
std::string SpirvCapabilityText(uint32_t capability);

}  // namespace am::rg

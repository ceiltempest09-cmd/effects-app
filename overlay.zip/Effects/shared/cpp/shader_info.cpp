#include "shader_info.h"

#include <cctype>
#include <cstdlib>
#include <cstring>

namespace am::rg {
namespace {

std::string Trim(const std::string& s) {
    size_t a = 0, b = s.size();
    while (a < b && std::isspace((unsigned char)s[a])) a++;
    while (b > a && std::isspace((unsigned char)s[b - 1])) b--;
    return s.substr(a, b - a);
}

std::vector<std::string> Words(const std::string& s) {
    std::vector<std::string> out;
    size_t i = 0;
    while (i < s.size()) {
        while (i < s.size() && (std::isspace((unsigned char)s[i]) || s[i] == ':')) {
            if (s[i] == ':') out.push_back(":");
            i++;
        }
        size_t j = i;
        while (j < s.size() && !std::isspace((unsigned char)s[j]) && s[j] != ':') j++;
        if (j > i) out.push_back(s.substr(i, j - i));
        i = j;
    }
    return out;
}

}  // namespace

ShaderHeader ParseShaderHeader(const std::string& src) {
    ShaderHeader h;
    int line = 1;
    bool inBlock = false, seenCode = false;
    size_t pos = 0;
    while (pos <= src.size()) {
        size_t eol = src.find('\n', pos);
        if (eol == std::string::npos) eol = src.size();
        std::string text = src.substr(pos, eol - pos);
        // strip comments (block comments may span lines)
        std::string code;
        for (size_t i = 0; i < text.size(); i++) {
            if (inBlock) {
                if (text[i] == '*' && i + 1 < text.size() && text[i + 1] == '/') { inBlock = false; i++; }
                continue;
            }
            if (text[i] == '/' && i + 1 < text.size() && text[i + 1] == '/') break;
            if (text[i] == '/' && i + 1 < text.size() && text[i + 1] == '*') { inBlock = true; i++; continue; }
            code += text[i];
        }
        code = Trim(code);
        if (!code.empty() && code[0] == '#') {
            std::string rest = Trim(code.substr(1));
            const size_t sp = rest.find_first_of(" \t");
            const std::string directive = rest.substr(0, sp);
            const std::string args = sp == std::string::npos ? "" : Trim(rest.substr(sp));
            if (directive == "version") {
                if (h.version != 0 || h.versionLine != 0) { h.ok = false; h.error = "#version appears twice"; h.errorLine = line; return h; }
                if (seenCode) { h.ok = false; h.error = "#version must be the first statement of the shader (only comments and blank lines may precede it)"; h.errorLine = line; return h; }
                const auto w = Words(args);
                char* end = nullptr;
                const long v = w.empty() ? 0 : std::strtol(w[0].c_str(), &end, 10);
                if (w.empty() || !end || *end || v < 100 || v > 999) { h.ok = false; h.error = "malformed #version directive"; h.errorLine = line; return h; }
                h.version = (int)v;
                h.versionLine = line;
                if (w.size() >= 2) {
                    if (w[1] == "es") h.profile = ShaderHeader::ES;
                    else if (w[1] == "core") h.profile = ShaderHeader::Core;
                    else if (w[1] == "compatibility") h.profile = ShaderHeader::Compatibility;
                    else { h.ok = false; h.error = "unknown #version profile '" + w[1] + "'"; h.errorLine = line; return h; }
                }
                if (w.size() > 2) { h.ok = false; h.error = "malformed #version directive"; h.errorLine = line; return h; }
            } else if (directive == "extension") {
                const auto w = Words(args);
                if (w.size() != 3 || w[1] != ":") { h.ok = false; h.error = "malformed #extension directive (expected '#extension NAME : behavior')"; h.errorLine = line; return h; }
                if (w[2] != "require" && w[2] != "enable" && w[2] != "warn" && w[2] != "disable") { h.ok = false; h.error = "unknown #extension behavior '" + w[2] + "'"; h.errorLine = line; return h; }
                h.extensions.push_back({w[0], w[2], line});
            } else if (directive == "include") {
                if (!h.includeLine) h.includeLine = line;
            }
            // other directives (#define, #if, #pragma, #line) do not count as code before #version... but #define does in the GLSL grammar
            else if (directive != "pragma" && directive != "line") seenCode = true;
        } else if (!code.empty()) {
            seenCode = true;
        }
        if (eol == src.size()) break;
        pos = eol + 1;
        line++;
    }
    return h;
}

bool CheckGlslHeader(Lang lang, const ShaderHeader& h, const GlslDevice& dev, std::string* why, int* line, std::vector<std::string>* warnings) {
    auto fail = [&](int at, std::string msg) { *line = at; *why = std::move(msg); return false; };
    *line = 0;
    if (!h.ok) return fail(h.errorLine, h.error);
    if (h.includeLine) return fail(h.includeLine, "#include is not supported: write the shader as one self-contained source");

    if (lang == Lang::GLSLES) {
        const int v = h.version == 0 ? 100 : h.version;
        const bool known = v == 100 || v == 300 || v == 310 || v == 320;
        if (!known) return fail(h.versionLine, "GLSL ES has versions 100, 300 es, 310 es and 320 es; '#version " + std::to_string(v) + "' is not one of them");
        if (v >= 300 && h.profile != ShaderHeader::ES) return fail(h.versionLine, "GLSL ES " + std::to_string(v) + " must be written '#version " + std::to_string(v) + " es'");
        if (v == 100 && h.profile != ShaderHeader::None) return fail(h.versionLine, "GLSL ES 1.00 takes no profile");
        const int have = dev.esMajor * 100 + dev.esMinor * 10;
        if (dev.esMajor == 0) return fail(h.versionLine, "this device has no GLSL ES front end");
        if (v == 100 && dev.esMajor < 2) return fail(h.versionLine, "GLSL ES 1.00 needs OpenGL ES 2.0 or newer");
        if (v != 100 && v > have) return fail(h.versionLine, "needs GLSL ES " + std::to_string(v / 100) + "." + std::to_string((v % 100) / 10) + " but this device supports up to " + std::to_string(dev.esMajor) + "." + std::to_string(dev.esMinor));
    } else if (lang == Lang::GLSL) {
        const int v = h.version == 0 ? 110 : h.version;
        if (h.profile == ShaderHeader::ES) return fail(h.versionLine, "lang=glsl is desktop GLSL; this source says '#version " + std::to_string(v) + " es'. Declare lang=\"glsl-es\" for GLSL ES");
        if (v < 110 || v > 460) return fail(h.versionLine, "'#version " + std::to_string(v) + "' is not a desktop GLSL version");
        if (h.profile != ShaderHeader::None && v < 150) return fail(h.versionLine, "profiles exist from #version 150");
        if (dev.desktopVersion == 0) return fail(h.versionLine, "this device has no desktop GLSL front end (it runs OpenGL ES / Vulkan only); desktop #version " + std::to_string(v) + " cannot be accepted as written");
        if (v > dev.desktopVersion) return fail(h.versionLine, "needs desktop GLSL " + std::to_string(v) + " but this device accepts up to " + std::to_string(dev.desktopVersion));
    } else if (lang == Lang::VulkanGLSL) {
        const int v = h.version == 0 ? 0 : h.version;
        if (v == 0) return fail(0, "Vulkan GLSL needs a '#version 450' (or 310 es / 320 es / 460) directive on the first line");
        if (h.profile == ShaderHeader::ES ? !(v == 310 || v == 320) : (v < 450 || v > 460))
            return fail(h.versionLine, "Vulkan GLSL is '#version 450' / '#version 460', or '#version 310 es' / '320 es'; '" + std::to_string(v) + "' is not accepted");
        if (!dev.vulkanGlsl) return fail(h.versionLine, "this build/device cannot compile Vulkan GLSL (no SPIR-V compiler linked, or the device does not run Vulkan)");
    } else {
        return fail(0, std::string("CheckGlslHeader does not apply to ") + ToString(lang));
    }

    for (const ShaderHeader::Extension& e : h.extensions) {
        if (e.behavior == "disable") continue;
        if (dev.extensions.count(e.name) || e.name == "all") continue;
        if (e.behavior == "require") return fail(e.line, "requires extension " + e.name + ", which this device does not have");
        if (warnings) warnings->push_back("line " + std::to_string(e.line) + ": extension " + e.name + " is requested with '" + e.behavior + "' but this device does not have it");
    }
    return true;
}

}  // namespace am::rg

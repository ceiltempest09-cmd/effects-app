# Scrub and drag stutter: what was found and changed

NOT compiled, NOT profiled: no Android SDK, Kotlin compiler or device here. The next CI build is the first compile. No quality setting, resolution, pass, precision or cache key changed.

## Causes found in the code (read, not measured)
1. Idle pre-render vs the first touch. The idle render holds the engine thread and capture lock while it draws, and only noticed a touch on its next 60 ms poll, then finished the frame in flight and tore its session down. Result: a hitch at the start of every drag or scrub, worse with many layers (slow frames).
2. Cache bar on the UI thread. `drawCacheBar` -> `PreviewCache.runsFor` ran `previewDirtyRanges` (walks and compares every layer) inside the draw on every frame in which a dragged layer changed the scene. Cost grows with the layer count.
3. Extra round trips to the engine thread on every scrubbed frame: `layerQuad` + `layerMatrix` (two trips, each applying pending state) and one `layerBounds` trip per selected layer.
4. `VideoLibrary.previewReady` and `previewShown` each re-walked and re-parsed every layer of the scene (`Scene` is a view over an XML tree) on every render.

## Changes
- `PreviewCache.interaction()` stops an idle (auto) render at once; renders started with the Pre-render button are never stopped by touches.
- `PreviewCache.runsFor` keeps its last bar answer while a finger moved in the last 80 ms; the existing idle follow-up refreshes it after the finger pauses.
- `EngineThread.layerGeometry` (quad + matrices) and `layerBoundsOf` (many layers) each take one trip; `Preview.kt` uses them.
- `VideoLibrary.drawnAt` keeps the last video-layer lookup per scene (by identity), time and mode.

## Not done (needs a device and a profiler)
- `EngineThread.setScene` still serialises and re-parses the whole scene for each edit frame; an incremental native update is the next big win for many-layer drags.
- Timeline row drawing was not changed (it already draws only visible rows).
- Send the `render ... still=` log lines and `RenderStats` from the phone to find out what dominates next.

package com.effects.motion.engine.bitdepth

import android.content.Context

/** Pixel storage format of a render target. Order matters: higher ordinal = higher quality. */
enum class BitDepth(val bits: Int, val label: String) {
    BIT8(8, "8-bit (RGBA8)"),
    BIT16(16, "16-bit float (RGBA16F)"),
    BIT32(32, "32-bit float (RGBA32F)");

    /** Value passed to native code (matches PixelFormat enum in render_targets.h). */
    val nativeId: Int get() = ordinal
}

/** Per-effect shader math precision. Compile-time: each value is a separate cached shader variant. */
enum class ShaderPrecision(val glsl: String?) {
    INHERIT(null),   // follow the project's working depth
    LOW("lowp"),     // see ARCHITECTURE.md: usually executes as fp16 on real GPUs
    MEDIUM("mediump"),
    HIGH("highp")
}

/** Per-effect intermediate buffer override (blur/glow scratch targets etc.). */
data class EffectPrecision(
    val math: ShaderPrecision = ShaderPrecision.INHERIT,
    val buffer: BitDepth? = null            // null = inherit
)

/** Persisted project settings. */
data class BitDepthSettings(
    val editDepth: BitDepth = BitDepth.BIT16,
    val exportDepth: BitDepth = BitDepth.BIT16,
    val autoUpgradeOnExport: Boolean = true
) {
    /** Requested depth for the given phase, before the hardware clamp. */
    fun requested(isExport: Boolean): BitDepth =
        BitDepth.BIT16      // the engine is locked to 16-bit float

    fun save(ctx: Context) = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
        .putInt("edit", editDepth.ordinal).putInt("export", exportDepth.ordinal)
        .putBoolean("autoUp", autoUpgradeOnExport).apply()

    companion object {
        private const val PREFS = "bit_depth_settings"
        fun load(ctx: Context): BitDepthSettings {
            val p = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            return BitDepthSettings(BitDepth.BIT16, BitDepth.BIT16, p.getBoolean("autoUp", true))
        }
    }
}

/** One row in the settings UI. */
data class DepthOption(val depth: BitDepth, val enabled: Boolean, val disabledReason: String?)

/** Single place that turns "what the user asked for" into "what the GPU will actually get". */
class BitDepthPolicy(private val caps: GpuCapabilities) {

    fun isSupported(d: BitDepth): Boolean = when (d) {
        BitDepth.BIT8 -> true
        BitDepth.BIT16 -> caps.rgba16fRenderable
        BitDepth.BIT32 -> caps.rgba32fRenderable
    }

    /** Falls back 32 -> 16 -> 8. Never returns something the device can't render to. */
    fun effective(requested: BitDepth): BitDepth {
        return BitDepth.BIT16       // 16-bit float only: no 8-bit or 32-bit fallback
    }

    /** Effect buffer override is clamped the same way; null = use the project depth. */
    fun effectBuffer(project: BitDepth, fx: EffectPrecision): BitDepth =
        effective(fx.buffer ?: project)

    /** Options for the settings screen: unsupported ones are shown greyed out with a reason. */
    fun options(): List<DepthOption> = BitDepth.values().map { d ->
        DepthOption(d, isSupported(d), if (isSupported(d)) null else reasonFor(d))
    }

    /** Extra hints (e.g. 32-bit available but no filtering / blending). */
    fun warnings(d: BitDepth): List<String> = buildList {
        if (d == BitDepth.BIT32 && isSupported(d) && !caps.rgba32fLinear)
            add("This GPU can't smoothly filter 32-bit textures; a slower shader filter is used.")
        if (d == BitDepth.BIT32 && isSupported(d) && !caps.rgba32fBlend)
            add("32-bit blending is unavailable; blend modes run in a shader pass instead.")
    }

    private fun reasonFor(d: BitDepth) = when (d) {
        BitDepth.BIT16 -> "Your GPU (${caps.renderer}) can't render to 16-bit float buffers."
        BitDepth.BIT32 -> "Your GPU (${caps.renderer}) can't render to 32-bit float buffers."
        else -> null
    }
}

# GLSL effect guide (Vibrant HQS)

Paste this whole file to ChatGPT, then say:
"Write the GLSL effect <name>: <what it should look like>. Follow this format exactly. Reply with one .glsl file only."

## What you get
One text file `glsl/<id>.glsl`. It has a header of `// @` lines, then normal GLSL ES code with `void main()`. The build converts it for the app.

## Header
```
// @id mything                      lowercase letters and digits only
// @name My Thing
// @category neon                   glow neon liquid glitch leaks sparkle depth beat text other
// @description One sentence.
// @param <id> <type> <default> [min=] [max=] [step=] [pixels=1] [percent=1] [unit=] [when=other:1,2] label="Label"
```
Param types and defaults:
- `float 1.5`, `angle 45` (degrees), `switch 0`, `point 0.5,0.5` (fraction of the layer)
- `color #ff2ea6` (or `#aarrggbb`)
- `choice 0 options="Soft|Hard|Strobe"` (default is an index)

## Code rules
- Every `// @param` needs `uniform` with the same id: `float`/`angle`/`switch`/`choice` -> `uniform float id;`, `point` -> `uniform vec2 id;`, `color` -> `uniform vec4 id;`.
- Automatic uniforms (no @param): `size` (vec2, pixels), `time` (seconds), `duration`, `layer`.
- Pictures: `uniform sampler2D image;` is the layer. Extra: `blurred` (needs a param with id `blur`, pixels), `bright` (params `threshold`, `blur`), `backdrop`, `below`.
- Sample with `texture2D(image, uv)`. `uv = gl_FragCoord.xy / size`. Here y goes top to bottom.
- Write the result to `gl_FragColor`. Colors are premultiplied: keep rgb <= alpha, divide rgb by alpha for the straight color.
- `gl_FragCoord` and `gl_FragColor` only inside `main()`. Pass values to helper functions as arguments.
- No `#if`/`#include`, no `#define` with arguments (plain `#define NAME value` is fine), no `texelFetch`, `dFdx`, `varying`, `attribute`, no recursion.
- Loops need constant bounds. Keep it light; it runs every frame.

## Example 1: 2D (`glsl/neonpulse.glsl`)
```glsl
// @id neonpulse
// @name Neon Pulse
// @category neon
// @description 2D: pulsing neon bloom with a colour tint and a chromatic fringe.
// @param strength float 1.2 min=0 max=4 step=0.01 label="Glow Strength"
// @param blur float 28 min=0 max=200 step=0.1 pixels=1 label="Glow Radius"
// @param tint color #ff2ea6 label="Neon Color"
// @param pulse float 0.6 min=0 max=3 step=0.01 label="Pulse Speed"
// @param fringe float 0.004 min=0 max=0.03 step=0.0005 label="Color Fringe"
uniform sampler2D image;
uniform sampler2D blurred;
uniform vec2 size;
uniform float time;
uniform float strength;
uniform float pulse;
uniform float fringe;
uniform vec4 tint;

void main() {
    vec2 uv = gl_FragCoord.xy / size;
    float beat = 0.5 + 0.5 * sin(time * 6.2831853 * pulse);
    vec4 base = texture2D(image, uv);
    vec2 d = vec2(fringe, 0.0);
    vec3 rgb = vec3(texture2D(image, uv + d).r, base.g, texture2D(image, uv - d).b);
    vec4 glow = texture2D(blurred, uv);
    vec3 neon = glow.rgb * tint.rgb * strength * (0.6 + 0.8 * beat) * 2.0;
    float a = clamp(max(base.a, glow.a * strength * 0.5), 0.0, 1.0);
    gl_FragColor = vec4(min(rgb + neon, vec3(a)), a);
}
```

## Example 2: 3D (`glsl/cubespin.glsl`)
```glsl
// @id cubespin
// @name Cube Spin 3D
// @category depth
// @description 3D: your layer wrapped on a spinning cube, with the original shown behind it.
// @param cubeSize float 1.1 min=0.3 max=2 step=0.01 label="Cube Size"
// @param spin float 40 min=-360 max=360 step=1 label="Spin (deg/s)"
// @param tilt angle 20 label="Tilt"
// @param zoom float 1 min=0.4 max=3 step=0.01 label="Zoom"
// @param bgAmount float 0.35 min=0 max=1 step=0.01 percent=1 label="Background"
uniform sampler2D image;
uniform vec2 size;
uniform float time;
uniform float cubeSize;
uniform float spin;
uniform float tilt;
uniform float zoom;
uniform float bgAmount;

mat3 rotY(float a) { float c = cos(a); float s = sin(a); return mat3(c, 0.0, -s, 0.0, 1.0, 0.0, s, 0.0, c); }
mat3 rotX(float a) { float c = cos(a); float s = sin(a); return mat3(1.0, 0.0, 0.0, 0.0, c, s, 0.0, -s, c); }

vec2 boxHit(vec3 ro, vec3 rd, vec3 h) {
    vec3 inv = 1.0 / (rd + vec3(0.000001));
    vec3 t1 = (-h - ro) * inv;
    vec3 t2 = (h - ro) * inv;
    vec3 tn = min(t1, t2);
    vec3 tf = max(t1, t2);
    return vec2(max(max(tn.x, tn.y), tn.z), min(min(tf.x, tf.y), tf.z));
}

void main() {
    vec2 uv = gl_FragCoord.xy / size;
    vec4 base = texture2D(image, uv);
    vec2 q = (gl_FragCoord.xy - 0.5 * size) / size.y;
    q.y = -q.y;
    vec3 ro = vec3(0.0, 0.0, -3.0 / max(zoom, 0.1));
    vec3 rd = normalize(vec3(q, 1.6));
    float ang = radians(spin) * time;
    float tl = radians(tilt);
    mat3 inv = rotY(-ang) * rotX(-tl);
    mat3 fwd = rotX(tl) * rotY(ang);
    vec3 h = vec3(cubeSize * 0.5);
    vec2 th = boxHit(inv * ro, inv * rd, h);
    if (th.x > th.y || th.y < 0.0) {
        gl_FragColor = base * bgAmount;
        return;
    }
    vec3 p = inv * ro + (inv * rd) * th.x;
    vec3 a = abs(p / h);
    vec3 n;
    vec2 f;
    if (a.x > a.y && a.x > a.z) {
        n = vec3(sign(p.x), 0.0, 0.0);
        f = vec2(p.z * sign(p.x), p.y);
    } else if (a.y > a.z) {
        n = vec3(0.0, sign(p.y), 0.0);
        f = vec2(p.x, p.z * sign(p.y));
    } else {
        n = vec3(0.0, 0.0, sign(p.z));
        f = vec2(-p.x * sign(p.z), p.y);
    }
    vec2 fuv = vec2(f.x / cubeSize + 0.5, 0.5 - f.y / cubeSize);
    vec4 tex = texture2D(image, clamp(fuv, 0.0, 1.0));
    float dif = clamp(dot(normalize(fwd * n), normalize(vec3(-0.4, 0.6, -0.7))), 0.0, 1.0);
    float light = 0.55 + 0.55 * dif;
    vec4 cube = vec4(tex.rgb * light, tex.a);
    gl_FragColor = cube + base * bgAmount * (1.0 - cube.a);
}
```

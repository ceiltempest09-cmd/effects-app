#!/usr/bin/env python3
"""Reference check for renderPlan() in shared/kotlin/.../editor/FrameRenderPlan.kt (same algorithm, line for line).

The model executor keeps history only across consecutive frames and empties it after a jump, exactly like render_graph.cpp's Executor::render.
For 3000 random scenes (temporal spans, partially filled caches, random render windows and playheads) every frame the plan stores must equal the
frame of a purely sequential render. The old order (playhead first, cached frames skipped) is run on the same inputs for contrast.
Run: python3 tests/tools/render_plan_check.py   (exit code 1 on any wrong frame)
"""
import random, sys

def run_executor(order, spans):
    hist = {i: None for i in range(len(spans))}      # per span: (last frame, state after it, state before it)
    out = {}
    for f in order:
        v = float(f)
        for i, s in enumerate(spans):
            if f in s:
                h = hist[i]
                if h is not None and h[0] == f: acc = h[2]            # same frame again: history = the frames before it
                elif h is not None and h[0] == f - 1: acc = h[1]      # next frame: history continues
                else: acc = 0.0                                       # first frame or a jump: history is empty
                new = acc * 0.5 + f                                   # temporal feedback
                hist[i] = (f, new, acc)
                v += new * 1000
        out[f] = v
    return out

def plan(rng, at, cached, spans):                    # == renderPlan()
    missing = [f for f in rng if not cached(f)]
    if not missing: return []
    if not spans: return [(f, True) for f in [x for x in missing if x >= at] + [x for x in missing if x < at]]
    runs = []
    for f in missing:
        starts = [s.start for s in spans if f in s]
        frm = min(starts) if starts else f
        if runs and frm <= runs[-1][1] + 1: runs[-1] = (runs[-1][0], f)
        else: runs.append((frm, f))
    ordered = [r for r in runs if r[1] >= at] + [r for r in runs if r[1] < at]
    miss = set(missing)
    return [(f, f in miss) for a, b in ordered for f in range(a, b + 1)]

def scene(rnd):
    n = rnd.randint(20, 120)
    spans = [range(a, min(n - 1, a + rnd.randint(0, 60)) + 1) for a in [rnd.randint(0, n - 1) for _ in range(rnd.randint(0, 3))]]
    ref = run_executor(list(range(n)), spans)
    p = rnd.choice([0, 0.3, 0.7])
    cached = {f: ref[f] for f in range(n) if rnd.random() < p}
    at = rnd.randint(0, n - 1); a = rnd.randint(0, n - 1); b = rnd.randint(a, n - 1)
    return spans, ref, cached, at, range(a, b + 1)

def main():
    trials, bad, old_bad = 3000, 0, 0
    rnd = random.Random(7)
    for _ in range(trials):
        spans, ref, cached, at, window = scene(rnd)
        steps = plan(window, at, lambda f: f in cached, spans)
        seq = run_executor([f for f, _ in steps], spans)
        bad += sum(1 for f, store in steps if store and abs(seq[f] - ref[f]) > 1e-6)
        frames = [f for f, _ in steps]
        assert len(frames) == len(set(frames)), "a frame is drawn twice"
        assert {f for f, s in steps if s} == {f for f in window if f not in cached}, "a missing frame is not stored exactly once"
    rnd = random.Random(7)
    for _ in range(trials):
        spans, ref, cached, at, window = scene(rnd)
        order = [f for f in list(window) if f >= at] + [f for f in list(window) if f < at]
        order = [f for f in order if f not in cached]
        seq = run_executor(order, spans)
        old_bad += sum(1 for f in order if abs(seq[f] - ref[f]) > 1e-6)
    print(f"{trials} scenes | new plan: {bad} wrong frames | old order: {old_bad} wrong frames")
    return 1 if bad else 0

if __name__ == "__main__":
    sys.exit(main())

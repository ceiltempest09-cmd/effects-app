// Contract test: the runtime XML written by Kotlin (GraphXml.write, from the shipped effects in shared/assets/effects)
// must be read and planned by the C++ engine code. Run tests/hostkt/run.sh first; it writes /tmp/em-graph-fixtures/*.xml.
//   g++ -std=c++20 -I shared/cpp tests/native/graph_contract_test.cpp shared/cpp/render_graph.cpp shared/cpp/render_graph_xml.cpp shared/cpp/xml.cpp -lexpat
#include "render_graph.h"
#include "render_graph_xml.h"
#include <cstdio>
#include <dirent.h>
#include <fstream>
#include <sstream>

using namespace am::rg;

int main(int argc, char** argv) {
    const std::string dir = argc > 1 ? argv[1] : "/tmp/em-graph-fixtures";
    DIR* d = opendir(dir.c_str());
    if (!d) { std::printf("no fixtures in %s (run tests/hostkt/run.sh)\n", dir.c_str()); return 2; }
    int bad = 0, count = 0;
    while (dirent* e = readdir(d)) {
        const std::string name = e->d_name;
        if (name.size() < 5 || name.substr(name.size() - 4) != ".xml") continue;
        std::ifstream in(dir + "/" + name);
        std::stringstream ss; ss << in.rdbuf();
        std::string err;
        auto root = am::ParseXml(ss.str(), &err);
        GraphDesc g; std::vector<Diag> diags;
        if (!root || !IsGraphXml(*root) || !ParseGraphXml(*root, &g, &diags)) { std::printf("FAIL %s: cannot read (%s)\n", name.c_str(), err.c_str()); bad++; continue; }
        const Plan p = BuildPlan(g, PlanOptions{});
        count++;
        std::printf("%-26s passes=%zu steps=%zu buffers=%zu textures=%zu peakLive=%d temporal=%d culled=%zu %s\n", name.c_str(), g.passes.size(), p.steps.size(),
                    p.desc.buffers.size(), g.textures.size(), p.peakLive, (int)p.temporal, p.culled.size(), p.ok() ? "OK" : "FAIL");
        for (const Diag& x : p.diags) std::printf("    %s\n", x.format().c_str());
        if (!p.ok() || !p.culled.empty() || p.steps.size() != g.passes.size()) bad++;
        // every shader text must survive the XML round trip with its newlines
        for (const PassDesc& ps : g.passes) if (ps.source.find("half4 main") == std::string::npos || ps.source.find('\n') == std::string::npos) { std::printf("    pass %s lost its source\n", ps.id.c_str()); bad++; }
    }
    closedir(d);
    std::printf("%d effects, %d problem(s)\n", count, bad);
    return bad || count < 5 ? 1 : 0;
}

package com.effects.motion.ui.home

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.effects.motion.R
import com.effects.motion.ui.theme.Am
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement

/** The "Uploading XML  20%" card shown while a project file is being read and imported. [progress] is 0f..1f. */
@Composable
fun ImportProgressCard(progress: Float, modifier: Modifier = Modifier) {
    val percent = (progress.coerceIn(0f, 1f) * 100).toInt()
    Column(
        modifier.widthIn(max = 360.dp).fillMaxWidth().padding(horizontal = 24.dp).clip(RoundedCornerShape(16.dp)).background(Am.Card).padding(20.dp),
    ) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(stringResource(R.string.import_uploading_xml), color = Am.Navy, fontSize = 16.sp, fontWeight = FontWeight.Medium)
            Text(stringResource(R.string.import_uploading_percent, percent), color = Am.Navy, fontSize = 16.sp)
        }
        Spacer(Modifier.height(14.dp))
        LinearProgressIndicator(
            progress = { progress.coerceIn(0f, 1f) },
            modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)),
            color = Am.Accent,
            trackColor = Am.Navy.copy(alpha = 0.15f),
        )
    }
}

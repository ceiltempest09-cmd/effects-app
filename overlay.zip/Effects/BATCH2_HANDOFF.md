# Batch 2 continuation handoff

## Current source
This is the `overlay.zip` project tree. Keep the `Effects/` folder as the archive root.
`Effects.zip` is a supporting reference archive; it is not the upload target.

## Native GLES baseline restored and verified
The following native test infrastructure was restored from the matching Effects source archive:
- `tests/native/run.sh`
- `tests/native/build_gl.sh`
- `docs/NATIVE_SHADERS.md`

The host suite was run against this source tree on Mesa llvmpipe:
- Render graph: 183 checks passed.
- Native shader: 105 checks passed.
- SPIR-V reflection: 22 checks passed.
- GLSL wrapper: 22 checks passed.
- History signature: 16 checks passed.
- Color pipeline: 114 checks passed.
- Real GLES / desktop GL backend: 1,227 checks passed, 0 failed, 1 skipped.
- The skipped check requires a SPIR-V compiler and Vulkan device unavailable in this host test build.

## Batch 2 status — NOT COMPLETE
This verification covers the standalone native render-graph backend. It does not establish that the Android app uses it as its primary renderer.

Still Skia-backed:
- `shared/cpp/engine.cpp` frame lifecycle and scene composition.
- `shared/cpp/scene.h` / `scene.cpp` scene and path model.
- Drawing, shapes, styles, text, and preview integration.
- Video-frame integration still adapts native YUV output back into a Skia image.
- The native GL graph bridge is implemented for the Graphite/Vulkan path; the Ganesh/OpenGL path explicitly refuses native sharing.

## Next engineering task
Implement a safe engine-owned GPU bridge for the Ganesh/OpenGL engine (same EGL context, AHardwareBuffer-backed shared surfaces, correct flush/synchronization and lifetime), then connect the frame lifecycle to the native graph. Do not create an unrelated second GL context for Ganesh. Do not remove Skia build dependencies until scene, drawing, text, video, and preview paths have real replacements and Android/device validation passes.

Android Gradle/NDK build and physical-device validation have not been run in this step.

#!/bin/bash
# GL optical-flow pipeline test on a real GLES driver (Mesa llvmpipe on a CPU-only host).
set -e
cd "$(dirname "$0")/../.."
CXX=${CXX:-g++}
OUT=${OUT:-/tmp/em-native-tests}; mkdir -p "$OUT"
$CXX -std=c++20 -fno-exceptions -fno-rtti -Wall -Wextra -O1 -I shared/cpp tests/native/gl_flow_test.cpp shared/cpp/gl_flow.cpp shared/cpp/glsl_library.cpp shared/cpp/gl_backend.cpp \
  shared/cpp/render_graph.cpp shared/cpp/render_graph_xml.cpp shared/cpp/xml.cpp shared/cpp/shader_info.cpp shared/cpp/shader_diag.cpp \
  shared/cpp/shader_cache.cpp shared/cpp/spirv_util.cpp -lexpat -ldl -lpthread -o "$OUT/gl_flow_test"
stdbuf -o0 "$OUT/gl_flow_test"

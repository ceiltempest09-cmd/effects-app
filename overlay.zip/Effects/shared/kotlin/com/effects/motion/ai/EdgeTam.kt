package com.effects.motion.ai

import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import com.effects.motion.R
import com.effects.motion.i18n.AppText
import com.effects.motion.model.MediaDeclaration
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import java.io.Closeable
import java.io.File
import kotlin.coroutines.coroutineContext

/** Side of the low-resolution mask EdgeTAM returns. */
internal const val EDGE_MASK_SIDE = 256

/** Prompt kinds understood by the decoder. */
internal const val EDGE_BACKGROUND = 0
internal const val EDGE_FOREGROUND = 1
internal const val EDGE_BOX_START = 2
internal const val EDGE_BOX_END = 3

internal object EdgeNative {
    external fun nativeOpen(encoderParam: String, encoderBin: String, decoderParam: String, decoderBin: String): Long
    external fun nativeClose(handle: Long)
    external fun nativeCancel(handle: Long)
    external fun nativeClearCancel(handle: Long)
    external fun nativeSetImage(handle: Long, bitmap: Bitmap): Int
    external fun nativeDecode(handle: Long, points: FloatArray, labels: IntArray, count: Int, mask: FloatArray): Int
    external fun nativeApply(handle: Long, mask: FloatArray, bitmap: Bitmap): Int
}

/** One prompt: a point in image pixels with a label (EDGE_FOREGROUND / EDGE_BACKGROUND), or a box corner. */
internal class EdgePrompt(val x: Float, val y: Float, val label: Int)

/** EdgeTAM image model: setImage() once per picture, then decode() for every tap or box. */
internal class EdgeTam private constructor(private val handle: Long) : Closeable {
    private var width = 0
    private var height = 0

    suspend fun setImage(bitmap: Bitmap) {
        check(!bitmap.isRecycled)
        width = bitmap.width
        height = bitmap.height
        checkResult(blocking { EdgeNative.nativeSetImage(handle, bitmap) })
    }

    /** Returns EDGE_MASK_SIDE * EDGE_MASK_SIDE foreground probabilities (row major, covers the whole picture). */
    suspend fun decode(prompts: List<EdgePrompt>): FloatArray {
        val used = prompts.takeLast(MAX_PROMPTS)
        require(used.isNotEmpty())
        val points = FloatArray(used.size * 2)
        val labels = IntArray(used.size)
        used.forEachIndexed { i, p ->
            points[i * 2] = p.x
            points[i * 2 + 1] = p.y
            labels[i] = p.label
        }
        val mask = FloatArray(EDGE_MASK_SIDE * EDGE_MASK_SIDE)
        checkResult(blocking { EdgeNative.nativeDecode(handle, points, labels, used.size, mask) })
        return mask
    }

    /** Boxes are two prompts: top-left and bottom-right corner. */
    fun box(left: Float, top: Float, right: Float, bottom: Float): List<EdgePrompt> =
        listOf(EdgePrompt(left, top, EDGE_BOX_START), EdgePrompt(right, bottom, EDGE_BOX_END))

    /** Writes the matte into [bitmap] (must be the picture given to setImage): alpha plus cleaned edge colours. */
    suspend fun apply(mask: FloatArray, bitmap: Bitmap) {
        checkResult(blocking { EdgeNative.nativeApply(handle, mask, bitmap) })
    }

    private fun checkResult(code: Int) {
        check(code != 1) { AppText.get(R.string.ai_cancelled) }
        check(code == 0) { AppText.get(if (code == -2) R.string.ai_out_of_memory_media else R.string.ai_model_failed) }
    }

    private suspend fun <T> blocking(work: () -> T): T = withContext(Dispatchers.Default) {
        runCancellable({ EdgeNative.nativeClearCancel(handle) }, { EdgeNative.nativeCancel(handle) }, work).also { ensureActive() }
    }

    override fun close() = EdgeNative.nativeClose(handle)

    companion object {
        const val MAX_PROMPTS = 8

        fun open(context: Context): EdgeTam {
            check(AiNative.loaded) { AppText.get(R.string.ai_runtime_unavailable) }
            val model = AiModel.EdgeTam
            model.verify(context)
            val handle = EdgeNative.nativeOpen(
                model.file(context, EDGE_ENCODER_PARAM).path, model.file(context, EDGE_ENCODER_BIN).path,
                model.file(context, EDGE_DECODER_PARAM).path, model.file(context, EDGE_DECODER_BIN).path,
            )
            check(handle != 0L) { AppText.get(R.string.ai_model_failed) }
            return EdgeTam(handle)
        }
    }
}

/** Photo cut-out driven by the person's taps: every tap is a foreground prompt for EdgeTAM. */
internal object EdgeCutout {
    suspend fun install(context: Context, progress: (Float) -> Unit) {
        if (!AiModel.EdgeTam.installed(context)) AiModel.EdgeTam.download(context, progress)
    }

    suspend fun run(context: Context, uri: String, original: MediaDeclaration?, limit: Int, cutout: Cutout, progress: AiProgress): AiMedia {
        require(cutout.keep.isNotEmpty())
        var bitmap: Bitmap? = null
        var file: File? = null
        var success = false
        try {
            file = aiFile(context, "png")
            progress(0f, AppText.get(R.string.ai_loading_model))
            val picture = BestCutout.decode(context, Uri.parse(uri), limit.coerceAtLeast(1))
            bitmap = picture
            coroutineContext.ensureActive()
            progress(0.2f, AppText.get(R.string.ai_removing_background))
            EdgeTam.open(context).use { net ->
                net.setImage(picture)
                progress(0.6f, AppText.get(R.string.ai_removing_background))
                val prompts = cutout.keep.map { (u, v) -> EdgePrompt(u * picture.width, v * picture.height, EDGE_FOREGROUND) } +
                    cutout.avoid.map { (u, v) -> EdgePrompt(u * picture.width, v * picture.height, EDGE_BACKGROUND) }
                val mask = net.decode(prompts)
                net.apply(mask, picture)
            }
            picture.setHasAlpha(true)
            picture.isPremultiplied = false
            // Taps were already used as prompts; only the softness / grow sliders still apply.
            Cutout(emptyList(), cutout.edge).let { if (!it.plain) picture.refineEdge(it) }
            progress(0.9f, AppText.get(R.string.ai_saving_transparent))
            file.outputStream().use { check(picture.compress(Bitmap.CompressFormat.PNG, 100, it)) { AppText.get(R.string.ai_cannot_save_image) } }
            coroutineContext.ensureActive()
            return aiMedia(context, file, "image/png", mapOf("width" to "${picture.width}", "height" to "${picture.height}",
                "orientation" to "${original?.orientation ?: 0}")).also { success = true }
        } finally {
            bitmap?.recycle()
            if (!success) file?.delete()
        }
    }

    private fun Bitmap.refineEdge(cutout: Cutout) {
        val row = IntArray(width)
        val alpha = ByteArray(width * height)
        for (y in 0 until height) {
            getPixels(row, 0, width, 0, y, width, 1)
            for (x in 0 until width) alpha[y * width + x] = (row[x] ushr 24).toByte()
        }
        val refined = cutout.refine(alpha, width, height)
        for (y in 0 until height) {
            getPixels(row, 0, width, 0, y, width, 1)
            for (x in 0 until width) row[x] = (row[x] and 0x00FFFFFF) or ((refined[y * width + x].toInt() and 0xFF) shl 24)
            setPixels(row, 0, width, 0, y, width, 1)
        }
    }
}

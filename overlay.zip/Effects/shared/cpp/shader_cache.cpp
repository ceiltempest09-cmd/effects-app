#include "shader_cache.h"

#include <algorithm>
#include <cstdio>
#include <cstring>
#include <dirent.h>
#include <sys/stat.h>
#include <utime.h>
#include <thread>
#include <unistd.h>

namespace am::rg {
namespace {

constexpr uint32_t kMagic = 0x43534D41u;   // "AMSC"
constexpr uint32_t kFormat = 1;

uint64_t Fnv(const void* data, size_t n, uint64_t h = 1469598103934665603ull) {
    const unsigned char* p = (const unsigned char*)data;
    for (size_t i = 0; i < n; i++) { h ^= p[i]; h *= 1099511628211ull; }
    return h;
}
uint64_t FnvStr(const std::string& s, uint64_t h) { h = Fnv(s.data(), s.size(), h); const unsigned char z = 0; return Fnv(&z, 1, h); }

struct Header { uint32_t magic, format; uint64_t key; uint32_t size; uint32_t pad; uint64_t sum; };   // 32 bytes
static_assert(sizeof(Header) == 32, "header layout");

}  // namespace

uint64_t ShaderCacheKey(const PassDesc& p, const std::string& compiler, const std::string& target, int preludeRevision) {
    uint64_t h = FnvStr(ToString(p.lang), 1469598103934665603ull);
    h = FnvStr(p.source, h);
    for (const auto& d : p.defines) { h = FnvStr(d.first, h); h = FnvStr(d.second, h); }   // std::map: sorted, so order-independent
    h = FnvStr(compiler, h);
    h = FnvStr(target, h);
    h = FnvStr(std::to_string(preludeRevision), h);
    return h;
}

std::string ShaderCache::path(uint64_t key) const {
    char name[40];
    std::snprintf(name, sizeof(name), "/%016llx.amsc", (unsigned long long)key);
    return fDir + name;
}

bool ShaderCache::load(uint64_t key, std::vector<uint8_t>* payload) const {
    if (fDir.empty()) return false;
    const std::string file = path(key);
    FILE* f = std::fopen(file.c_str(), "rb");
    if (!f) return false;
    Header h;
    bool ok = std::fread(&h, sizeof(h), 1, f) == 1 && h.magic == kMagic && h.format == kFormat && h.key == key;
    std::vector<uint8_t> data;
    if (ok) {
        data.resize(h.size);
        ok = (h.size == 0 || std::fread(data.data(), 1, h.size, f) == h.size) && std::fgetc(f) == EOF && Fnv(data.data(), data.size()) == h.sum;
    }
    std::fclose(f);
    if (!ok) { std::remove(file.c_str()); return false; }
    *payload = std::move(data);
    utime(file.c_str(), nullptr);          // recently used = newest, so trim() drops cold entries first
    return true;
}

bool ShaderCache::store(uint64_t key, const uint8_t* data, size_t size) const {
    if (fDir.empty() || (int64_t)(size + sizeof(Header)) > fMax) return false;
    mkdir(fDir.c_str(), 0775);
    const std::string file = path(key);
    const std::string tmp = file + ".tmp" + std::to_string((unsigned long long)std::hash<std::thread::id>{}(std::this_thread::get_id())) + "_" + std::to_string((int)getpid());
    FILE* f = std::fopen(tmp.c_str(), "wb");
    if (!f) return false;
    Header h{kMagic, kFormat, key, (uint32_t)size, 0, Fnv(data, size)};
    bool ok = std::fwrite(&h, sizeof(h), 1, f) == 1 && (size == 0 || std::fwrite(data, 1, size, f) == size);
    ok = std::fclose(f) == 0 && ok;
    if (!ok || std::rename(tmp.c_str(), file.c_str()) != 0) { std::remove(tmp.c_str()); return false; }
    trim();
    return true;
}

namespace {
struct Entry { std::string name; int64_t size; int64_t mtime; };
std::vector<Entry> List(const std::string& dir) {
    std::vector<Entry> out;
    DIR* d = opendir(dir.c_str());
    if (!d) return out;
    while (dirent* e = readdir(d)) {
        const std::string n = e->d_name;
        if (n.size() < 5 || n.compare(n.size() - 5, 5, ".amsc") != 0) continue;
        struct stat st;
        if (stat((dir + "/" + n).c_str(), &st) == 0) out.push_back({n, (int64_t)st.st_size, (int64_t)st.st_mtime});
    }
    closedir(d);
    return out;
}
}  // namespace

int64_t ShaderCache::bytes() const { int64_t s = 0; for (const Entry& e : List(fDir)) s += e.size; return s; }

void ShaderCache::trim() const {
    std::vector<Entry> all = List(fDir);
    int64_t total = 0;
    for (const Entry& e : all) total += e.size;
    std::sort(all.begin(), all.end(), [](const Entry& a, const Entry& b) { return a.mtime != b.mtime ? a.mtime < b.mtime : a.name < b.name; });
    for (const Entry& e : all) {
        if (total <= fMax) break;
        std::remove((fDir + "/" + e.name).c_str());
        total -= e.size;
    }
}

void ShaderCache::clear() const { for (const Entry& e : List(fDir)) std::remove((fDir + "/" + e.name).c_str()); }

}  // namespace am::rg

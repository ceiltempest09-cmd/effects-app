#!/usr/bin/env python3
"""Inventory production Skia API use before the native renderer migration.

Run from the Effects/ repository root:
    python3 tools/audit_skia_migration.py
    python3 tools/audit_skia_migration.py --verbose
    python3 tools/audit_skia_migration.py --strict

This is a migration guard, not an automatic source rewrite. It deliberately
fails strict mode until the production renderer no longer depends on Skia.
"""
from __future__ import annotations
import argparse
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / "shared" / "cpp"
SUFFIXES = {".h", ".hpp", ".cpp", ".cc", ".cxx"}
API = re.compile(
    r"\b(?:SkCanvas|SkSurface|SkImage|SkPaint|SkPath|SkPicture|"
    r"SkRuntimeEffect|SkImageFilter|SkBitmap|SkPixmap|SkMatrix|"
    r"SkM44|SkPoint|SkRect|SkFont|SkTypeface|sk_sp)\b|"
    r"#\s*include\s*[<\"]include/(?:core|effects|gpu|android)/",
)
GROUPS = {
    "engine/frame lifecycle": {"engine.cpp", "engine.h"},
    "scene and path model": {"scene.cpp", "scene.h", "camera.cpp", "depth.cpp", "model.cpp"},
    "drawing/shapes/styles/text/preview": {
        "drawing.cpp", "drawing.h", "shapes.cpp", "styles.cpp",
        "text.cpp", "text.h", "textanim.cpp", "preview.cpp", "preview.h",
        "pieces3d.cpp", "pieces3d.h",
    },
    "video and image adapters": {"gl_yuv.cpp", "gl_yuv.h", "ndk_images.cpp"},
}

def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--strict", action="store_true",
                        help="exit 1 if any Skia API use remains in production C++")
    parser.add_argument("--verbose", action="store_true",
                        help="print matching source lines")
    args = parser.parse_args()
    by_file: dict[str, list[tuple[int, str]]] = {}
    if BASE.exists():
        for path in sorted(BASE.rglob("*")):
            if not path.is_file() or path.suffix not in SUFFIXES:
                continue
            try:
                lines = path.read_text(encoding="utf-8", errors="replace").splitlines()
            except OSError:
                continue
            matches = [(i, line.strip()) for i, line in enumerate(lines, 1)
                       if API.search(line)]
            if matches:
                by_file[str(path.relative_to(ROOT))] = matches
    print("Production Skia API inventory")
    print(f"Files with references: {len(by_file)}")
    print(f"Matching lines: {sum(map(len, by_file.values()))}")
    for label, files in GROUPS.items():
        found = [(name, len(by_file[name])) for name in sorted(by_file)
                 if Path(name).name in files]
        print(f"\n{label}: {sum(count for _, count in found)} matches across {len(found)} files")
        for name, count in found:
            print(f"  {name}: {count}")
            if args.verbose:
                for number, source in by_file[name]:
                    print(f"    {number}: {source[:180]}")
    ungrouped = [(name, len(lines)) for name, lines in by_file.items()
                 if not any(Path(name).name in files for files in GROUPS.values())]
    if ungrouped:
        print(f"\nOther production C++: {sum(n for _, n in ungrouped)} matches")
        for name, count in ungrouped:
            print(f"  {name}: {count}")
    print("\nResult: " + ("BLOCKED — production Skia dependencies remain."
                         if by_file else "CLEAN — no production Skia dependencies found."))
    return 1 if args.strict and by_file else 0

if __name__ == "__main__":
    raise SystemExit(main())

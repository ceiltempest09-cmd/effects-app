package com.effects.motion.editor

import android.content.Context
import android.util.Log
import com.effects.motion.model.Scene
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileOutputStream
import java.security.MessageDigest
import java.util.zip.CRC32
import org.json.JSONArray
import org.json.JSONObject

/**
 * Rendered preview frames kept in app-managed storage (not the temporary cache folder), one folder per project.
 * A render is committed by renaming meta.json last, so a crash while writing never leaves a half-valid cache.
 */
internal object PersistentCache {
    const val MANUAL = 0
    const val SMART = 1
    const val AGGRESSIVE = 2

    // 3: frames of temporal (history) effects are now rendered in unbroken runs; earlier saved frames depend on where the render started.
    private const val VERSION = 3
    private const val TAG = "AMCache"
    private const val META = "meta.json"
    private const val INFO = "info.json"
    private const val ACCESS = "access"
    private const val STALE_MS = 7L * 24 * 60 * 60 * 1000
    private const val LOW_STORAGE = 3L * 1024 * 1024 * 1024

    class Loaded(val store: FrameStore, val pruned: Boolean)

    class Entry(val id: String, val name: String, val bytes: Long, val frames: Int, val complete: Boolean, val accessed: Long)

    fun root(context: Context): File = File(context.applicationContext.filesDir, "render_cache")

    private fun safe(id: String): String =
        id.map { if (it.isLetterOrDigit() || it == '-' || it == '_') it else '_' }.joinToString("").ifEmpty { "project" }

    private fun dir(context: Context, projectId: String): File = File(root(context), safe(projectId))

    private fun dirs(context: Context): List<File> = root(context).listFiles { f -> f.isDirectory }?.toList().orEmpty()

    private fun dirBytes(dir: File): Long = dir.walkTopDown().filter { it.isFile }.sumOf { it.length() }

    private fun accessed(dir: File): Long = File(dir, ACCESS).takeIf { it.isFile }?.lastModified() ?: dir.lastModified()

    private fun touch(dir: File) {
        runCatching { File(dir, ACCESS).writeText("1") }
    }

    private fun installStamp(context: Context): Long = runCatching {
        context.packageManager.getPackageInfo(context.packageName, android.content.pm.PackageManager.PackageInfoFlags.of(0)).lastUpdateTime
    }.getOrDefault(0L)

    /** The project as it is rendered. One save/load round trip first, so a scene read back from disk looks the same as the one that was rendered. */
    private fun canonical(key: CacheKey): String =
        Scene.parse(key.scene.node.toXml()).node.let { it.copy(attrs = it.attrs - setOf("title", "modifiedTime", "createdTime")) }.toXml()

    /** Everything except the scene that changes what a rendered frame looks like. */
    private fun environment(context: Context, key: CacheKey, cell: Float): String {
        val text = "v$VERSION|${installStamp(context)}|${key.divisor}|${key.androidEmoji}|${key.accurateBlur}|${key.group.joinToString(",")}|${cell.toInt()}"
        return MessageDigest.getInstance("SHA-256").digest(text.toByteArray()).joinToString("") { "%02x".format(it) }
    }

    fun total(context: Context): Long = dirs(context).sumOf { dirBytes(it) }

    fun list(context: Context): List<Entry> = dirs(context).mapNotNull { d ->
        val info = runCatching { JSONObject(File(d, INFO).readText()) }.getOrNull() ?: return@mapNotNull null
        if (!File(d, META).isFile) return@mapNotNull null
        Entry(d.name, info.optString("name", d.name), dirBytes(d), info.optInt("frames"), info.optBoolean("complete"), accessed(d))
    }.sortedByDescending { it.accessed }

    fun clearProject(context: Context, id: String) {
        File(root(context), id).deleteRecursively()
    }

    fun clearAll(context: Context) {
        root(context).deleteRecursively()
    }

    /** Frees space from the least recently used projects. The open project is never touched. */
    private fun makeRoom(context: Context, need: Long, limit: Long, mode: Int, activeId: String): Boolean {
        val active = safe(activeId)
        val others = dirs(context).filter { it.name != active }.sortedBy { accessed(it) }
        var used = others.sumOf { dirBytes(it) }
        if (used + need <= limit) return true
        if (mode == MANUAL) return false
        for (d in others) {
            if (used + need <= limit) break
            used -= dirBytes(d)
            d.deleteRecursively()
        }
        return used + need <= limit
    }

    fun cleanup(context: Context, limit: Long, mode: Int, activeId: String) {
        if (mode == MANUAL) return
        val active = safe(activeId)
        val now = System.currentTimeMillis()
        if (mode == AGGRESSIVE) dirs(context).filter { it.name != active && now - accessed(it) > STALE_MS }.forEach { it.deleteRecursively() }
        val target = if (mode == AGGRESSIVE && context.applicationContext.filesDir.usableSpace < LOW_STORAGE) limit / 2 else limit
        var used = total(context)
        for (d in dirs(context).filter { it.name != active }.sortedBy { accessed(it) }) {
            if (used <= target) break
            used -= dirBytes(d)
            d.deleteRecursively()
        }
    }

    fun save(
        context: Context, projectId: String, name: String, key: CacheKey, store: FrameStore, width: Int, height: Int, cell: Float,
        complete: Boolean, limit: Long, mode: Int,
    ): Boolean {
        val app = context.applicationContext
        if (store.count == 0) return false
        if (!makeRoom(app, store.bytes, limit, mode, projectId)) {
            Log.i(TAG, "render cache not saved: limit reached")
            return false
        }
        val project = dir(app, projectId)
        project.mkdirs()
        val stamp = System.nanoTime()
        val frames = File(project, "frames-$stamp.bin")
        val tmpFrames = File(project, "frames-$stamp.bin.tmp")
        val ids = ArrayList<Int>()
        val offsets = ArrayList<Long>()
        val sizes = ArrayList<Int>()
        val crcs = ArrayList<Long>()
        try {
            BufferedOutputStream(FileOutputStream(tmpFrames), 1 shl 16).use { out ->
                var offset = 0L
                for (frame in store.first..store.last) {
                    val bytes = store[frame] ?: continue
                    out.write(bytes)
                    ids += frame
                    offsets += offset
                    sizes += bytes.size
                    crcs += CRC32().apply { update(bytes) }.value
                    offset += bytes.size
                }
            }
            if (ids.isEmpty() || !tmpFrames.renameTo(frames)) {
                tmpFrames.delete()
                return false
            }
            val meta = JSONObject()
                .put("version", VERSION)
                .put("env", environment(app, key, cell))
                .put("scene", canonical(key))
                .put("width", width)
                .put("height", height)
                .put("first", ids[0])
                .put("file", frames.name)
                .put("size", frames.length())
                .put("f", JSONArray(ids))
                .put("o", JSONArray(offsets))
                .put("s", JSONArray(sizes))
                .put("c", JSONArray(crcs))
            val tmpMeta = File(project, "$META.tmp")
            tmpMeta.writeText(meta.toString())
            if (!tmpMeta.renameTo(File(project, META))) {
                tmpMeta.delete()
                frames.delete()
                return false
            }
            File(project, INFO).writeText(JSONObject().put("name", name).put("frames", ids.size).put("complete", complete).toString())
            touch(project)
            project.listFiles { f -> f.name.startsWith("frames-") && f.name != frames.name }?.forEach { it.delete() }
            Log.i(TAG, "render cache saved frames=%d bytes=%d".format(ids.size, frames.length()))
            return true
        } catch (e: Exception) {
            Log.w(TAG, "saving the render cache failed", e)
            tmpFrames.delete()
            return false
        }
    }

    /**
     * Returns the saved frames that are still valid. When the project was edited since, only the frames the edit
     * touches are dropped (the same dependency check the live preview uses), so unaffected frames are reused.
     */
    fun load(context: Context, projectId: String, key: CacheKey, cell: Float, width: Int, height: Int): Loaded? {
        val app = context.applicationContext
        val project = dir(app, projectId)
        val metaFile = File(project, META)
        if (!metaFile.isFile) return null
        try {
            val meta = JSONObject(metaFile.readText())
            if (meta.getInt("version") != VERSION) {
                project.deleteRecursively()                 // saved by an older layout: never readable again, so give the space back
                return null
            }
            if (meta.getInt("width") != width || meta.getInt("height") != height) return null
            if (meta.getString("env") != environment(app, key, cell)) return null
            val file = File(project, meta.getString("file"))
            if (!file.isFile || file.length() != meta.getLong("size")) {
                project.deleteRecursively()
                return null
            }
            val ids = meta.getJSONArray("f")
            val offsets = meta.getJSONArray("o")
            val sizes = meta.getJSONArray("s")
            val crcs = meta.getJSONArray("c")
            val store = FrameStore(meta.getInt("first"), file.length().coerceAtLeast(1L), file, keepFile = true)
            for (i in 0 until ids.length()) store.adopt(ids.getInt(i), offsets.getLong(i), sizes.getInt(i))
            if (!intact(store, ids, crcs)) {
                store.close()
                project.deleteRecursively()
                return null
            }
            val now = canonical(key)
            val saved = meta.getString("scene")
            var pruned = false
            if (saved != now) {
                val after = Scene.parse(now)
                val dirty = previewDirtyRanges(Scene.parse(saved), after)
                val last = after.lastFrame
                store.removeWhere { frame -> frame > last || dirty.any { frame in it } }
                pruned = true
                if (store.count == 0) {
                    store.close()
                    return null
                }
            }
            touch(project)
            return Loaded(store, pruned)
        } catch (e: Exception) {
            Log.w(TAG, "restoring the render cache failed", e)
            return null
        }
    }

    private fun intact(store: FrameStore, ids: JSONArray, crcs: JSONArray): Boolean {
        if (ids.length() == 0) return false
        for (i in setOf(0, ids.length() / 2, ids.length() - 1)) {
            val bytes = store[ids.getInt(i)] ?: return false
            if (CRC32().apply { update(bytes) }.value != crcs.getLong(i)) return false
        }
        return true
    }
}

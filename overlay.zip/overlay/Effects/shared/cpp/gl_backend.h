// gl_backend.h — a real GPU execution backend for the render graph (render_graph.h): GLSL ES and desktop GLSL passes are
// compiled by the DRIVER and drawn into RGBA8 / RGBA16F / RGBA32F textures.
//
//   GlContext   an EGL context (ES 3.x or desktop GL 3.3+/4.x) with a 1x1 pbuffer, for hosts that have none (tests, tools),
//               or GlContext::Adopt() to run inside the engine's own EGL context.
//   GlBackend   rg::Backend: compile (driver, cached as program binaries in ShaderCache), bind uniforms and samplers by
//               reflection, draw a full-screen triangle, blend, read back for tests. Formats are PROBED on the device
//               (create, attach, clear to a value outside 0..1 / outside half precision, read back), never assumed.
//
// No GL or EGL header is needed: every entry point is loaded at run time (eglGetProcAddress), so the same source builds on
// Android (libEGL / libGLESv3 are already linked), on Linux with Mesa (llvmpipe: real GLES 3.2 and GL 4.5 on the CPU) and on macOS.
//
// What it does NOT run (and says so through supports()/accepts()): lang=vulkan-glsl and lang=spirv (no SPIR-V compiler or SPIR-V
// loader is linked; see docs/NATIVE_SHADERS.md), desktop GLSL on an ES context, GLSL ES on a desktop context.
//
// Threading: every call, including construction and destruction, must be made on the thread the context is current on.
// Builds with -fno-exceptions -fno-rtti.
#pragma once

#include "fence_stats.h"
#include "render_graph.h"
#include "shader_cache.h"
#include "shader_info.h"

#include <cstdint>
#include <map>
#include <memory>
#include <set>
#include <string>
#include <thread>
#include <vector>

struct AHardwareBuffer;   // Android only; declared here so the header needs no Android header

namespace am::rg {

// ---------------------------------------------------------------- GL / EGL entry points (loaded, not linked)
struct GlFns;
using GetProc = void* (*)(const char*);
GetProc DefaultGetProc();                                  // dlopen("libEGL") + eglGetProcAddress; nullptr when there is no EGL

// ---------------------------------------------------------------- context
class GlContext {
public:
    enum class Api { ES, Desktop };
    ~GlContext();
    GlContext(const GlContext&) = delete;
    GlContext& operator=(const GlContext&) = delete;

    // Creates a context and makes it current on this thread. Api::ES asks for ES 3.x (highest the driver gives, >= 3.0),
    // Api::Desktop for a core profile 3.3 .. 4.6. nullptr + *error when the platform cannot.
    static std::unique_ptr<GlContext> Create(Api api, std::string* error);
    // Uses whatever context is current on this thread (the engine's). Never destroys it.
    static std::unique_ptr<GlContext> Adopt(std::string* error);

    bool makeCurrent();
    Api api() const { return fApi; }
    GetProc getProc() const { return fGetProc; }
    bool owned() const { return fOwned; }
private:
    GlContext() = default;
    void* fDisplay = nullptr; void* fContext = nullptr; void* fSurface = nullptr;
    Api fApi = Api::ES;
    GetProc fGetProc = nullptr;
    bool fOwned = false;
    void* fEgl = nullptr;
};

// ---------------------------------------------------------------- device report
struct GlDeviceCaps {
    std::string vendor, renderer, version, glsl;           // as the driver reports them
    bool es = true;
    int major = 0, minor = 0;                              // context version
    int maxTextureSize = 0, maxColorAttachments = 0, maxTextureUnits = 0;
    GlslDevice glslDevice;                                 // for CheckGlslHeader
    // Per format, from a real create / attach / clear / read-back probe (not from extension names):
    struct FormatCaps { bool renderable = false; bool linear = false; bool blend = false; bool exactFloat = false; std::string note; };
    FormatCaps rgba8, rgba16f, rgba32f;
    bool programBinary = false;                            // glGetProgramBinary works: compiled shaders can be cached on disk
    bool timerQuery = false;                               // GPU time per pass (EXT_disjoint_timer_query / ARB_timer_query)
    bool resetNotification = false;                        // context loss can be detected (KHR_robustness / EXT_robustness / GL 4.5)
    bool borderClamp = false;                              // Wrap::Decal is available
    const FormatCaps& of(Format f) const { return f == Format::RGBA32F ? rgba32f : f == Format::RGBA16F ? rgba16f : rgba8; }
    std::string describe() const;                          // human readable, one line per fact (used by tests and the profiler)
};

struct GlStats {
    int64_t shaderCompiles = 0, programMemoryHits = 0, programDiskHits = 0, programDiskStores = 0, programDiskRejected = 0;
    int64_t targetsCreated = 0, targetsDestroyed = 0, passesRun = 0, drawCalls = 0;
    int64_t liveTargets = 0, liveBytes = 0, peakBytes = 0;
    int64_t gpuNanosTotal = 0;                             // sum of per-pass GPU time (timer query or finish-bracketed wall time)
};

struct GlOptions {
    std::string cacheDirectory;                            // "" = no disk cache of compiled programs
    int64_t cacheMaxBytes = 32 << 20;
    bool profile = false;                                  // measure every pass (glFinish bracket when there is no timer query)
    Format working = Format::Inherit;                      // Inherit = RGBA16F when renderable and linearly filterable, else RGBA8
};

class GlBackend : public Backend {
public:
    class GlTarget;
    // The context must be current. `ok()` is false (and error() says why) when the driver is unusable (no ES 3.0 / GL 3.3).
    GlBackend(GlContext& context, const GlOptions& options = GlOptions());
    ~GlBackend() override;
    bool ok() const { return fOk; }
    const std::string& error() const { return fError; }
    const GlDeviceCaps& caps() const { return fCaps; }
    const GlStats& stats() const { return fStats; }

    // ---- rg::Backend
    const char* name() const override { return fName.c_str(); }
    bool supports(Lang) const override;
    bool supports(Format) const override;
    Format workingFormat() const override { return fWorking; }
    int maxTextureSize() const override { return fCaps.maxTextureSize; }
    Target* create(int w, int h, Format f) override;
    void destroy(Target*) override;
    Target* texture(const TextureDesc&) override;
    Target* blank(int w, int h, Format f) override;
    bool run(const PassRun&, std::string* error) override;
    int64_t gpuNanos() override { return fLastGpuNs; }
    bool accepts(const PassDesc& pass, Diag* why) override;

    // ---- hand-off with another backend (Skia) through AHardwareBuffer storage. Android only: elsewhere canShare() is false and the
    // hand-off calls refuse with a clear message. Synchronisation is a glFinish before the other API reads (EGL native fence sync can
    // replace it later); the other side submits and waits before it hands a target to us.
    bool canShare(Format f) const override;
    Target* createShared(int w, int h, Format f) override;
    bool release(Target* t, Backend& to, std::string* error) override;
    Target* acquire(Backend& from, Target* t, bool forWrite, std::string* error) override;
    void relinquish(Target* view) override;
    void reclaim(Target* t, Backend& user) override;
    // The other API's fence (sync fd): when EGL_ANDROID_native_fence_sync + EGL_KHR_wait_sync exist, this context's GPU queue waits for it
    // (the CPU does not block); otherwise, or if EGL refuses the fd, the calling thread waits on it. Takes the fd either way.
    bool waitForeign(int fd, std::string* error) override;
    size_t viewCount() const { return fViews.size(); }     // cached GL views of foreign buffers (tests, profiler)

    // ---- pixel access (tests, thumbnails, the CPU side of export). Rows are top to bottom, premultiplied RGBA.
    bool upload(Target*, const float* rgba);               // w*h*4 floats; RGBA8 targets quantise
    bool uploadRgba8(Target*, const uint8_t* rgba);
    bool readback(Target*, std::vector<float>* rgba);      // exact for 16F / 32F, 0..1 steps for RGBA8
    Target* createFromFloats(int w, int h, Format f, const float* rgba);

    // ---- shared buffers (Android): a target backed by an AHardwareBuffer, so Skia / Vulkan can read what a pass drew and a pass can
    // sample what Skia drew, with no copy. Formats: RGBA8 and RGBA16F only (there is no AHardwareBuffer format for RGBA32F).
    // On other platforms these return nullptr / false. `cpuAccess` adds CPU read/write usage (tests only; slower on some GPUs).
    Target* createShared(int w, int h, Format f, AHardwareBuffer** buffer, bool cpuAccess = false);
    Target* wrapShared(AHardwareBuffer* buffer);           // GL view of an existing buffer (takes its own reference)
    AHardwareBuffer* sharedBuffer(Target*) const;          // nullptr for ordinary targets
    bool finishShared();                                   // glFinish: all GL writes are visible to the next API that reads the buffer

    // ---- diagnostics
    const std::vector<Diag>& lastDiags() const { return fDiags; }   // compile messages of the last failed or warned compile, mapped to file:line
    bool contextLost();                                    // true once the driver reports a reset (every later call fails cleanly)
    void dropPrograms();                                   // free compiled programs (low memory); they are rebuilt (disk cache first) on demand
    size_t programCount() const { return fPrograms.size(); }
    int compileProgramForTest(const PassDesc& pass, std::string* log);   // compile only, returns the GL program id or 0

private:
    struct Program;
    struct SamplerKey;
    Program* program(const PassDesc& pass, std::string* error);
    bool compileProgram(const PassDesc& pass, Program* out, std::string* error);
    bool probeFormats();
    bool probeFormat(Format f, GlDeviceCaps::FormatCaps* caps);
    unsigned sampler(Filter f, Wrap w);
    bool checkThread(std::string* error) const;
    Target* adoptShared(AHardwareBuffer* buffer, Format f, int w, int h);
    void noteError(const char* where);
    GlFns* gl() const { return fGl.get(); }

    GlContext& fContext;
    GlOptions fOptions;
    std::unique_ptr<GlFns> fGl;
    std::unique_ptr<ShaderCache> fDiskCache;
    GlDeviceCaps fCaps;
    GlStats fStats;
    Format fWorking = Format::RGBA8;
    std::string fName = "gl";
    std::string fError;
    bool fOk = false;
    std::thread::id fThread;
    unsigned fVao = 0, fVbo = 0;
    std::map<uint64_t, std::unique_ptr<Program>> fPrograms;
    std::map<int, unsigned> fSamplers;
    std::map<std::string, std::unique_ptr<GlTarget>> fTextures, fBlanks;
    std::set<GlTarget*> fLive;
    struct View { GlTarget* target; int users; uint64_t used; };
    std::map<AHardwareBuffer*, View> fViews;                // GL views of buffers another backend owns, kept while that buffer lives
    uint64_t fViewClock = 0;
    void freeView(GlTarget* t);
    void trimViews(bool all);
    std::vector<Diag> fDiags;
    int64_t fLastGpuNs = -1;
    unsigned fQuery = 0;
    bool fLost = false;
    int fFenceState = -1;                                  // EGL fence support: -1 not probed yet, 0 absent, 1 usable
    void* fEglCreateSync = nullptr; void* fEglWaitSync = nullptr; void* fEglDestroySync = nullptr;
    enum class FenceWait { NotTaken, Queued, Failed };
    FenceWait gpuWaitOnFence(int fd);                      // NotTaken: the fd is still the caller's. Queued / Failed: EGL owns the fd now
};

// Format <-> text used by reports.
const char* FormatText(Format f);

}  // namespace am::rg

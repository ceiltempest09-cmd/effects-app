package com.effects.motion.ai

import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.geometry.Offset
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.CoroutineStart
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancelAndJoin
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** The cut-out brush session that is open in the editor right now (read by the canvas overlay). */
internal object CutoutBrush {
    var session by mutableStateOf<CutoutSession?>(null)
}

/** One brush stroke; points are fractions (0..1) of the layer as it is shown on the canvas. */
internal class BrushStroke(val keep: Boolean, val points: List<Offset>)

/** A prompt point in picture (frame) fractions. */
internal class BrushPoint(val u: Float, val v: Float, val keep: Boolean)

/**
 * Live brush cut-out: the person paints green (keep) or red (remove) strokes on the canvas, the strokes are
 * thinned to at most 8 prompt points, EdgeTAM decodes them and the selection is shown as an outline.
 */
internal class CutoutSession(val layerId: Long, private val uri: String, private val turn: Int) {
    enum class Phase { Loading, Ready, Failed }

    val strokes = mutableStateListOf<BrushStroke>()
    var erase by mutableStateOf(false)
    var phase by mutableStateOf(Phase.Loading)
        private set
    var busy by mutableStateOf(false)
        private set
    var message by mutableStateOf("")
        private set
    var overlay by mutableStateOf<Bitmap?>(null)
        private set
    var live by mutableStateOf<List<Offset>>(emptyList())
        private set

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var loading: Job? = null
    private var job: Job? = null
    private var net: EdgeTam? = null
    private var width = 1
    private var height = 1
    @Volatile private var closed = false

    fun start(context: Context, preparing: String, failed: String) {
        val app = context.applicationContext
        loading = scope.launch {
            try {
                if (!AiModel.EdgeTam.installed(app)) {
                    message = preparing
                    EdgeCutout.install(app) {}
                }
                message = preparing
                val picture = withContext(Dispatchers.IO) { BestCutout.decode(app, Uri.parse(uri), EDGE_PREVIEW_SIDE) }
                try {
                    width = picture.width
                    height = picture.height
                    val opened = EdgeTam.open(app)
                    try {
                        opened.setImage(picture)
                    } catch (t: Throwable) {
                        opened.close()
                        throw t
                    }
                    if (closed) opened.close() else net = opened
                } finally {
                    picture.recycle()
                }
                if (!closed) {
                    message = ""
                    phase = Phase.Ready
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                fail(e.message ?: failed)
            } catch (_: OutOfMemoryError) {
                fail(failed)
            } catch (_: LinkageError) {
                fail(failed)
            }
        }
    }

    private fun fail(text: String) {
        message = text
        phase = Phase.Failed
    }

    fun begin(p: Offset) {
        if (phase == Phase.Ready) live = listOf(p)
    }

    fun extend(p: Offset) {
        val last = live.lastOrNull() ?: return
        if ((last - p).getDistance() > 0.004f && live.size < 400) live = live + p
    }

    fun end() {
        val points = live
        live = emptyList()
        if (points.isEmpty()) return
        strokes.add(BrushStroke(!erase, points))
        refresh()
    }

    fun undo() {
        if (strokes.isNotEmpty()) strokes.removeAt(strokes.lastIndex)
        refresh()
    }

    fun clear() {
        strokes.clear()
        refresh()
    }

    val hasKeep: Boolean get() = strokes.any { it.keep }

    /** Prompt points: at least one per stroke, extra points spread along longer strokes, 8 at most. */
    fun points(): List<BrushPoint> {
        val list = strokes.toList().takeLast(EdgeTam.MAX_PROMPTS)
        if (list.isEmpty()) return emptyList()
        val take = IntArray(list.size) { 1 }
        var spare = EdgeTam.MAX_PROMPTS - list.size
        var grew = true
        while (spare > 0 && grew) {
            grew = false
            for (i in list.indices) {
                if (spare > 0 && take[i] < minOf(4, list[i].points.size)) {
                    take[i]++
                    spare--
                    grew = true
                }
            }
        }
        return list.flatMapIndexed { i, stroke ->
            val pts = stroke.points
            val picked = if (take[i] <= 1) listOf(pts[pts.size / 2]) else List(take[i]) { k -> pts[k * (pts.size - 1) / (take[i] - 1)] }
            picked.map { p ->
                val (u, v) = viewToFrame(p.x.coerceIn(0f, 1f), p.y.coerceIn(0f, 1f), turn)
                BrushPoint(u, v, stroke.keep)
            }
        }
    }

    private fun refresh() {
        job?.cancel()
        val previous = job
        val prompts = points().map { EdgePrompt(it.u * width, it.v * height, if (it.keep) EDGE_FOREGROUND else EDGE_BACKGROUND) }
        if (prompts.none { it.label == EDGE_FOREGROUND }) {
            overlay = null
            busy = false
            return
        }
        lateinit var mine: Job
        mine = scope.launch(start = CoroutineStart.LAZY) {
            previous?.join()
            busy = true
            try {
                val engine = net ?: return@launch
                val mask = engine.decode(prompts)
                overlay = withContext(Dispatchers.Default) { outline(mask) }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                message = e.message.orEmpty()
            } finally {
                if (job === mine) busy = false
            }
        }
        job = mine
        mine.start()
    }

    /** Mask (picture space) -> overlay bitmap in canvas space: pink outline, light green fill, dimmed outside. */
    private fun outline(mask: FloatArray): Bitmap {
        val n = EDGE_MASK_SIDE
        val inside = BooleanArray(n * n)
        for (y in 0 until n) for (x in 0 until n) {
            val (fu, fv) = viewToFrame((x + .5f) / n, (y + .5f) / n, turn)
            val mx = (fu * n).toInt().coerceIn(0, n - 1)
            val my = (fv * n).toInt().coerceIn(0, n - 1)
            inside[y * n + x] = mask[my * n + mx] > 0.5f
        }
        val pixels = IntArray(n * n)
        for (y in 0 until n) for (x in 0 until n) {
            val i = y * n + x
            pixels[i] = if (!inside[i]) 0x59000000 else {
                val edge = x == 0 || y == 0 || x == n - 1 || y == n - 1 || !inside[i - 1] || !inside[i + 1] || !inside[i - n] || !inside[i + n]
                if (edge) 0xFFFF4DA6.toInt() else 0x403DDC84
            }
        }
        return Bitmap.createBitmap(pixels, n, n, Bitmap.Config.ARGB_8888)
    }

    fun close() {
        closed = true
        val jobs = listOfNotNull(loading, job)
        CoroutineScope(Dispatchers.Default).launch {
            jobs.forEach { it.cancelAndJoin() }
            net?.close()
            net = null
            scope.coroutineContext[Job]?.cancel()
        }
    }

    private companion object {
        const val EDGE_PREVIEW_SIDE = 1024
    }
}

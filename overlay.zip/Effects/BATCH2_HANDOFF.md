# Batch 2 continuation handoff (2026-11-22)

## What this archive is
This is the current `overlay.zip` project tree with only missing native/support source headers restored from `Effects.zip`.
All pre-existing `overlay.zip` files were preserved; no existing overlay file was overwritten.

## Reconciliation performed
- Added 21 absent `.h` / native test source files from `Effects.zip`.
- Added files are support headers for the existing LAME, RNNoise and RIFE build sources, plus native renderer test sources.
- The archive still has the `Effects/` project root. When uploading to the existing repository, upload the CONTENTS of `Effects/`, not a nested `Effects/Effects/` directory.

## Batch 2 status — NOT COMPLETE
The current app engine is still Skia-backed:
- `shared/cpp/engine.cpp` includes and uses Skia Ganesh/Graphite surfaces and canvases.
- `shared/cpp/scene.h` and `scene.cpp` use Skia path, matrix, image, and canvas types.
- `shared/cpp/gl_yuv.cpp` has a native GLES conversion function, but the active engine call site uses `fYuv.convert(...)`, which wraps the GL texture back into a Skia `SkImage`.
- `GraphGpuBridge` sharing is implemented for Graphite/Vulkan only. `sharesWithNative()` explicitly rejects the Ganesh/OpenGL engine.
- `GraphRunner`'s native GL backend creates its own EGL context, while the app's Ganesh GL renderer owns a separate context. A safe shared-context/resource/fence design is still required.

## Next actual Batch 2 engineering task
Implement and test a supported engine-owned GL context/resource bridge for the OpenGL engine, or redesign the frame lifecycle around one native GLES context. Do not simply enable a second independent context or remove Skia build dependencies: that would risk invalid texture ownership, unsynchronized GPU access, and a broken preview.
Android NDK build and device validation remain required before marking Batch 2 complete.

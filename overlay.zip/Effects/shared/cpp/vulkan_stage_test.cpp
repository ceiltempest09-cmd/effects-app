// vulkan_stage_test.cpp - GPU Test stage "vulkan-hardening" (phase 5B). Runs the effect backend (rg::Backend "vulkan") directly:
//   A. shaders it must refuse, each with a readable message, and valid controls it must accept
//   B. texture edge handling (clamp / repeat / mirror) read back and compared with the CPU
//   C. three chained passes (RGBA8 and RGBA16F) and a feedback loop that must be refused
//   D. RGBA32F: renders; blending into it is refused when the device cannot blend it
//   E. targets created and destroyed leave no live Vulkan targets behind
// Crash isolation like vulkan_exec: a crumb file <cacheDir>/vkstage.stage; if the app died inside, the next run says so and skips once.
#include "vulkan_stage_test.h"

#include "glsl_compile.h"
#include "render_graph.h"
#include "spirv_util.h"
#include "vulkan_backend.h"

#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <string>
#include <vector>

namespace am {
using namespace rg;

namespace {

struct Out {
    std::string* text; int* pass; int* fail;
    void line(const std::string& s) { *text += s + "\n"; }
    void check(bool c, const std::string& s) { if (c) { (*pass)++; line("PASS  " + s); } else { (*fail)++; line("FAIL  " + s); } }
    void info(const std::string& s) { line("INFO  " + s); }
};

std::string Num(double v) { char b[64]; std::snprintf(b, sizeof b, "%.5g", v); return b; }
bool Has(const std::string& t, const char* s) { return t.find(s) != std::string::npos; }
std::string Lower(std::string s) { for (char& c : s) if (c >= 'A' && c <= 'Z') c = (char)(c - 'A' + 'a'); return s; }

PassDesc Make(const char* id, Lang lang, const std::string& src) {
    PassDesc p; p.id = p.name = id; p.lang = lang; p.source = src; p.file = "gpu-test";
    return p;
}

bool Accepts(Backend& be, const PassDesc& p, std::string* why) {
    Diag d;
    const bool ok = be.accepts(p, &d);
    *why = d.message;
    return ok;
}

std::string SpirvBase64(const std::string& fragmentOrVertex, GlslStage stage) {
    GlslCompileResult c = CompileGlslToSpirv(fragmentOrVertex, GlslDialect::Vulkan, stage);
    if (!c.ok) return std::string();
    return Base64Encode(reinterpret_cast<const uint8_t*>(c.words.data()), c.words.size() * 4);
}

// ---------------------------------------------------------------- A. refusals
void RefusalTests(Out& O, Backend& be) {
    const int before = VulkanBackendLiveTargets(&be);
    struct Case { const char* what; Lang lang; std::string src; const char* expect; };
    const std::string kHead = "#version 450\n";
    const std::string fragOnlyVertexModule = SpirvBase64(
        "#version 450\nvoid main() { gl_Position = vec4(0.0, 0.0, 0.0, 1.0); }\n", GlslStage::Vertex);
    const std::vector<Case> cases = {
        {"syntax error (Vulkan GLSL)", Lang::VulkanGLSL, kHead + "layout(location = 0) out vec4 o;\nvoid main() { o = vec4(1.0) }\n", "glslang"},
        {"fragment 'in' variable", Lang::VulkanGLSL, kHead + "layout(location = 0) in vec2 uv;\nlayout(location = 0) out vec4 o;\nvoid main() { o = vec4(uv, 0.0, 1.0); }\n", "'in' variable"},
        {"push constants", Lang::VulkanGLSL, kHead + "layout(push_constant) uniform P { float g; } pc;\nlayout(location = 0) out vec4 o;\nvoid main() { o = vec4(pc.g); }\n", "push constants"},
        {"storage buffer", Lang::VulkanGLSL, kHead + "layout(std430, set = 0, binding = 1) buffer B { float v[]; };\nlayout(location = 0) out vec4 o;\nvoid main() { o = vec4(v[0]); }\n", "storage buffers"},
        {"descriptor set 1", Lang::VulkanGLSL, kHead + "layout(std140, set = 1, binding = 0) uniform U { float g; };\nlayout(location = 0) out vec4 o;\nvoid main() { o = vec4(g); }\n", "only set 0"},
        {"no colour output", Lang::VulkanGLSL, kHead + "void main() { }\n", "no colour output"},
        {"desktop glsl with a matrix uniform", Lang::GLSL, "#version 330\nuniform mat4 m;\nout vec4 o;\nvoid main() { o = m[0]; }\n", "cannot run on Vulkan as written"},
        {"desktop glsl older than 330", Lang::GLSL, "#version 120\nvoid main() { gl_FragColor = vec4(1.0); }\n", ""},
        {"spirv that is not base64", Lang::SPIRV, "!!!this is not base64!!!", "not valid base64"},
        {"spirv with valid base64 but garbage bytes", Lang::SPIRV, "AAAAAAAAAAAAAAAAAAAAAAAA", "not valid"},
        {"spirv with only a vertex entry point", Lang::SPIRV, fragOnlyVertexModule, "no fragment entry point"},
    };
    for (const Case& c : cases) {
        if (c.lang == Lang::SPIRV && c.src.empty()) { O.line("SKIP  refusal: " + std::string(c.what) + " (could not build the module)"); continue; }
        std::string why;
        const bool ok = Accepts(be, Make("bad", c.lang, c.src), &why);
        const bool matched = c.expect[0] == 0 ? !why.empty() : Has(why, c.expect);
        O.check(!ok && matched, std::string("refused: ") + c.what + " -> \"" + (why.size() > 110 ? why.substr(0, 110) + "..." : why) + "\"");
    }
    // controls: the same machinery must still ACCEPT good shaders after all those refusals
    std::string why;
    const std::string good = kHead + "layout(std140, set = 0, binding = 0) uniform U { vec2 size; };\nlayout(location = 0) out vec4 o;\nvoid main() { o = vec4(gl_FragCoord.xy / size, 0.0, 1.0); }\n";
    O.check(Accepts(be, Make("good-vk", Lang::VulkanGLSL, good), &why), "accepted: valid Vulkan GLSL after the refusals" + (why.empty() ? std::string() : " (" + why + ")"));
    const std::string b64 = SpirvBase64(good, GlslStage::Fragment);
    O.check(!b64.empty() && Accepts(be, Make("good-spv", Lang::SPIRV, b64), &why), "accepted: valid SPIR-V module (base64)" + (why.empty() ? std::string() : " (" + why + ")"));
    O.check(Accepts(be, Make("good-gl", Lang::GLSL, "#version 330\nuniform vec2 size;\nout vec4 o;\nvoid main() { o = vec4(gl_FragCoord.xy / size, 0.0, 1.0); }\n"), &why), "accepted: valid desktop GLSL (loose uniform)" + (why.empty() ? std::string() : " (" + why + ")"));
    O.check(VulkanBackendLiveTargets(&be) == before, "refusing and accepting shaders created no Vulkan targets (" + std::to_string(before) + " before and after)");
}

// ---------------------------------------------------------------- helpers for rendering
const char* kConst = "#version 330\nuniform vec2 size;\nuniform vec4 value;\nout vec4 o;\nvoid main() { o = value; }\n";
const char* kRamp = "#version 330\nuniform vec2 size;\nout vec4 o;\nvoid main() { o = vec4(gl_FragCoord.x / size.x, 0.0, 0.0, 1.0); }\n";
const char* kShift = "#version 330\nuniform sampler2D src;\nuniform vec2 size;\nuniform float shift;\nout vec4 o;\n"
                     "void main() { o = texture(src, vec2(gl_FragCoord.x / size.x + shift, 0.5)); }\n";
const char* kAdd = "#version 330\nuniform sampler2D src;\nuniform vec2 size;\nout vec4 o;\n"
                   "void main() { o = texture(src, gl_FragCoord.xy / size) + vec4(0.1, 0.1, 0.1, 0.0); }\n";
const char* kScale = "#version 330\nuniform sampler2D src;\nuniform vec2 size;\nout vec4 o;\n"
                     "void main() { o = texture(src, gl_FragCoord.xy / size) * vec4(2.0, 1.0, 0.5, 1.0); }\n";

bool RunPass(Backend& be, PassDesc& p, Target* out, Target* in, Wrap wrap, bool clear, int w, int h, std::string* err) {
    static const std::string kName = "src";
    PassRun r; r.pass = &p; r.output = out; r.areaWidth = w; r.areaHeight = h; r.clear = clear;
    if (in) { BoundInput b; b.name = &kName; b.target = in; b.filter = Filter::Nearest; b.wrap = wrap; r.inputs.push_back(b); }
    return be.run(r, err);
}

double Tol(Format f) { return f == Format::RGBA8 ? 3.0 / 255 : f == Format::RGBA16F ? 2e-3 : 1e-4; }

// ---------------------------------------------------------------- B. edges
void EdgeTest(Out& O, Backend& be, Format f, Wrap wrap, const char* wrapName) {
    const std::string tag = std::string("edge ") + wrapName + " " + ToString(f);
    const int W = 8, H = 2;
    Target* a = VulkanBackendCreatePrivate(&be, W, H, f);
    Target* b = VulkanBackendCreatePrivate(&be, W, H, f);
    if (!a || !b) { O.check(false, tag + ": could not allocate targets"); if (a) be.destroy(a); if (b) be.destroy(b); return; }
    PassDesc pa = Make("ramp", Lang::GLSL, kRamp), pb = Make("shift", Lang::GLSL, kShift);
    pb.constants.push_back({"shift", {0.5f}});     // exactly 4 texels to the right
    std::string err; std::vector<float> px;
    if (!RunPass(be, pa, a, nullptr, Wrap::Clamp, true, W, H, &err)) { O.check(false, tag + ": ramp pass failed: " + err); be.destroy(a); be.destroy(b); return; }
    if (!RunPass(be, pb, b, a, wrap, true, W, H, &err)) { O.check(false, tag + ": sampling pass failed: " + err); be.destroy(a); be.destroy(b); return; }
    if (!VulkanBackendReadback(&be, b, &px, &err)) { O.check(false, tag + ": readback failed: " + err); be.destroy(a); be.destroy(b); return; }
    double worst = 0;
    for (int y = 0; y < H; y++) for (int x = 0; x < W; x++) {
        const int idx = x + 4;
        int t = idx;
        if (wrap == Wrap::Clamp) t = idx > W - 1 ? W - 1 : idx;
        else if (wrap == Wrap::Repeat) t = idx % W;
        else { const int m = idx % (2 * W); t = m < W ? m : 2 * W - 1 - m; }
        const double expect = (t + 0.5) / W;
        worst = std::fmax(worst, std::fabs(px[((size_t)y * W + x) * 4] - expect));
    }
    O.check(worst <= Tol(f), tag + ": samples past the right edge match the CPU, max error " + Num(worst) + " (limit " + Num(Tol(f)) + ")");
    be.destroy(a); be.destroy(b);
}

// ---------------------------------------------------------------- C. chain and feedback
void ChainTest(Out& O, Backend& be, Format f) {
    const std::string tag = std::string("three chained passes ") + ToString(f);
    if (!be.supports(f)) { O.line(std::string("SKIP  ") + tag + ": format not renderable on this GPU"); return; }
    const int W = 16, H = 4;
    Target* t[3] = {VulkanBackendCreatePrivate(&be, W, H, f), VulkanBackendCreatePrivate(&be, W, H, f), VulkanBackendCreatePrivate(&be, W, H, f)};
    if (!t[0] || !t[1] || !t[2]) { O.check(false, tag + ": could not allocate targets"); for (Target* x : t) if (x) be.destroy(x); return; }
    PassDesc p0 = Make("fill", Lang::GLSL, kConst), p1 = Make("add", Lang::GLSL, kAdd), p2 = Make("scale", Lang::GLSL, kScale);
    p0.constants.push_back({"value", {0.2f, 0.4f, 0.6f, 1.0f}});
    std::string err; std::vector<float> px;
    bool ok = RunPass(be, p0, t[0], nullptr, Wrap::Clamp, true, W, H, &err) && RunPass(be, p1, t[1], t[0], Wrap::Clamp, true, W, H, &err) &&
              RunPass(be, p2, t[2], t[1], Wrap::Clamp, true, W, H, &err) && VulkanBackendReadback(&be, t[2], &px, &err);
    if (!ok) O.check(false, tag + ": " + err);
    else {
        double worst = 0;
        const double e[4] = {0.6, 0.5, 0.35, 1.0};
        for (size_t i = 0; i < (size_t)W * H; i++) for (int c = 0; c < 4; c++) worst = std::fmax(worst, std::fabs(px[i * 4 + c] - e[c]));
        const double tol = f == Format::RGBA8 ? 0.02 : Tol(f);
        O.check(worst <= tol, tag + ": fill -> add -> scale matches the CPU on every pixel, max error " + Num(worst) + " (limit " + Num(tol) + ")");
        // the middle target must be unchanged by the third pass (no write to an input)
        std::vector<float> mid;
        if (VulkanBackendReadback(&be, t[1], &mid, &err)) {
            double w2 = 0; const double m[4] = {0.3, 0.5, 0.7, 1.0};
            for (size_t i = 0; i < (size_t)W * H; i++) for (int c = 0; c < 4; c++) w2 = std::fmax(w2, std::fabs(mid[i * 4 + c] - m[c]));
            O.check(w2 <= (f == Format::RGBA8 ? 0.012 : Tol(f)), tag + ": the middle pass output was not disturbed by later passes, max error " + Num(w2));
        }
    }
    // a pass that reads the buffer it renders into must be refused with a message (no read/write feedback loop on the GPU)
    std::string loop;
    const bool ran = RunPass(be, p1, t[1], t[1], Wrap::Clamp, true, W, H, &loop);
    O.check(!ran && Has(loop, "feedback loop"), std::string("feedback loop refused (") + ToString(f) + "): \"" + loop.substr(0, 100) + "\"");
    for (Target* x : t) be.destroy(x);
}

// ---------------------------------------------------------------- D. RGBA32F
void Rgba32Test(Out& O, Backend& be) {
    if (!be.supports(Format::RGBA32F)) { O.line("SKIP  RGBA32F: not renderable on this GPU"); return; }
    const int W = 8, H = 2;
    Target* a = VulkanBackendCreatePrivate(&be, W, H, Format::RGBA32F);
    if (!a) { O.check(false, "RGBA32F: could not allocate a private target"); return; }
    PassDesc p = Make("hdr", Lang::GLSL, kConst);
    p.constants.push_back({"value", {2.5f, -0.25f, 100.0f, 1.0f}});
    std::string err; std::vector<float> px;
    if (!RunPass(be, p, a, nullptr, Wrap::Clamp, true, W, H, &err) || !VulkanBackendReadback(&be, a, &px, &err)) { O.check(false, "RGBA32F render failed: " + err); be.destroy(a); return; }
    double worst = 0; const double e[4] = {2.5, -0.25, 100.0, 1.0};
    for (size_t i = 0; i < (size_t)W * H; i++) for (int c = 0; c < 4; c++) worst = std::fmax(worst, std::fabs(px[i * 4 + c] - e[c]) / (std::fabs(e[c]) > 1 ? std::fabs(e[c]) : 1.0));
    O.check(worst <= 1e-5, "RGBA32F: values outside 0..1 (2.5, -0.25, 100) are stored exactly, max relative error " + Num(worst));
    const bool noBlend = Has(Lower(VulkanBackendDescribe()), "rgba32f: render yes, blend no");
    if (noBlend) {
        PassDesc add = Make("blend", Lang::GLSL, kConst); add.blend = Blend::Add;
        add.constants.push_back({"value", {0.1f, 0.1f, 0.1f, 0.1f}});
        std::string why;
        const bool ran = RunPass(be, add, a, nullptr, Wrap::Clamp, false, W, H, &why);
        O.check(!ran && Has(why, "blending"), "RGBA32F cannot blend on this GPU: an additive pass into it is refused with \"" + why.substr(0, 90) + "\"");
    } else O.line("SKIP  RGBA32F blend refusal: this GPU can blend RGBA32F");
    be.destroy(a);
}

// ---------------------------------------------------------------- E. leaks
void LeakTest(Out& O, Backend& be) {
    const int before = VulkanBackendLiveTargets(&be);
    std::vector<Target*> all;
    for (int i = 0; i < 24; i++) {
        const Format f = i % 3 == 0 ? Format::RGBA8 : i % 3 == 1 ? Format::RGBA16F : Format::RGBA32F;
        if (!be.supports(f)) continue;
        if (Target* t = VulkanBackendCreatePrivate(&be, 32 + i, 16, f)) all.push_back(t);
    }
    const int during = VulkanBackendLiveTargets(&be);
    PassDesc p = Make("fill", Lang::GLSL, kConst);
    p.constants.push_back({"value", {0.5f, 0.5f, 0.5f, 1.0f}});
    std::string err; bool ran = true;
    for (Target* t : all) ran = ran && RunPass(be, p, t, nullptr, Wrap::Clamp, true, t->width, t->height, &err);
    for (Target* t : all) be.destroy(t);
    const int after = VulkanBackendLiveTargets(&be);
    O.check(ran, "leak test: a pass ran into each of " + std::to_string(all.size()) + " targets" + (ran ? std::string() : ": " + err));
    O.check(during == before + (int)all.size() && after == before, "leak test: live Vulkan targets " + std::to_string(before) + " -> " + std::to_string(during) + " -> " + std::to_string(after) + " (back to the start)");
}

}  // namespace

void RunVulkanStageTests(std::string* text, int* pass, int* fail, const std::string& cacheDir) {
    Out O{text, pass, fail};
    O.line("== Vulkan hardening (refusals, edges, chained passes, RGBA32F, leaks) ==");
    const std::string crumb = cacheDir + "/vkstage.stage";
    if (FILE* f = std::fopen(crumb.c_str(), "rb")) {
        std::fclose(f);
        std::remove(crumb.c_str());
        O.line("SKIP  the previous run died inside this stage (crumb file found); skipped once, run GPU Test again to retry");
        return;
    }
    std::string why;
    Backend* be = SharedVulkanBackend(&why);
    if (!be) { O.line("SKIP  Vulkan effect backend not available: " + why); return; }
    if (FILE* f = std::fopen(crumb.c_str(), "wb")) { std::fputs("running", f); std::fclose(f); }
    RefusalTests(O, *be);
    for (Format f : {Format::RGBA8, Format::RGBA16F}) {
        if (!be->supports(f)) { O.line(std::string("SKIP  edge tests ") + ToString(f) + ": format not renderable"); continue; }
        EdgeTest(O, *be, f, Wrap::Clamp, "clamp");
        EdgeTest(O, *be, f, Wrap::Repeat, "repeat");
        EdgeTest(O, *be, f, Wrap::Mirror, "mirror");
    }
    ChainTest(O, *be, Format::RGBA8);
    ChainTest(O, *be, Format::RGBA16F);
    Rgba32Test(O, *be);
    LeakTest(O, *be);
    O.info("vulkan backend after the stage: " + VulkanBackendDescribe());
    std::remove(crumb.c_str());
}

}  // namespace am

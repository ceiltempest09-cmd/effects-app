package com.effects.motion.export

import com.effects.motion.model.Scene
import org.junit.Assert.assertEquals
import org.junit.Test

class ExportSizeTest {
    private fun scene(width: Int, height: Int) =
        Scene.parse("""<scene width="$width" height="$height" fps="30" totalTime="1000"><shape id="1" startTime="0" endTime="999"/></scene>""")

    @Test fun aTallPhoneProjectAtFourKFitsTheUhdFrameInsteadOfBeingRefused() {
        assertEquals(1686 to 3840, exportSize(scene(1080, 2460), 2160, true))
        assertEquals(3840 to 1686, exportSize(scene(2460, 1080), 2160, true))
    }

    @Test fun ordinaryFourKProjectsAreUnchanged() {
        assertEquals(3840 to 2160, exportSize(scene(1920, 1080), 2160, true))
        assertEquals(2160 to 3840, exportSize(scene(1080, 1920), 2160, true))
        assertEquals(2160 to 2160, exportSize(scene(1080, 1080), 2160, true))
    }

    @Test fun presetsBelowFourKKeepTheirShortSide() {
        assertEquals(1080 to 2460, exportSize(scene(1080, 2460), 1080, true))
        assertEquals(1440 to 3280, exportSize(scene(1080, 2460), 1440, true))
        assertEquals(Int.MAX_VALUE, longSideLimit(1440))
        assertEquals(UhdLongSide, longSideLimit(2160))
    }
}

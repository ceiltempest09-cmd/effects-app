package com.effects.motion

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.graphics.Typeface
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import com.effects.motion.engine.GpuSelfTest
import com.effects.motion.engine.NativeEngine
import android.widget.Switch
import java.io.File
import kotlin.concurrent.thread

/** A separate launcher icon ("GPU Test"): runs the native GPU self-test on this phone and shows the report as text. */
class GpuTestActivity : Activity() {
    private lateinit var out: TextView
    private lateinit var status: TextView

    // What the Effects screen last failed to draw (written by the engine), so a silent "nothing happened" has a visible reason.
    override fun onResume() {
        super.onResume()
        val flag = NativeEngine.nativeShadersRequested(cacheDir)
        val file = cacheDir.listFiles { f -> f.isDirectory && Regex("gpu-\\d+").matches(f.name) }.orEmpty()
            .map { File(it, "last-effect-error.txt") }.firstOrNull { it.exists() }
        status.text = "Native effects switch: " + (if (flag) "ON (needs an app restart after changing)" else "OFF") + "\n" +
            "Last effect draw error: " + (file?.readText()?.trim() ?: "none recorded")
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (16 * resources.displayMetrics.density).toInt()
        val run = Button(this).apply { text = "Run GPU test" }
        val copy = Button(this).apply { text = "Copy report" }
        val nativeSwitch = Switch(this).apply {
            text = "Native GLSL ES in effects (experimental, restart the app to apply)"
            isChecked = NativeEngine.nativeShadersRequested(cacheDir)
            setOnCheckedChangeListener { _, on ->
                NativeEngine.requestNativeShaders(cacheDir, on)
                Toast.makeText(this@GpuTestActivity, if (on) "On after the next app start" else "Off after the next app start", Toast.LENGTH_SHORT).show()
            }
        }
        status = TextView(this).apply { typeface = Typeface.MONOSPACE; textSize = 11f; setTextIsSelectable(true) }
        out = TextView(this).apply { typeface = Typeface.MONOSPACE; textSize = 11f; setTextIsSelectable(true); text = "Tap Run GPU test." }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 2, pad, pad)
            addView(run); addView(copy); addView(nativeSwitch); addView(status)
            addView(ScrollView(this@GpuTestActivity).apply { addView(out) })
        }
        setContentView(root)
        run.setOnClickListener {
            out.text = "Running..."
            run.isEnabled = false
            thread {
                val report = try {
                    GpuSelfTest.run(File(cacheDir, "gpu-selftest").absolutePath)
                } catch (t: Throwable) {
                    "The test crashed: $t"
                }
                runOnUiThread { out.text = report; run.isEnabled = true }
            }
        }
        copy.setOnClickListener {
            (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("gpu report", out.text))
            Toast.makeText(this, "Copied", Toast.LENGTH_SHORT).show()
        }
    }
}

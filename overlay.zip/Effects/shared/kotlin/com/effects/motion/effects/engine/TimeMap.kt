package com.effects.motion.effects.engine

import kotlin.math.abs
import kotlin.math.floor

/** What happens when the mapped source time leaves 0..sourceMs. */
enum class Boundary { Hold, Loop, Mirror, Blank }

/** Key: output (clip) time -> source time, both in ms. Keys must have strictly increasing outMs. */
data class TimeKey(val outMs: Double, val srcMs: Double)

/**
 * Pure, stateless output-time -> source-time mapping. Same input always gives the same result, so scrubbing,
 * reverse, freeze and export agree. Between keys the map is linear: equal srcMs = freeze, falling srcMs = reverse,
 * different slopes = speed ramp. Before the first key / after the last key the end segments continue with the
 * slope they have (freeze if there is only one key).
 */
class TimeMap(keys: List<TimeKey>, val sourceMs: Double, val boundary: Boundary = Boundary.Hold) {
    val keys: List<TimeKey> = keys.sortedBy { it.outMs }

    init {
        require(this.keys.isNotEmpty()) { "time map needs at least one key" }
        require(sourceMs > 0.0) { "source length must be positive" }
        require(this.keys.zipWithNext().all { (a, b) -> b.outMs > a.outMs }) { "time map keys must have strictly increasing output times" }
        require(this.keys.all { it.outMs.isFinite() && it.srcMs.isFinite() }) { "time map keys must be finite" }
    }

    /** Unbounded source time; may be outside 0..sourceMs. */
    fun rawSourceMs(outMs: Double): Double {
        if (keys.size == 1) return keys[0].srcMs
        val i = when {
            outMs <= keys.first().outMs -> 1
            outMs >= keys.last().outMs -> keys.lastIndex
            else -> keys.indexOfFirst { it.outMs > outMs }
        }
        val a = keys[i - 1]
        val b = keys[i]
        return a.srcMs + (b.srcMs - a.srcMs) * (outMs - a.outMs) / (b.outMs - a.outMs)
    }

    /** Source time after the boundary rule, or null when the clip is blank at this time. */
    fun sourceMs(outMs: Double): Double? {
        val raw = rawSourceMs(outMs)
        if (raw in 0.0..sourceMs) return raw
        return when (boundary) {
            Boundary.Hold -> raw.coerceIn(0.0, sourceMs)
            Boundary.Blank -> null
            Boundary.Loop -> raw - floor(raw / sourceMs) * sourceMs
            Boundary.Mirror -> {
                val period = sourceMs * 2
                val p = raw - floor(raw / period) * period
                if (p <= sourceMs) p else period - p
            }
        }
    }

    /** Local speed (source ms per output ms; negative = reverse, 0 = freeze) at an output time. */
    fun speedAt(outMs: Double): Double {
        if (keys.size == 1) return 0.0
        val i = when {
            outMs <= keys.first().outMs -> 1
            outMs >= keys.last().outMs -> keys.lastIndex
            else -> keys.indexOfFirst { it.outMs > outMs }
        }
        val a = keys[i - 1]
        val b = keys[i]
        return (b.srcMs - a.srcMs) / (b.outMs - a.outMs)
    }

    companion object {
        fun constantSpeed(speed: Double, sourceMs: Double, boundary: Boundary = Boundary.Hold) =
            TimeMap(listOf(TimeKey(0.0, 0.0), TimeKey(1000.0, 1000.0 * speed)), sourceMs, boundary)

        fun reverse(sourceMs: Double) = TimeMap(listOf(TimeKey(0.0, sourceMs), TimeKey(sourceMs, 0.0)), sourceMs)

        fun freeze(atSrcMs: Double, sourceMs: Double) = TimeMap(listOf(TimeKey(0.0, atSrcMs)), sourceMs)
    }
}

/** Two source frames and the blend weight toward the second, for a requested source time. */
data class FrameChoice(val before: Int, val after: Int, val blend: Float) {
    val isExact: Boolean get() = before == after
}

object FrameLookup {
    /** Frame timestamps (us) must be sorted ascending; variable frame rate is fine. Null when no frames exist. */
    fun choose(stampsUs: LongArray, srcMs: Double): FrameChoice? {
        if (stampsUs.isEmpty()) return null
        val us = srcMs * 1000.0
        if (us <= stampsUs.first()) return FrameChoice(0, 0, 0f)
        if (us >= stampsUs.last()) return FrameChoice(stampsUs.lastIndex, stampsUs.lastIndex, 0f)
        var lo = 0
        var hi = stampsUs.lastIndex
        while (hi - lo > 1) {
            val mid = (lo + hi) ushr 1
            if (stampsUs[mid] <= us) lo = mid else hi = mid
        }
        if (abs(stampsUs[lo] - us) < 1e-6) return FrameChoice(lo, lo, 0f)
        val span = (stampsUs[hi] - stampsUs[lo]).toDouble()
        return FrameChoice(lo, hi, ((us - stampsUs[lo]) / span).toFloat())
    }

    const val MaxWindow = 16

    /** Frame indices around [centre] for a temporal effect: offsets clamped into the clip, deduplicated, bounded. */
    fun window(stampsUs: LongArray, centre: Int, offsets: IntArray): IntArray {
        if (stampsUs.isEmpty()) return IntArray(0)
        require(offsets.size <= MaxWindow) { "frame window is limited to $MaxWindow frames" }
        return offsets.map { (centre + it).coerceIn(0, stampsUs.lastIndex) }.distinct().sorted().toIntArray()
    }
}

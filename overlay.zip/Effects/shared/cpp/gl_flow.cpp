#include "gl_flow.h"

#include "glsl_library.h"

#include <algorithm>
#include <chrono>
#include <cmath>

namespace am::flow {
using rg::Constant;
using rg::Filter;
using rg::Target;

namespace {
constexpr int kFused[] = {1, 2, 4};
int FusedIndex(int remaining, int most) {
    for (int i = 2; i > 0; i--) if (kFused[i] <= std::min(remaining, most)) return i;
    return 0;
}
double Since(std::chrono::steady_clock::time_point s) { return std::chrono::duration<double, std::milli>(std::chrono::steady_clock::now() - s).count(); }
}  // namespace

rg::Format Flow::fieldFormat() const {
    return fGl.supports(rg::Format::RGBA16F) && fGl.caps().rgba16f.linear ? rg::Format::RGBA16F : rg::Format::RGBA32F;
}

Target* Flow::make(int w, int h, rg::Format f) {
    Target* t = fGl.create(std::max(w, 1), std::max(h, 1), f);
    if (t) fLive.push_back(t); else fError = "could not allocate a " + std::to_string(w) + "x" + std::to_string(h) + " target";
    return t;
}

void Flow::release(Target* t) {
    if (!t) return;
    auto it = std::find(fLive.begin(), fLive.end(), t);
    if (it != fLive.end()) fLive.erase(it);
    fGl.destroy(t);
}

bool Flow::draw(const std::string& id, const std::string& source, Target* out, int areaW, int areaH, const std::vector<In>& inputs,
                const std::vector<Constant>& constants) {
    if (!out) return false;
    rg::PassDesc p;
    p.id = id; p.name = id; p.lang = rg::Lang::GLSLES; p.file = "glsl_library:" + id; p.source = source; p.constants = constants;
    std::vector<std::string> names;
    for (const In& i : inputs) names.push_back(i.name);
    rg::PassRun r;
    r.pass = &p; r.output = out; r.areaWidth = areaW; r.areaHeight = areaH; r.clear = true;
    for (size_t i = 0; i < inputs.size(); i++) {
        rg::BoundInput b; b.name = &names[i]; b.target = inputs[i].target; b.filter = inputs[i].filter; b.wrap = rg::Wrap::Clamp;
        r.inputs.push_back(b);
    }
    std::string error;
    if (!fGl.run(r, &error)) { fError = id + ": " + error; return false; }
    fPasses++;
    return true;
}

// One pyramid level: the derivative terms, then Jacobi relaxations (fused 1/2/4 at a time) for each warp.
Target* Flow::flowLevel(Target* grey, Target* previous, const Params& p, int level) {
    const int w = grey->width, h = grey->height;
    Target* terms = field(2 * w, h);
    Target* ping = field(w, h);
    Target* pong = field(w, h);
    if (!terms || !ping || !pong) { release(terms); release(ping); release(pong); return nullptr; }
    float scale = previous ? 0.5f : 1.0f, gain = previous ? 2.0f : 0.0f;
    Target* current = previous ? previous : grey;
    const int iterations = std::clamp(p.iterations << level, 1, 64);
    bool ok = true;
    for (int warp = 0; warp < std::max(p.warps, 1) && ok; warp++) {
        ok = draw("interp.derivatives", glsl::Source("interp.derivatives"), terms, w, h,
                  {{"pyramid", grey, Filter::Linear}, {"flow", current, Filter::Linear}},
                  {{"scale", {scale}}, {"gain", {gain}}});
        for (int done = 0; done < iterations && ok;) {
            const int fused = FusedIndex(iterations - done, p.fuse);
            ok = draw("interp.jacobi" + std::to_string(kFused[fused]), glsl::JacobiSource(kFused[fused]), ping, w, h,
                      {{"flow", current, scale == 1.0f ? Filter::Nearest : Filter::Linear}, {"terms", terms, Filter::Nearest}},
                      {{"scale", {scale}}, {"gain", {gain}}, {"alpha2", {p.alpha * p.alpha}}});
            if (!ok) break;
            current = ping;
            std::swap(ping, pong);
            scale = 1.0f; gain = 1.0f;
            done += kFused[fused];
        }
    }
    // `current` is one of ping / pong / (the previous level's field, which the caller still owns); keep it, free the rest.
    Target* result = ok ? current : nullptr;
    if (result == previous || result == grey) {   // no iteration ran (cannot happen with iterations >= 1) - still return a private copy
        result = nullptr;
    }
    for (Target* t : {terms, ping, pong}) if (t != result) release(t);
    return result;
}

Target* Flow::estimate(Target* a, Target* b, const Params& p, Stats* stats) {
    if (!a || !b) { fError = "estimate: missing frame"; return nullptr; }
    const auto start = std::chrono::steady_clock::now();
    fPasses = 0;
    const int divisor = std::max(p.divisor, 1), levels = std::max(p.levels, 1);
    int w = (a->width + divisor - 1) / divisor, h = (a->height + divisor - 1) / divisor;
    std::vector<Target*> pyramid;
    Target* g0 = field(w, h);
    bool ok = g0 && draw("interp.grey", glsl::Source("interp.grey"), g0, w, h, {{"a", a, Filter::Linear}, {"b", b, Filter::Linear}}, {{"d", {(float)divisor}}});
    if (g0) pyramid.push_back(g0);
    while (ok && (int)pyramid.size() < levels && std::min(w, h) >= 32) {
        w = (w + 1) / 2; h = (h + 1) / 2;
        Target* next = field(w, h);
        if (!next) { ok = false; break; }
        pyramid.push_back(next);
        ok = draw("interp.down", glsl::Source("interp.down"), next, w, h, {{"src", pyramid[pyramid.size() - 2], Filter::Linear}}, {});
    }
    Target* flow = nullptr;
    for (int level = (int)pyramid.size() - 1; level >= 0 && ok; level--) {
        Target* next = flowLevel(pyramid[level], flow, p, level);
        if (flow) release(flow);
        flow = next;
        ok = flow != nullptr;
    }
    const int levelCount = (int)pyramid.size();
    for (Target* t : pyramid) release(t);
    if (stats) { stats->passes = fPasses; stats->levels = levelCount; stats->ms = Since(start); }
    if (!ok) { release(flow); return nullptr; }
    return flow;
}

Target* Flow::synthesize(Target* a, Target* b, Target* flow, float t, int divisor, Target* before, Target* after) {
    if (!a || !b) { fError = "synthesize: missing frame"; return nullptr; }
    const bool four = !flow && before && after;
    Target* out = picture(a->width, a->height);
    if (!out) return nullptr;
    bool ok;
    if (four) {
        const float u = 1 - t;
        ok = draw("interp.soft", glsl::Source("interp.soft"), out, a->width, a->height,
                  {{"p", before, Filter::Linear}, {"a", a, Filter::Linear}, {"b", b, Filter::Linear}, {"n", after, Filter::Linear}},
                  {{"w", {u * u * u / 6, (3 * t * t * t - 6 * t * t + 4) / 6, (-3 * t * t * t + 3 * t * t + 3 * t + 1) / 6, t * t * t / 6}}});
    } else if (flow) {
        ok = draw("interp.warp", glsl::Source("interp.warp"), out, a->width, a->height,
                  {{"a", a, Filter::Linear}, {"b", b, Filter::Linear}, {"flow", flow, Filter::Linear}},
                  {{"t", {t}}, {"d", {(float)std::max(divisor, 1)}}});
    } else {
        ok = draw("interp.blend", glsl::Source("interp.blend"), out, a->width, a->height, {{"a", a, Filter::Linear}, {"b", b, Filter::Linear}}, {{"t", {t}}});
    }
    if (!ok) { release(out); return nullptr; }
    return out;
}

Target* Flow::motionBlur(Target* image, Target* flow, float t, float length, int divisor) {
    if (!image || !flow) return nullptr;
    Target* out = picture(image->width, image->height);
    if (!out) return nullptr;
    if (!draw("interp.motionblur", glsl::Source("interp.motionblur"), out, image->width, image->height,
              {{"image", image, Filter::Linear}, {"flow", flow, Filter::Linear}},
              {{"t", {t}}, {"k", {length}}, {"d", {(float)std::max(divisor, 1)}}})) { release(out); return nullptr; }
    return out;
}

Target* Flow::moshStep(Target* state, Target* prior, Target* frame, Target* flow, const MoshParams& p, float salt, Target** motion) {
    if (!state || !frame) return nullptr;
    const int divisor = std::max(p.flow.divisor, 1);
    const int fw = flow ? flow->width : (frame->width + divisor - 1) / divisor;
    const int fh = flow ? flow->height : (frame->height + divisor - 1) / divisor;
    Target* none = fGl.blank(fw, fh, fieldFormat());      // transparent, backend-owned
    Target* moved = field(fw, fh);
    if (!moved || !none) { release(moved); return nullptr; }
    if (!draw("interp.moshmotion", glsl::Source("interp.moshmotion"), moved, fw, fh,
              {{"flow", flow ? flow : none, Filter::Linear}, {"prior", prior ? prior : none, Filter::Nearest}},
              {{"intensity", {p.intensity}}, {"bloom", {p.bloom}}, {"glitch", {p.glitch}},
               {"cell", {std::max(p.block / divisor, 1.0f)}}, {"salt", {salt}}})) { release(moved); return nullptr; }
    Target* out = picture(state->width, state->height);
    if (!out) { release(moved); return nullptr; }
    if (!draw("interp.moshimage", glsl::Source("interp.moshimage"), out, state->width, state->height,
              {{"state", state, Filter::Linear}, {"frame", frame, Filter::Linear},
               {"motion", moved, p.block >= 2 * divisor ? Filter::Nearest : Filter::Linear}},
              {{"d", {(float)divisor}}, {"decay", {std::clamp(p.decay, 0.0f, 1.0f)}}})) { release(moved); release(out); return nullptr; }
    *motion = moved;
    return out;
}

}  // namespace am::flow

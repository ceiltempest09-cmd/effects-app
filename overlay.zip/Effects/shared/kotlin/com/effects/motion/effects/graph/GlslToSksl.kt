package com.effects.motion.effects.graph

/** SkSL output was removed: every pass is native GLSL ES (see [GlslNative]). Kept only so older callers still compile; it always reports an error. */
object GlslToSksl {
    class Implicit(val name: String, val sksl: String, val bool: Boolean = false)

    class Result(val sksl: String, val issues: List<Issue>, val headerLines: Int)

    fun convert(
        glsl: String, inputs: List<String>, colorUniforms: Set<String> = emptySet(), effect: String = "", pass: String? = null,
        file: String? = null, firstLine: Int = 1, defines: Map<String, String> = emptyMap(),
        implicit: List<Implicit> = emptyList(),
    ): Result = Result("", listOf(Issue(IssueKind.UNSUPPORTED, "SkSL was removed; passes run as native GLSL ES", true, effect, pass, -1, "sksl", file, firstLine)), 0)
}

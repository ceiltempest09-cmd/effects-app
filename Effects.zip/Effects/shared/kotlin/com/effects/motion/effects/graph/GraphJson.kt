package com.effects.motion.effects.graph

import org.json.JSONArray
import org.json.JSONObject

/**
 * JSON form of effect schema 2 (see docs/EFFECT_FORMAT.md, section "Multi-pass effects").
 * An effect file with a "passes" array is a graph effect; one with "sksl" is the original one-pass effect and is never touched here.
 */
object GraphJson {
    private val TopKnown = setOf("schema", "id", "name", "category", "description", "since", "params", "presets", "native", "requires",
        "textures", "buffers", "passes", "output", "history", "source")
    private val PassKnown = setOf("id", "name", "lang", "source", "inputs", "output", "blend", "clear", "after", "constants", "defines", "file", "line")
    private val BufferKnown = setOf("id", "scale", "width", "height", "format", "precision", "filter", "wrap", "history")
    private val TextureKnown = setOf("id", "source", "width", "height", "seed", "filter", "wrap")

    fun isGraph(json: JSONObject): Boolean = json.has("passes")

    class Parsed(val graph: EffectGraph?, val issues: List<Issue>)

    fun parse(json: JSONObject, effectId: String, fileName: String = "$effectId.json"): Parsed {
        val issues = mutableListOf<Issue>()
        fun bad(msg: String, kind: IssueKind = IssueKind.MALFORMED, pass: String? = null, index: Int = -1) {
            issues += Issue(kind, msg, true, effectId, pass, index, null, fileName)
        }
        val schema = json.optInt("schema", GRAPH_SCHEMA)
        if (schema < GRAPH_SCHEMA) bad("a file with \"passes\" must declare \"schema\": $GRAPH_SCHEMA (found $schema)")
        if (schema > GRAPH_SCHEMA) bad("effect schema $schema is newer than this build understands ($GRAPH_SCHEMA). Update the app.", IssueKind.UNSUPPORTED)
        if (json.has("sksl")) bad("has both \"sksl\" and \"passes\". Use \"sksl\" for a one-pass effect or \"passes\" for a graph, not both.")
        val passesJson = json.optJSONArray("passes")
        if (passesJson == null) { bad("\"passes\" must be an array"); return Parsed(null, issues) }

        val passes = List(passesJson.length()) { i ->
            val o = passesJson.optJSONObject(i)
            if (o == null) { bad("passes[$i] is not an object", index = i); return@List GraphPass("pass$i", "") }
            val id = o.optString("id", "pass$i")
            val src = o.opt("source")
            val text = (src as? String)
                ?: (src as? JSONArray)?.let { a -> List(a.length()) { a.optString(it) }.joinToString("\n") }
                ?: ""
            val inputs = when (val raw = o.opt("inputs")) {
                is JSONObject -> raw.keys().asSequence().map { PassInput(it, raw.optString(it)) }.toList()
                is JSONArray -> List(raw.length()) { k -> raw.optJSONObject(k)?.let { PassInput(it.optString("name"), it.optString("ref")) } ?: PassInput("", "") }
                null -> emptyList()
                else -> { bad("inputs must be an object {name: ref}", pass = id, index = i); emptyList() }
            }
            val constants = linkedMapOf<String, List<Float>>()
            o.optJSONObject("constants")?.let { c ->
                for (k in c.keys()) {
                    val v = c.opt(k)
                    constants[k] = (v as? Number)?.let { listOf(it.toFloat()) }
                        ?: (v as? JSONArray)?.let { a -> List(a.length()) { n -> a.optDouble(n, Double.NaN).toFloat() } }
                        ?: emptyList()
                    if (constants[k].isNullOrEmpty() || constants.getValue(k).any { it.isNaN() }) bad("constant '$k' must be a number or an array of numbers", pass = id, index = i)
                }
            }
            val defines = linkedMapOf<String, String>()
            o.optJSONObject("defines")?.let { d -> for (k in d.keys()) defines[k] = d.opt(k)?.toString() ?: "" }
            val after = o.optJSONArray("after")?.let { a -> List(a.length()) { a.optString(it) } } ?: emptyList()
            GraphPass(
                id = id, source = text, name = o.optString("name", id), lang = o.optString("lang", "sksl"), inputs = inputs,
                output = o.optString("output", ""), blend = o.optString("blend", "replace"), clear = o.optBoolean("clear", true), after = after,
                constants = constants, defines = defines, file = o.optString("file", "$fileName#passes[$i].source"), line = o.optInt("line", 1),
                extra = unknown(o, PassKnown),
            )
        }
        val buffers = json.optJSONArray("buffers")?.let { a ->
            List(a.length()) { i ->
                val o = a.optJSONObject(i) ?: run { bad("buffers[$i] is not an object"); return@List GraphBuffer("buffer$i") }
                GraphBuffer(o.optString("id"), o.optDouble("scale", 1.0).toFloat(), o.optInt("width", 0), o.optInt("height", 0),
                    o.optString("format", "inherit"), o.optString("precision", "preferred"), o.optString("filter", "linear"),
                    o.optString("wrap", "clamp"), o.optInt("history", 0), unknown(o, BufferKnown))
            }
        }.orEmpty()
        val textures = json.optJSONArray("textures")?.let { a ->
            List(a.length()) { i ->
                val o = a.optJSONObject(i) ?: run { bad("textures[$i] is not an object"); return@List GraphTexture("texture$i", "") }
                GraphTexture(o.optString("id"), o.optString("source"), o.optInt("width", 256), o.optInt("height", 256), o.optInt("seed", 1),
                    o.optString("filter", "nearest"), o.optString("wrap", "repeat"), unknown(o, TextureKnown))
            }
        }.orEmpty()
        val req = json.optJSONObject("requires")
        val requires = GraphRequires(
            backends = req?.optJSONArray("backends")?.let { a -> List(a.length()) { a.optString(it) } }.orEmpty(),
            features = req?.optJSONArray("features")?.let { a -> List(a.length()) { a.optString(it) } }.orEmpty(),
            minSchema = req?.optInt("minSchema", GRAPH_SCHEMA) ?: GRAPH_SCHEMA,
        )
        val history = json.optJSONObject("history")
        val graph = EffectGraph(
            passes = passes, buffers = buffers, textures = textures, output = json.optString("output", ""),
            seek = history?.optString("seek", "reset") ?: "reset", maxReplay = history?.optInt("maxReplay", 120) ?: 120,
            requires = requires, extra = unknown(json, TopKnown),
        )
        return Parsed(graph, issues)
    }

    private fun unknown(o: JSONObject, known: Set<String>): Map<String, String> {
        val r = linkedMapOf<String, String>()
        for (k in o.keys()) if (k !in known) r[k] = o.opt(k)?.toString() ?: ""
        return r
    }

    /** Writes the graph part of an effect file (callers add id/name/category/params). Round-trips through [parse]. */
    fun write(graph: EffectGraph, into: JSONObject = JSONObject()): JSONObject {
        into.put("schema", GRAPH_SCHEMA)
        if (graph.requires != GraphRequires())
            into.put("requires", JSONObject().put("backends", JSONArray(graph.requires.backends)).put("features", JSONArray(graph.requires.features)).put("minSchema", graph.requires.minSchema))
        if (graph.textures.isNotEmpty()) into.put("textures", JSONArray().also { a ->
            graph.textures.forEach { t ->
                a.put(JSONObject().put("id", t.id).put("source", t.source).put("width", t.width).put("height", t.height).put("seed", t.seed)
                    .put("filter", t.filter).put("wrap", t.wrap).also { o -> t.extra.forEach { (k, v) -> o.put(k, v) } })
            }
        })
        if (graph.buffers.isNotEmpty()) into.put("buffers", JSONArray().also { a ->
            graph.buffers.forEach { b ->
                a.put(JSONObject().put("id", b.id).put("scale", b.scale.toDouble()).put("format", b.format).put("precision", b.precision)
                    .put("filter", b.filter).put("wrap", b.wrap).put("history", b.history)
                    .also { o -> if (b.width > 0) o.put("width", b.width); if (b.height > 0) o.put("height", b.height); b.extra.forEach { (k, v) -> o.put(k, v) } })
            }
        })
        into.put("passes", JSONArray().also { a ->
            graph.passes.forEach { p ->
                a.put(JSONObject().put("id", p.id).put("name", p.name).put("lang", p.lang).put("source", p.source)
                    .put("inputs", JSONArray().also { ia -> p.inputs.forEach { ia.put(JSONObject().put("name", it.name).put("ref", it.ref)) } })
                    .put("output", p.output).put("blend", p.blend).put("clear", p.clear)
                    .also { o ->
                        if (p.after.isNotEmpty()) o.put("after", JSONArray(p.after))
                        if (p.constants.isNotEmpty()) o.put("constants", JSONObject().also { c -> p.constants.forEach { (k, v) -> c.put(k, JSONArray(v.map { it.toDouble() })) } })
                        if (p.defines.isNotEmpty()) o.put("defines", JSONObject().also { d -> p.defines.forEach { (k, v) -> d.put(k, v) } })
                        if (p.file.isNotEmpty()) o.put("file", p.file)
                        if (p.line != 1) o.put("line", p.line)
                        p.extra.forEach { (k, v) -> o.put(k, v) }
                    })
            }
        })
        if (graph.output.isNotEmpty()) into.put("output", graph.output)
        if (graph.seek != "reset" || graph.maxReplay != 120) into.put("history", JSONObject().put("seek", graph.seek).put("maxReplay", graph.maxReplay))
        graph.extra.forEach { (k, v) -> into.put(k, v) }
        return into
    }
}

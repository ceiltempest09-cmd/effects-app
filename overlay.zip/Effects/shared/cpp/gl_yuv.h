#pragma once

#include <EGL/egl.h>
#include <EGL/eglext.h>
#include <GLES3/gl3.h>
#include <GLES2/gl2ext.h>
#include <android/hardware_buffer.h>

#include "include/core/SkImage.h"

class GrDirectContext;

struct GlYuvTexture {
    GLuint texture = 0; // Caller owns the texture and must delete it with glDeleteTextures.
    int width = 0;
    int height = 0;
    explicit operator bool() const { return texture != 0 && width > 0 && height > 0; }
};

class GlYuv {
public:
    // Native GLES path. Returns an RGBA8 GL_TEXTURE_2D without creating a Skia image.
    // The returned texture belongs to the caller and must be deleted on the owning GL context.
    GlYuvTexture convertTexture(AHardwareBuffer* buffer, int colorStandard, int colorRange);

    // Transitional compatibility adapter for the existing Skia-backed engine.
    sk_sp<SkImage> convert(GrDirectContext* context, AHardwareBuffer* buffer, int colorStandard, int colorRange, SkAlphaType alpha);

private:
    bool setUp();
    int fState = 0;
    bool fDriver = false;
    GLuint fProgram = 0;
    GLuint fExternal = 0;
    GLuint fFramebuffer = 0;
    GLuint fVao = 0; // Private vertex state; never mutate the engine's VAO 0.
    GLint fMatrix = -1;
    GLint fOffset = -1;
    PFNEGLGETNATIVECLIENTBUFFERANDROIDPROC fClientBuffer = nullptr;
    PFNEGLCREATEIMAGEKHRPROC fCreateImage = nullptr;
    PFNEGLDESTROYIMAGEKHRPROC fDestroyImage = nullptr;
    PFNGLEGLIMAGETARGETTEXTURE2DOESPROC fTargetTexture = nullptr;
};

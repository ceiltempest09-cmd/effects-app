package com.effects.motion.effects

import com.effects.motion.effects.engine.CubeLut
import com.effects.motion.effects.engine.LutBake
import org.json.JSONArray
import org.json.JSONObject
import java.security.MessageDigest
import java.util.Locale

/** Builds the schema-2 effect for one imported 3D LUT: one pass reading the baked float16 texture, trilinear in the shader. */
object LutEffect {
    class Built(val key: String, val json: JSONObject)

    fun hash(bytes: ByteArray): String =
        MessageDigest.getInstance("SHA-256").digest(bytes).take(5).joinToString("") { "%02x".format(it) }

    fun slug(name: String): String =
        name.lowercase(Locale.ROOT).replace(Regex("[^a-z0-9]+"), "_").trim('_').take(24).ifBlank { "lut" }

    /** `binPath` is where the baked file is stored (see LutBake). `hash` is the content hash of the .cube text. */
    fun build(displayName: String, lut: CubeLut, hash: String, binPath: String): Built {
        LutBake.problem(lut)?.let { throw IllegalArgumentException(it) }
        val l = LutBake.layout(lut.size)
        val key = "lut_${slug(displayName)}_$hash"
        val tex = "t$hash"
        fun nums(vararg v: Float) = JSONArray(v.map { it.toDouble() })
        val params = JSONArray().put(
            JSONObject().put("id", "amount").put("label", "Amount").put("type", "float").put("default", 1.0)
                .put("min", 0.0).put("max", 1.0).put("step", 0.01).put("percent", true),
        )
        val pass = JSONObject().put("id", "apply").put("lang", "sksl").put("source", JSONArray(Shader.lines()))
            .put("inputs", JSONObject().put("image", "source").put("lut", "texture:$tex")).put("output", "out")
            .put("constants", JSONObject().put("n", nums(lut.size.toFloat())).put("cols", nums(l.cols.toFloat()))
                .put("dmin", nums(*lut.domainMin)).put("dmax", nums(*lut.domainMax)))
        val json = JSONObject().put("schema", 2).put("id", key).put("name", displayName).put("category", "color")
            .put("description", "3D LUT (${lut.size} points) from a .cube file, trilinear, float16.")
            .put("requires", JSONObject().put("backends", JSONArray().put("skia")).put("features", JSONArray().put("float16")))
            .put("params", params)
            .put("textures", JSONArray().put(JSONObject().put("id", tex).put("source", "lutf16:$binPath").put("width", l.width).put("height", l.height)
                .put("filter", "nearest").put("wrap", "clamp")))
            .put("buffers", JSONArray().put(JSONObject().put("id", "out").put("scale", 1.0).put("format", "inherit")))
            .put("passes", JSONArray().put(pass)).put("output", "out")
        return Built(key, json)
    }

    /** Texel centres are addressed explicitly, so the texture's own filter does not matter; blending is done here. */
    private val Shader = """
uniform shader image;
uniform shader lut;
uniform float2 size;
uniform float2 lut_px;
uniform float amount;
uniform float n;
uniform float cols;
uniform float3 dmin;
uniform float3 dmax;
half4 tex(float x, float y) { return lut.eval(float2(x + 0.5, y + 0.5) * (size / lut_px)); }
half3 slice(float k, float2 uv) {
  float2 o = float2(mod(k, cols) * n, floor(k / cols) * n);
  float2 f = floor(uv);
  float2 t = uv - f;
  float2 g = min(f + 1.0, float2(n - 1.0));
  half3 a = tex(o.x + f.x, o.y + f.y).rgb;
  half3 b = tex(o.x + g.x, o.y + f.y).rgb;
  half3 c = tex(o.x + f.x, o.y + g.y).rgb;
  half3 d = tex(o.x + g.x, o.y + g.y).rgb;
  return mix(mix(a, b, half(t.x)), mix(c, d, half(t.x)), half(t.y));
}
half4 main(float2 p) {
  half4 s = image.eval(p);
  half3 rgb = s.a > 0.0 ? s.rgb / s.a : half3(0.0);
  float3 v = clamp((float3(rgb) - dmin) / (dmax - dmin), 0.0, 1.0) * (n - 1.0);
  float kz = floor(v.z);
  half3 mapped = mix(slice(kz, v.xy), slice(min(kz + 1.0, n - 1.0), v.xy), half(v.z - kz));
  half3 outc = mix(rgb, mapped, half(amount));
  return half4(outc * s.a, s.a);
}
""".trim()

}

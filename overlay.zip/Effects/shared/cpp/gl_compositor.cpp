#include "gl_compositor.h"

#include "glsl_library.h"

#include <algorithm>
#include <cmath>

namespace am::comp {
using rg::Constant;
using rg::Filter;
using rg::Target;

namespace {
// Places one layer on the canvas: inverse-maps each output pixel into the layer, soft 1px edge, opacity and mask applied.
const char* const kPlace = R"GLSL(#version 300 es
precision highp float;
precision highp int;
precision highp sampler2D;
out vec4 _frag;
uniform sampler2D layer; uniform vec2 layer_px;
uniform sampler2D mask; uniform vec2 mask_px;
uniform mat3 inv;
uniform float opacity;
uniform float maskMode;
uniform vec2 fs;   // canvas pixels per layer pixel along the layer's x / y axis (edge softness is 1 CANVAS pixel)
vec4 _am_main(vec2 p) {
    vec2 q = (inv * vec3(p, 1.0)).xy;
    vec2 d = min(q, layer_px - q) * fs;
    float cover = clamp(d.x + 0.5, 0.0, 1.0) * clamp(d.y + 0.5, 0.0, 1.0);
    if (cover <= 0.0) return vec4(0.0);
    vec4 c = texture(layer, clamp(q, vec2(0.0), layer_px) / layer_px) * (cover * opacity);
    if (maskMode > 0.5) {
        vec4 m = texture(mask, p / mask_px);
        float k = maskMode < 1.5 ? m.a : maskMode < 2.5 ? 1.0 - m.a : (m.a > 0.0 ? dot(m.rgb / m.a, vec3(0.299, 0.587, 0.114)) * m.a : 0.0);
        c *= k;
    }
    return c;
}
void main() {
  _frag = _am_main(gl_FragCoord.xy);
}
)GLSL";

// The blend modes Skia handled natively (screen, mask = DstIn, exclude = DstOut, clipping-mask = SrcATop) plus source-over.
std::string NativeBlend(const std::string& id) {
    const char* expr = nullptr;
    if (id == "normal") expr = "s + d * (1.0 - s.a)";
    else if (id == "screen") expr = "s + d - s * d";
    else if (id == "mask") expr = "d * s.a";
    else if (id == "exclude") expr = "d * (1.0 - s.a)";
    else if (id == "clipping-mask") expr = "s * d.a + d * (1.0 - s.a)";
    if (!expr) return std::string();
    return std::string(R"GLSL(#version 300 es
precision highp float;
precision highp int;
precision highp sampler2D;
out vec4 _frag;
uniform sampler2D src; uniform vec2 src_px;
uniform sampler2D dst; uniform vec2 dst_px;
void main() {
  vec2 p = gl_FragCoord.xy;
  vec4 s = texture(src, p / src_px), d = texture(dst, p / dst_px);
  _frag = )GLSL") + expr + ";\n}\n";
}

const char* const kBackground = R"GLSL(#version 300 es
precision highp float;
out vec4 _frag;
uniform vec4 color;
void main() { _frag = color; }
)GLSL";
}  // namespace

Affine Affine::Rotate(float r) { Affine m; const float c = std::cos(r), s = std::sin(r); m.a = c; m.b = s; m.c = -s; m.d = c; return m; }

Affine Affine::then(const Affine& o) const {   // o * this
    Affine m;
    m.a = o.a * a + o.c * b;  m.c = o.a * c + o.c * d;  m.e = o.a * e + o.c * f + o.e;
    m.b = o.b * a + o.d * b;  m.d = o.b * c + o.d * d;  m.f = o.b * e + o.d * f + o.f;
    return m;
}

bool Affine::invert(Affine* out) const {
    const float det = a * d - b * c;
    if (!(std::fabs(det) > 1e-12f)) return false;
    const float i = 1.0f / det;
    out->a = d * i;  out->b = -b * i;  out->c = -c * i;  out->d = a * i;
    out->e = -(out->a * e + out->c * f);
    out->f = -(out->b * e + out->d * f);
    return true;
}

Compositor::~Compositor() { for (Target* t : fLive) fGl.destroy(t); }

Target* Compositor::make(int w, int h) {
    Target* t = fGl.create(std::max(w, 1), std::max(h, 1), fGl.workingFormat());
    if (t) fLive.push_back(t); else fError = "could not allocate a " + std::to_string(w) + "x" + std::to_string(h) + " target";
    return t;
}

void Compositor::release(Target* t) {
    if (!t) return;
    auto it = std::find(fLive.begin(), fLive.end(), t);
    if (it != fLive.end()) fLive.erase(it);
    fGl.destroy(t);
}

bool Compositor::draw(const std::string& id, const std::string& source, Target* out, const std::vector<In>& inputs,
                      const std::vector<Constant>& constants) {
    if (!out) return false;
    rg::PassDesc p;
    p.id = id; p.name = id; p.lang = rg::Lang::GLSLES; p.file = "gl_compositor:" + id; p.source = source; p.constants = constants;
    std::vector<std::string> names;
    names.reserve(inputs.size());
    for (const In& i : inputs) names.push_back(i.name);
    rg::PassRun r;
    r.pass = &p; r.output = out; r.areaWidth = out->width; r.areaHeight = out->height; r.clear = true;
    for (size_t i = 0; i < inputs.size(); i++) {
        rg::BoundInput b; b.name = &names[i]; b.target = inputs[i].target; b.filter = inputs[i].filter; b.wrap = rg::Wrap::Clamp;
        r.inputs.push_back(b);
    }
    std::string error;
    if (!fGl.run(r, &error)) { fError = id + ": " + error; return false; }
    fPasses++;
    return true;
}

Target* Compositor::render(int w, int h, const std::vector<Layer>& layers, const float* background) {
    fError.clear(); fWarning.clear();
    Target* canvas = make(w, h);
    if (!canvas) return nullptr;
    const float clear[4] = {0, 0, 0, 0};
    const float* bg = background ? background : clear;
    if (!draw("comp.background", kBackground, canvas, {}, {{"color", {bg[0], bg[1], bg[2], bg[3]}}})) { release(canvas); return nullptr; }
    Target* placed = nullptr; Target* spare = nullptr;
    for (const Layer& L : layers) {
        if (!L.image || L.opacity <= 0.0f) continue;
        Affine inv;
        if (!L.transform.invert(&inv)) continue;                // a collapsed layer draws nothing
        if (!placed && !(placed = make(w, h))) { release(canvas); release(spare); return nullptr; }
        if (!spare && !(spare = make(w, h))) { release(canvas); release(placed); return nullptr; }
        const bool masked = L.maskMode != MaskMode::None && L.mask;
        Target* maskTarget = masked ? L.mask : L.image;          // the sampler must be bound even when unused
        const Filter flt = L.smooth ? Filter::Linear : Filter::Nearest;
        const std::vector<Constant> k = {
            {"inv", {inv.a, inv.b, 0, inv.c, inv.d, 0, inv.e, inv.f, 1}},
            {"fs", {std::hypot(L.transform.a, L.transform.b), std::hypot(L.transform.c, L.transform.d)}},
            {"opacity", {std::min(L.opacity, 1.0f)}},
            {"maskMode", {masked ? (float)(int)L.maskMode : 0.0f}}};
        if (!draw("comp.place", kPlace, placed, {{"layer", L.image, flt}, {"mask", maskTarget, Filter::Linear}}, k)) { release(canvas); release(placed); release(spare); return nullptr; }
        std::string blendSource = NativeBlend(L.blend);
        if (blendSource.empty()) blendSource = glsl::BlendSource(L.blend);
        if (blendSource.empty()) {
            if (fWarning.empty()) fWarning = "unknown blend mode '" + L.blend + "' drawn as normal";
            blendSource = NativeBlend("normal");
        }
        if (!draw("comp.blend." + L.blend, blendSource, spare, {{"src", placed, Filter::Nearest}, {"dst", canvas, Filter::Nearest}}, {})) { release(canvas); release(placed); release(spare); return nullptr; }
        std::swap(canvas, spare);
    }
    release(placed); release(spare);
    return canvas;
}

Target* Compositor::gradient(int w, int h, const Gradient& g) {
    fError.clear();
    Target* out = make(w, h);
    if (!out) return nullptr;
    const float bw = g.box[2] > 0 ? g.box[2] : (float)w, bh = g.box[3] > 0 ? g.box[3] : (float)h;
    const char* src = glsl::Source("style.gradient");
    if (!src) { fError = "style.gradient is missing from the shader library"; release(out); return nullptr; }
    const std::vector<Constant> k = {
        {"c0", {g.c0[0], g.c0[1], g.c0[2], g.c0[3]}}, {"c1", {g.c1[0], g.c1[1], g.c1[2], g.c1[3]}},
        {"p0", {g.p0[0], g.p0[1]}}, {"p1", {g.p1[0], g.p1[1]}},
        {"box", {g.box[0], g.box[1], bw, bh}}, {"kind", {(float)g.kind}}};
    if (!draw("comp.gradient", src, out, {}, k)) { release(out); return nullptr; }
    return out;
}

Target* Compositor::toneMap(Target* src, const ToneMap& t) {
    fError.clear();
    if (!src) { fError = "toneMap: no input"; return nullptr; }
    Target* out = make(src->width, src->height);
    if (!out) return nullptr;
    const char* code = glsl::Source("display.tonemap");
    if (!code) { fError = "display.tonemap is missing from the shader library"; release(out); return nullptr; }
    std::vector<float> m(t.toSrgb, t.toSrgb + 9);
    const std::vector<Constant> k = {{"toSrgb", m}, {"linearIn", {t.linearIn ? 1.0f : 0.0f}}, {"knee", {t.knee}}, {"peak", {t.peak}}};
    if (!draw("comp.tonemap", code, out, {{"src", src, Filter::Nearest}}, k)) { release(out); return nullptr; }
    return out;
}

}  // namespace am::comp

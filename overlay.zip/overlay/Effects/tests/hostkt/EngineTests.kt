import com.effects.motion.effects.engine.*

private var failures = 0
private fun check(name: String, ok: Boolean) { if (!ok) { failures++; println("FAIL $name") } else println("ok   $name") }
private fun near(a: Double, b: Double) = kotlin.math.abs(a - b) < 1e-6

fun main() {
    val ok = CapabilityCheck.check(listOf("current_frame", "time_access"), setOf(EffectCapability.CurrentFrame))
    check("missing capability reported", ok.missing.size == 1 && !ok.ok)
    check("unknown capability reported", CapabilityCheck.check(listOf("warp_drive"), EffectCapability.entries.toSet()).unknown.size == 1)

    val fwd = TimeMap.constantSpeed(2.0, 10_000.0)
    check("speed x2", near(fwd.sourceMs(1000.0)!!, 2000.0))
    check("same answer when seeking directly", near(fwd.sourceMs(1234.5)!!, fwd.sourceMs(1234.5)!!))
    check("hold past end", near(fwd.sourceMs(60_000.0)!!, 10_000.0))
    val rev = TimeMap.reverse(10_000.0)
    check("reverse start", near(rev.sourceMs(0.0)!!, 10_000.0))
    check("reverse mid", near(rev.sourceMs(2500.0)!!, 7500.0))
    check("reverse speed negative", rev.speedAt(100.0) < 0)
    val frz = TimeMap.freeze(3000.0, 10_000.0)
    check("freeze", near(frz.sourceMs(0.0)!! , 3000.0) && near(frz.sourceMs(99_999.0)!!, 3000.0) && frz.speedAt(5.0) == 0.0)
    check("blank boundary", TimeMap(listOf(TimeKey(0.0, 0.0), TimeKey(1000.0, 1000.0)), 1000.0, Boundary.Blank).sourceMs(1500.0) == null)
    check("loop boundary", near(TimeMap(listOf(TimeKey(0.0, 0.0), TimeKey(1000.0, 1000.0)), 1000.0, Boundary.Loop).sourceMs(1250.0)!!, 250.0))
    check("mirror boundary", near(TimeMap(listOf(TimeKey(0.0, 0.0), TimeKey(1000.0, 1000.0)), 1000.0, Boundary.Mirror).sourceMs(1250.0)!!, 750.0))
    val ramp = TimeMap(listOf(TimeKey(0.0, 0.0), TimeKey(1000.0, 1000.0), TimeKey(2000.0, 3000.0)), 5000.0)
    check("ramp second segment", near(ramp.sourceMs(1500.0)!!, 2000.0) && near(ramp.speedAt(1500.0), 2.0))
    check("unsorted keys rejected", runCatching { TimeMap(listOf(TimeKey(0.0, 0.0), TimeKey(0.0, 5.0)), 1000.0) }.isFailure)

    val stamps = longArrayOf(0, 33_333, 66_667, 100_000)
    check("no frames -> null", FrameLookup.choose(LongArray(0), 10.0) == null)
    check("before first clamps", FrameLookup.choose(stamps, -5.0)!!.isExact)
    check("after last clamps", FrameLookup.choose(stamps, 9999.0)!!.before == 3)
    val mid = FrameLookup.choose(stamps, 50.0)!!
    check("between frames blends", mid.before == 1 && mid.after == 2 && mid.blend > 0.4f && mid.blend < 0.6f)
    check("exact stamp", FrameLookup.choose(stamps, 33.333)!!.let { it.before == 1 && it.after == 2 || it.isExact })
    check("window clamps at clip edge", FrameLookup.window(stamps, 0, intArrayOf(-2, -1, 0, 1)).contentEquals(intArrayOf(0, 1)))
    check("window bounded", runCatching { FrameLookup.window(stamps, 1, IntArray(17)) }.isFailure)

    val cube = buildString {
        append("TITLE \"swap\"\nLUT_3D_SIZE 2\n")
        for (b in 0..1) for (g in 0..1) for (r in 0..1) append("$b $g $r\n")
    }
    val parsed = CubeLut.parse(cube)
    check("cube parses", parsed is CubeLutResult.Ok)
    val lut = (parsed as CubeLutResult.Ok).lut
    val o = lut.apply(1f, 0f, 0f)
    check("cube maps red to blue", near(o[0].toDouble(), 0.0) && near(o[2].toDouble(), 1.0))
    val h = lut.apply(0.5f, 0f, 0f)
    check("cube interpolates", near(h[2].toDouble(), 0.5))
    check("cube wrong row count", CubeLut.parse("LUT_3D_SIZE 2\n0 0 0\n") is CubeLutResult.Error)
    check("cube bad number names line", (CubeLut.parse("LUT_3D_SIZE 2\n0 0 x\n") as CubeLutResult.Error).line == 2)
    check("cube data before size", CubeLut.parse("0 0 0\n") is CubeLutResult.Error)
    check("cube oversize rejected", CubeLut.parse("LUT_3D_SIZE 500\n") is CubeLutResult.Error)
    check("1d lut", (CubeLut.parse("LUT_1D_SIZE 2\n0 0 0\n1 1 1\n") as CubeLutResult.Ok).lut.apply(0.25f, 0.5f, 1f).let { near(it[0].toDouble(), 0.25) && near(it[2].toDouble(), 1.0) })

    if (failures > 0) { println("$failures FAILED"); kotlin.system.exitProcess(1) } else println("all engine tests passed")
}

package com.effects.motion.ui.editor

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Modifier
import com.effects.motion.R
import com.effects.motion.editor.EditorState
import com.effects.motion.library.ProjectStore
import com.effects.motion.library.TemplateStore
import com.effects.motion.model.Layer
import com.effects.motion.model.XmlNode
import com.effects.motion.model.formatFloats
import com.effects.motion.model.withCopiedLayerIds
import com.effects.motion.platform.LocalContext
import com.effects.motion.platform.Toast
import com.effects.motion.ui.home.EmbedRequest
import com.effects.motion.ui.home.TemplateEditor
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
internal fun DeskTemplateEmbed(state: EditorState) {
    val id = EmbedRequest.templateId ?: return
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    fun end() { EmbedRequest.templateId = null; state.engine.setScene(state.scene) }
    DisposableEffect(Unit) { onDispose { EmbedRequest.templateId = null } }
    Box(Modifier.fillMaxSize()) {
        TemplateEditor(id, state.engine, state.settings, onClose = ::end) { template ->
            scope.launch {
                val local = try { withContext(Dispatchers.IO) { TemplateStore(context).localize(template, ProjectStore(context).mediaDir(state.projectId)) } }
                catch (e: java.io.IOException) {
                    Toast.makeText(context, context.getString(R.string.template_add_failed), Toast.LENGTH_LONG).show()
                    return@launch
                }
                val start = state.scene.frameStart(state.frame)
                val layerId = Layer.newId()
                val copied = local.withCopiedLayerIds().node
                val inner = copied.copy(children = copied.children.filterNot { it.name == "media" })
                val layer = Layer(XmlNode("embedScene", linkedMapOf("id" to "$layerId", "label" to local.title.ifBlank { context.getString(R.string.template) }, "startTime" to "$start", "endTime" to "${start + local.totalTime}"),
                    listOf(XmlNode("transform", children = listOf(XmlNode("location", mapOf("value" to formatFloats(floatArrayOf(state.scene.width / 2f, state.scene.height / 2f, 0f)))))), inner)))
                state.edit { it.add(layer, local.media) }
                state.selectedId = layerId
                end()
            }
        }
    }
}

# Unified Effects Motion library + GLSL runtime + thumbnail presentation fix

## What this patch changes

1. Alight Motion and After Effects bundled JSON effects are installed into the
   single Effects Motion source (`em`), not separate `am` / `ae` libraries.
2. Both bundled packs use the 16-bit Balance tier (`VIBRANT`).
3. The bundled-install stamp is versioned so existing separate-source imports
   are removed and rebuilt once under Effects Motion.
4. EffectCatalog resolves thumbnails from the native effects folder first,
   then from `assets/alightmotion/thumb` or `assets/ae/thumb`.
5. Effect detail and preset thumbnails now display the supplied thumbnail as
   one full image. The artificial split, generated color test-card half and
   center divider are removed.
6. Native shader execution is enabled by default. This is required for GLSL ES
   passes: otherwise the graph is planned with only the Skia backend and errors
   with "GLSL ES ... Skia backend cannot run".

## Preserved
- GLSL ES / GLSL / Vulkan / SPIR-V implementations and SkSL compatibility.
- Existing Effects Motion library definitions and custom libraries.
- Effect parameter definitions, project formats, export settings and shader
  source files.
- Both GPU backends; this does not hard-disable Vulkan or OpenGL.

## Validation still required
Build the FOSS Release APK and test the BCC LED effect and several other GLSL
ES effects. Native GLSL ES execution requires the app's Graphite GPU bridge and
a usable OpenGL ES 3.0+ context. Unsupported devices will still report the
native backend capability error; this patch does not claim device testing.

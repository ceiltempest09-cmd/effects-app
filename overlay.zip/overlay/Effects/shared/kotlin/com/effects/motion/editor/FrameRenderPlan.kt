package com.effects.motion.editor

import com.effects.motion.model.Scene
import com.effects.motion.model.XmlNode

/**
 * One frame of an ordered cache render. When [store] is false the frame is only drawn to bring the history of temporal effects up to date
 * (it is already cached, or it is not wanted); its pixels are not kept.
 */
internal class RenderStep(val frame: Int, val store: Boolean)

/** True when the node, or anything inside it, is a visible effect that keeps frames of history ([isTemporal] answers by effect id). */
private fun XmlNode.hasTemporalEffect(isTemporal: (String) -> Boolean): Boolean =
    (name == "effect" && this["hidden"] != "true" && this["id"]?.let(isTemporal) == true) || children.any { it.hasTemporalEffect(isTemporal) }

/**
 * The frame spans (inclusive) in which a layer with a history effect is drawn. A frame inside such a span is only correct when every earlier
 * frame of the span went through the effect, in order: the history of a ping-pong buffer is the previous frames, and after any jump the native
 * executor starts it empty (render_graph.cpp, Executor::render). Rendering from the playhead, skipping frames that are already cached, or
 * capturing frames while scrubbing therefore produces frames whose history differs from a sequential render, which shows up as flicker or
 * pops where such frames meet cached ones.
 */
internal fun temporalSpans(scene: Scene, isTemporal: (String) -> Boolean): List<IntRange> {
    val last = scene.lastFrame.coerceAtLeast(0)
    return scene.layers
        .filter { it.kind != "audio" && it.node.hasTemporalEffect(isTemporal) }
        .map { scene.frameAt(it.startTime).coerceIn(0, last)..scene.frameAt(it.endTime).coerceIn(0, last) }
}

internal fun frameInSpans(frame: Int, spans: List<IntRange>): Boolean = spans.any { frame in it }

/**
 * The order in which the missing frames of [range] are rendered.
 *
 * Without temporal spans: from the playhead [at] to the end, then the part before it (what is about to be played comes first).
 * With spans: every missing frame inside a span is reached by an unbroken ascending run that starts at the first frame of the earliest span
 * that contains it. The frames of the run that are already cached are drawn again without being kept, because only that makes the history
 * identical to a sequential render, whatever the playhead was when the render started or which frames were cached before. Runs that touch or
 * overlap are joined. Runs that contain or follow the playhead come first.
 */
internal fun renderPlan(range: IntRange, at: Int, cached: (Int) -> Boolean, spans: List<IntRange>): List<RenderStep> {
    val missing = range.filter { !cached(it) }
    if (missing.isEmpty()) return emptyList()
    if (spans.isEmpty()) return (missing.filter { it >= at } + missing.filter { it < at }).map { RenderStep(it, true) }

    val runs = ArrayList<IntRange>()
    for (frame in missing) {                                   // ascending
        val from = spans.filter { frame in it }.minOfOrNull { it.first } ?: frame
        val last = runs.lastOrNull()
        if (last != null && from <= last.last + 1) runs[runs.size - 1] = last.first..frame   // joins: from <= last.last + 1 and frame > last.last
        else runs += from..frame
    }
    // A later run can start before an earlier one ends only through the join above; sorting keeps the result ascending inside each run.
    val ordered = runs.filter { it.last >= at } + runs.filter { it.last < at }
    val missingSet = HashSet(missing)
    return ordered.flatMap { run -> run.map { RenderStep(it, it in missingSet) } }
}

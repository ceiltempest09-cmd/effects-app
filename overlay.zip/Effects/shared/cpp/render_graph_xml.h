// render_graph_xml.h — reads the <effect graph="2"> runtime XML that EffectDefinition.runtimeXml() writes.
#pragma once
#include "render_graph.h"
#include "xml.h"

namespace am::rg {

constexpr int kGraphSchema = 2;

// True when `root` declares a pass graph (attribute graph="N" or <pass> children).
bool IsGraphXml(const XmlNode& root);

// Fills `out`. Problems are appended to `diags` (malformed values, newer schema than this build understands...);
// returns false when any error was added. Unknown attributes are kept in the extra maps, never dropped.
bool ParseGraphXml(const XmlNode& root, GraphDesc* out, std::vector<Diag>* diags);

}  // namespace am::rg

// @id neonpulse
// @name Neon Pulse
// @category neon
// @description 2D: pulsing neon bloom with a colour tint and a chromatic fringe.
// @param strength float 1.2 min=0 max=4 step=0.01 label="Glow Strength"
// @param blur float 28 min=0 max=200 step=0.1 pixels=1 label="Glow Radius"
// @param tint color #ff2ea6 label="Neon Color"
// @param pulse float 0.6 min=0 max=3 step=0.01 label="Pulse Speed"
// @param fringe float 0.004 min=0 max=0.03 step=0.0005 label="Color Fringe"
uniform sampler2D image;
uniform sampler2D blurred;
uniform vec2 size;
uniform float time;
uniform float strength;
uniform float pulse;
uniform float fringe;
uniform vec4 tint;

void main() {
    vec2 uv = gl_FragCoord.xy / size;
    float beat = 0.5 + 0.5 * sin(time * 6.2831853 * pulse);
    vec4 base = texture2D(image, uv);
    vec2 d = vec2(fringe, 0.0);
    vec3 rgb = vec3(texture2D(image, uv + d).r, base.g, texture2D(image, uv - d).b);
    vec4 glow = texture2D(blurred, uv);
    vec3 neon = glow.rgb * tint.rgb * strength * (0.6 + 0.8 * beat) * 2.0;
    float a = clamp(max(base.a, glow.a * strength * 0.5), 0.0, 1.0);
    gl_FragColor = vec4(min(rgb + neon, vec3(a)), a);
}

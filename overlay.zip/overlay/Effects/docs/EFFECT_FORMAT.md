# Effects: how to write an effect

Paste this whole file to the AI, then say: "Write the effect <name>: <what it should look like>. Follow this format exactly and reply with one JSON file only."

## 1. What an effect is
One JSON file, `shared/assets/effects/<id>.json`, holding the effect's info, its settings (params) and a Skia SkSL shader (`sksl`). No Kotlin or C++ is needed.

To add it:
1. Put `<id>.json` in `shared/assets/effects/`.
2. Add `"<id>"` to the list in `shared/assets/effects/index.json` (the list order is the browser order).
3. Optional thumbnail: `shared/assets/effects/thumb/<id>.webp`.

`<id>` is lowercase letters and digits only (e.g. `softglow`). Inside projects the effect is stored as `fx.<id>`.

## 2. JSON file
```json
{
  "id": "softglow",
  "name": "Soft Glow",
  "category": "stylize",
  "description": "Adds a soft glow around bright areas.",
  "params": [ ... ],
  "sksl": "...shader source as one JSON string, newlines written as \n..."
}
```
- `category` must be one of: `color`, `blur`, `distort`, `stylize`, `noise`, `repeat`, `key`, `move`, `beat`, `3d`, `text`, `other`.
- `sksl` is required. Never set `"native": true` (that needs C++).
- Optional: `since` (version text), `presets` (section 5).

## 3. Params
Each entry in `params`:

| field | meaning |
|---|---|
| `id` | unique name; must equal the shader uniform name |
| `label` | text shown in the UI |
| `type` | `float`, `angle`, `point`, `color`, `switch`, `choice`, `text` |
| `default` | starting value (format depends on type) |
| `min`, `max`, `step` | slider range (float, angle, point) |
| `percent` | `true` shows a 0..1 value as 0..100% |
| `pixels` | `true` marks a value measured in pixels |
| `unit` | label suffix such as `"s"` or `"%"` |
| `options` | list of names, only for `choice` |
| `when` | show only if another param has certain values, e.g. `{"mode": [1, 2]}` |

Type to shader uniform:

| type | default looks like | shader declaration |
|---|---|---|
| `float` | `1.5` | `uniform float name;` |
| `angle` | `45` (degrees) | `uniform float name;` use `radians(name)` |
| `point` | `[0.5, 0.5]` (fraction of width/height) | `uniform float2 name;` multiply by `size` |
| `color` | `"#ffffff"` or `"#ccff8800"` (#AARRGGBB) | `layout(color) uniform half4 name;` |
| `switch` | `0` or `1` | `uniform float name;` test `name == 1.0` |
| `choice` | index like `0` (needs `options`, default must be a valid index) | `uniform float name;` compare to 0.0, 1.0, ... |

Every uniform the shader declares must either be an automatic one (section 4) or have a param with the same id. Otherwise its value is 0.

## 4. The shader (SkSL, not GLSL)
Required shape:
```
uniform shader image;
uniform float2 size;
half4 main(float2 coord) { ... return half4(...); }
```
- Use SkSL types: `float2`, `float3`, `half4`. Do not use `vec2`, `texture2D`, `gl_FragColor`.
- `coord` is in pixels, from (0,0) to `size`. Read the layer with `image.eval(coord)`.
- Colors are premultiplied. Divide `rgb` by `a` when you need the straight color, multiply back before returning.
- Loops need constant bounds. Keep it light: this runs on every frame.

Automatic uniforms (declare only what you use, no param needed):
- `size` (float2, pixels), `time` (float, seconds)
- `duration` (float, layer length in seconds)
- `layer` (float2, layer size)
- Beat effects: `beat` (0..1 pulse), `beatTime`, `beatIndex`. If you use these, also add params `decay`, `beats` (choice: Every Beat, Every 2nd Beat, Every 4th Beat), `offset`, `bpm`.

Extra inputs (declare them and the engine fills them in):
- `uniform shader blurred;` a blurred copy of the layer. The blur radius comes from a param with id `blur` (pixels).
- `uniform shader bright;` a blurred copy of only the bright areas. Uses params `threshold` (0..1) and `blur`.
- `uniform shader backdrop;` what is behind the layer.
- `uniform shader below;` the layers underneath.

## 5. Presets (optional)
```json
"presets": [ { "name": "Strong", "params": { "strength": 2.5, "radius": 40 } } ]
```
A param value can be animated: `"progress": [[0, 0], [1.5, 1]]` means value 0 at 0 s and 1 at 1.5 s.

## 6. Complete example
```json
{
  "id": "softglow",
  "name": "Soft Glow",
  "category": "stylize",
  "description": "Adds a soft glow around the layer.",
  "params": [
    { "id": "strength", "label": "Strength", "type": "float", "default": 1.0, "min": 0, "max": 4, "step": 0.01 },
    { "id": "blur", "label": "Radius", "type": "float", "default": 24, "min": 0, "max": 200, "step": 0.1, "pixels": true },
    { "id": "glowColor", "label": "Color", "type": "color", "default": "#ffffff" }
  ],
  "sksl": "uniform shader image;\nuniform shader blurred;\nuniform float2 size;\nuniform float strength;\nlayout(color) uniform half4 glowColor;\nhalf4 main(float2 coord) {\n    half4 base = image.eval(coord);\n    half4 soft = blurred.eval(coord);\n    half3 glow = soft.rgb * half(strength) * glowColor.rgb;\n    half a = clamp(max(base.a, soft.a * half(strength)), 0.0, 1.0);\n    return half4(min(base.rgb + glow, half3(a)), a);\n}\n"
}
```

## 7. Checklist before you send it back
- The reply is valid JSON, with the shader written as one string using `\n`.
- Every shader uniform has a matching param, or is automatic.
- No `native`, no GLSL names, `category` is in the list.
- If the app shows the effect as unavailable, it shows the shader error text. Paste that error to the AI and ask it to fix the shader.

## 8. Multi-pass effects (effect schema 2)

An effect may declare several render passes instead of one shader. Use either `sksl` (one pass, sections 1-7) or `passes` (this section), never both.

**JSON** (`"schema": 2`): `passes[]` (`id`, `lang` = `sksl` | `glsl` | `glsles`, `source` as a string or an array of lines, `inputs` {shaderChild: ref}, `output` buffer id, `blend`, `clear`, `after`, `constants`, `defines`), `buffers[]` (`id`, `scale` or `width`/`height`, `format` = `inherit` | `rgba8` | `rgba16f` | `rgba32f`, `precision` = `preferred` | `required`, `filter`, `wrap`, `history`), `textures[]` (`builtin:noise`, `builtin:ramp-x`, `builtin:ramp-y`, with `size`, `seed`), `output`, `seek` (`reset`), `params[]` as in section 3. See `shared/assets/effects/deepglow.json` and the other four multi-pass samples.

**Input references:** `source` (the layer image), `buffer:id`, `buffer:id@n` (n frames back; needs `history >= n`), `texture:id`, `pass:id`. Execution order comes from these references (stable topological order); cycles, unknown ids, read-before-write and write-while-read are reported with pass id and line. Passes nothing reads are culled.

**Shader conventions (SkSL):** premultiplied in and out; coordinates are pixels of the effect area; every input also gets `<input>_px` (its size). Automatic uniforms: `size`, `time`, `frame`, `out_px`. Any other uniform binds to the control of the same name, or to a pass `constants` entry.

**Temporal effects:** a buffer with `history` keeps previous frames (`history=1` is ping-pong). Frames are quantised to the project fps. A jump in time, a changed area or changed layer timing resets history (`seek="reset"`); `seek="replay"` is rejected on the Skia backend. Preview, export and stills keep separate histories.

**Languages:** SkSL runs in Skia as written. `lang="glsl-es"` passes are NOT translated: the importer keeps the text exactly and the device's OpenGL ES driver runs it (Graphite engine only; a Ganesh engine refuses with a clear message). It must follow section 9: premultiplied in and out, no `varying`/`in` inputs (use `gl_FragCoord` and `size`), uniforms bound by name. Legacy `lang="glsl"` passes in the effect-XML dialect (`v_uv`, `acScreenSize`, straight alpha) are still translated to SkSL by the importer's subset converter until the Vulkan backend can run desktop GLSL; anything outside the subset is an error naming the line. `glsl-vk` and `spirv` have no backend yet and are rejected with `error[capability]`.

**Colour controls:** an XML `<color>` control is written to the runtime XML as `<param ... type="color"/>`. A native pass declaring `uniform vec4 tint;` receives R, G, B, A (a `vec3` receives R, G, B), straight (not premultiplied), exactly like `layout(color) uniform half4` in SkSL. Multiply by alpha yourself if you need premultiplied.

**XML:** `<effect graph="2" output=".." seek="..">` with `<texture>`, `<buffer>`, `<pass>` (`<source>`, `<input name ref>`, `<const>`, `<define>`). The importer converts it to schema-2 JSON; unknown attributes are kept as `xml_*` metadata and reported.

**Known limits:** native GLSL / GLSL ES / Vulkan GLSL / SPIR-V execution is NOT implemented (section 9 is the contract a native backend must meet); `backdrop` (below) inputs and adjustment-layer placement are not supported for multi-pass effects; `asset:`/`param:` textures are not supported.

## 9. Native shader languages: contract (not yet implemented by any backend)

This section is the behaviour every backend must give, so one effect can mix languages. No backend honours it yet except SkSL; the host tests (`tests/native/run.sh`) check the routing, hand-off ordering and diagnostics, not any GLSL execution.

**Per pass:** `lang` is `sksl`, `glsl` (desktop GLSL, only where the device's compiler accepts the `#version` as written), `glsl-es` (`#version 100`, `300 es`, `310 es`, `320 es`), `glsl-vk` (`#version 450`/`460` or `310 es`/`320 es`, Vulkan semantics, compiled to SPIR-V) or `spirv` (base64 module with one fragment entry point). Sources are single files: `#include` is an error. `#version`, `#extension` and `precision` are passed through as written; an unmet `#version` or `#extension ... : require` is a Capability error at that line, an unmet `enable`/`warn` extension is a warning.

**Coordinates:** fragment coordinates are pixels of the effect area, origin top-left, y down (SkSL `p`, GLSL `gl_FragCoord.xy`). Texture coordinates are normalised, `(0,0)` is the top-left texel. A GLES backend flips to meet this; Vulkan's framebuffer origin already matches.

**Colour:** every buffer and input is premultiplied RGBA, in the canvas colour space, stored as it is (RGBA8 UNORM / RGBA16F / RGBA32F; no hardware sRGB decode or encode). Shaders read and write premultiplied values. `blend` applies to what the pass writes onto the target (replace / over / add / multiply / screen on premultiplied values), the same for every language.

**Binding:** each pass input `name` is `uniform sampler2D name` (SkSL: `uniform shader name`) with the input's `filter` and `wrap`. Automatic uniforms, by name: `size` (vec2, effect area px), `time` (float seconds), `frame` (frame index), `out_px` (vec2, output target px), `<input>_px` (vec2, input px). Any other uniform binds to the control or `constants` entry of the same name; a uniform with no value is an error naming it.

**Diagnostics:** compile errors keep the line of the effect file (`file:line`), counting from the pass' first source line; the same `Diag` text reaches the importer UI for every language.

package com.effects.motion.export

import com.effects.motion.model.Scene
import com.effects.motion.model.mediaUris
import com.effects.motion.platform.Context
import com.effects.motion.platform.Uri
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileDescriptor
import java.io.FileInputStream
import java.io.FileOutputStream
import java.security.MessageDigest

/**
 * Reuse of an earlier finished video export.
 *
 * The preview render cache cannot feed a final export: its frames are small (screen size divided by the preview quality),
 * JPEG-compressed unless saved losslessly, and flattened onto the transparency checkerboard (PreviewCache.Encoder.encode).
 * Using them would lower the quality, which a final export must never do. What can be reused with no loss at all is a
 * previous export of exactly the same project with exactly the same settings: that file is the finished render already.
 *
 * A saved export is reused only when every input that can change the picture or sound still matches:
 * the project (without its title and timestamps), every export setting, the output size, the app build,
 * every media file (size, modified time, first and last 64 KB), the imported effects and the font files.
 * When anything is unknown, missing, or different, the export is rendered normally. Nothing is ever deleted
 * (neither the user's media nor the earlier export); the index only forgets entries.
 */
internal object ExportReuse {
    private const val VERSION = 1
    private const val MAX_ENTRIES = 6
    private const val SAMPLE = 64 * 1024
    private const val CHUNK = 1 shl 20

    /** True when the export that just finished was copied from an earlier one, so its time says nothing about how long a render takes. */
    @Volatile var lastReused = false

    private class Entry(val fp: String, val uri: String, val size: Long, val sample: String, val at: Long)

    private fun file(context: Context) = File(File(context.applicationContext.filesDir, "export_reuse").apply { mkdirs() }, "index.json")

    private fun read(context: Context): MutableList<Entry> = runCatching {
        val array = JSONArray(file(context).readText())
        MutableList(array.length()) { i ->
            array.getJSONObject(i).let { Entry(it.getString("fp"), it.getString("uri"), it.getLong("size"), it.getString("sample"), it.getLong("at")) }
        }
    }.getOrElse { mutableListOf() }

    private fun write(context: Context, entries: List<Entry>) {
        val target = file(context)
        val temp = File(target.parentFile, "index.json.tmp")
        runCatching {
            temp.writeText(JSONArray(entries.map { JSONObject().put("fp", it.fp).put("uri", it.uri).put("size", it.size).put("sample", it.sample).put("at", it.at) }).toString())
            if (!temp.renameTo(target)) temp.delete()
        }.onFailure { temp.delete() }
    }

    private fun sha(vararg parts: ByteArray): String =
        MessageDigest.getInstance("SHA-256").also { md -> parts.forEach { md.update(it) } }.digest().joinToString("") { "%02x".format(it) }

    internal fun sha(text: String) = sha(text.toByteArray())

    /** Size, and a hash of the first and last 64 KB, of whatever the uri points to. Null when it cannot be read. */
    internal fun sampleOf(context: Context, uri: String): Pair<Long, String>? = runCatching {
        context.contentResolver.openAssetFileDescriptor(Uri.parse(uri), "r")?.use { afd ->
            val length = afd.length.takeIf { it >= 0 } ?: return@use null
            FileInputStream(afd.fileDescriptor).use { input ->
                val channel = input.channel
                val head = ByteArray(minOf(SAMPLE.toLong(), length).toInt())
                channel.position(afd.startOffset)
                java.io.DataInputStream(input).readFully(head)
                val tail = ByteArray(minOf(SAMPLE.toLong(), length).toInt())
                channel.position(afd.startOffset + length - tail.size)
                java.io.DataInputStream(input).readFully(tail)
                length to sha(head, tail, length.toString().toByteArray())
            }
        }
    }.getOrNull()

    internal fun modified(context: Context, uri: String): String = runCatching {
        context.contentResolver.query(Uri.parse(uri), arrayOf(android.provider.MediaStore.MediaColumns.DATE_MODIFIED), null, null, null)?.use {
            if (it.moveToFirst() && !it.isNull(0)) it.getLong(0).toString() else ""
        }.orEmpty()
    }.getOrDefault("")

    /** Names, sizes and times of the files below the folders whose name contains one of [words] (fonts, imported effects). */
    internal fun foldersSignature(context: Context, vararg words: String): String {
        val roots = context.applicationContext.filesDir.listFiles { f -> f.isDirectory && words.any { f.name.contains(it, ignoreCase = true) } }.orEmpty().sortedBy { it.name }
        return roots.joinToString("|") { root -> root.walkTopDown().filter { it.isFile }.sortedBy { it.path }.joinToString(",") { "${it.relativeTo(root).path}:${it.length()}:${it.lastModified()}" } }
    }

    /** A hash of everything that decides what the exported file contains, or null when something cannot be checked (then nothing is reused). */
    fun fingerprint(context: Context, scene: Scene, xml: String, s: ExportSettings): String? = runCatching {
        val canonical = Scene.parse(xml).node.let { it.copy(attrs = it.attrs - setOf("title", "modifiedTime", "createdTime")) }.toXml()
        val (width, height) = exportSize(scene, s.shortSide, even = true)
        val media = scene.node.mediaUris().sorted().map { uri ->
            val sample = sampleOf(context, uri) ?: error("cannot read $uri")
            "$uri:${sample.second}:${modified(context, uri)}"
        }
        val app = runCatching { context.packageManager.getPackageInfo(context.packageName, 0).lastUpdateTime }.getOrDefault(0L)
        sha(listOf("v$VERSION", app, width, height, s.toString(), sha(canonical), media.joinToString("|"), foldersSignature(context, "effect", "lut"), foldersSignature(context, "font")).joinToString("\n"))
    }.getOrNull()

    /**
     * Copies the earlier export into [out] when it is still there, unchanged, and matches [fp]. Returns false (with [out] emptied again)
     * when it cannot, and the caller renders as usual.
     */
    suspend fun reuse(context: Context, fp: String, out: FileDescriptor, progress: (Float) -> Unit): Boolean {
        val entries = read(context)
        val entry = entries.firstOrNull { it.fp == fp } ?: return false
        val now = sampleOf(context, entry.uri)
        if (now == null || now.first != entry.size || now.second != entry.sample) {
            write(context, entries - entry)               // moved, deleted or changed since: forget it
            return false
        }
        val sink = FileOutputStream(out)                  // not closed: the descriptor belongs to the export
        try {
            context.contentResolver.openInputStream(Uri.parse(entry.uri))?.use { input ->
                val buffer = ByteArray(CHUNK)
                var copied = 0L
                while (true) {
                    currentCoroutineContext().ensureActive()
                    val n = input.read(buffer)
                    if (n < 0) break
                    sink.write(buffer, 0, n)
                    copied += n
                    progress((copied.toFloat() / entry.size).coerceIn(0f, 1f) * 0.98f)
                }
                if (copied != entry.size) error("copied $copied of ${entry.size} bytes")
            } ?: error("cannot open the earlier export")
            sink.flush()
            return true
        } catch (t: Throwable) {
            runCatching { sink.channel.truncate(0); sink.channel.position(0) }
            if (t is kotlinx.coroutines.CancellationException) throw t
            android.util.Log.w("AMExport", "the earlier export cannot be reused, rendering again", t)
            return false
        }
    }

    /** Remembers a finished, verified export so the next identical one can reuse it. Keeps the newest few. */
    fun remember(context: Context, fp: String, uri: Uri) {
        val sample = sampleOf(context, uri.toString()) ?: return
        val entries = read(context).filter { it.fp != fp }.toMutableList()
        entries += Entry(fp, uri.toString(), sample.first, sample.second, System.currentTimeMillis())
        write(context, entries.sortedByDescending { it.at }.take(MAX_ENTRIES))
    }
}

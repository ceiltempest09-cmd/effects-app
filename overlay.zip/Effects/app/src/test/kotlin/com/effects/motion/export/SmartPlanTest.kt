package com.effects.motion.export

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class SmartPlanTest {
    /** A cached export of [frames] frames in groups of [size]. */
    private fun groups(frames: Int, size: Int) = (0 until frames step size).map { CachedGop(it, minOf(size, frames - it), it * 10L, 10, 0L) }

    @Test fun unchangedTailIsSkippedAndFirstFramesAreAlwaysDrawn() {
        val plan = planSmartExport(300, groups(300, 30), dirty = listOf(100..130), temporal = emptyList())!!
        assertEquals(FrameAction.Keep, plan.actions[0])                    // the first encoder session creates the track
        assertEquals(FrameAction.Skip, plan.actions[299])
        assertTrue((90..160).none { plan.actions[it] == FrameAction.Skip && it in 100..130 })
        assertTrue(plan.skipped > 150)
    }

    @Test fun dirtyFramesAreNeverReused() {
        val dirty = listOf(100..130, 200..201)
        val plan = planSmartExport(300, groups(300, 30), dirty, emptyList())!!
        for (r in dirty) for (k in r) assertEquals("frame $k", FrameAction.Keep, plan.actions[k])
        for (g in plan.reused) for (k in g.first until g.end) assertTrue(dirty.none { k in it })
    }

    @Test fun historySpanIsWarmedUpFromItsFirstFrame() {
        // Span 100..250 with a dirty frame at 200: frames 100..199 are drawn to rebuild the history, 200..250 are kept.
        val plan = planSmartExport(300, groups(300, 10), dirty = listOf(200..200), temporal = listOf(100..250))!!
        for (k in 100..199) assertEquals("frame $k", FrameAction.Warm, plan.actions[k])
        for (k in 200..250) assertEquals("frame $k", FrameAction.Keep, plan.actions[k])
        assertEquals(FrameAction.Skip, plan.actions[299])
    }

    @Test fun dirtinessSpreadsToTheRestOfAHistorySpan() {
        val bad = dirtyFrames(100, listOf(40..40), listOf(10..60, 70..90))
        assertTrue((40..60).all { bad[it] })
        assertTrue((0..39).none { bad[it] })
        assertTrue((70..90).none { bad[it] })
    }

    @Test fun nothingToReuseOrTooLittleMeansNoPlan() {
        assertNull(planSmartExport(300, emptyList(), emptyList(), emptyList()))
        assertNull(planSmartExport(300, groups(300, 30), dirty = listOf(0..299), temporal = emptyList()))
        assertNull(planSmartExport(300, groups(300, 30), dirty = listOf(40..299), temporal = emptyList()))   // only the first group is clean and it is redrawn
    }

    @Test fun groupsBeyondTheNewLengthAndOverlappingIndexesAreRejected() {
        val plan = planSmartExport(100, groups(300, 30), dirty = emptyList(), temporal = emptyList())
        assertNotNull(plan)
        assertTrue(plan!!.reused.all { it.end <= 100 })
        assertNull(planSmartExport(100, listOf(CachedGop(0, 60, 0, 1, 0), CachedGop(30, 60, 0, 1, 0)), emptyList(), emptyList()))
    }

    @Test fun sessionsStartAtWarmUpAndEndWithTheKeptRun() {
        val plan = planSmartExport(300, groups(300, 10), dirty = listOf(200..205), temporal = listOf(100..250))!!
        val sessions = smartSessions(plan)
        val s = sessions.first { it.keepStart == 200 }
        assertEquals(100, s.drawStart)
        assertEquals(259, s.keepEnd)   // 250 is dirty too (history), so its whole group of 10 is drawn
        assertEquals(0, sessions.first().keepStart)
        // every frame that is kept belongs to exactly one session
        for (k in 0 until 300) if (plan.actions[k] == FrameAction.Keep) assertEquals(1, sessions.count { k in it.keepStart..it.keepEnd })
    }

    @Test fun exportFramesAtAnotherRateAreWidened() {
        assertEquals(10..20, toExportFrames(10..20, 30, 30, 100))
        val r = toExportFrames(30..59, 30, 60, 1000)   // 1 s .. 2 s at 60 fps = frames 60..119, one frame of margin each side
        assertTrue(r.first <= 59 && r.last >= 120)
    }
}

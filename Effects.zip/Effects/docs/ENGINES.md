# Engine Reactor effects (shader engines)

All engines are schema-1 SkSL effects in `shared/assets/effects/` (listed in `index.json`). They run on the app's existing Skia render core, so preview and export use the same shader and parameters. Every control is a real uniform; keyframes, presets and the effect UI come from the existing effect system.

| Engine | Effect ids | Category |
|---|---|---|
| Glow | glow (earlier overlay) | Stylize |
| Blur | engblur (gaussian + focus), engblurdir (box, directional, motion, radial, zoom) | Blur |
| Warps | engwarp | Distort |
| Color | engcolor (LUT: use the app's existing .cube LUT effect) | Color |
| Lighting | englight | Stylize |
| Particles | engparticle | Other |
| 3D | eng3d | 3D |
| Physics | engphysics | Move |
| Texture | engtexture | Noise |
| Shake | engshake | Move |
| Text animation | existing native text animation (not changed) | Text |

Limits: single-layer shader effects; no sprite/texture-image particles, no importable texture images, no mesh/extruded 3D text, no multi-body physics, no GPU-native GLSL/SPIR-V execution (see docs/NATIVE_SHADERS.md).

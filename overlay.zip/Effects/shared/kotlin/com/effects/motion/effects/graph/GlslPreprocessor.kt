package com.effects.motion.effects.graph

/**
 * A real GLSL preprocessor (not regex substitution): comments, line continuations, #define (object and function-like),
 * #undef, #if/#ifdef/#ifndef/#elif/#else/#endif with a full integer expression evaluator, #version/#extension/#pragma/#line.
 * Output keeps exactly one output line per input line, so line numbers in compiler errors stay valid.
 * Not supported (reported, never ignored): #include, # and ## in macros.
 */
object GlslPreprocessor {
    class Result(val text: String, val version: String?, val issues: List<Issue>) {
        val ok: Boolean get() = !issues.hasError
    }

    private class Macro(val params: List<String>?, val body: String)

    private const val MAX_DEPTH = 32
    private const val MAX_OUTPUT = 1 shl 20

    fun run(
        source: String, defines: Map<String, String> = emptyMap(), effect: String = "", pass: String? = null,
        file: String? = null, firstLine: Int = 1,
    ): Result {
        val issues = mutableListOf<Issue>()
        var version: String? = null
        fun err(line: Int, msg: String, kind: IssueKind = IssueKind.TRANSLATION) {
            issues += Issue(kind, msg, true, effect, pass, -1, "glsl", file, firstLine + line - 1)
        }
        val macros = linkedMapOf<String, Macro>("GL_ES" to Macro(null, "1"), "__VERSION__" to Macro(null, "300"))
        for ((k, v) in defines) macros[k] = Macro(null, v.ifEmpty { "1" })

        val lines = joinContinuations(stripComments(source))
        val out = StringBuilder()
        class Cond(val parentActive: Boolean, var taken: Boolean, var active: Boolean, var seenElse: Boolean = false)
        val stack = ArrayList<Cond>()
        fun active() = stack.isEmpty() || stack.last().active

        for ((idx, raw) in lines.withIndex()) {
            val n = idx + 1
            val t = raw.trim()
            if (!t.startsWith("#")) {
                if (active() && t.isNotEmpty()) out.append(expand(raw, macros, 0, { m: String -> err(n, m) }))
                out.append('\n')
                continue
            }
            val body = t.substring(1).trim()
            val word = body.takeWhile { it.isLetter() }
            val rest = body.substring(word.length).trim()
            when (word) {
                "" -> {}
                "define" -> if (active()) {
                    val name = rest.takeWhile { it.isLetterOrDigit() || it == '_' }
                    if (name.isEmpty()) err(n, "#define needs a name")
                    else {
                        val after = rest.substring(name.length)
                        if (after.startsWith("(")) {
                            val close = after.indexOf(')')
                            if (close < 0) err(n, "#define $name: missing ')'")
                            else {
                                val params = after.substring(1, close).split(',').map { it.trim() }.filter { it.isNotEmpty() }
                                macros[name] = Macro(params, after.substring(close + 1).trim())
                            }
                        } else macros[name] = Macro(null, after.trim())
                        if (macros[name]?.body?.contains('#') == true) err(n, "#define $name uses # or ##, which this preprocessor does not support", IssueKind.UNSUPPORTED)
                    }
                }
                "undef" -> if (active()) macros.remove(rest.trim())
                "ifdef" -> { val a = active() && rest.trim() in macros; stack += Cond(active(), a, a) }
                "ifndef" -> { val a = active() && rest.trim() !in macros; stack += Cond(active(), a, a) }
                "if" -> {
                    val parent = active()
                    val v = if (parent) eval(rest, macros) { err(n, it) } else 0L
                    stack += Cond(parent, v != 0L, parent && v != 0L)
                }
                "elif" -> if (stack.isEmpty()) err(n, "#elif without #if") else stack.last().let { c ->
                    if (c.seenElse) err(n, "#elif after #else")
                    else if (c.taken || !c.parentActive) c.active = false
                    else { val v = eval(rest, macros) { err(n, it) }; c.active = v != 0L; c.taken = v != 0L }
                }
                "else" -> if (stack.isEmpty()) err(n, "#else without #if") else stack.last().let { c ->
                    if (c.seenElse) err(n, "second #else") else { c.seenElse = true; c.active = c.parentActive && !c.taken; c.taken = true }
                }
                "endif" -> if (stack.isEmpty()) err(n, "#endif without #if") else stack.removeAt(stack.size - 1)
                "version" -> if (active()) version = rest
                "extension", "pragma", "line" -> {}
                "error" -> if (active()) err(n, "#error $rest", IssueKind.VALIDATION)
                "include" -> if (active()) err(n, "#include is not supported (GLSL ES has no include). Put the code in the pass source.", IssueKind.UNSUPPORTED)
                else -> if (active()) err(n, "unknown directive #$word", IssueKind.MALFORMED)
            }
            out.append('\n')
            if (out.length > MAX_OUTPUT) { err(n, "the shader expands to more than 1 MB"); break }
        }
        if (stack.isNotEmpty()) err(lines.size, "missing #endif", IssueKind.MALFORMED)
        return Result(out.toString().removeSuffix("\n"), version, issues)
    }

    /** Replaces comments by spaces and keeps every newline. */
    private fun stripComments(s: String): String {
        val o = StringBuilder(s.length)
        var i = 0
        while (i < s.length) {
            if (s.startsWith("//", i)) { while (i < s.length && s[i] != '\n') i++ }
            else if (s.startsWith("/*", i)) {
                i += 2
                o.append(' ')
                while (i < s.length && !s.startsWith("*/", i)) { if (s[i] == '\n') o.append('\n'); i++ }
                i += 2
            } else o.append(s[i++])
        }
        return o.toString()
    }

    /** "\<newline>" joins lines; the joined line is followed by empty lines so numbering is unchanged. */
    private fun joinContinuations(s: String): List<String> {
        val raw = s.replace("\r\n", "\n").replace('\r', '\n').split('\n')
        val result = ArrayList<String>()
        var i = 0
        while (i < raw.size) {
            var line = raw[i]
            var extra = 0
            while (line.endsWith("\\") && i + 1 < raw.size) { line = line.dropLast(1) + raw[++i]; extra++ }
            result += line
            repeat(extra) { result += "" }
            i++
        }
        return result
    }

    private fun isId(c: Char) = c.isLetterOrDigit() || c == '_'

    private fun expand(text: String, macros: Map<String, Macro>, depth: Int, err: (String) -> Unit, blocked: Set<String> = emptySet()): String {
        if (depth > MAX_DEPTH) { err("macro expansion is nested more than $MAX_DEPTH deep"); return text }
        val o = StringBuilder()
        var i = 0
        while (i < text.length) {
            val c = text[i]
            if (c.isLetter() || c == '_') {
                var j = i
                while (j < text.length && isId(text[j])) j++
                val name = text.substring(i, j)
                val m = macros[name]
                if (m == null || name in blocked || (i > 0 && (text[i - 1].isDigit() || text[i - 1] == '.'))) { o.append(name); i = j; continue }
                if (m.params == null) { o.append(expand(m.body, macros, depth + 1, err, blocked + name)); i = j; continue }
                var k = j
                while (k < text.length && text[k].isWhitespace()) k++
                if (k >= text.length || text[k] != '(') { o.append(name); i = j; continue }
                val args = ArrayList<String>()
                var level = 0
                val cur = StringBuilder()
                var p = k
                var closed = false
                while (p < text.length) {
                    val ch = text[p]
                    if (ch == '(') { if (level++ > 0) cur.append(ch) }
                    else if (ch == ')') { if (--level == 0) { closed = true; break } else cur.append(ch) }
                    else if (ch == ',' && level == 1) { args += cur.toString().trim(); cur.clear() }
                    else cur.append(ch)
                    p++
                }
                if (!closed) { err("macro $name: unterminated argument list"); o.append(text.substring(i)); break }
                if (cur.isNotBlank() || args.isNotEmpty()) args += cur.toString().trim()
                if (args.size != m.params.size) { err("macro $name expects ${m.params.size} argument(s), got ${args.size}"); i = p + 1; continue }
                val bound = m.params.zip(args.map { expand(it, macros, depth + 1, err, blocked) }).toMap()
                val sub = Regex("[A-Za-z_][A-Za-z0-9_]*").replace(m.body) { bound[it.value] ?: it.value }
                o.append(expand(sub, macros, depth + 1, err, blocked + name))
                i = p + 1
            } else if (c.isDigit()) {
                var j = i
                while (j < text.length && (isId(text[j]) || text[j] == '.')) j++
                o.append(text, i, j); i = j
            } else { o.append(c); i++ }
        }
        return o.toString()
    }

    // ---- #if expressions
    private fun eval(expr: String, macros: Map<String, Macro>, err: (String) -> Unit): Long {
        val defined = Regex("""defined\s*(?:\(\s*([A-Za-z_]\w*)\s*\)|([A-Za-z_]\w*))""").replace(expr) { m ->
            if ((m.groupValues[1].ifEmpty { m.groupValues[2] }) in macros) "1" else "0"
        }
        val text = expand(defined, macros, 0, err)
        val p = ExprParser(text, err)
        val v = p.ternary()
        p.skip()
        if (p.i < text.length) err("cannot read the #if expression near '${text.substring(p.i).take(12)}'")
        return v
    }

    private class ExprParser(val s: String, val err: (String) -> Unit) {
        var i = 0
        fun skip() { while (i < s.length && s[i].isWhitespace()) i++ }
        fun eat(op: String): Boolean { skip(); return if (s.startsWith(op, i)) { i += op.length; true } else false }
        fun peekIsNot(op: String, notFollowed: String): Boolean { skip(); return s.startsWith(op, i) && !(i + op.length < s.length && s[i + op.length] in notFollowed) }

        fun ternary(): Long {
            val c = logicOr()
            if (eat("?")) { val a = ternary(); if (!eat(":")) err("missing ':' in #if"); val b = ternary(); return if (c != 0L) a else b }
            return c
        }
        fun logicOr(): Long { var v = logicAnd(); while (eat("||")) { val r = logicAnd(); v = if (v != 0L || r != 0L) 1 else 0 }; return v }
        fun logicAnd(): Long { var v = bitOr(); while (eat("&&")) { val r = bitOr(); v = if (v != 0L && r != 0L) 1 else 0 }; return v }
        fun bitOr(): Long { var v = bitXor(); while (peekIsNot("|", "|")) { i++; v = v or bitXor() }; return v }
        fun bitXor(): Long { var v = bitAnd(); while (eat("^")) v = v xor bitAnd(); return v }
        fun bitAnd(): Long { var v = equality(); while (peekIsNot("&", "&")) { i++; v = v and equality() }; return v }
        fun equality(): Long {
            var v = relational()
            while (true) { v = if (eat("==")) b(v == relational()) else if (eat("!=")) b(v != relational()) else return v }
        }
        fun relational(): Long {
            var v = shift()
            while (true) {
                v = if (eat("<=")) b(v <= shift()) else if (eat(">=")) b(v >= shift())
                else if (peekIsNot("<", "<")) { i++; b(v < shift()) } else if (peekIsNot(">", ">")) { i++; b(v > shift()) } else return v
            }
        }
        fun shift(): Long {
            var v = additive()
            while (true) { v = if (eat("<<")) v shl additive().toInt().coerceIn(0, 63) else if (eat(">>")) v shr additive().toInt().coerceIn(0, 63) else return v }
        }
        fun additive(): Long { var v = mul(); while (true) { v = if (eat("+")) v + mul() else if (eat("-")) v - mul() else return v } }
        fun mul(): Long {
            var v = unary()
            while (true) {
                if (eat("*")) v *= unary()
                else if (eat("/")) { val r = unary(); if (r == 0L) { err("division by zero in #if"); v = 0 } else v /= r }
                else if (eat("%")) { val r = unary(); if (r == 0L) { err("division by zero in #if"); v = 0 } else v %= r }
                else return v
            }
        }
        fun unary(): Long {
            if (eat("!")) return b(unary() == 0L)
            if (eat("~")) return unary().inv()
            if (eat("-")) return -unary()
            if (eat("+")) return unary()
            if (eat("(")) { val v = ternary(); if (!eat(")")) err("missing ')' in #if"); return v }
            skip()
            val start = i
            if (i < s.length && s[i].isDigit()) {
                while (i < s.length && (s[i].isLetterOrDigit())) i++
                val t = s.substring(start, i).trimEnd('u', 'U')
                return (if (t.startsWith("0x") || t.startsWith("0X")) t.substring(2).toLongOrNull(16) else t.toLongOrNull()) ?: run { err("bad number '$t' in #if"); 0 }
            }
            if (i < s.length && (s[i].isLetter() || s[i] == '_')) { while (i < s.length && isId(s[i])) i++; return 0 }   // undefined identifier = 0
            err("unexpected '${s.getOrNull(i) ?: "end"}' in #if")
            i = s.length
            return 0
        }
        fun b(x: Boolean): Long = if (x) 1 else 0
    }
}

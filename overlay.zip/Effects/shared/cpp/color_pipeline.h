#pragma once
// color_pipeline.h — the project colour settings and what the engine does with them. Header-only and free of Skia / GL, so the decisions
// (what is requested, what the GPU can give, when highlights are rolled off, when output is dithered) are covered by the host tests
// (tests/native/color_pipeline_test.cpp). engine.cpp turns a ColorPlan into surfaces; effects_graph.cpp reads the working depth.
//
// Four settings, deliberately independent (see ProjectColor.kt):
//   bitDepth      storage precision of every render target / intermediate buffer: 8 (RGBA8), 16 (RGBA16F), 32 (RGBA32F)
//   workingSpace  what the stored numbers mean: sRGB-encoded, linear-light sRGB, linear-light Rec.2020
//   hdrRange      values above 1.0 are kept (HDR-capable) or the picture is SDR
//   preview       how the EDITOR shows the project (never changes an export): Standard / High / HDR
// 32-bit is more precise, not "more HDR". A 32-bit SDR project and a 16-bit HDR project are both valid.
#include <algorithm>
#include <cmath>
#include <cstdlib>
#include <cstring>

namespace am {

enum class WorkingSpace : int { kSrgb = 0, kLinearSrgb = 1, kRec2020 = 2 };
enum class PreviewMode : int { kStandard = 0, kHigh = 1, kHdr = 2 };

struct ColorSettings {
    // 0 = the project has no colour settings (saved before they existed): the engine behaves exactly as it did then.
    int bitDepth = 0;
    PreviewMode preview = PreviewMode::kStandard;
    WorkingSpace space = WorkingSpace::kSrgb;
    bool hdrRange = false;
    bool legacy() const { return bitDepth == 0; }
    bool operator==(const ColorSettings& o) const {
        return bitDepth == o.bitDepth && preview == o.preview && space == o.space && hdrRange == o.hdrRange;
    }
};

// Any value that is missing or not understood falls back to the legacy value for THAT setting, so a damaged attribute never breaks a project.
// Without a valid bit depth the whole thing is legacy (the other three are then ignored: they only mean something next to a depth).
inline ColorSettings ParseColorSettings(const char* bitDepth, const char* preview, const char* space, const char* range) {
    ColorSettings s;
    if (bitDepth && !std::strcmp(bitDepth, "8")) s.bitDepth = 8;
    else if (bitDepth && !std::strcmp(bitDepth, "16")) s.bitDepth = 16;
    else if (bitDepth && !std::strcmp(bitDepth, "32")) s.bitDepth = 32;
    else return s;
    if (preview && !std::strcmp(preview, "high")) s.preview = PreviewMode::kHigh;
    else if (preview && !std::strcmp(preview, "hdr")) s.preview = PreviewMode::kHdr;
    if (space && !std::strcmp(space, "linear")) s.space = WorkingSpace::kLinearSrgb;
    else if (space && !std::strcmp(space, "rec2020")) s.space = WorkingSpace::kRec2020;
    s.hdrRange = range && !std::strcmp(range, "hdr");
    return s;
}

// What one frame will really do on this GPU.
struct ColorPlan {
    bool managed = false;       // false: draw straight into the destination, exactly as before (legacy projects and 8-bit sRGB)
    int bits = 8;               // precision of the working surface actually used: 8, 16 or 32
    WorkingSpace space = WorkingSpace::kSrgb;
    bool keepHdr = false;       // values above 1.0 survive the whole pipeline (needs a floating-point surface)
    bool toneMap = false;       // the display transform rolls highlights off instead of clipping them (HDR preview on an SDR display)
    bool dither = false;        // float -> 8-bit output is dithered (no banding in gradients)
    bool accurateBlur = false;  // High and HDR previews always use the full shutter blur
    bool downgraded = false;    // the GPU could not give the requested precision
};

// The effect-graph intermediates follow the project depth. 0 = legacy: the graph keeps choosing for itself (half float when it can).
inline int GraphDepth(const ColorSettings& s, const ColorPlan& p) { return s.legacy() ? 0 : p.bits; }

inline ColorPlan PlanColor(const ColorSettings& s, bool exporting, bool canRender16, bool canRender32) {
    ColorPlan p;
    if (s.legacy()) return p;
    int bits = s.bitDepth;
    // HDR Preview exists to show values above 1.0, which an 8-bit buffer cannot hold: the PREVIEW (never the export) is lifted to half float.
    const bool hdrPreview = !exporting && s.preview == PreviewMode::kHdr && s.hdrRange;
    if (hdrPreview && bits < 16) bits = 16;
    const int wanted = bits;
    if (bits == 32 && !canRender32) bits = 16;
    if (bits == 16 && !canRender16) bits = 8;
    p.bits = bits;
    p.space = s.space;
    p.downgraded = bits != wanted;
    p.keepHdr = s.hdrRange && bits >= 16;
    p.toneMap = hdrPreview && p.keepHdr;
    p.dither = bits > 8 && (exporting || s.preview != PreviewMode::kStandard);
    p.accurateBlur = !exporting && s.preview != PreviewMode::kStandard;
    // 8-bit sRGB is what the engine always did: no extra surface, no extra pass. Everything else needs a working surface.
    p.managed = !(bits == 8 && s.space == WorkingSpace::kSrgb);
    return p;
}

// ---- highlight roll-off (the reference for the SkSL in engine.cpp; kept in step by the host test)
// Identity up to kToneKnee, then a smooth shoulder that maps kTonePeak to exactly 1.0 (extended Reinhard on the excess over the knee,
// continuous in value and slope at the knee). Applied to the largest channel, so the ratios between R, G and B are kept: bright saturated
// colours keep their hue, and no channel is left above 1.0 (nothing is clipped just because it was bright).
constexpr float kToneKnee = 0.6f;
constexpr float kTonePeak = 6.0f;

inline float RollOff(float x, float knee = kToneKnee, float peak = kTonePeak) {
    if (!(x > knee)) return x;
    const float t = (x - knee) / (1.0f - knee);
    const float w = (peak - knee) / (1.0f - knee);
    const float m = t * (1.0f + t / (w * w)) / (1.0f + t);
    return knee + (1.0f - knee) * m;
}

inline void ToneMapRgb(float rgb[3], float knee = kToneKnee, float peak = kTonePeak) {
    const float m = std::max(std::max(rgb[0], rgb[1]), rgb[2]);
    if (!(m > knee)) return;
    const float s = RollOff(m, knee, peak) / m;
    for (int i = 0; i < 3; i++) rgb[i] *= s;
}

// Linear Rec.2020 -> linear Rec.709/sRGB primaries (ITU-R BT.2087), row-major.
constexpr float kRec2020ToSrgb[9] = {
     1.6604910f, -0.5876411f, -0.0728499f,
    -0.1245505f,  1.1328999f, -0.0083494f,
    -0.0181508f, -0.1005789f,  1.1187297f,
};

inline float SrgbEncode(float l) { return l <= 0.0031308f ? 12.92f * l : 1.055f * std::pow(l, 1.0f / 2.4f) - 0.055f; }
inline float SrgbDecode(float e) { return e <= 0.04045f ? e / 12.92f : std::pow((e + 0.055f) / 1.055f, 2.4f); }

}  // namespace am

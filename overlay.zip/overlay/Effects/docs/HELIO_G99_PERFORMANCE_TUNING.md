# Playback-focused performance tuning

Target profile: Infinix X6833B / Helio G99 / Android 14.

This patch is conservative. It does not change shader languages, rendering backends, project formats, preview resolution, export resolution, codec quality, or effect behavior.

## Changes
- Cache-frame decode workers: 3 -> 2, reducing CPU contention with live rendering and the UI.
- Cache encoders: 3 -> 2, reducing concurrent CPU and memory-bandwidth pressure.
- Playback capture queue: 3 -> 2, bounding queued pixel buffers.
- Playhead-mode automatic render horizon: 8 -> 4 seconds, limiting background work.
- Playback capture budget: 85% -> 60% of the frame interval, skipping background cache captures sooner when they could compete with live playback.
- Capture re-probe interval: 45 -> 90 skipped frames, reducing repeated expensive probes during sustained heavy playback.

## Preserved
- SKSL and GLSL support are untouched.
- Skia, OpenGL ES and Vulkan integrations are untouched.
- Preview quality and output resolution are unchanged.
- Export pipeline, codec settings, bitrates and output quality are unchanged.
- Temporal-effect ordering and cache-correctness fixes remain intact.

## Verification limits
These are source-level scheduling changes. They require an Android build and on-device profiling to confirm the performance effect. No measured FPS improvement is claimed.

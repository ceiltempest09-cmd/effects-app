#include "tracker.h"

#include <algorithm>
#include <cmath>
#include <limits>
#include <stdexcept>
#include <vector>

namespace motion {
namespace {

constexpr int maximum_levels = 4;
constexpr double minimum_correlation = 0.45;

struct Image {
    int width = 0;
    int height = 0;
    std::vector<float> pixels;
    std::vector<float> horizontal;
};

struct Patch {
    int radius = 0;
    std::vector<float> values;
    double energy = 0.0;
    double texture = 0.0;
    bool valid = false;
};

// Patch pixel (u, v) lands at (x + a*u + c*v, y + b*u + d*v).  A similarity has c = -b and d = a;
// the full affine form lets a patch follow the shear and foreshortening a rotating camera causes.
struct Warp {
    double x = 0.0;
    double y = 0.0;
    double a = 1.0;
    double b = 0.0;
    double c = 0.0;
    double d = 1.0;
};

double warp_det(const Warp& w) { return w.a * w.d - w.b * w.c; }
double warp_scale(const Warp& w) { return std::sqrt(std::max(0.0, warp_det(w))); }

struct Sample {
    double value;
    double gx;
    double gy;
};

struct PointState {
    Point origin;
    Warp warp;
    double vx = 0.0;
    double vy = 0.0;
    bool working_valid = false;
    std::array<Patch, maximum_levels> anchor;   // frame 0 appearance: drift-free reference
    std::array<Patch, maximum_levels> working;  // appearance in the previous frame: follows slow change
};

double square(double value) {
    return value * value;
}

bool contains(const Image& image, const Warp& warp, int radius) {
    const double ex = radius * (std::abs(warp.a) + std::abs(warp.c));
    const double ey = radius * (std::abs(warp.b) + std::abs(warp.d));
    return std::isfinite(warp.x) && std::isfinite(warp.y) &&
           std::isfinite(ex) && std::isfinite(ey) && warp.x - ex >= 0.0 &&
           warp.y - ey >= 0.0 && warp.x + ex < image.width - 1.001 &&
           warp.y + ey < image.height - 1.001;
}

Sample sample_gradient(const Image& image, double x, double y) {
    const int ix = static_cast<int>(x);
    const int iy = static_cast<int>(y);
    const double fx = x - ix;
    const double fy = y - iy;
    const float* row = image.pixels.data() + static_cast<std::size_t>(iy) * image.width + ix;
    const double p00 = row[0];
    const double p10 = row[1];
    const double p01 = row[image.width];
    const double p11 = row[image.width + 1];
    return {p00 + fx * (p10 - p00) + fy * (p01 - p00) +
                fx * fy * (p11 - p10 - p01 + p00),
            (1.0 - fy) * (p10 - p00) + fy * (p11 - p01),
            (1.0 - fx) * (p01 - p00) + fx * (p11 - p10)};
}

double sample(const Image& image, double x, double y) {
    return sample_gradient(image, x, y).value;
}

float filtered_luma(const std::uint8_t* row, int width, int x) {
    return (row[std::max(0, x - 2)] + 4.0f * row[std::max(0, x - 1)] +
            6.0f * row[x] + 4.0f * row[std::min(width - 1, x + 1)] +
            row[std::min(width - 1, x + 2)]) * 0.0625f;
}

void prepare_patch(Patch& patch, int radius) {
    patch.radius = radius;
    patch.values.resize(static_cast<std::size_t>(2 * radius + 1) * (2 * radius + 1));
}

void extract_patch(Patch& patch, const Image& image, const Warp& warp) {
    patch.valid = false;
    patch.energy = 0.0;
    patch.texture = 0.0;
    if (!contains(image, warp, patch.radius)) {
        return;
    }
    double sum = 0.0;
    std::size_t index = 0;
    for (int y = -patch.radius; y <= patch.radius; ++y) {
        for (int x = -patch.radius; x <= patch.radius; ++x) {
            const double value = sample(image, warp.x + warp.a * x + warp.c * y,
                                        warp.y + warp.b * x + warp.d * y);
            patch.values[index++] = static_cast<float>(value);
            sum += value;
        }
    }
    const double mean = sum / patch.values.size();
    for (float& value : patch.values) {
        value = static_cast<float>(value - mean);
        patch.energy += square(value);
    }
    double xx = 0.0;
    double xy = 0.0;
    double yy = 0.0;
    const int side = 2 * patch.radius + 1;
    for (int y = 1; y < side - 1; ++y) {
        for (int x = 1; x < side - 1; ++x) {
            const std::size_t offset = static_cast<std::size_t>(y) * side + x;
            const double gx = 0.5 * (patch.values[offset + 1] - patch.values[offset - 1]);
            const double gy = 0.5 * (patch.values[offset + side] - patch.values[offset - side]);
            xx += gx * gx;
            xy += gx * gy;
            yy += gy * gy;
        }
    }
    const double eigenvalue = 0.5 * (xx + yy - std::hypot(xx - yy, 2.0 * xy));
    patch.texture = std::min(1.0, eigenvalue / (4.0 * square(side - 2)));
    patch.texture *= std::min(1.0, patch.energy / (100.0 * patch.values.size()));
    patch.valid = patch.energy > 1.0 && patch.texture > 0.01;
}

double correlation(const Patch& patch, const Image& image, const Warp& warp) {
    if (!patch.valid || !contains(image, warp, patch.radius)) {
        return -1.0;
    }
    double sum = 0.0;
    double sum_square = 0.0;
    double product = 0.0;
    std::size_t index = 0;
    for (int y = -patch.radius; y <= patch.radius; ++y) {
        for (int x = -patch.radius; x <= patch.radius; ++x) {
            const double value = sample(image, warp.x + warp.a * x + warp.c * y,
                                        warp.y + warp.b * x + warp.d * y);
            sum += value;
            sum_square += value * value;
            product += value * patch.values[index++];
        }
    }
    const double energy = sum_square - sum * sum / patch.values.size();
    if (energy < patch.values.size()) {
        return -1.0;
    }
    return std::clamp(product / std::sqrt(patch.energy * energy), -1.0, 1.0);
}


// Solve an n x n system in place (n <= 6) with partial pivoting.
bool solve(double matrix[6][6], double right[6], double answer[6], int n) {
    double maximum = 0.0;
    for (int i = 0; i < n; ++i) {
        maximum = std::max(maximum, matrix[i][i]);
    }
    for (int column = 0; column < n; ++column) {
        int pivot = column;
        for (int row = column + 1; row < n; ++row) {
            if (std::abs(matrix[row][column]) > std::abs(matrix[pivot][column])) {
                pivot = row;
            }
        }
        if (std::abs(matrix[pivot][column]) < std::max(1e-8, maximum * 1e-7)) {
            return false;
        }
        if (pivot != column) {
            for (int j = column; j < n; ++j) {
                std::swap(matrix[pivot][j], matrix[column][j]);
            }
            std::swap(right[pivot], right[column]);
        }
        for (int row = column + 1; row < n; ++row) {
            const double factor = matrix[row][column] / matrix[column][column];
            for (int j = column + 1; j < n; ++j) {
                matrix[row][j] -= factor * matrix[column][j];
            }
            right[row] -= factor * right[column];
        }
    }
    for (int row = n - 1; row >= 0; --row) {
        double value = right[row];
        for (int column = row + 1; column < n; ++column) {
            value -= matrix[row][column] * answer[column];
        }
        answer[row] = value / matrix[row][row];
        if (!std::isfinite(answer[row])) {
            return false;
        }
    }
    return true;
}

// A step may change the scale by about a third and squash one axis by up to 4x; a flip is never allowed.
bool allowed_shape(const Warp& warp, double reference_scale) {
    const double det = warp_det(warp);
    if (!(det > 0.0)) {
        return false;
    }
    const double scale = std::sqrt(det);
    const double energy = square(warp.a) + square(warp.b) + square(warp.c) + square(warp.d);
    const double big = 0.5 * (energy + std::sqrt(std::max(0.0, energy * energy - 4.0 * det * det)));
    const double small = det * det / big;
    return scale >= 0.25 && scale <= 4.0 &&
           scale >= reference_scale * 0.75 && scale <= reference_scale * 1.34 &&
           big / small <= 16.0;
}

// Gauss-Newton alignment of a template to the image.  dof 4 = shift + rotation/scale (used on the coarse
// levels where it is stable), dof 6 = shift + full affine (used on the fine levels).
double refine(const Patch& patch, const Image& image, Warp& warp,
              double reference_scale, int iterations, std::vector<Sample>& samples, int dof) {
    double score = correlation(patch, image, warp);
    if (score < -0.5) {
        return score;
    }
    const double count = static_cast<double>(patch.values.size());
    const double radius = patch.radius;
    for (int iteration = 0; iteration < iterations; ++iteration) {
        double sum = 0.0;
        double sum_square = 0.0;
        double sum_j[6]{};
        double sum_ij[6]{};
        std::size_t index = 0;
        auto jacobian_of = [&](const Sample& value, double x, double y, double* j) {
            j[0] = value.gx;
            j[1] = value.gy;
            if (dof == 4) {
                j[2] = (value.gx * x + value.gy * y) / radius;
                j[3] = (-value.gx * y + value.gy * x) / radius;
            } else {
                j[2] = value.gx * x / radius;
                j[3] = value.gy * x / radius;
                j[4] = value.gx * y / radius;
                j[5] = value.gy * y / radius;
            }
        };
        for (int y = -patch.radius; y <= patch.radius; ++y) {
            for (int x = -patch.radius; x <= patch.radius; ++x) {
                const Sample value = sample_gradient(image, warp.x + warp.a * x + warp.c * y,
                                                     warp.y + warp.b * x + warp.d * y);
                samples[index++] = value;
                double j[6];
                jacobian_of(value, x, y, j);
                sum += value.value;
                sum_square += value.value * value.value;
                for (int k = 0; k < dof; ++k) {
                    sum_j[k] += j[k];
                    sum_ij[k] += value.value * j[k];
                }
            }
        }
        const double mean = sum / count;
        const double energy = sum_square - sum * mean;
        if (energy < count) {
            break;
        }
        const double gain = std::sqrt(energy / patch.energy);
        double projection[6];
        for (int k = 0; k < dof; ++k) {
            projection[k] = (sum_ij[k] - mean * sum_j[k]) / energy;
            sum_j[k] /= count;
        }
        double matrix[6][6]{};
        double right[6]{};
        index = 0;
        for (int y = -patch.radius; y <= patch.radius; ++y) {
            for (int x = -patch.radius; x <= patch.radius; ++x) {
                const Sample value = samples[index];
                const double centered = value.value - mean;
                const double residual = centered - gain * patch.values[index++];
                double j[6];
                jacobian_of(value, x, y, j);
                const double weight = std::min(1.0, 15.0 / std::max(0.001, std::abs(residual)));
                for (int k = 0; k < dof; ++k) {
                    j[k] -= sum_j[k] + centered * projection[k];
                }
                for (int row = 0; row < dof; ++row) {
                    right[row] -= weight * j[row] * residual;
                    for (int column = row; column < dof; ++column) {
                        matrix[row][column] += weight * j[row] * j[column];
                    }
                }
            }
        }
        for (int row = 0; row < dof; ++row) {
            for (int column = 0; column < row; ++column) {
                matrix[row][column] = matrix[column][row];
            }
        }
        if (dof == 6) {
            // A light ridge on the shape terms keeps a weakly textured patch from inventing shear.
            double trace = 0.0;
            for (int k = 2; k < 6; ++k) {
                trace += matrix[k][k];
            }
            for (int k = 2; k < 6; ++k) {
                matrix[k][k] += 0.01 * trace / 4.0 + 1e-9;
            }
        }
        double step[6]{};
        if (!solve(matrix, right, step, dof)) {
            break;
        }
        double shape = 0.0;
        for (int k = 2; k < dof; ++k) {
            shape += square(step[k]);
        }
        const double movement = std::hypot(step[0], step[1]) + std::sqrt(shape);
        if (movement < 0.003) {
            break;
        }
        double fraction = std::min(1.0, 3.0 / movement);
        bool improved = false;
        for (int attempt = 0; attempt < 6; ++attempt) {
            Warp candidate = warp;
            candidate.x += fraction * step[0];
            candidate.y += fraction * step[1];
            if (dof == 4) {
                candidate.a += fraction * step[2] / radius;
                candidate.d += fraction * step[2] / radius;
                candidate.b += fraction * step[3] / radius;
                candidate.c -= fraction * step[3] / radius;
            } else {
                candidate.a += fraction * step[2] / radius;
                candidate.b += fraction * step[3] / radius;
                candidate.c += fraction * step[4] / radius;
                candidate.d += fraction * step[5] / radius;
            }
            const double next_score = allowed_shape(candidate, reference_scale)
                ? correlation(patch, image, candidate) : -1.0;
            if (next_score > score + 1e-9) {
                warp = candidate;
                const double improvement = next_score - score;
                score = next_score;
                improved = true;
                if (improvement < 1e-8 || fraction * movement < 0.003) {
                    return score;
                }
                break;
            }
            fraction *= 0.5;
        }
        if (!improved) {
            break;
        }
    }
    return score;
}

Transform fit(const std::array<PointState, 4>& states, const Result& result,
              unsigned mask) {
    double weight_sum = 0.0;
    Point source;
    Point target;
    for (std::size_t i = 0; i < result.count; ++i) {
        if ((mask & (1U << i)) == 0) {
            continue;
        }
        const double weight = square(result.points[i].confidence);
        weight_sum += weight;
        source.x += weight * states[i].origin.x;
        source.y += weight * states[i].origin.y;
        target.x += weight * result.points[i].position.x;
        target.y += weight * result.points[i].position.y;
    }
    if (weight_sum <= 0.0) {
        return {};
    }
    source.x /= weight_sum;
    source.y /= weight_sum;
    target.x /= weight_sum;
    target.y /= weight_sum;
    double denominator = 0.0;
    double real = 0.0;
    double imaginary = 0.0;
    for (std::size_t i = 0; i < result.count; ++i) {
        if ((mask & (1U << i)) == 0) {
            continue;
        }
        const double weight = square(result.points[i].confidence);
        const double x = states[i].origin.x - source.x;
        const double y = states[i].origin.y - source.y;
        const double u = result.points[i].position.x - target.x;
        const double v = result.points[i].position.y - target.y;
        denominator += weight * (x * x + y * y);
        real += weight * (x * u + y * v);
        imaginary += weight * (x * v - y * u);
    }
    Transform transform;
    if (denominator > 1e-12 && result.count > 1) {
        transform.a = real / denominator;
        transform.b = imaginary / denominator;
    }
    transform.tx = target.x - transform.a * source.x + transform.b * source.y;
    transform.ty = target.y - transform.b * source.x - transform.a * source.y;
    return transform;
}

int bit_count(unsigned mask) {
    int count = 0;
    while (mask != 0) {
        count += static_cast<int>(mask & 1U);
        mask >>= 1U;
    }
    return count;
}

Transform relative_transform(const Transform& current, const Transform& previous) {
    const double denominator = square(previous.a) + square(previous.b);
    Transform result;
    result.a = (current.a * previous.a + current.b * previous.b) / denominator;
    result.b = (current.b * previous.a - current.a * previous.b) / denominator;
    result.tx = current.tx - result.a * previous.tx + result.b * previous.ty;
    result.ty = current.ty - result.b * previous.tx - result.a * previous.ty;
    return result;
}


struct Located {
    Warp warp;
    double score = -1.0;
    double anchor_score = -1.0;
};

// Least-squares affine map from the origins of the masked points to where they were found (needs 3+ points).
bool fit_affine(const std::array<PointState, 4>& states, const Result& result, unsigned mask,
                std::size_t count, double out[6]) {
    double matrix[6][6]{};
    double right_x[6]{};
    double right_y[6]{};
    int used = 0;
    for (std::size_t i = 0; i < count; ++i) {
        if ((mask & (1U << i)) == 0) {
            continue;
        }
        ++used;
    }
    if (used < 3) {
        return false;
    }
    // Normal equations for [x y 1] * [a c tx]^T = x' and [x y 1] * [b d ty]^T = y'.
    double n3[6][6]{};
    double rx[6]{};
    double ry[6]{};
    for (std::size_t i = 0; i < count; ++i) {
        if ((mask & (1U << i)) == 0) {
            continue;
        }
        const double w = std::max(1e-3, square(result.points[i].confidence));
        const double row[3] = {states[i].origin.x, states[i].origin.y, 1.0};
        for (int r = 0; r < 3; ++r) {
            for (int c = 0; c < 3; ++c) {
                n3[r][c] += w * row[r] * row[c];
            }
            rx[r] += w * row[r] * result.points[i].position.x;
            ry[r] += w * row[r] * result.points[i].position.y;
        }
    }
    double sx[6]{};
    double sy[6]{};
    double m1[6][6]{};
    double m2[6][6]{};
    for (int r = 0; r < 3; ++r) {
        for (int c = 0; c < 3; ++c) {
            m1[r][c] = m2[r][c] = n3[r][c];
        }
    }
    if (!solve(m1, rx, sx, 3) || !solve(m2, ry, sy, 3)) {
        return false;
    }
    (void)matrix; (void)right_x; (void)right_y;
    out[0] = sx[0]; out[1] = sy[0];   // a, b
    out[2] = sx[1]; out[3] = sy[1];   // c, d
    out[4] = sx[2]; out[5] = sy[2];   // tx, ty
    return true;
}

}

struct Tracker::State {
    Options options;
    std::size_t count;
    std::array<PointState, 4> points;
    std::array<Image, maximum_levels> pyramid;
    std::vector<Sample> samples;
    Transform group;
    int width = 0;
    int height = 0;
    unsigned refresh_age = 0;
    bool initialized = false;

    State(const Point* positions, std::size_t point_count, Options settings)
        : options(settings), count(point_count) {
        const int side = 2 * options.patch_radius + 1;
        samples.resize(static_cast<std::size_t>(side) * side);
        for (std::size_t i = 0; i < count; ++i) {
            points[i].origin = positions[i];
            for (int level = 0; level < options.pyramid_levels; ++level) {
                const int divisor = 1 << level;
                const int radius = std::max(4, (options.patch_radius + divisor - 1) / divisor);
                prepare_patch(points[i].anchor[level], radius);
                prepare_patch(points[i].working[level], radius);
            }
        }
    }

    void allocate(int frame_width, int frame_height) {
        const int target_width = frame_width;
        const int target_height = frame_height;
        width = height = 0;
        initialized = false;
        for (int level = 0; level < options.pyramid_levels; ++level) {
            Image& image = pyramid[level];
            image.width = frame_width;
            image.height = frame_height;
            image.pixels.resize(static_cast<std::size_t>(frame_width) * frame_height);
            if (level + 1 < options.pyramid_levels) {
                image.horizontal.resize(static_cast<std::size_t>(level == 0 ? frame_width :
                    (frame_width + 1) / 2) * frame_height);
            }
            frame_width = (frame_width + 1) / 2;
            frame_height = (frame_height + 1) / 2;
        }
        width = target_width;
        height = target_height;
    }

    void build_pyramid(Frame frame) {
        Image& base = pyramid[0];
        for (int y = 0; y < height; ++y) {
            const std::uint8_t* source = frame.data + static_cast<std::size_t>(y) * frame.stride;
            float* destination = base.horizontal.data() + static_cast<std::size_t>(y) * width;
            int x = 0;
            for (; x < std::min(width, 2); ++x) {
                destination[x] = filtered_luma(source, width, x);
            }
            for (; x < width - 2; ++x) {
                destination[x] = (source[x - 2] + 4.0f * source[x - 1] + 6.0f * source[x] +
                                  4.0f * source[x + 1] + source[x + 2]) * 0.0625f;
            }
            for (; x < width; ++x) {
                destination[x] = filtered_luma(source, width, x);
            }
        }
        for (int y = 0; y < height; ++y) {
            const float* rows[5];
            for (int k = 0; k < 5; ++k) {
                rows[k] = base.horizontal.data() +
                    static_cast<std::size_t>(std::clamp(y + k - 2, 0, height - 1)) * width;
            }
            float* destination = base.pixels.data() + static_cast<std::size_t>(y) * width;
            for (int x = 0; x < width; ++x) {
                destination[x] = (rows[0][x] + 4.0f * rows[1][x] + 6.0f * rows[2][x] +
                                  4.0f * rows[3][x] + rows[4][x]) * 0.0625f;
            }
        }
        for (int level = 1; level < options.pyramid_levels; ++level) {
            Image& source = pyramid[level - 1];
            Image& destination = pyramid[level];
            for (int y = 0; y < source.height; ++y) {
                const float* row = source.pixels.data() + static_cast<std::size_t>(y) * source.width;
                float* output = source.horizontal.data() + static_cast<std::size_t>(y) * destination.width;
                for (int x = 0; x < destination.width; ++x) {
                    const int center = 2 * x;
                    output[x] = (row[std::max(0, center - 2)] +
                        4.0f * row[std::max(0, center - 1)] + 6.0f * row[center] +
                        4.0f * row[std::min(source.width - 1, center + 1)] +
                        row[std::min(source.width - 1, center + 2)]) * 0.0625f;
                }
            }
            for (int y = 0; y < destination.height; ++y) {
                const int center = 2 * y;
                const float* rows[5];
                for (int k = 0; k < 5; ++k) {
                    rows[k] = source.horizontal.data() +
                        static_cast<std::size_t>(std::clamp(center + k - 2, 0, source.height - 1)) * destination.width;
                }
                float* output = destination.pixels.data() + static_cast<std::size_t>(y) * destination.width;
                for (int x = 0; x < destination.width; ++x) {
                    output[x] = (rows[0][x] + 4.0f * rows[1][x] + 6.0f * rows[2][x] +
                                 4.0f * rows[3][x] + rows[4][x]) * 0.0625f;
                }
            }
        }
    }

    Result initialize() {
        group = {};
        refresh_age = 0;
        Result result;
        result.count = count;
        unsigned mask = 0;
        for (std::size_t i = 0; i < count; ++i) {
            PointState& point = points[i];
            point.warp = {point.origin.x, point.origin.y, 1.0, 0.0, 0.0, 1.0};
            point.vx = point.vy = 0.0;
            for (int level = 0; level < options.pyramid_levels; ++level) {
                const double divisor = 1 << level;
                extract_patch(point.anchor[level], pyramid[level],
                              {point.origin.x / divisor, point.origin.y / divisor, 1.0, 0.0, 0.0, 1.0});
            }
            point.working = point.anchor;
            point.working_valid = point.anchor[0].valid;
            result.points[i].position = point.origin;
            result.points[i].confidence = point.anchor[0].valid ? point.anchor[0].texture : 0.0;
            result.points[i].lost = result.points[i].confidence < options.min_confidence;
            if (!result.points[i].lost) {
                mask |= 1U << i;
            }
        }
        result.lost = bit_count(mask) < needed();
        initialized = true;
        return result;
    }

    // Points that must be followed for the frame to count: all of one, both of two, all but one of three or four.
    int needed() const {
        return count == 1 ? 1 : count == 2 ? 2 : static_cast<int>(count) - 1;
    }

    Warp descend(const std::array<Patch, maximum_levels>& templates, Warp warp, int top_level,
                 double reference_scale) {
        for (int level = top_level; level >= 0; --level) {
            if (!templates[level].valid) {
                continue;
            }
            const double divisor = 1 << level;
            Warp local = warp;
            local.x /= divisor;
            local.y /= divisor;
            refine(templates[level], pyramid[level], local, reference_scale,
                   options.max_iterations, samples, level >= 2 ? 4 : 6);
            warp = local;
            warp.x *= divisor;
            warp.y *= divisor;
        }
        return warp;
    }

    // Two-stage follow: first against last frame's appearance (robust to slow change such as the angle of
    // view), then pull back onto the frame 0 appearance so small errors never accumulate into drift.
    Located track_from(PointState& point, Warp start, int top_level, double reference_scale) {
        Located found;
        const bool stage_one = point.working_valid;
        Warp followed = start;
        if (stage_one) {
            followed = descend(point.working, followed, top_level, reference_scale);
        }
        Warp locked = descend(point.anchor, followed, stage_one ? std::min(top_level, 1) : top_level,
                              reference_scale);
        const Patch& anchor = point.anchor[0];
        Warp best = locked;
        double best_score = correlation(anchor, pyramid[0], best);
        for (int y = -1; y <= 1; ++y) {
            for (int x = -1; x <= 1; ++x) {
                if (x == 0 && y == 0) {
                    continue;
                }
                Warp candidate = locked;
                candidate.x += 0.75 * x;
                candidate.y += 0.75 * y;
                const double score = correlation(anchor, pyramid[0], candidate);
                if (score > best_score) {
                    best_score = score;
                    best = candidate;
                }
            }
        }
        if (best.x != locked.x || best.y != locked.y) {
            refine(anchor, pyramid[0], best, reference_scale, options.max_iterations, samples, 6);
            best_score = correlation(anchor, pyramid[0], best);
        }
        found.anchor_score = best_score;
        if (!stage_one) {
            found.warp = best;
            found.score = best_score;
            return found;
        }
        const double followed_score = correlation(point.working[0], pyramid[0], followed);
        const double correction = std::hypot(best.x - followed.x, best.y - followed.y);
        const bool lock = best_score >= 0.75 && (correction <= 2.0 || best_score >= 0.92 || followed_score < best_score);
        if (lock) {
            found.warp = best;
            found.score = std::max(best_score, 0.92 * followed_score);
        } else {
            found.warp = followed;
            found.score = 0.92 * followed_score;
        }
        return found;
    }

    bool within_search(const PointState& point, const Warp& warp) const {
        return std::abs(warp.x - point.warp.x) <= options.search_radius + 0.1 &&
               std::abs(warp.y - point.warp.y) <= options.search_radius + 0.1 &&
               allowed_shape(warp, warp_scale(point.warp));
    }

    Located locate(PointState& point) {
        const double reference_scale = warp_scale(point.warp);
        Warp prediction = point.warp;
        prediction.x += std::clamp(point.vx, -double(options.search_radius), double(options.search_radius));
        prediction.y += std::clamp(point.vy, -double(options.search_radius), double(options.search_radius));
        Located best = track_from(point, prediction, options.pyramid_levels - 1, reference_scale);
        if (!within_search(point, best.warp)) {
            best.score = -1.0;
        }
        if (best.score >= 0.90) {
            return best;
        }
        // Lost: scan the neighbourhood on a coarse level and try the strongest peaks.
        const std::array<Patch, maximum_levels>& scan = point.working_valid ? point.working : point.anchor;
        int level = options.pyramid_levels - 1;
        while (level > 0 && !scan[level].valid) {
            --level;
        }
        const double divisor = 1 << level;
        const int radius = (options.search_radius + static_cast<int>(divisor) - 1) /
                           static_cast<int>(divisor);
        std::array<Warp, 8> candidates{};
        std::array<double, 8> scores;
        scores.fill(-1.0);
        for (int y = -radius; y <= radius; ++y) {
            for (int x = -radius; x <= radius; ++x) {
                Warp candidate = point.warp;
                candidate.x = point.warp.x / divisor + x;
                candidate.y = point.warp.y / divisor + y;
                const double score = correlation(scan[level], pyramid[level], candidate);
                std::size_t slot = 0;
                for (std::size_t i = 0; i < candidates.size(); ++i) {
                    if (scores[i] > -1.0 && square(candidate.x - candidates[i].x) +
                        square(candidate.y - candidates[i].y) < 4.0) {
                        slot = i;
                        break;
                    }
                    if (scores[i] < scores[slot]) {
                        slot = i;
                    }
                }
                if (score > scores[slot]) {
                    scores[slot] = score;
                    candidates[slot] = candidate;
                }
            }
        }
        for (std::size_t attempt = 0; attempt < candidates.size(); ++attempt) {
            const auto peak = std::max_element(scores.begin(), scores.end());
            if (*peak <= -1.0) {
                break;
            }
            Warp candidate = candidates[static_cast<std::size_t>(peak - scores.begin())];
            *peak = -1.0;
            candidate.x *= divisor;
            candidate.y *= divisor;
            Located tried = track_from(point, candidate, level, reference_scale);
            if (!within_search(point, tried.warp)) {
                tried.score = -1.0;
            }
            if (tried.score > best.score) {
                best = tried;
            }
            if (best.score >= 0.995) {
                break;
            }
        }
        return best;
    }

    // With only two points a similarity fit has one spare reading; with three or four the motion is a
    // perspective one, so no point may be thrown out for not fitting a similarity.
    unsigned consensus(const Result& , unsigned mask) {
        if (count > 2 || bit_count(mask) <= 2) {
            return mask;
        }
        return mask;
    }

    double confidence_of(const PointState& point, double score) const {
        return point.anchor[0].texture *
            std::clamp((score - minimum_correlation) / (1.0 - minimum_correlation), 0.0, 1.0);
    }

    Result update() {
        Result result;
        result.count = count;
        std::array<Warp, 4> found{};
        unsigned mask = 0;
        for (std::size_t i = 0; i < count; ++i) {
            PointState& point = points[i];
            Located located;
            if (point.anchor[0].valid) {
                located = locate(point);
            } else {
                located.warp = point.warp;
            }
            found[i] = located.warp;
            double confidence = confidence_of(point, std::max(located.score, 0.0));
            if (!within_search(point, found[i])) {
                confidence = 0.0;
            }
            result.points[i] = {{found[i].x, found[i].y}, confidence, confidence < options.min_confidence};
            if (!result.points[i].lost) {
                mask |= 1U << i;
            }
        }
        mask = consensus(result, mask);
        if (count > 1 && bit_count(mask) >= 1) {
            Transform model = fit(points, result, mask);
            if (bit_count(mask) == 1) {
                // One survivor says where the group is but not how it turned: keep the last known turn
                // and scale rather than trusting a single small patch with it.
                for (std::size_t i = 0; i < count; ++i) {
                    if ((mask & (1U << i)) != 0) {
                        model.a = group.a;
                        model.b = group.b;
                        model.tx = found[i].x - model.a * points[i].origin.x + model.b * points[i].origin.y;
                        model.ty = found[i].y - model.b * points[i].origin.x - model.a * points[i].origin.y;
                    }
                }
            }
            double affine[6]{};
            const bool perspective = count > 2 && fit_affine(points, result, mask, count, affine);
            const double tolerance = count > 2 ? 36.0 : 2.25;
            for (std::size_t i = 0; i < count; ++i) {
                if ((mask & (1U << i)) != 0 || !points[i].anchor[0].valid) {
                    continue;
                }
                PointState& point = points[i];
                Point predicted = model.apply(point.origin);
                if (perspective) {
                    predicted = {affine[0] * point.origin.x + affine[2] * point.origin.y + affine[4],
                                 affine[1] * point.origin.x + affine[3] * point.origin.y + affine[5]};
                }
                Warp candidate = point.warp;
                candidate.x = predicted.x;
                candidate.y = predicted.y;
                const Located again = track_from(point, candidate, options.pyramid_levels - 1,
                                                 warp_scale(point.warp));
                const double confidence = confidence_of(point, std::max(again.score, 0.0));
                if (confidence >= options.min_confidence &&
                    (square(again.warp.x - predicted.x) + square(again.warp.y - predicted.y)) <= tolerance &&
                    within_search(point, again.warp)) {
                    found[i] = again.warp;
                    result.points[i] = {{again.warp.x, again.warp.y}, confidence, false};
                    mask |= 1U << i;
                }
            }
            if (bit_count(mask) < static_cast<int>(count) && perspective) {
                // Give lost points a best-guess position so a perspective fit still has four corners.
                for (std::size_t i = 0; i < count; ++i) {
                    if ((mask & (1U << i)) == 0) {
                        result.points[i].position = {
                            affine[0] * points[i].origin.x + affine[2] * points[i].origin.y + affine[4],
                            affine[1] * points[i].origin.x + affine[3] * points[i].origin.y + affine[5]};
                        found[i].x = result.points[i].position.x;
                        found[i].y = result.points[i].position.y;
                    }
                }
            }
        }
        result.lost = bit_count(mask) < needed();
        result.transform = result.lost ? group : fit(points, result, mask);
        if (!std::isfinite(result.transform.scale()) || result.transform.scale() < 1e-6) {
            result.lost = true;
            result.transform = group;
        }
        if (count > 1 && !result.lost) {
            // A real frame never turns the group by more than a few degrees or rescales it by a third;
            // a jump like that is a false match on repeated texture, so report it as lost instead.
            const Transform step = relative_transform(result.transform, group);
            if (step.scale() < 0.75 || step.scale() > 1.34 || std::abs(step.rotation()) > 0.25) {
                result.lost = true;
                result.transform = group;
            }
        }
        result.motion = result.lost ? Transform{} : relative_transform(result.transform, group);
        for (std::size_t i = 0; i < count; ++i) {
            PointState& point = points[i];
            if ((mask & (1U << i)) != 0 && !result.lost) {
                const Warp previous = point.warp;
                point.warp = found[i];
                point.vx = point.warp.x - previous.x;
                point.vy = point.warp.y - previous.y;
                if (result.points[i].confidence > 0.6) {
                    // Remember how the feature looks now so the next frame is compared with this one.
                    std::array<Patch, maximum_levels> fresh = point.working;
                    bool good = true;
                    for (int level = 0; level < options.pyramid_levels && good; ++level) {
                        const double divisor = 1 << level;
                        Warp local = point.warp;
                        local.x /= divisor;
                        local.y /= divisor;
                        extract_patch(fresh[level], pyramid[level], local);
                        good = fresh[level].valid || level > 0;
                    }
                    if (good && fresh[0].valid) {
                        point.working = fresh;
                        point.working_valid = true;
                    }
                }
            } else {
                result.points[i].lost = true;
                result.points[i].confidence = std::min(result.points[i].confidence, options.min_confidence * 0.5);
                if (!result.lost) {
                    const Point predicted = result.transform.apply(point.origin);
                    point.vx = predicted.x - point.warp.x;
                    point.vy = predicted.y - point.warp.y;
                    point.warp.x = predicted.x;
                    point.warp.y = predicted.y;
                } else {
                    point.vx = point.vy = 0.0;
                }
                result.points[i].position = {point.warp.x, point.warp.y};
            }
        }
        group = result.transform;
        return result;
    }
};

Point Transform::apply(Point point) const noexcept {
    return {a * point.x - b * point.y + tx, b * point.x + a * point.y + ty};
}

double Transform::scale() const noexcept {
    return std::hypot(a, b);
}

double Transform::rotation() const noexcept {
    return std::atan2(b, a);
}

Tracker::Tracker(const Point* points, std::size_t count, Options options) {
    if (points == nullptr || count < 1 || count > 4 ||
        options.patch_radius < 8 || options.patch_radius > 48 ||
        options.search_radius < 1 || options.search_radius > 512 ||
        options.pyramid_levels < 3 || options.pyramid_levels > 4 ||
        options.max_iterations < 1 || options.max_iterations > 100 ||
        options.refresh_interval < 1 || !std::isfinite(options.min_confidence) ||
        options.min_confidence <= 0.0 || options.min_confidence > 1.0) {
        throw std::invalid_argument("invalid tracker configuration");
    }
    for (std::size_t i = 0; i < count; ++i) {
        if (!std::isfinite(points[i].x) || !std::isfinite(points[i].y)) {
            throw std::invalid_argument("nonfinite point");
        }
        for (std::size_t j = 0; j < i; ++j) {
            if (std::hypot(points[i].x - points[j].x, points[i].y - points[j].y) < 0.001) {
                throw std::invalid_argument("coincident points");
            }
        }
    }
    state_ = std::make_unique<State>(points, count, options);
}

Tracker::~Tracker() = default;
Tracker::Tracker(Tracker&&) noexcept = default;
Tracker& Tracker::operator=(Tracker&&) noexcept = default;

Result Tracker::track(Frame frame) {
    if (!state_) {
        throw std::logic_error("moved tracker");
    }
    if (frame.data == nullptr || frame.width < 1 || frame.height < 1 ||
        frame.width > 16384 || frame.height > 16384 || frame.stride < frame.width) {
        throw std::invalid_argument("invalid luma frame");
    }
    if (frame.width != state_->width || frame.height != state_->height) {
        state_->allocate(frame.width, frame.height);
    }
    state_->build_pyramid(frame);
    return state_->initialized ? state_->update() : state_->initialize();
}

void Tracker::reset() noexcept {
    if (state_) {
        state_->initialized = false;
    }
}

}

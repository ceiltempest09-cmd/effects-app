# Playback glitching at normal preview quality

NOT verified: no Android SDK, Kotlin compiler, Skia or device here. Not compiled, not profiled, no before/after numbers. The next CI build is the first compile.

## Cause found in the code (not measured)
While playing, `EngineThread.renderNow` drew the live frame and then, for every frame missing from the cache (always the case when the pre-render is
"out of date"), called `tapFrame` -> `NativeEngine.previewStill`: a SECOND full `DrawScene`, a freshly allocated Skia render target and a synchronous
read-back, all on the engine thread, before the next live frame could start. Frame cost was roughly live draw + full capture + read-back.
The capture size is `cacheFrameSize(.., divisor)`, so Half/Quarter ("Lower Pixel") cut both draws and the read-back 4x/16x, which hides the problem.

## Change
`EngineThread.kt` only: `tapFrameWithinBudget` replaces the direct `tapFrame` call. A capture runs only if no newer view is waiting and
(average live draw + average capture cost) <= 85% of the frame interval; a skipped capture is re-probed every 45 frames so the estimate recovers.
Nothing displayed is skipped or replaced, quality/default settings/export/cache keys are untouched; skipped frames are filled by the idle/ordered render.
Counters `tapsRun` / `tapsLeftOut` expose how often captures ran or were left out.

## Not done / follow-ups
- Capture still allocates a new render target per call (`EngineImpl::offscreen`); reuse would help but needs on-device testing.
- If playback still stutters with captures off, the live draw itself is over budget: needs `RenderStats` numbers from the device.

## Second cause: playing from a finished pre-render (from the user's screen recording)
Not compiled or run here. The recording shows "Pre-rendered" while playing, with the playhead moving and the preview frozen or flashing between full
frames and an empty one. `CachedFrame` drew the cached frame only when `shown.frame == state.frame`, and `FramePlayer` showed a decoded frame only when it was
the exact wanted frame. The playhead runs on the audio/wall clock, so when a JPEG decode finishes late the frame is never shown and nothing is drawn;
the live surface underneath (not updated while playing from the cache) shows through. Smaller (Lower Pixel) frames decode in time, which hides it.

Change: `FramePlayer.holdLatest` keeps the newest decoded frame (at most 8 behind, never backwards, keeps its own frame number) on screen while the right one
decodes; `FramePlayer.drawable` lets `CachedFrame` draw it only while playing. Scrubbing and paused display still need the exact frame.
This hides late frames instead of speeding up decoding. If it still looks choppy on the device, decode time per frame is the next thing to measure.

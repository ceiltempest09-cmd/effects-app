#include "bridge_selftest.h"
#include "engine.h"

#include <android/hardware_buffer.h>

#include <algorithm>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <vector>

namespace am {
void SetNativeShaders(bool on);   // effects_graph.cpp
bool NativeShadersEnabled();

namespace {
constexpr int kSize = 256;

const char* kSksl =
    "<effect id=\"fx.bridge_sksl\" graph=\"2\" output=\"out\" seek=\"reset\">\n"
    " <buffer id=\"m\" format=\"rgba16f\"/><buffer id=\"n\" format=\"rgba16f\"/>\n"
    " <pass id=\"a\" lang=\"sksl\" output=\"m\"><input name=\"image\" ref=\"source\"/><source><![CDATA[\n"
    "uniform shader image;\nhalf4 main(float2 p) { return image.eval(p) * 0.8; }\n]]></source></pass>\n"
    " <pass id=\"b\" lang=\"sksl\" output=\"n\"><input name=\"image\" ref=\"buffer:m\"/><source><![CDATA[\n"
    "uniform shader image;\nhalf4 main(float2 p) { return image.eval(p) * 0.5; }\n]]></source></pass>\n"
    " <pass id=\"c\" lang=\"sksl\" output=\"out\"><input name=\"image\" ref=\"buffer:n\"/><source><![CDATA[\n"
    "uniform shader image;\nhalf4 main(float2 p) { return image.eval(p); }\n]]></source></pass>\n"
    "</effect>\n";

const char* kNative =
    "<effect id=\"fx.bridge_native\" graph=\"2\" output=\"out\" seek=\"reset\">\n"
    " <buffer id=\"m\" format=\"rgba16f\"/><buffer id=\"n\" format=\"rgba16f\"/>\n"
    " <pass id=\"a\" lang=\"sksl\" output=\"m\"><input name=\"image\" ref=\"source\"/><source><![CDATA[\n"
    "uniform shader image;\nhalf4 main(float2 p) { return image.eval(p) * 0.8; }\n]]></source></pass>\n"
    " <pass id=\"b\" lang=\"glsl-es\" output=\"n\"><input name=\"src\" ref=\"buffer:m\"/><source><![CDATA[#version 300 es\n"
    "precision highp float;\nuniform sampler2D src;\nuniform vec2 size;\nout vec4 o;\n"
    "void main() { o = texture(src, gl_FragCoord.xy / size) * 0.5; }\n]]></source></pass>\n"
    " <pass id=\"c\" lang=\"sksl\" output=\"out\"><input name=\"image\" ref=\"buffer:n\"/><source><![CDATA[\n"
    "uniform shader image;\nhalf4 main(float2 p) { return image.eval(p); }\n]]></source></pass>\n"
    "</effect>\n";

std::string Scene(const std::string& effect) {
    return std::string("<?xml version='1.0' encoding='UTF-8' ?>\n<scene title=\"bridge\" width=\"256\" height=\"256\" exportWidth=\"256\" exportHeight=\"256\" "
        "bgcolor=\"#ff000000\" totalTime=\"999\" fps=\"30\">\n"
        "  <shape id=\"1\" label=\"Circle\" startTime=\"0\" endTime=\"999\" fillType=\"color\" s=\".circle\">\n"
        "    <transform><location value=\"128.0,128.0,0.0\"/><scale value=\"1.6,1.6\"/></transform>\n"
        "    <fillColor value=\"#fff24949\"/>\n    <property name=\"size\" type=\"vec2\" value=\"100.0,100.0\"/>\n") +
        (effect.empty() ? "" : "    <effect id=\"" + effect + "\"/>\n") + "  </shape>\n</scene>\n";
}

bool Render(Engine& engine, const std::string& effect, std::vector<uint8_t>* rgba, std::string* why) {
    std::string error;
    if (!engine.setScene(Scene(effect), &error)) { *why = "setScene: " + error; return false; }
    AHardwareBuffer_Desc d = {};
    d.width = kSize; d.height = kSize; d.layers = 1; d.format = AHARDWAREBUFFER_FORMAT_R8G8B8A8_UNORM;
    d.usage = AHARDWAREBUFFER_USAGE_GPU_FRAMEBUFFER | AHARDWAREBUFFER_USAGE_GPU_SAMPLED_IMAGE | AHARDWAREBUFFER_USAGE_CPU_READ_OFTEN;
    AHardwareBuffer* buffer = nullptr;
    if (AHardwareBuffer_allocate(&d, &buffer) != 0 || !buffer) { *why = "cannot allocate the output buffer"; return false; }
    int code = 0;
    for (int i = 0; i < 2; i++) code = engine.renderBuffer(buffer, 0, 0xff000000);   // twice: the second frame reuses every pooled target
    bool ok = code == 0;
    if (!ok) *why = "renderBuffer returned " + std::to_string(code);
    if (ok) {
        AHardwareBuffer_Desc info = {};
        AHardwareBuffer_describe(buffer, &info);
        void* mem = nullptr;
        if (AHardwareBuffer_lock(buffer, AHARDWAREBUFFER_USAGE_CPU_READ_OFTEN, -1, nullptr, &mem) != 0 || !mem) { *why = "cannot lock the output buffer"; ok = false; }
        else {
            rgba->assign((size_t)kSize * kSize * 4, 0);
            for (int y = 0; y < kSize; y++) std::memcpy(&(*rgba)[(size_t)y * kSize * 4], static_cast<uint8_t*>(mem) + (size_t)y * info.stride * 4, (size_t)kSize * 4);
            AHardwareBuffer_unlock(buffer, nullptr);
        }
    }
    AHardwareBuffer_release(buffer);
    return ok;
}

int MaxDiff(const std::vector<uint8_t>& a, const std::vector<uint8_t>& b) {
    int m = 0;
    if (a.size() != b.size()) return 255;
    for (size_t i = 0; i < a.size(); i++) m = std::max(m, std::abs((int)a[i] - (int)b[i]));
    return m;
}
}  // namespace

void RunBridgeSelfTest(std::string* text, int* pass, int* fail) {
    auto line = [&](const std::string& s) { *text += s + "\n"; };
    auto ok = [&](const std::string& s) { (*pass)++; line("PASS  " + s); };
    auto bad = [&](const std::string& s) { (*fail)++; line("FAIL  " + s); };
    line("== Skia <-> native GL bridge (real engine, Graphite on Vulkan) ==");
    const bool before = NativeShadersEnabled();
    SetNativeShaders(true);
    std::string error;
    std::unique_ptr<Engine> engine = Engine::Make(Backend::kGraphite, &error);
    if (!engine || engine->failed()) { bad("engine did not start: " + error); SetNativeShaders(before); return; }
    ok("engine started: " + engine->info().substr(0, 120));
    std::string a = engine->loadEffect(kSksl), b = engine->loadEffect(kNative);
    if (a != "ok") bad("all-SkSL reference effect did not load: " + a); else ok("all-SkSL reference effect loads");
    if (b != "ok") bad("SkSL -> GLSL ES -> SkSL effect did not load: " + b); else ok("SkSL -> GLSL ES -> SkSL effect loads (GLSL ES kept as GLSL ES)");
    if (a == "ok" && b == "ok") {
        std::vector<uint8_t> none, sksl, native;
        std::string why;
        if (!Render(*engine, "", &none, &why)) bad("render without effect: " + why);
        else if (!Render(*engine, "fx.bridge_sksl", &sksl, &why)) bad("render with the all-SkSL effect: " + why);
        else if (!Render(*engine, "fx.bridge_native", &native, &why)) bad("render with the native effect: " + why);
        else {
            const int engaged = MaxDiff(none, sksl);
            if (engaged > 40) ok("the reference effect changed the picture (max change " + std::to_string(engaged) + "/255)");
            else bad("the reference effect did not change the picture (max change " + std::to_string(engaged) + "); the comparison below proves nothing");
            const int d = MaxDiff(sksl, native);
            const std::string msg = "native GLSL ES pass between two SkSL passes matches the all-SkSL result, max difference " + std::to_string(d) + "/255 (limit 4)";
            if (d <= 4 && engaged > 40) ok(msg); else bad(msg);
        }
    }
    engine.reset();
    SetNativeShaders(before);
}
}  // namespace am

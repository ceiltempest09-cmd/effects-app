# Host-side Kotlin tests

`org/json/Json.kt` is a small stand-in for Android's `org.json` so the schema, importer and converter code can be compiled and
tested on a plain JVM without the Android SDK (`run.sh`). It is NOT part of the app; the app uses the platform `org.json`.

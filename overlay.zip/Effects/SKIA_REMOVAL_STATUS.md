# Skia removal status — migration tracking

## Batch 1: standalone GLSL ES / OpenGL ES render-graph backend

**Status: HOST-VERIFIED; NOT YET THE APPLICATION'S PRIMARY RENDERER.**

The project contains a real EGL/OpenGL ES 3.x backend (`gl_backend.{h,cpp}`) and a backend-neutral render graph (`render_graph.{h,cpp}`). The backend compiles GLSL ES on the device driver, manages render targets and textures, binds uniforms/samplers, executes passes, supports pooling/history, reports capabilities, and records diagnostics/statistics. The render graph plans and executes passes through backend capability selection and explicit inter-backend hand-offs.

### Verification performed on this source upload

- `tests/native/build_gl.sh`: **1,227 checks passed, 0 failed, 1 skipped** on Mesa llvmpipe. It exercised GLES 3.2 and desktop GL 4.5, shader compilation/execution, formats, uniforms/samplers, blending, multi-pass graphs, history, pooling, profiling, and error handling. The skipped test is SPIR-V/Vulkan execution because no SPIR-V compiler/Vulkan backend is available in this host test build.
- `tests/native/run.sh` component tests: render graph **171 passed**; native shader **105 passed**; SPIR-V reflection **22 passed**; GLSL wrapper **22 passed**; history signature **16 passed**; color pipeline **114 passed**. The full script did not complete within the available execution window when it reached its final GPU test; the GPU test was run separately and passed as stated above.
- Fixed a missing `<algorithm>` include in `tests/native/render_graph_test.cpp`, which previously prevented the host test suite from compiling (`std::any_of`).
- Android Gradle/NDK build and Mali-G57 device test: **not run**.

### Critical integration limitation

This completes the **standalone renderer / render-graph foundation only**. It does NOT make the app fully GLSL. `engine.cpp`, scene compositing, shapes, styles, text, video-frame integration, and the current Skia rendering lifecycle still depend on Skia. The app's effect graph adapter and Kotlin importer still have Skia/SkSL integration paths. Do not remove Skia from CMake or GitHub Actions yet; doing so would break the current app renderer.

### Next batch

Batch 2 must connect the native renderer to the real engine frame lifecycle and replace scene/layer compositing and video-frame paths. This requires a concrete engine-to-GPU bridge and correct synchronization/resource ownership; it is not safe to claim the application uses GLSL until that is implemented and tested.

No features were intentionally removed or stubbed in this batch. Package/application identity and signing configuration were not changed.


## Batch 2 continuation — source reconciliation (2026-11-22)

The two supplied archives are complementary, not interchangeable. `overlay.zip` contains the newer integration files and build configuration but omits 49 C++ source/header files that its own CMake configuration references. `Effects.zip` contains those missing implementation files. The working Batch 2 tree was reconciled by adding only files absent from `overlay.zip`; existing overlay files were preserved (including its newer `gl_yuv.cpp` and `gl_yuv.h`). The CMake-referenced `.cpp` source existence check now reports no missing files.

This is source-tree repair, not completion of Batch 2. The current engine still renders through Skia surfaces/canvases, the video YUV path still adapts the native GL texture back into a Skia image, and `GraphRunner` still uses its Skia backend as the source/result adapter. The app's Android build and on-device GLES integration have not yet been verified. Do not mark Batch 2 complete or remove Skia from the build yet.


## Batch 2 continuation — native test runner restored and rerun

Restored the native host test scripts and native shader capability notes into the current `overlay.zip` tree from the supporting `Effects.zip` archive. Ran `tests/native/run.sh` from the project root on Mesa llvmpipe:

- Render graph: 183 passed.
- Native shader: 105 passed.
- SPIR-V reflection: 22 passed.
- GLSL wrapper: 22 passed.
- History signature: 16 passed.
- Color pipeline: 114 passed.
- GLES / desktop GL backend: 1,227 passed, 0 failed, 1 skipped.

The skipped test is SPIR-V / Vulkan execution because this host test build has no SPIR-V compiler or Vulkan device. These are host tests of the standalone native backend, not Android app/device tests. Batch 2 remains open: the app frame lifecycle, Skia-backed scene composition, Ganesh/OpenGL bridge, and video/preview integration still need migration.


## Batch 2 continuation — video GL state isolation (2026-11-22)

`shared/cpp/gl_yuv.cpp` now preserves the calling GL context's state around native YUV-to-RGBA texture conversion. It restores the framebuffer, viewport, program, texture unit and bindings, VAO, array buffer, color mask, and blend/scissor/depth/stencil/cull enables. The converter no longer resets the framebuffer to 0 unconditionally.

The native host test suite passed: 183 render-graph, 105 shader, 22 SPIR-V reflection, 22 GLSL wrapper, 16 history-signature, 114 color-pipeline, and 1,227 GLES/desktop GL backend checks passed (one SPIR-V/Vulkan check skipped due to missing host tools/device). The Android-only YUV converter was not compiled by those host tests.

This is a video-path safety improvement, not completion of video migration: `GlYuv::convert()` still wraps the native texture as a Skia `SkImage` for the current engine. Scene/drawing/text/preview and the engine-owned GL bridge remain to be migrated.


## Batch 2 continuation — Ganesh/OpenGL native graph bridge

The engine GPU bridge now has a Ganesh/OpenGL path in addition to the existing Graphite/Vulkan path:

- `GraphGpuBridge` exposes whether the native backend must adopt the engine's current EGL context and a stable context identity.
- The GLES render-graph backend adopts the engine EGL context for Ganesh instead of creating an unrelated second context.
- Ganesh wraps graph AHardwareBuffers with `SkSurfaces::WrapAndroidHardwareBuffer`; wrappers are cached and invalidated by `forgetBuffer`.
- Ganesh hand-off submits and waits on the same GL queue. Native writes invalidate Ganesh's cached GL state with `resetContext()`.
- The adopted GL backend is released by the engine before EGL teardown, after effect graphs are dropped.

Validation: the native host suite passes (183 render-graph, 105 shader, 22 SPIR-V reflection, 22 GLSL wrapper, 16 history-signature, 114 color-pipeline, and 1,227 GLES/desktop GL checks; one SPIR-V/Vulkan check skipped). These tests do not compile the Android-only `engine.cpp` or validate Ganesh AHardwareBuffer wrapping on a device. Android Gradle/NDK build and physical-device verification are still required. Scene, drawing, text, preview, and the video SkImage adapter remain Skia-backed.


## Batch 2 continuation — YUV converter GL-state isolation (2026-11-22)

The native YUV-to-RGBA converter now preserves independent draw/read framebuffer bindings and texture-unit-0 sampler state, and uses its own VAO so it does not mutate the application's VAO 0 vertex attributes. GL object allocation failures are reported during setup.

The host native suite passed (183 render-graph, 105 shader, 22 SPIR-V reflection, 22 GLSL wrapper, 16 history-signature, 114 color-pipeline, and 1,227 GLES/desktop GL checks; one SPIR-V/Vulkan test skipped). This suite does not compile the Android-only YUV converter. The Android build/device test remains outstanding. Video still flows through the Skia image adapter; this change does not complete video migration.


## Batch 2 continuation — migration audit gate (2026-11-22)

Added `tools/audit_skia_migration.py` for repeatable subsystem-level inventory. On the current overlay source it reports 1,523 matching production C++ lines across 26 files: engine/frame lifecycle (160), scene/path model (194), drawing/shapes/styles/text/preview (798), direct video/image adapter files (8), and other effects/interpolation/geometry code (363). The video dependency is larger than the direct adapter count because `engine.cpp` stores decoded frames as `SkImage`.

`tests/native/run.sh` was rerun successfully: 183 render-graph, 105 shader, 22 SPIR-V reflection, 22 GLSL wrapper, 16 history-signature, 114 color-pipeline, and 1,227 GLES/desktop GL checks passed; one SPIR-V/Vulkan check was skipped due to missing host compiler/device. This validates the standalone native backend only. No Android build or device test was performed. The application renderer remains Skia-backed and Batch 2 remains incomplete.

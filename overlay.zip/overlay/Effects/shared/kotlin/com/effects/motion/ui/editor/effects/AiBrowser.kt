package com.effects.motion.ui.editor.effects

import com.effects.motion.i18n.text
import androidx.compose.ui.res.pluralStringResource
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.selection.selectableGroup
import androidx.compose.ui.semantics.Role
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.keepScreenOn
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.effects.motion.ai.AiAction
import com.effects.motion.ai.AiDevice
import com.effects.motion.ai.AiEnhance
import com.effects.motion.ai.AiSmooth
import com.effects.motion.ai.AiTools
import com.effects.motion.ai.CutoutQuality
import com.effects.motion.ai.AiVerdict
import com.effects.motion.ai.EnhanceMode
import com.effects.motion.ai.aiEstimate
import com.effects.motion.export.formatBytes
import androidx.compose.foundation.border
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import com.effects.motion.ai.AiKind
import com.effects.motion.ai.MAX_SMOOTH_FRAMES
import com.effects.motion.ai.aiMarks
import com.effects.motion.ai.smoothPlan
import com.effects.motion.export.FrameInterpolation
import com.effects.motion.export.MotionBlur
import com.effects.motion.export.SmoothLevel
import com.effects.motion.ui.export.SmoothingHelp
import androidx.compose.material3.Icon
import com.effects.motion.ai.LONG_MATTE_SECONDS
import com.effects.motion.ai.MAX_MATTE_SECONDS
import com.effects.motion.ai.MatteSides
import com.effects.motion.ai.NoiseSource
import com.effects.motion.ai.matteBytes
import com.effects.motion.ai.matteSeconds
import com.effects.motion.ai.matteSize
import com.effects.motion.ai.smoothSource
import com.effects.motion.model.Layer
import com.effects.motion.model.Scene
import kotlin.math.roundToInt
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Matrix
import android.media.MediaMetadataRetriever
import android.net.Uri
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.runtime.produceState
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import com.effects.motion.ai.BestCutout
import com.effects.motion.ai.CutoutChoice
import com.effects.motion.ai.MAX_TAPS
import com.effects.motion.ai.MatteEdge
import com.effects.motion.ai.backgroundMark
import com.effects.motion.ai.Tap
import com.effects.motion.ai.frameToView
import com.effects.motion.ai.viewToFrame
import com.effects.motion.library.openableUri
import com.effects.motion.media.decodePicture
import com.effects.motion.platform.scaledFrame
import com.effects.motion.ui.editor.panels.EdgeSlider
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import com.effects.motion.ui.theme.Am
import com.effects.motion.ui.theme.TilePress
import com.effects.motion.ui.theme.pressScale
import androidx.compose.foundation.LocalIndication
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.runtime.remember
import androidx.compose.ui.res.stringResource
import com.effects.motion.R

@Composable
internal fun AiBackdrop(modifier: Modifier, action: AiAction? = null) {
    Canvas(modifier.background(Brush.linearGradient(listOf(Color(0xFF7862A8), Color(0xFF467B8B), Color(0xFF509C95))))) {
        for ((x, y, radius) in listOf(Triple(0.16f, 0.25f, 4f), Triple(0.83f, 0.32f, 3f), Triple(0.71f, 0.78f, 2f))) {
            val cx = size.width * x; val cy = size.height * y; val r = radius.dp.toPx()
            drawPath(Path().apply {
                moveTo(cx, cy - r); quadraticTo(cx, cy, cx + r, cy)
                quadraticTo(cx, cy, cx, cy + r); quadraticTo(cx, cy, cx - r, cy)
                quadraticTo(cx, cy, cx, cy - r); close()
            }, Color.White.copy(alpha = 0.65f))
        }
        val cx = size.width / 2; val cy = size.height / 2
        val unit = minOf(size.width, size.height)
        when (action) {
            AiAction.Background -> {
                drawCircle(Color.White.copy(alpha = 0.85f), unit * 0.1f, Offset(cx, cy - unit * 0.12f))
                drawPath(Path().apply {
                    moveTo(cx - unit * 0.22f, cy + unit * 0.22f)
                    cubicTo(cx - unit * 0.22f, cy - unit * 0.05f, cx + unit * 0.22f, cy - unit * 0.05f, cx + unit * 0.22f, cy + unit * 0.22f)
                    close()
                }, Color.White.copy(alpha = 0.85f))
            }
            AiAction.Noise -> {
                for (i in -4..4) {
                    val h = unit * (if (i % 2 == 0) 0.13f else 0.23f)
                    val x = cx + i * unit * 0.06f
                    drawLine(Color.White.copy(alpha = 0.85f), Offset(x, cy - h), Offset(x, cy + h), unit * 0.022f, StrokeCap.Round)
                }
            }
            AiAction.Video -> drawPath(Path().apply {
                moveTo(cx - unit * 0.12f, cy - unit * 0.2f)
                lineTo(cx + unit * 0.2f, cy); lineTo(cx - unit * 0.12f, cy + unit * 0.2f); close()
            }, Color.White.copy(alpha = 0.85f))
            AiAction.Enhance -> {
                val stroke = androidx.compose.ui.graphics.drawscope.Stroke(unit * 0.025f)
                drawRect(Color.White.copy(alpha = 0.85f), Offset(cx - unit * 0.22f, cy - unit * 0.02f), androidx.compose.ui.geometry.Size(unit * 0.2f, unit * 0.2f))
                drawRect(Color.White.copy(alpha = 0.85f), Offset(cx - unit * 0.22f, cy - unit * 0.22f), androidx.compose.ui.geometry.Size(unit * 0.44f, unit * 0.44f), style = stroke)
                drawLine(Color.White.copy(alpha = 0.85f), Offset(cx + unit * 0.02f, cy - unit * 0.02f), Offset(cx + unit * 0.15f, cy - unit * 0.15f), unit * 0.025f, StrokeCap.Round)
            }
            AiAction.Smooth, AiAction.Reverse, null -> Unit
        }
    }
}

@Composable
internal fun AiTile(action: AiAction, layer: Layer?, tools: AiTools) {
    val reason = action.unavailable(layer)
    Column(Modifier.width(100.dp).padding(5.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        val press = remember { MutableInteractionSource() }
        Column(Modifier.pressScale(press, TilePress).alpha(if (reason == null) 1f else 0.35f)
            .clickable(press, LocalIndication.current, enabled = reason == null && tools.running == null) { tools.apply(action) }, horizontalAlignment = Alignment.CenterHorizontally) {
            AiBackdrop(Modifier.size(93.dp).clip(RoundedCornerShape(5.dp)), action)
            Text(stringResource(action.title), Modifier.fillMaxWidth().height(26.dp).padding(top = 4.dp), color = Am.OnDark, fontSize = 8.sp,
                lineHeight = 9.sp, textAlign = androidx.compose.ui.text.style.TextAlign.Center, maxLines = 2)
        }
        Text(reason?.text() ?: "", Modifier.fillMaxWidth().height(16.dp), color = Am.OnDark.copy(alpha = 0.7f), fontSize = 8.sp,
            textAlign = androidx.compose.ui.text.style.TextAlign.Center, maxLines = 1)
    }
}

private const val PICK_SIDE = 640

private suspend fun pickFrame(context: Context, uri: String, timeUs: Long): ImageBitmap? = withContext(Dispatchers.IO) {
    val retriever = MediaMetadataRetriever()
    try {
        retriever.setDataSource(context, Uri.parse(openableUri(uri)))
        retriever.scaledFrame(timeUs, MediaMetadataRetriever.OPTION_CLOSEST, PICK_SIDE, PICK_SIDE)?.asImageBitmap()
    } catch (e: CancellationException) {
        throw e
    } catch (_: Exception) {
        null
    } finally {
        runCatching { retriever.release() }
    }
}

private suspend fun pickPicture(context: Context, uri: String, turn: Int): ImageBitmap? = withContext(Dispatchers.IO) {
    val picture = runCatching { decodePicture(context.contentResolver, Uri.parse(openableUri(uri)), PICK_SIDE) }.getOrNull() ?: return@withContext null
    if (Math.floorMod(turn, 360) == 0) return@withContext picture.asImageBitmap()
    runCatching {
        Bitmap.createBitmap(picture, 0, 0, picture.width, picture.height, Matrix().apply { postRotate(turn.toFloat()) }, true)
            .also { if (it !== picture) picture.recycle() }.asImageBitmap()
    }.getOrElse { picture.asImageBitmap() }
}

private fun fitted(picture: ImageBitmap, width: Float, height: Float): Rect {
    val scale = minOf(width / picture.width, height / picture.height)
    val w = picture.width * scale
    val h = picture.height * scale
    return Rect((width - w) / 2, (height - h) / 2, (width + w) / 2, (height + h) / 2)
}

@Composable
private fun SubjectPicker(picture: ImageBitmap?, turn: Int, taps: List<Tap>, hint: String, onTaps: (List<Tap>) -> Unit) {
    val latest by rememberUpdatedState(taps)
    Box(Modifier.padding(top = 12.dp).fillMaxWidth().height(180.dp).clip(RoundedCornerShape(6.dp)).background(Am.PanelInset), Alignment.Center) {
        if (picture == null) Text(stringResource(R.string.about_loading), color = Am.Caption, fontSize = 12.sp)
        else Canvas(Modifier.fillMaxSize().pointerInput(picture, turn) {
            detectTapGestures { at ->
                val box = fitted(picture, size.width.toFloat(), size.height.toFloat())
                if (!box.contains(at)) return@detectTapGestures
                val near = latest.indexOfFirst { (u, v) ->
                    val (x, y) = frameToView(u, v, turn)
                    (Offset(box.left + x * box.width, box.top + y * box.height) - at).getDistance() < 24.dp.toPx()
                }
                onTaps(if (near >= 0) latest.filterIndexed { i, _ -> i != near }
                    else (latest + viewToFrame((at.x - box.left) / box.width, (at.y - box.top) / box.height, turn)).takeLast(MAX_TAPS))
            }
        }) {
            val box = fitted(picture, size.width, size.height)
            drawImage(picture, dstOffset = IntOffset(box.left.roundToInt(), box.top.roundToInt()),
                dstSize = IntSize(box.width.roundToInt().coerceAtLeast(1), box.height.roundToInt().coerceAtLeast(1)))
            for ((u, v) in taps) {
                val (x, y) = frameToView(u, v, turn)
                val at = Offset(box.left + x * box.width, box.top + y * box.height)
                drawCircle(Color.Black.copy(alpha = 0.55f), 10.5.dp.toPx(), at)
                drawCircle(Am.Accent, 9.dp.toPx(), at)
                drawCircle(Color.White, 3.dp.toPx(), at)
            }
        }
        val all = taps.isEmpty()
        Box(Modifier.align(Alignment.TopStart).padding(6.dp).height(30.dp).clip(RoundedCornerShape(15.dp)).background(if (all) Am.Accent else Color.Black.copy(alpha = 0.6f))
            .clickable { onTaps(emptyList()) }.padding(horizontal = 12.dp), Alignment.Center) {
            Text(stringResource(R.string.subject_keep_all), color = if (all) Am.OnAccent else Color.White, fontSize = 13.sp, maxLines = 1)
        }
    }
    Text(if (taps.isEmpty()) hint else stringResource(R.string.subject_chosen), Modifier.padding(top = 6.dp).fillMaxWidth().height(48.dp),
        color = Am.Caption, fontSize = 12.sp, lineHeight = 16.sp, maxLines = 3)
}

@Composable
internal fun AiVideoDialog(tools: AiTools, scene: Scene) {
    val layer = tools.videoSetup ?: return
    val media = layer.mediaFill?.uri?.let(scene::media)
    val context = LocalContext.current
    val frame by produceState<ImageBitmap?>(null, layer.mediaFill?.uri, layer.mediaFill?.inTime) {
        value = layer.mediaFill?.let { pickFrame(context, it.uri, it.inTime * 1000L) }
    }
    val seconds = media?.let(layer::matteSeconds) ?: 0.0
    val frames = (seconds * (media?.fps ?: 30f)).roundToInt()
    val size = media?.let { matteSize(it.width, it.height, tools.videoSide) }
    val tooLong = seconds > MAX_MATTE_SECONDS
    val sizeNames = listOf(R.string.aibrowser_size_small, R.string.aibrowser_size_medium, R.string.aibrowser_size_large)
    AlertDialog(onDismissRequest = { tools.videoSetup = null },
        title = { Text(stringResource(AiAction.Video.title), color = Am.OnDark) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                Text(stringResource(R.string.every_frame_of_this_clip_is),
                    color = Am.OnDark, fontSize = 14.sp)
                Row(Modifier.padding(top = 14.dp).fillMaxWidth().height(36.dp).clip(RoundedCornerShape(6.dp)).background(Am.PanelInset)) {
                    for ((side, name) in MatteSides.zip(sizeNames)) {
                        val on = side == tools.videoSide
                        Box(Modifier.weight(1f).fillMaxHeight().padding(2.dp).clip(RoundedCornerShape(5.dp)).background(if (on) Am.FieldHi else Color.Transparent)
                            .clickable { tools.videoSide = side }, Alignment.Center) {
                            Text(stringResource(R.string.aibrowser_size_option, stringResource(name), side.toString()), color = if (on) Am.Accent else Am.OnDark, fontSize = 12.sp, maxLines = 1)
                        }
                    }
                }
                SubjectPicker(frame, media?.orientation ?: 0, tools.subject, stringResource(R.string.subject_hint_video)) { tools.subject = it }
                Text(
                    when {
                        tooLong -> pluralStringResource(R.plurals.aibrowser_too_long, MAX_MATTE_SECONDS / 60, (MAX_MATTE_SECONDS / 60).toString())
                        size == null -> stringResource(R.string.aibrowser_no_size)
                        else -> pluralStringResource(
                            if (seconds > LONG_MATTE_SECONDS) R.plurals.aibrowser_estimate_long else R.plurals.aibrowser_estimate, frames,
                            frames.toString(), size.first.toString(), size.second.toString(), (matteBytes(seconds, size.first, size.second) / 1_000_000 + 1).toString(),
                        )
                    },
                    Modifier.padding(top = 12.dp).height(54.dp), color = if (tooLong) Am.Warning else Am.Caption, fontSize = 12.sp, lineHeight = 17.sp,
                )
            }
        },
        confirmButton = {
            TextButton({ tools.apply(AiAction.Video, confirmed = true) }, enabled = !tooLong && size != null) { Text(stringResource(R.string.start), color = Am.Accent) }
        },
        dismissButton = { TextButton({ tools.videoSetup = null }) { Text(stringResource(R.string.cancel), color = Am.Accent) } },
        containerColor = Am.Field)
}

@Composable
internal fun AiNoiseDialog(tools: AiTools) {
    if (tools.noiseSetup == null) return
    AlertDialog(onDismissRequest = { tools.noiseSetup = null },
        title = { Text(stringResource(AiAction.Noise.title), color = Am.OnDark) },
        text = {
            Column {
                Text(stringResource(R.string.ai_noise_question), color = Am.OnDark, fontSize = 14.sp)
                Column(Modifier.padding(top = 12.dp).selectableGroup(), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    for (source in NoiseSource.entries) {
                        val on = source == tools.noiseSource
                        Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(6.dp)).background(if (on) Am.FieldHi else Am.PanelInset)
                            .selectable(on, role = Role.RadioButton) { tools.noiseSource = source }.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                            RadioButton(on, null, colors = RadioButtonDefaults.colors(selectedColor = Am.Accent, unselectedColor = Am.OnDark))
                            Column(Modifier.padding(start = 10.dp)) {
                                Text(stringResource(source.title), color = if (on) Am.Accent else Am.OnDark, fontSize = 14.sp)
                                Text(stringResource(source.hint), color = Am.Caption, fontSize = 12.sp, lineHeight = 16.sp)
                            }
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton({ tools.apply(AiAction.Noise, confirmed = true) }) { Text(stringResource(R.string.start), color = Am.Accent) } },
        dismissButton = { TextButton({ tools.noiseSetup = null }) { Text(stringResource(R.string.cancel), color = Am.Accent) } },
        containerColor = Am.Field)
}

@Composable
internal fun AiCutoutDialog(tools: AiTools, scene: Scene) {
    val layer = tools.cutoutSetup ?: return
    val context = LocalContext.current
    val size = formatBytes(com.effects.motion.ai.AiModel.Cutout.bytes)
    val mark = layer.backgroundMark
    val source = mark?.original ?: layer.node["fillImage"]
    val turn = (source?.let(scene::media) ?: mark?.media)?.orientation ?: 0
    val picture by produceState<ImageBitmap?>(null, source, turn) { value = source?.let { pickPicture(context, it, turn) } }
    val asks = remember(layer.id) { CutoutChoice.of(context).asks(BestCutout.offered) }
    AlertDialog(onDismissRequest = { tools.cutoutSetup = null },
        title = { Text(stringResource(R.string.ai_remove_background), color = Am.OnDark) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                SubjectPicker(picture, turn, tools.subject, stringResource(R.string.subject_hint_photo)) { tools.subject = it }
                EdgeSlider(stringResource(R.string.cutout_softness), tools.edge.softness, 0..MatteEdge.MAX_SOFTNESS) { tools.edge = tools.edge.copy(softness = it) }
                EdgeSlider(stringResource(R.string.cutout_grow_shrink), tools.edge.grow, -MatteEdge.MAX_GROW..MatteEdge.MAX_GROW) { tools.edge = tools.edge.copy(grow = it) }
                Text(stringResource(R.string.cutout_edge_photo), Modifier.padding(top = 4.dp), color = Am.Caption, fontSize = 12.sp, lineHeight = 16.sp)
                if (tools.subject.isNotEmpty() && !com.effects.motion.platform.PlatformFeatures.desktop) PrecisePickChoice(tools, formatBytes(com.effects.motion.ai.AiModel.EdgeTam.bytes), com.effects.motion.ai.AiModel.EdgeTam.installed(context))
                if (asks) CutoutQualityChoice(tools, size)
            }
        },
        confirmButton = { TextButton({ tools.apply(AiAction.Background, confirmed = true) }) { Text(stringResource(R.string.start), color = Am.Accent) } },
        dismissButton = { TextButton({ tools.cutoutSetup = null }) { Text(stringResource(R.string.cancel), color = Am.Accent) } },
        containerColor = Am.Field)
}

@Composable
private fun PrecisePickChoice(tools: AiTools, size: String, installed: Boolean) {
    val on = tools.precisePick
    Row(Modifier.padding(top = 14.dp).fillMaxWidth().clip(RoundedCornerShape(6.dp)).background(if (on) Am.FieldHi else Am.PanelInset)
        .selectable(on, role = Role.Checkbox) { tools.precisePick = !on }.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
        Checkbox(on, null, colors = CheckboxDefaults.colors(checkedColor = Am.Accent, uncheckedColor = Am.OnDark))
        Column(Modifier.padding(start = 10.dp)) {
            Text(stringResource(R.string.cutout_precise), color = if (on) Am.Accent else Am.OnDark, fontSize = 14.sp)
            Text(if (installed) stringResource(R.string.cutout_precise_hint) else stringResource(R.string.cutout_precise_hint_download, size),
                color = Am.Caption, fontSize = 12.sp, lineHeight = 16.sp)
        }
    }
}

@Composable
private fun CutoutQualityChoice(tools: AiTools, size: String) {
    Text(stringResource(R.string.settings_cutout_quality), Modifier.padding(top = 14.dp), color = Am.OnDark, fontSize = 14.sp)
    Text(stringResource(R.string.cutout_question), Modifier.padding(top = 4.dp), color = Am.Caption, fontSize = 12.sp, lineHeight = 16.sp)
    Column(Modifier.padding(top = 8.dp).selectableGroup(), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        for (quality in CutoutQuality.entries) {
            val on = quality == tools.cutoutQuality
            Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(6.dp)).background(if (on) Am.FieldHi else Am.PanelInset)
                .selectable(on, role = Role.RadioButton) { tools.cutoutQuality = quality }.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                RadioButton(on, null, colors = RadioButtonDefaults.colors(selectedColor = Am.Accent, unselectedColor = Am.OnDark))
                Column(Modifier.padding(start = 10.dp)) {
                    Text(stringResource(quality.title), color = if (on) Am.Accent else Am.OnDark, fontSize = 14.sp)
                    Text(stringResource(quality.hint, size), color = Am.Caption, fontSize = 12.sp, lineHeight = 16.sp)
                }
            }
        }
    }
}

@Composable
internal fun AiEnhanceDialog(tools: AiTools, scene: Scene, onQuickSharpen: () -> Unit) {
    val layer = tools.enhanceSetup ?: return
    val context = LocalContext.current
    val media = layer.mediaFill?.uri?.let(scene::media)
    val options = tools.enhance
    val fits = media != null && options.mode.fits(media.width, media.height)
    val seconds = media?.let(layer::matteSeconds) ?: 0.0
    val tooLong = seconds > MAX_MATTE_SECONDS
    var help by remember { mutableStateOf<EnhanceMode?>(null) }
    var estimate by remember { mutableStateOf<String?>(null) }
    var cannot by remember { mutableStateOf(false) }
    val missing = options.models.filterNot { it.installed(context) }.sumOf { it.bytes }
    LaunchedEffect(options, layer, media) {
        estimate = null
        cannot = false
        if (media == null || !options.usesAi || !fits) return@LaunchedEffect
        val phone = AiDevice.phone(context)
        val gmac = seconds * (media.fps ?: 30f) * options.gmacPerFrame(media.width, media.height)
        aiEstimate(phone, gmac, AiDevice.measured(options.model, phone.usesGpu)).let { estimate = it.text; cannot = it.verdict == AiVerdict.Cannot }
        AiDevice.benchmark(context, options.model)?.let { rate -> aiEstimate(phone, gmac, rate).let { estimate = it.text; cannot = it.verdict == AiVerdict.Cannot } }
    }
    AlertDialog(onDismissRequest = { tools.enhanceSetup = null },
        title = { Text(stringResource(R.string.ai_enhance), color = Am.OnDark) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                Column(Modifier.selectableGroup(), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    for (mode in EnhanceMode.entries.filter { it != EnhanceMode.Faces || com.effects.motion.platform.PlatformFeatures.aiFaces }) {
                        val on = mode == options.mode
                        Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(6.dp)).background(if (on) Am.FieldHi else Am.PanelInset)
                            .selectable(on, role = Role.RadioButton) { tools.enhance = options.copy(mode = mode) }.padding(10.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                RadioButton(on, null, colors = RadioButtonDefaults.colors(selectedColor = Am.Accent, unselectedColor = Am.OnDark))
                                Column(Modifier.weight(1f).padding(start = 10.dp)) {
                                    Text(stringResource(mode.title), color = if (on) Am.Accent else Am.OnDark, fontSize = 14.sp)
                                    Text(stringResource(mode.hint), color = Am.Caption, fontSize = 12.sp, lineHeight = 16.sp)
                                }
                                Box(Modifier.size(32.dp).clip(CircleShape).clickable { help = if (help == mode) null else mode }, Alignment.Center) {
                                    Box(Modifier.size(20.dp).border(1.5.dp, Am.OnDark, CircleShape), Alignment.Center) {
                                        Text("?", color = Am.OnDark, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                            if (help == mode) Text(stringResource(mode.help), Modifier.padding(top = 6.dp), color = Am.OnDark, fontSize = 12.sp, lineHeight = 17.sp)
                        }
                    }
                }
                if (options.mode == EnhanceMode.Sharpen) EnhanceSwitch(stringResource(R.string.ai_enhance_quick), options.quick) { tools.enhance = options.copy(quick = it) }
                if (options.usesAi) {
                    EnhanceSwitch(stringResource(R.string.ai_enhance_cartoon), options.cartoon) { tools.enhance = options.copy(cartoon = it) }
                    if (!options.cartoon) EnhanceSwitch(stringResource(R.string.ai_enhance_grain), options.grain) { tools.enhance = options.copy(grain = it) }
                }
                val note = when {
                    !options.usesAi -> stringResource(R.string.ai_enhance_quick_note)
                    media == null -> stringResource(R.string.aibrowser_no_size)
                    tooLong -> pluralStringResource(R.plurals.aibrowser_too_long, MAX_MATTE_SECONDS / 60, (MAX_MATTE_SECONDS / 60).toString())
                    !fits -> AiEnhance.capText(options.mode)
                    else -> listOfNotNull(estimate ?: stringResource(R.string.ai_checking_phone),
                        if (missing > 0) stringResource(R.string.ai_download_once, formatBytes(missing)) else null).joinToString("\n")
                }
                Text(note, Modifier.padding(top = 12.dp).heightIn(min = 40.dp), color = if (!fits || tooLong || cannot) Am.Warning else Am.Caption, fontSize = 12.sp, lineHeight = 17.sp)
            }
        },
        confirmButton = {
            TextButton({
                if (options.usesAi) tools.apply(AiAction.Enhance, confirmed = true) else { tools.enhanceSetup = null; onQuickSharpen() }
            }, enabled = !options.usesAi || (fits && !tooLong && !cannot)) {
                Text(stringResource(if (options.usesAi && missing > 0) R.string.ai_download_and_start else R.string.start), color = Am.Accent)
            }
        },
        dismissButton = { TextButton({ tools.enhanceSetup = null }) { Text(stringResource(R.string.cancel), color = Am.Accent) } },
        containerColor = Am.Field)
}

@Composable
private fun EnhanceSwitch(label: String, on: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.padding(top = 8.dp).fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.weight(1f), color = Am.OnDark, fontSize = 14.sp)
        com.effects.motion.ui.editor.panels.ThinSwitch(on, onChange = onChange)
    }
}

@Composable
internal fun AiProgressDialog(tools: AiTools) {
    if (tools.message.isEmpty()) return
    val action = tools.running
    var reporting by remember { mutableStateOf(false) }
    if (reporting) com.effects.motion.ui.home.ReportDialog(tools.message) { reporting = false }
    AlertDialog(onDismissRequest = { if (action == null) tools.dismiss() },
        properties = androidx.compose.ui.window.DialogProperties(dismissOnClickOutside = action == null),
        title = { Text((action ?: tools.last)?.let { stringResource(it.title) } ?: stringResource(R.string.ai), color = Am.OnDark) },
        text = {
            Column(if (action != null) Modifier.keepScreenOn() else Modifier) {
                Text(tools.message, color = Am.OnDark, fontSize = 14.sp)
                if (action == null && tools.retry != null) TextButton({ reporting = true }) { Text(stringResource(R.string.report_button), color = Am.Accent) }
                if (action != null) {
                    Spacer(Modifier.height(16.dp))
                    LinearProgressIndicator(progress = { tools.progress }, Modifier.fillMaxWidth(), color = Am.Accent)
                }
            }
        },
        confirmButton = {
            TextButton({ if (action != null) tools.cancel() else tools.retry?.let(tools::apply) ?: tools.dismiss() }) {
                Text(stringResource(if (action != null) R.string.cancel else if (tools.retry != null) R.string.aibrowser_retry else R.string.ok), color = Am.Accent)
            }
        },
        dismissButton = { if (action == null && tools.retry != null) TextButton(tools::dismiss) { Text(stringResource(R.string.cancel), color = Am.Accent) } },
        containerColor = Am.Field)
}

@Composable
internal fun AiSmoothDialog(tools: AiTools, scene: Scene) {
    val layer = tools.smoothSetup ?: return
    var help by remember { mutableStateOf(false) }
    val previous = layer.aiMarks.firstOrNull { it.kind == AiKind.Smooth }
    val media = previous?.media ?: layer.mediaFill?.uri?.let(scene::media)
    val source = layer.smoothSource(previous)
    val s = tools.smoothing
    val plan = media?.let { smoothPlan(source, it, scene.fps, s) }
    val tooLong = plan != null && (plan.seconds > MAX_MATTE_SECONDS || plan.frames > MAX_SMOOTH_FRAMES)
    val ai = s.method == FrameInterpolation.Ai
    val estimate = if (ai && plan != null) com.effects.motion.ui.export.aiSmoothEstimate(
        AiSmooth.gmac(s.level, plan.frames.toDouble(), media.width, media.height), s.level) else null
    val cannot = estimate?.verdict == AiVerdict.Cannot
    val download = ai && !AiSmooth.installed(LocalContext.current, s.level)
    AlertDialog(onDismissRequest = { tools.smoothSetup = null },
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(stringResource(AiAction.Smooth.title), color = Am.OnDark)
                Box(Modifier.size(36.dp).clickable { help = true }, Alignment.Center) {
                    Icon(com.effects.motion.ui.export.ExportIcons.Help, stringResource(R.string.export_what_is, stringResource(AiAction.Smooth.title)), Modifier.size(20.dp), tint = Am.Caption)
                }
            }
        },
        text = {
            Column {
                Text(stringResource(R.string.smooth_intro), color = Am.OnDark, fontSize = 14.sp)
                Text(stringResource(R.string.smooth_method), Modifier.padding(top = 12.dp), color = Am.Caption, fontSize = 12.sp)
                Pills(FrameInterpolation.entries, s.method, true, { stringResource(it.label) },
                    locked = { it == FrameInterpolation.Ai && !com.effects.motion.Tier.has(com.effects.motion.Feature.AiSmooth) }) { tools.smoothing = s.copy(method = it) }
                Pills(SmoothLevel.entries, s.level, s.method != FrameInterpolation.Off, { stringResource(it.label) },
                    locked = { s.method == FrameInterpolation.Flow && it == SmoothLevel.High && !com.effects.motion.Tier.has(com.effects.motion.Feature.FlowHigh) }) { tools.smoothing = s.copy(level = it) }
                Text(stringResource(R.string.export_motion_blur), Modifier.padding(top = 12.dp), color = Am.Caption, fontSize = 12.sp)
                Pills(MotionBlur.entries, s.blur, true, { stringResource(it.label) }) { tools.smoothing = s.copy(blur = it) }
                Text(
                    when {
                        media == null -> stringResource(R.string.ai_video_missing)
                        tooLong -> stringResource(R.string.ai_clip_too_long, (MAX_MATTE_SECONDS / 60).toString())
                        plan == null -> stringResource(R.string.smooth_nothing)
                        else -> pluralStringResource(R.plurals.smooth_estimate, plan.frames, plan.frames.toString(), plan.fps.toString(),
                            plan.width.toString(), plan.height.toString(), (plan.bytes / 1_000_000 + 1).toString())
                    },
                    Modifier.padding(top = 12.dp).height(54.dp), color = if (plan == null || tooLong) Am.Warning else Am.Caption, fontSize = 12.sp, lineHeight = 17.sp,
                )
                if (ai && plan != null && !tooLong) Text(com.effects.motion.ui.export.aiSmoothNote(estimate, s.level, clip = true), Modifier.padding(top = 4.dp),
                    color = if (cannot) Am.Warning else Am.Caption, fontSize = 12.sp, lineHeight = 17.sp)
            }
        },
        confirmButton = {
            TextButton({ tools.apply(AiAction.Smooth, confirmed = true) }, enabled = plan != null && !tooLong && !cannot) {
                Text(stringResource(if (download) R.string.ai_download_and_start else R.string.start), color = Am.Accent)
            }
        },
        dismissButton = { TextButton({ tools.smoothSetup = null }) { Text(stringResource(R.string.cancel), color = Am.Accent) } },
        containerColor = Am.Field)
    if (help) AlertDialog(onDismissRequest = { help = false },
        title = { Text(stringResource(R.string.export_interpolation), color = Am.OnDark) },
        text = { SmoothingHelp(Am.OnDark, Modifier.heightIn(max = 420.dp)) },
        confirmButton = { TextButton({ help = false }) { Text(stringResource(R.string.ok), color = Am.Accent) } },
        containerColor = Am.Field)
}

@Composable
private fun <T> Pills(options: List<T>, selected: T, enabled: Boolean, label: @Composable (T) -> String, locked: (T) -> Boolean = { false }, onPick: (T) -> Unit) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val needs = stringResource(R.string.tier_needs_latest)
    Row(Modifier.padding(top = 6.dp).fillMaxWidth().height(36.dp).alpha(if (enabled) 1f else 0.4f).clip(RoundedCornerShape(6.dp)).background(Am.PanelInset)) {
        for (option in options) {
            val on = option == selected
            Box(Modifier.weight(1f).fillMaxHeight().padding(2.dp).clip(RoundedCornerShape(5.dp)).background(if (on) Am.FieldHi else Color.Transparent)
                .clickable(enabled = enabled) { if (locked(option)) android.widget.Toast.makeText(context, needs, android.widget.Toast.LENGTH_SHORT).show() else onPick(option) }, Alignment.Center) {
                Row(Modifier.alpha(if (locked(option)) 0.45f else 1f), verticalAlignment = Alignment.CenterVertically) {
                    if (locked(option)) Icon(com.effects.motion.ui.export.ExportIcons.Lock, null, Modifier.size(12.dp), tint = Am.OnDark)
                    Text(label(option), color = if (on) Am.Accent else Am.OnDark, fontSize = 12.sp, lineHeight = 13.sp, maxLines = 2, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                }
            }
        }
    }
}

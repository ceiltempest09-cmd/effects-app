package com.effects.motion.effects.engine

import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.ceil
import kotlin.math.pow
import kotlin.math.sqrt

/**
 * Turns a parsed 3D .cube LUT into the file the renderer loads as a float16 texture ("lutf16:<path>").
 *
 * File: little endian. int32 magic "LF16", int32 width, int32 height, then width*height RGBA half floats (alpha 1).
 * The N blue slices are tiled in a grid of `cols` slices per row; inside a slice x is red, y is green. Slice k (blue index)
 * sits at column k % cols, row k / cols. Unused tiles are zero. Nothing is resampled: every table entry is stored.
 */
object LutBake {
    const val Magic = 0x3631464C            // bytes 'L' 'F' '1' '6'
    const val MaxSide = 2048                // the effect validator's texture limit

    class Layout(val size: Int, val cols: Int, val rows: Int) {
        val width: Int get() = cols * size
        val height: Int get() = rows * size
    }

    fun layout(size: Int): Layout {
        val cols = ceil(sqrt(size.toDouble())).toInt()
        return Layout(size, cols, (size + cols - 1) / cols)
    }

    /** Null when the table fits the texture limits, otherwise the reason. */
    fun problem(lut: CubeLut): String? {
        if (!lut.is3d) return "Only 3D LUTs (LUT_3D_SIZE) are supported; this file is a 1D LUT."
        val l = layout(lut.size)
        if (l.width > MaxSide || l.height > MaxSide) return "A ${lut.size}-point LUT does not fit a ${MaxSide}-pixel texture."
        return null
    }

    fun bake(lut: CubeLut): ByteArray {
        problem(lut)?.let { throw IllegalArgumentException(it) }
        val l = layout(lut.size)
        val n = lut.size
        val out = ByteBuffer.allocate(12 + l.width * l.height * 8).order(ByteOrder.LITTLE_ENDIAN)
        out.putInt(Magic).putInt(l.width).putInt(l.height)
        val one = halfBits(1f).toShort()
        for (y in 0 until l.height) for (x in 0 until l.width) {
            val k = (y / n) * l.cols + (x / n)
            if (k < n) {
                val at = ((k * n + (y % n)) * n + (x % n)) * 3
                out.putShort(halfBits(lut.table[at]).toShort()).putShort(halfBits(lut.table[at + 1]).toShort()).putShort(halfBits(lut.table[at + 2]).toShort())
            } else {
                out.putShort(0).putShort(0).putShort(0)
            }
            out.putShort(one)
        }
        return out.array()
    }

    /** IEEE half bits, round to nearest even. NaN becomes 0; values beyond the half range clamp to +-65504. */
    fun halfBits(v: Float): Int {
        val bits = java.lang.Float.floatToRawIntBits(if (v.isNaN()) 0f else v)
        val sign = (bits ushr 16) and 0x8000
        val rawExp = (bits ushr 23) and 0xFF
        if (rawExp == 0xFF) return sign or 0x7BFF
        val exp = rawExp - 127 + 15
        val man = bits and 0x7FFFFF
        if (exp >= 31) return sign or 0x7BFF
        if (exp <= 0) {
            if (exp < -10) return sign
            val m = man or 0x800000
            val shift = 14 - exp
            var h = m ushr shift
            val rem = m and ((1 shl shift) - 1)
            val mid = 1 shl (shift - 1)
            if (rem > mid || (rem == mid && (h and 1) == 1)) h++
            return sign or h
        }
        var h = (exp shl 10) or (man ushr 13)
        val rem = man and 0x1FFF
        if (rem > 0x1000 || (rem == 0x1000 && (h and 1) == 1)) h++
        if ((h and 0x7C00) == 0x7C00) return sign or 0x7BFF
        return sign or h
    }

    fun halfToFloat(h: Int): Float {
        val s = if (h and 0x8000 != 0) -1.0 else 1.0
        val e = (h shr 10) and 0x1F
        val m = h and 0x3FF
        return when (e) {
            0 -> (s * m * 2.0.pow(-24)).toFloat()
            31 -> if (m == 0) (s * Double.POSITIVE_INFINITY).toFloat() else Float.NaN
            else -> (s * (1.0 + m / 1024.0) * 2.0.pow(e - 15)).toFloat()
        }
    }
}

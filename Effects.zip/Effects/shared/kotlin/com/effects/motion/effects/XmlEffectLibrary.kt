package com.effects.motion.effects

import com.effects.motion.effects.graph.EffectGraph
import com.effects.motion.effects.graph.GraphBuffer
import com.effects.motion.effects.graph.GraphConvert
import com.effects.motion.effects.graph.GraphPass
import com.effects.motion.effects.graph.GraphValidator
import com.effects.motion.effects.graph.PassInput
import com.effects.motion.effects.graph.hasError
import com.effects.motion.model.Keyframe
import com.effects.motion.platform.Context
import org.w3c.dom.Element
import java.io.InputStream
import java.util.Locale
import javax.xml.parsers.DocumentBuilderFactory

/**
 * The bundled XML effect library (assets/alightmotion/): index.xml lists one entry per effect (numbered revisions folded together, with its
 * presets); em/<file>.xml is the effect itself in the engine's graph format (native GLSL ES passes, 16-bit float buffers), written at build time
 * by tools/am_build.py + tools/am_to_em.py. Nothing here compiles or translates a shader: the text goes to the OpenGL ES backend as written.
 * Effects the converter could not express are not listed (see the build report), they are never shown broken.
 */
object XmlEffectLibrary {
    private const val Folder = "alightmotion"
    private const val MaxXml = 4_000_000

    @Volatile private var cached: List<EffectDefinition>? = null

    fun load(context: Context): List<EffectDefinition> = cached ?: synchronized(this) {
        cached ?: read { path -> context.assets.open("$Folder/$path") }.also { cached = it }
    }

    /** Pure function of the file opener, so it can run in host tests. */
    fun read(open: (String) -> InputStream): List<EffectDefinition> {
        val index = runCatching { parse(open("index.xml")) }.getOrNull() ?: return emptyList()
        val out = ArrayList<EffectDefinition>()
        for (e in index.children("effect")) {
            runCatching { build(e, open) }.getOrNull()?.let(out::add)
        }
        return out
    }

    private fun build(e: Element, open: (String) -> InputStream): EffectDefinition? {
        val live = e.children("revision").firstOrNull { it.getAttribute("live") == "true" } ?: return null
        val file = parse(open("em/" + live.getAttribute("file").substringAfterLast('/')))
        if (file.getAttribute("status") != "ok") return null
        val family = e.getAttribute("family").substringAfterLast('.').ifBlank { e.getAttribute("id").substringAfterLast('.') }
        val key = "am_" + family.lowercase(Locale.ROOT).replace(Regex("[^a-z0-9]+"), "_").trim('_')
        val params = file.children("param").map(::param)
        if (params.any { it == null }) return null
        val ps = params.filterNotNull()
        val buffers = file.children("buffer").map {
            GraphBuffer(it.getAttribute("id"), it.getAttribute("scale").toFloatOrNull() ?: 1f, 0, 0, "rgba16f", "required",
                it.getAttribute("filter").ifBlank { "linear" }, it.getAttribute("wrap").ifBlank { "clamp" }, it.getAttribute("history").toIntOrNull() ?: 0)
        }
        val passes = file.children("pass").mapIndexed { i, p ->
            GraphPass(
                id = p.getAttribute("id"), source = p.children("source").firstOrNull()?.textContent.orEmpty(), name = p.getAttribute("name").ifBlank { p.getAttribute("id") },
                lang = "glsl-es", inputs = p.children("input").map { PassInput(it.getAttribute("name"), it.getAttribute("ref")) },
                output = p.getAttribute("output"), blend = p.getAttribute("blend").ifBlank { "replace" }, clear = p.getAttribute("clear") != "false",
                constants = p.children("const").associate { c -> c.getAttribute("name") to c.getAttribute("value").split(',').map { it.trim().toFloatOrNull() ?: 0f } },
                file = live.getAttribute("file"), line = 1,
            )
        }
        if (passes.isEmpty()) return null
        val graph = EffectGraph(passes = passes, buffers = buffers)
        if (GraphValidator.validate("fx.$key", graph, GraphConvert.NativeLanguages, "OpenGL ES").hasError) return null
        val presets = e.children("preset").filter { it.getAttribute("id") != "standard" }.mapNotNull { preset(it, ps) }
        return EffectDefinition(
            id = "fx.$key", key = key, name = e.getAttribute("name").ifBlank { family }, category = categoryOf(e.getAttribute("category")),
            description = e.getAttribute("desc"), params = ps, presets = presets,
            thumbnailPath = e.getAttribute("thumb").takeIf { it.isNotBlank() },
            pack = EffectPacks.Vibrant, source = EffectSources.AlightMotion, graph = graph, lang = "GLSL_ES",
        )
    }

    private fun categoryOf(id: String): String = when (id) {
        "color" -> "colorlight"; "drawing" -> "drawedge"; "distort" -> "warp"
        "blur", "procedural", "3d", "transform", "repeat", "matte", "opacity", "text" -> id
        else -> "other"
    }

    private fun param(p: Element): EffectParam? {
        val id = p.getAttribute("name")
        val label = p.getAttribute("label").ifBlank { id }
        val value = p.getAttribute("value")
        val min = p.getAttribute("min").toFloatOrNull() ?: 0f
        val max = p.getAttribute("max").toFloatOrNull() ?: 1f
        val step = p.getAttribute("step").toFloatOrNull() ?: 0.01f
        return when (p.getAttribute("kind")) {
            "float" -> EffectParam(id, label, "float", (value.toFloatOrNull() ?: 0f).toString(), min, max, step, percent = p.getAttribute("percent") == "true")
            "angle" -> EffectParam(id, label, "angle", (value.toFloatOrNull() ?: 0f).toString(), min, max, step)
            "switch" -> EffectParam(id, label, "switch", (value.equals("true", true) || value == "1").toString())
            "point" -> EffectParam(id, label, "point", value.ifBlank { "0.5,0.5" })
            "color" -> {
                val c = value.lowercase(Locale.ROOT).let { if (it.length == 7) "#ff" + it.drop(1) else it }
                if (!Regex("#[0-9a-f]{8}").matches(c)) null else EffectParam(id, label, "color", c)
            }
            "choice" -> {
                val choices = p.children("choice")
                val values = choices.map { it.getAttribute("value").toIntOrNull() ?: return null }
                if (choices.isEmpty() || values != values.indices.toList()) return null        // controls are stored by index; odd value tables are not listed
                val default = value.toIntOrNull()?.takeIf { it in values.indices } ?: return null
                EffectParam(id, label, "choice", default.toFloat().toString().removeSuffix(".0"), 0f, values.size - 1f, 1f, options = choices.map { it.getAttribute("label") })
            }
            else -> null
        }
    }

    private fun preset(p: Element, params: List<EffectParam>): EffectPreset? {
        val values = linkedMapOf<String, String>()
        val keys = linkedMapOf<String, List<Keyframe>>()
        for (prop in p.children("property")) {
            val name = prop.getAttribute("name")
            if (params.none { it.id == name }) continue
            val kfs = prop.children("kf")
            if (kfs.isEmpty()) prop.getAttribute("value").takeIf { it.isNotEmpty() }?.let { values[name] = it }
            else keys[name] = kfs.map { Keyframe(it.getAttribute("t").toFloatOrNull() ?: 0f, it.getAttribute("v"), it.getAttribute("e").takeIf { e -> e.isNotEmpty() }) }
        }
        if (values.isEmpty() && keys.isEmpty()) return null
        return EffectPreset(p.getAttribute("name").ifBlank { "Preset" }, values, keys)
    }

    private fun parse(input: InputStream): Element {
        val bytes = input.use { it.readBytes() }
        require(bytes.size <= MaxXml) { "effect file too large" }
        val text = bytes.toString(Charsets.UTF_8)
        require(!text.contains("<!DOCTYPE", true) && !text.contains("<!ENTITY", true)) { "DOCTYPE and ENTITY are not allowed" }
        return DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(bytes.inputStream()).documentElement
    }

    private fun Element.children(tag: String): List<Element> = buildList {
        val n = childNodes
        for (i in 0 until n.length) (n.item(i) as? Element)?.takeIf { it.tagName == tag }?.let(::add)
    }
}

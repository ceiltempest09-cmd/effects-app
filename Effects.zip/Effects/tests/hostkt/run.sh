#!/bin/bash
# Compiles the Android-free Kotlin sources + tests with the Kotlin compiler bundled in Gradle's lib dir and runs them.
set -e
ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
L=${GRADLE_LIB:-/opt/gradle-8.14.3/lib}
OUT=${OUT:-/tmp/hostkt-out}
CP=$(ls $L/kotlin-compiler-embeddable-*.jar $L/kotlin-stdlib-2*.jar $L/kotlin-script-runtime-*.jar $L/kotlin-reflect-*.jar $L/kotlin-daemon-embeddable-*.jar $L/trove4j*.jar $L/annotations-*.jar $L/kotlinx-coroutines-core-jvm-*.jar | tr '\n' ':')
rm -rf "$OUT"; mkdir -p "$OUT"
SRC="$ROOT/shared/kotlin/com/effects/motion/effects/graph $ROOT/tests/hostkt/org $ROOT/tests/hostkt/GraphTests.kt $ROOT/tests/hostkt/ImportTests.kt $ROOT/shared/kotlin/com/effects/motion/effects/AmXml.kt $ROOT/shared/kotlin/com/effects/motion/effects/SkslConvert.kt"
java -cp "$CP" org.jetbrains.kotlin.cli.jvm.K2JVMCompiler -no-stdlib -no-reflect -cp $L/kotlin-stdlib-2.0.21.jar $SRC "$@" -d "$OUT" 2>&1 | { grep -v "^Picked up" || true; }
java -cp "$OUT:$L/kotlin-stdlib-2.0.21.jar" GraphTestsKt

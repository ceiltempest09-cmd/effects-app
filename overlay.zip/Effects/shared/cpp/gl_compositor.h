// gl_compositor.h - layer compositing on the native GL backend (replaces SkCanvas layer drawing: transform, opacity, mask,
// 24 blend modes + normal, gradient fills, HDR display tone map). Pure GLSL ES from glsl_library.h / gl_compositor.cpp.
// No Skia types. Host-tested on Mesa in tests/native/gl_compositor_test.cpp. Not yet called by engine.cpp (that is the
// engine hookup step). All calls on the thread the GlBackend's context is current on. Results belong to the caller (release()).
#pragma once

#include "gl_backend.h"

#include <string>
#include <vector>

namespace am::comp {

struct Affine {            // maps layer pixels -> canvas pixels:  x' = a*x + c*y + e,  y' = b*x + d*y + f
    float a = 1, b = 0, c = 0, d = 1, e = 0, f = 0;
    static Affine Translate(float x, float y) { Affine m; m.e = x; m.f = y; return m; }
    static Affine Scale(float sx, float sy) { Affine m; m.a = sx; m.d = sy; return m; }
    static Affine Rotate(float radians);                      // about the origin
    Affine then(const Affine& o) const;                       // apply *this first, then o
    bool invert(Affine* out) const;                           // false when singular
};

enum class MaskMode : int { None = 0, Alpha = 1, InvertedAlpha = 2, Luma = 3 };

struct Layer {
    rg::Target* image = nullptr;     // premultiplied RGBA, any size (the layer's own pixels)
    Affine transform;                // layer pixels -> canvas pixels
    float opacity = 1;
    std::string blend = "normal";    // "normal" or any id of glsl::BlendModes(); unknown ids fall back to normal and set warning()
    rg::Target* mask = nullptr;      // canvas-sized (canvas pixels); used when maskMode != None
    MaskMode maskMode = MaskMode::None;
    bool smooth = true;              // bilinear sampling (false = nearest)
};

struct Gradient {
    enum Kind { Linear = 0, Radial = 1, Sweep = 2 } kind = Linear;
    float c0[4] = {0, 0, 0, 1}, c1[4] = {1, 1, 1, 1};        // premultiplied end colours
    float p0[2] = {0, 0}, p1[2] = {1, 0};                    // in box-relative 0..1 coordinates
    float box[4] = {0, 0, 0, 0};                             // x, y, w, h in pixels; w/h 0 = whole target
};

struct ToneMap {
    float toSrgb[9] = {1, 0, 0, 0, 1, 0, 0, 0, 1};           // column-major 3x3 to linear sRGB primaries
    bool linearIn = false;                                   // input already linear (else sRGB-encoded)
    float knee = 0.8f, peak = 1.0f;
};

class Compositor {
public:
    explicit Compositor(rg::GlBackend& gl) : fGl(gl) {}
    ~Compositor();
    Compositor(const Compositor&) = delete;
    Compositor& operator=(const Compositor&) = delete;

    // Draws the layers bottom to top onto a transparent (or `background`) canvas of w x h pixels. nullptr + error() on failure.
    rg::Target* render(int w, int h, const std::vector<Layer>& layers, const float* background = nullptr);
    // A canvas-sized gradient image (use it as a Layer::image with an identity transform).
    rg::Target* gradient(int w, int h, const Gradient& g);
    rg::Target* toneMap(rg::Target* src, const ToneMap& t);

    void release(rg::Target* t);
    rg::Target* picture(int w, int h) { return make(w, h); }
    const std::string& error() const { return fError; }
    const std::string& warning() const { return fWarning; }
    int passes() const { return fPasses; }

private:
    struct In { const char* name; rg::Target* target; rg::Filter filter; };
    rg::Target* make(int w, int h);
    bool draw(const std::string& id, const std::string& source, rg::Target* out, const std::vector<In>& inputs,
              const std::vector<rg::Constant>& constants);

    rg::GlBackend& fGl;
    std::string fError, fWarning;
    int fPasses = 0;
    std::vector<rg::Target*> fLive;
};

}  // namespace am::comp

# Alight Motion thumbnail path correction

The bundled ZIP stores thumbnails as `thumb/am_<original-json-stem>.webp`.
The importer namespaces runtime effect IDs with `alightmotion_`; deriving a
thumbnail filename from that namespaced ID points at a file that does not
exist. This patch saves the path from the original bundled JSON filename
before namespacing the ID, then restores that path when loading the effect.

The stored path is `thumb/am_<stem>.webp`. The catalog asset resolver checks
`assets/effects/thumb/` first, matching the existing build workflow that copies
Alight Motion pictures into `assets/effects/thumb`.

No effect definitions, categories, shader code, or parameter values change.

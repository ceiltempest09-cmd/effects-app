package com.effects.motion.editor

import android.app.ActivityManager
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Handler
import android.os.HandlerThread
import android.util.Log
import android.widget.Toast
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import com.effects.motion.platform.PlatformFeatures
import com.effects.motion.platform.rawFrameImage
import com.effects.motion.platform.releaseFrameImage
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.effects.motion.R
import com.effects.motion.Tier
import com.effects.motion.engine.EngineThread
import com.effects.motion.export.Smoothing
import com.effects.motion.model.Scene
import java.io.ByteArrayOutputStream
import java.nio.ByteBuffer
import kotlin.math.abs
import kotlin.math.roundToInt
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Deferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.delay

private const val MIB = 1L shl 20
private const val MAX_BUDGET = 256 * MIB
private const val MAX_DISK_BUDGET = 1024 * MIB
private const val DISK_RESERVE = 1024 * MIB
private const val CACHE_PREFIX = "preview-cache-"
private const val MAX_SIDE = 1920
private const val ESTIMATE_PER_MILLE = 150L
private const val QUALITY = 85
private const val AHEAD = 8
private const val POOL = AHEAD + 3
private const val DECODERS = 3
private const val TAG = "AMCache"
private const val ENCODERS = 3
private const val CAPTURE_QUEUE = 3
private const val LOOKAHEAD_SECONDS = 8
private const val REUSE_GUARD_NS = 250_000_000L

/**
 * The render cache is always made at full preview size, whatever Preview Quality is chosen. Preview Quality only lowers the live draw; the cache key used to
 * include it, so switching to Half/Quarter threw away a finished pre-render (the player size changed, `ensure` cleared the store) and the preview fell back
 * to the live draw. Cached frames are drawn scaled down to the preview, so one cache serves every quality.
 */
const val CACHE_DIVISOR = 1

/** The two render modes of the settings: smart renders the whole timeline when idle, playhead only keeps the stretch ahead of the playhead ready. */
const val MODE_SMART = 0
const val MODE_PLAYHEAD = 1

fun previewCacheBudget(memoryClassMb: Int, lowRam: Boolean, compatible: Boolean): Long {
    val percent = when { lowRam -> 8; compatible -> 12; else -> 15 }
    return minOf(MAX_BUDGET, memoryClassMb.coerceAtLeast(16) * MIB * percent / 100)
}

fun rawStoreBudget(heapMax: Long): Long = minOf(4096 * MIB, heapMax * 2 / 5)

fun storeBudget(budget: Long, width: Int, height: Int): Long = maxOf(budget / 4, budget - POOL * 4L * width * height)

fun cacheFrameSize(sceneWidth: Int, sceneHeight: Int, fit: Float, divisor: Int): Pair<Int, Int> {
    val longest = maxOf(sceneWidth, sceneHeight, 1)
    val cap = minOf(1f, MAX_SIDE.toFloat() / longest)
    val scale = if (fit > 0f) minOf(fit / divisor.coerceAtLeast(1), cap) else cap / divisor.coerceAtLeast(1)
    return maxOf(1, (sceneWidth * scale).roundToInt()) to maxOf(1, (sceneHeight * scale).roundToInt())
}

fun framesThatFit(budget: Long, width: Int, height: Int): Int =
    (budget / maxOf(1L, width.toLong() * height * ESTIMATE_PER_MILLE / 1000)).coerceIn(1L, Int.MAX_VALUE.toLong()).toInt()

fun renderRange(lastFrame: Int, playhead: Int, maxFrames: Int): IntRange {
    val total = lastFrame.coerceAtLeast(0) + 1
    if (maxFrames >= total) return 0 until total
    val count = maxFrames.coerceAtLeast(1)
    val start = playhead.coerceIn(0, total - count)
    return start until start + count
}

fun previewRange(lastFrame: Int, playhead: Int, budget: Long, width: Int, height: Int): IntRange =
    renderRange(lastFrame, playhead, framesThatFit(budget, width, height))

fun flattenOnChecker(rgba: ByteArray, width: Int, height: Int, cell: Float): Boolean {
    val size = cell.coerceAtLeast(1f)
    var translucent = false
    var i = 3
    for (y in 0 until height) {
        val row = ((height - y - 0.5f) / size).toInt()
        for (x in 0 until width) {
            val a = rgba[i].toInt() and 0xff
            if (a != 0xff) {
                translucent = true
                val base = if ((((x + 0.5f) / size).toInt() + row) and 1 == 1) 0xcc else 0xe5
                for (c in 1..3) rgba[i - c] = (((rgba[i - c].toInt() and 0xff) * a + base * (255 - a) + 127) / 255).toByte()
                rgba[i] = -1
            }
            i += 4
        }
    }
    return translucent
}

/**
 * Rendered frames, in memory first and then in a file once the memory share is used up (a compositing app's RAM and disk cache).
 * Memory frames are drawn green on the timeline, frames in the file blue.
 */
class FrameStore(
    val first: Int, val budget: Long, private val file: java.io.File? = null, val raw: Boolean = false, private val keepFile: Boolean = false,
    /** With a file: how many bytes of frames stay in memory before the rest is written to the file. Zero keeps everything in the file. */
    private val ramBudget: Long = 0L,
) : java.io.Closeable {
    private data class Record(val data: ByteArray?, val offset: Long, val size: Int)
    private val records = java.util.TreeMap<Int, Record>()
    private val disk = file?.let { f -> if (keepFile) java.io.RandomAccessFile(f, "r") else java.io.RandomAccessFile(f, "rw").apply { setLength(0) } }
    private var end = 0L
    private var ramBytes = 0L
    private var closed = false
    /** Bumped whenever frames move inside the file or the store closes, so a read that ran without the lock can tell it may have seen moved data. */
    private var layout = 0L
    @Volatile var bytes = 0L
        private set
    @Volatile var count = 0
        private set
    val last: Int get() = synchronized(this) { records.lastKeyOrNull() ?: first - 1 }
    /** The first frame that is actually stored. */
    val lowest: Int get() = synchronized(this) { if (records.isEmpty()) first else records.firstKey() }
    val onDisk: Boolean get() = disk != null
    /** A store that was brought back from a saved file only reads; frames that are rendered later need a store that takes new ones. */
    val writable: Boolean get() = !keepFile

    @Synchronized fun add(frame: ByteArray): Boolean = put(first + count, frame)

    @Synchronized fun put(index: Int, frame: ByteArray): Boolean {
        val replaced = records[index]
        if (closed || index < first || bytes - (replaced?.size ?: 0) + frame.size > budget) return false
        val replacedRam = replaced?.let { if (it.data != null) it.size.toLong() else 0L } ?: 0L
        val inRam = disk == null || ramBytes - replacedRam + frame.size <= ramBudget
        var offset = 0L
        if (!inRam) {
            val target = disk
            // Frames that were removed leave holes in the file; closing them up gives the room back.
            if (end + frame.size > budget) compact()
            if (end + frame.size > budget) return false
            offset = end
            try { target.seek(offset); target.write(frame) }
            catch (_: java.io.IOException) { return false }
            end += frame.size
        }
        if (replaced != null) forget(replaced)
        records[index] = Record(if (inRam) frame else null, offset, frame.size)
        bytes += frame.size
        if (inRam) ramBytes += frame.size
        count = records.size
        return true
    }

    private fun forget(record: Record) {
        bytes -= record.size
        if (record.data != null) ramBytes -= record.size
    }

    private fun compact() {
        val target = disk ?: return
        var at = 0L
        try {
            for (entry in records.entries.filter { it.value.data == null }.sortedBy { it.value.offset }) {
                val record = entry.value
                if (record.offset != at) {
                    val moved = ByteArray(record.size)
                    target.seek(record.offset)
                    target.readFully(moved)
                    target.seek(at)
                    target.write(moved)
                    entry.setValue(Record(null, at, record.size))
                }
                at += record.size
            }
            end = at
            layout++
        } catch (_: java.io.IOException) {
            // The file stays as it was; the frame that needed the room is simply not stored.
        }
    }

    /** Registers a frame that is already stored in the file this store was opened on. */
    @Synchronized fun adopt(index: Int, offset: Long, size: Int) {
        if (closed || index < first) return
        records[index]?.let { forget(it) }
        records[index] = Record(null, offset, size)
        bytes += size
        count = records.size
    }

    @Synchronized fun removeWhere(remove: (Int) -> Boolean) {
        val iterator = records.entries.iterator()
        while (iterator.hasNext()) {
            val record = iterator.next()
            if (remove(record.key)) { forget(record.value); iterator.remove() }
        }
        count = records.size
    }

    @Synchronized fun evictFarther(at: Int, frame: Int): Boolean {
        if (records.isEmpty()) return false
        fun distance(f: Int) = if (f >= at) (f - at).toLong() else 2L * (at - f)
        val victim = if (distance(records.firstKey()) >= distance(records.lastKey())) records.firstKey() else records.lastKey()
        if (distance(victim) <= distance(frame)) return false
        forget(records.remove(victim)!!)
        count = records.size
        return true
    }

    /** Runs of consecutive frames. [disk] picks the ones kept in the file (true), in memory (false), or all of them (null). */
    @Synchronized fun runs(disk: Boolean? = null): List<IntRange> {
        val out = ArrayList<IntRange>()
        var start = -1
        var end = -2
        for ((k, record) in records) {
            if (disk != null && (record.data == null) != disk) continue
            if (k != end + 1) { if (start >= 0) out += start..end; start = k }
            end = k
        }
        if (start >= 0) out += start..end
        return out
    }

    @Synchronized operator fun contains(frame: Int): Boolean = !closed && records.containsKey(frame)

    /**
     * A frame in memory is returned at once. A frame in the file is read with a positional read outside the lock, so scrubbing through disk frames
     * does not wait for (or hold up) the render that is writing new ones; if the file was compacted or the record replaced meanwhile, the read is
     * repeated, and after three tries it is done under the lock.
     */
    operator fun get(frame: Int): ByteArray? {
        repeat(3) {
            val taken = synchronized(this) {
                if (closed) return null
                val found = records[frame] ?: return null
                found.data?.let { return it }
                found to layout
            }
            val record = taken.first
            val seen = taken.second
            val channel = disk?.channel ?: return null
            val out = ByteArray(record.size)
            val read = try { readAt(channel, out, record.offset) } catch (_: java.io.IOException) { false }
            synchronized(this) {
                if (!closed && layout == seen && records[frame] === record) return if (read) out else null
            }
        }
        return synchronized(this) {
            val record = if (closed) null else records[frame]
            when {
                record == null -> null
                record.data != null -> record.data
                else -> try { ByteArray(record.size).also { disk!!.seek(record.offset); disk.readFully(it) } } catch (_: java.io.IOException) { null }
            }
        }
    }

    private fun readAt(channel: java.nio.channels.FileChannel, out: ByteArray, position: Long): Boolean {
        val buffer = ByteBuffer.wrap(out)
        var at = position
        while (buffer.hasRemaining()) {
            val n = channel.read(buffer, at)
            if (n < 0) return false
            at += n
        }
        return true
    }

    @Synchronized override fun close() {
        if (closed) return
        closed = true
        layout++
        runCatching { disk?.close() }
        records.clear()
        bytes = 0L
        ramBytes = 0L
        count = 0
        if (!keepFile) file?.delete()
    }

    private fun <K, V> java.util.TreeMap<K, V>.lastKeyOrNull(): K? = if (isEmpty()) null else lastKey()
}

fun diskBudget(free: Long): Long = minOf(MAX_DISK_BUDGET, (free - DISK_RESERVE) / 4).coerceAtLeast(0L)

data class CacheKey(val projectId: String, val scene: Scene, val divisor: Int, val androidEmoji: Boolean, val resources: Long = 0, val accurateBlur: Boolean = true, val group: List<Long> = emptyList())

internal fun cacheBarShows(cached: CacheKey, now: CacheKey, catchingUp: Boolean): Boolean =
    cached.projectId == now.projectId && (cached.scene.node === now.scene.node || catchingUp && cached.copy(scene = now.scene) == now)

class FramePlayer internal constructor(private val store: FrameStore, val width: Int, val height: Int) {
    class Shown(val frame: Int, val image: ImageBitmap, val at: Long)
    private class Decoded(val bitmap: Bitmap?, val image: ImageBitmap)

    var shown by mutableStateOf<Shown?>(null)
        private set
    @Volatile var shows = 0L
        private set
    private val pool = java.util.concurrent.Executors.newFixedThreadPool(DECODERS) { r -> Thread(r, "am-cache-decode").apply { isDaemon = true } }
    private val decoded = HashMap<Int, Decoded>()
    private val inflight = HashSet<Int>()
    private val recent = ArrayDeque<Int>()
    /** When each frame was last put on screen. The compositor draws on its own thread, so a bitmap that was shown a moment ago may still be read. */
    private val shownAt = HashMap<Int, Long>()
    @Volatile private var wanted = -1
    @Volatile private var closed = false
    private val epoch = java.util.concurrent.atomic.AtomicLong()

    fun want(frame: Int, playing: Boolean) {
        if (closed) return
        val version = epoch.get()
        wanted = frame
        val ready = synchronized(this) { decoded[frame] }
        if (ready != null) show(frame, ready.image, version)
        else if (playing) holdLatest(frame, version)
        schedule(frame, if (playing) AHEAD else 0, version)
    }

    /**
     * While playing, a frame that is not decoded yet when the clock reaches it must not leave the preview empty (the live surface under it is
     * stale, which shows as flicker): the newest decoded frame before it, at most [AHEAD] frames back, stays on screen until the right one is ready.
     * It keeps its own frame number, so it is never taken for the current frame, and the shown frame never goes backwards.
     */
    private fun holdLatest(frame: Int, version: Long) {
        val held = synchronized(this) {
            val newest = decoded.keys.filter { it < frame && frame - it <= AHEAD }.maxOrNull() ?: return
            if (newest <= (shown?.frame ?: Int.MIN_VALUE) && (shown?.frame ?: 0) <= frame) return
            newest to decoded.getValue(newest).image
        }
        show(held.first, held.second, version)
    }

    /** True when [shown] may be drawn for [frame]: the exact frame, or while playing a decoded frame at most [AHEAD] frames behind it. */
    fun drawable(shown: Shown, frame: Int, playing: Boolean): Boolean =
        shown.frame == frame || (playing && frame - shown.frame in 1..AHEAD)

    private fun show(frame: Int, image: ImageBitmap, version: Long) {
        synchronized(this) {
            if (closed || epoch.get() != version) return
            val now = System.nanoTime()
            if (recent.lastOrNull() != frame) { recent.addLast(frame); shows++ }
            while (recent.size > 2) recent.removeFirst()
            shownAt[frame] = now
            shown = Shown(frame, image, now)
        }
    }

    /** Frames are decoded on several threads, the wanted one first, so decoding keeps up with playback. */
    private fun schedule(target: Int, count: Int, version: Long) {
        for (k in 0..count) {
            val frame = target + k
            val queue = synchronized(this) { frame !in decoded && inflight.add(frame) }
            if (!queue) continue
            try {
                pool.execute { decodeTask(frame, version) }
            } catch (_: java.util.concurrent.RejectedExecutionException) {
                synchronized(this) { inflight.remove(frame) }
            }
        }
    }

    private fun decodeTask(frame: Int, version: Long) {
        try {
            val distance = frame - wanted
            if (closed || epoch.get() != version || distance < 0 || distance > AHEAD) return
            val made = decode(frame, version) ?: return
            if (wanted == frame) show(frame, made.image, version)
        } finally {
            synchronized(this) { inflight.remove(frame) }
        }
    }

    private fun decode(frame: Int, version: Long): Decoded? {
        synchronized(this) { decoded[frame] }?.let { return it }
        val bytes = store[frame] ?: return null
        val reuse = synchronized(this) { victim() }
        val made = if (store.raw) {
            Decoded(null, (try { rawFrameImage(bytes, width, height) } catch (_: OutOfMemoryError) { null }) ?: return null)
        } else {
            val bitmap = decodeEncoded(bytes, reuse) ?: return null
            Decoded(bitmap, bitmap.asImageBitmap())
        }
        synchronized(this) {
            if (closed || version != epoch.get()) return null
            decoded[frame] = made
        }
        return made
    }

    private fun decodeEncoded(bytes: ByteArray, reuse: Bitmap?): Bitmap? {
        val options = BitmapFactory.Options().apply { inMutable = true; inBitmap = reuse }
        val bitmap = try {
            try { BitmapFactory.decodeByteArray(bytes, 0, bytes.size, options) }
            catch (_: IllegalArgumentException) {
                BitmapFactory.decodeByteArray(bytes, 0, bytes.size, BitmapFactory.Options().apply { inMutable = true })
            }
        } catch (_: OutOfMemoryError) { null }
        return bitmap
    }

    private fun victim(): Bitmap? {
        if (decoded.size < POOL) return null
        val target = wanted
        val now = System.nanoTime()
        shownAt.entries.removeAll { it.key !in decoded || now - it.value > REUSE_GUARD_NS * 8 }
        // Frames that were on screen a moment ago keep their bitmap, unless the pool has already grown well past its size (then memory wins).
        val guard = decoded.size <= POOL + 6
        val frame = decoded.keys.filter { it !in recent && it !in target..target + AHEAD && (!guard || now - (shownAt[it] ?: Long.MIN_VALUE / 2) > REUSE_GUARD_NS) }
            .maxByOrNull { abs(it - target) } ?: return null
        val removed = decoded.remove(frame) ?: return null
        shownAt.remove(frame)
        if (store.raw) releaseFrameImage(removed.image)
        return removed.bitmap
    }

    internal fun drop() {
        epoch.incrementAndGet()
        synchronized(this) { decoded.clear(); recent.clear(); shownAt.clear() }
        shown = null
    }

    internal fun close() {
        closed = true
        pool.shutdownNow()
        drop()
    }
}

object PreviewCache {
    enum class Phase { Empty, Rendering, Ready }
    enum class PreRender { None, Rendering, Ready, Outdated }
    private enum class Outcome { Done, Full, Stopped, Failed, NoMemory }

    var phase by mutableStateOf(Phase.Empty)
        private set
    var progress by mutableFloatStateOf(0f)
        private set
    var key by mutableStateOf<CacheKey?>(null)
        private set
    var player by mutableStateOf<FramePlayer?>(null)
        private set
    private var rendered by mutableStateOf<CacheKey?>(null)
    private var gaps = false
    @Volatile private var store: FrameStore? = null
    @Volatile private var stopRequested = false
    @Volatile private var memoryStopped = false
    @Volatile private var building: FrameStore? = null
    private var job: Job? = null
    private var generation = 0
    var revision by mutableLongStateOf(0L)
        private set
    private var revisedNs = 0L
    private fun revise(force: Boolean = false) {
        val now = System.nanoTime()
        if (force || now - revisedNs > 100_000_000L) { revisedNs = now; revision++ }
    }
    /** Key of the render that is being built, so the cache bar can keep showing frames while it runs. */
    @Volatile private var renderKey: CacheKey? = null
    /** Frames of the last finished render that an edit has not touched, worked out once per edit. */
    private var validFor: Pair<Any, Any>? = null
    private var dirtyNow: List<IntRange> = emptyList()
    private val validRuns = arrayOfNulls<List<IntRange>>(3)

    /** Runs of cached frames; [disk] picks the ones kept in the file (blue on the timeline), in memory (green), or all (null). */
    fun runs(disk: Boolean? = null): List<IntRange> = when (phase) {
        Phase.Rendering -> building?.runs(disk).orEmpty()
        Phase.Ready -> store?.runs(disk).orEmpty()
        Phase.Empty -> emptyList()
    }

    fun runsFor(state: EditorState, disk: Boolean? = null): List<IntRange> {
        val now = keyOf(state)
        if (phase == Phase.Rendering) {
            // The frames already kept and the ones rendered so far stay on the bar; nothing disappears while rendering.
            val rendering = renderKey ?: return emptyList()
            return if (cacheBarShows(rendering, now, catchingUp = false)) runs(disk) else emptyList()
        }
        val cached = key ?: return emptyList()
        if (cacheBarShows(cached, now, catchingUp = false)) return runs(disk)
        // The scene has moved on from the cache: show the part the edit did not touch, since that part needs no new render.
        val kept = store ?: return emptyList()
        if (phase != Phase.Ready || cached.copy(scene = now.scene) != now) return emptyList()
        val pair: Pair<Any, Any> = cached.scene.node to now.scene.node
        val known = validFor
        if (known == null || known.first !== pair.first || known.second !== pair.second) {
            dirtyNow = previewDirtyRanges(cached.scene, now.scene)
            validRuns.fill(null)
            validFor = pair
        }
        val slot = when (disk) { null -> 0; false -> 1; true -> 2 }
        return validRuns[slot] ?: kept.runs(disk).flatMap { run -> subtract(run, dirtyNow, now.scene.lastFrame) }.also { validRuns[slot] = it }
    }

    private fun subtract(run: IntRange, dirty: List<IntRange>, last: Int): List<IntRange> {
        var parts = listOf(run.first..minOf(run.last, last))
        for (hole in dirty) {
            parts = parts.flatMap { part ->
                if (hole.last < part.first || hole.first > part.last) listOf(part)
                else listOfNotNull(
                    (part.first until hole.first).takeIf { !it.isEmpty() },
                    ((hole.last + 1)..part.last).takeIf { !it.isEmpty() },
                )
            }
        }
        return parts.filter { !it.isEmpty() }
    }
    var fit by mutableFloatStateOf(0f)
    var checkerCell by mutableFloatStateOf(25f)
    private var preparedCell = 0f
    @Volatile private var interactionNs = 0L
    fun interaction() { interactionNs = System.nanoTime() }
    val idleMs: Long get() = if (PlatformFeatures.desktop) 1_000L else 2_000L
    fun idle(): Boolean = System.nanoTime() - interactionNs >= idleMs * 1_000_000L

    /** Keeps the cache in step with edits: the frames an edit touches are dropped, every other frame stays. */
    suspend fun follow(next: CacheKey) {
        val previous = key ?: return
        if (phase == Phase.Rendering || previous.scene == next.scene || previous.copy(scene = next.scene) != next) return
        reconcile(previous, next)
    }

    private suspend fun reconcile(previous: CacheKey, next: CacheKey) {
        val dirty = withContext(Dispatchers.Default) { previewDirtyRanges(previous.scene, next.scene) }
        currentCoroutineContext().ensureActive()
        if (key !== previous) return
        store?.removeWhere { frame -> dirty.any { frame in it } || frame > next.scene.lastFrame }
        if (dirty.isNotEmpty()) player?.drop()
        validFor = null
        key = next
        revise(force = true)
    }

    /** A store with room for the memory share and, when the device has the space, a file for the rest. */
    private fun createStore(context: Context, width: Int, height: Int): FrameStore {
        val app = context.applicationContext
        val manager = app.getSystemService(ActivityManager::class.java)
        val memory = storeBudget(previewCacheBudget(manager?.memoryClass ?: 128, manager?.isLowRamDevice == true, Tier.compatible), width, height)
        val folder = app.cacheDir
        val onDisk = runCatching { diskBudget(folder.usableSpace) }.getOrDefault(0L)
        if (onDisk > 0L) {
            val file = java.io.File(folder, CACHE_PREFIX + System.nanoTime() + ".bin")
            runCatching { FrameStore(0, memory + onDisk, file, ramBudget = memory) }.getOrNull()?.let { return it }
        }
        return FrameStore(0, memory)
    }

    /** The store that frames are added to while playing: brought up to date with edits, or created when there is none yet. */
    private suspend fun ensure(state: EditorState, context: Context): FrameStore? {
        if (phase == Phase.Rendering || fit <= 0f) return null
        val next = keyOf(state)
        val cell = checkerCell
        val (width, height) = cacheFrameSize(next.scene.width, next.scene.height, fit, next.divisor)
        val previous = key
        val kept = store
        if (kept != null && previous != null && !kept.raw && player?.width == width && player?.height == height && preparedCell == cell &&
            (previous == next || previous.copy(scene = next.scene) == next)) {
            if (previous != next) {
                reconcile(previous, next)
                if (key != next) return null
            }
            if (kept.writable) return kept
            // A render that was brought back from the saved files only reads, so its frames move into a store that takes new ones.
            val moved = withContext(Dispatchers.IO) {
                createStore(context, width, height).also { made ->
                    for (frame in kept.lowest..kept.last) { val bytes = kept[frame] ?: continue; if (!made.put(frame, bytes)) break }
                }
            }
            if (phase == Phase.Rendering || store !== kept || key != next) { moved.close(); return null }
            store = moved
            player?.close()
            player = FramePlayer(moved, width, height)
            kept.close()
            revise(force = true)
            return moved
        }
        clear()
        val made = withContext(Dispatchers.IO) { createStore(context, width, height) }
        if (phase != Phase.Empty) { made.close(); return null }
        store = made
        player = FramePlayer(made, width, height)
        preparedCell = cell
        key = next
        phase = Phase.Ready
        revise(force = true)
        return made
    }

    /**
     * Caches frames while the video plays: every frame the preview draws and the cache does not have yet is captured at the moment it is on screen,
     * so the cache fills up right behind the playhead and the next time round it plays from the cache. Runs until the caller stops it.
     */
    suspend fun capturePlayback(state: EditorState, context: Context) {
        val engine = state.engine
        while (phase == Phase.Rendering) delay(30)
        val built = ensure(state, context) ?: return
        val next = key ?: return
        val scene = next.scene
        val (width, height) = cacheFrameSize(scene.width, scene.height, fit, next.divisor)
        val cell = checkerCell
        val temporal = temporalSpans(scene, temporalTest(state))
        val queued = java.util.concurrent.ConcurrentHashMap.newKeySet<Int>()
        val queue = kotlinx.coroutines.channels.Channel<Pair<Int, ByteArray>>(CAPTURE_QUEUE)
        val captureWidth = width
        val captureHeight = height
        val tap = object : EngineThread.FrameTap {
            override val width: Int = captureWidth
            override val height: Int = captureHeight
            override val accurateBlur: Boolean = next.accurateBlur
            override fun timeFor(timeMs: Int): Int {
                val frame = scene.frameAt(timeMs)
                if (frame > scene.lastFrame || frame in built || frame in queued || !heapRoom(captureWidth.toLong() * captureHeight * 16)) return -1
                // A frame whose effect keeps history is only right when the frames before it were drawn in order; playback after a seek or a
                // scrub was not, so these frames are left to the ordered render.
                if (frameInSpans(frame, temporal)) return -1
                return scene.frameStart(frame)
            }
            override fun deliver(shownMs: Int, pixels: ByteArray) {
                val frame = scene.frameAt(shownMs)
                if (!queued.add(frame)) return
                if (queue.trySend(frame to pixels).isFailure) queued.remove(frame)
            }
        }
        engine.frameTap = tap
        try {
            withContext(Dispatchers.Default) {
                val encoder = Encoder(width, height)
                try {
                    for ((frame, pixels) in queue) {
                        val bytes = encoder.encode(pixels, cell)
                        if (bytes != null && key === next) {
                            val at = state.frame
                            while (!built.put(frame, bytes)) if (!built.evictFarther(at, frame)) break
                            revise()
                        }
                        queued.remove(frame)
                    }
                } finally { encoder.bitmap.recycle() }
            }
        } finally {
            engine.frameTap = null
            queue.cancel()
        }
    }

    /** The frames an idle render covers: the whole timeline in smart mode, a stretch ahead of the playhead in playhead mode. */
    fun autoRange(state: EditorState, mode: Int): IntRange {
        val last = state.scene.lastFrame.coerceAtLeast(0)
        if (mode != MODE_PLAYHEAD) return 0..last
        val at = state.frame.coerceIn(0, last)
        return at..minOf(last, at + state.scene.fps * LOOKAHEAD_SECONDS)
    }

    /** True when some frame of [range] is not cached yet. */
    fun missing(range: IntRange): Boolean {
        val kept = store ?: return true
        return range.any { it !in kept }
    }

    /** How many frames are cached; an idle render that does not add any gives up instead of starting over and over. */
    val cachedFrames: Int get() = store?.count ?: 0

    val first: Int get() = store?.lowest ?: 0
    val last: Int get() = store?.last ?: -1

    fun covers(frame: Int): Boolean = store?.contains(frame) == true

    fun preRender(state: EditorState, resources: Long = state.engine.mediaRevision.value): PreRender = when {
        phase == Phase.Rendering -> PreRender.Rendering
        phase == Phase.Ready && !gaps && key == keyOf(state, resources) && complete(state.scene.lastFrame) -> PreRender.Ready
        rendered?.projectId == state.projectId -> PreRender.Outdated
        else -> PreRender.None
    }

    private fun complete(lastFrame: Int): Boolean = store?.let { it.lowest == 0 && it.count > lastFrame } == true

    fun keyOf(state: EditorState, resources: Long = state.engine.mediaRevision.value) =
        CacheKey(state.projectId, state.scene, CACHE_DIVISOR, state.settings.androidEmoji, resources, state.accurateBlur, state.groupPath)

    /**
     * Renders the frames of [window] (the whole timeline by default) that are not cached yet. The render does not move the playhead; frames the edits
     * have not touched are kept, so only what is missing is drawn. [auto] is the idle render of the render mode: it shows no messages and does not stop playback.
     * Playback that was running when the button was tapped carries on from the same frame once the render is done.
     */
    fun render(state: EditorState, context: Context, scope: CoroutineScope, window: IntRange? = null, auto: Boolean = false) {
        if (phase == Phase.Rendering) return
        // An idle render never starts while a video is being prefetched: both need the decoder and the GPU, and the prefetch comes first.
        if (auto && com.effects.motion.media.VideoProxies.busy) return
        val app = context.applicationContext
        val scene = state.scene
        val (width, height) = cacheFrameSize(scene.width, scene.height, fit, CACHE_DIVISOR)
        val last = scene.lastFrame.coerceAtLeast(0)
        val range = (window ?: 0..last).let { it.first.coerceIn(0, last)..it.last.coerceIn(0, last) }
        val next = keyOf(state)
        val cell = checkerCell
        val before = key
        val kept = store
        val at = state.frame
        // Frames the edit has not touched are always kept (including the ones made while playing), so only what is missing or affected is rendered.
        val reuse = kept != null && before != null && !kept.raw && player?.width == width && player?.height == height && preparedCell == cell &&
            before.copy(scene = next.scene) == next
        val live = if (reuse && kept.writable) kept else null
        val seed = if (reuse && live == null) kept else null
        val seedScene = before?.scene
        val resume = state.playing && !auto
        val begun = System.nanoTime()
        if (seed != null) store = null
        if (live == null) clear()
        else {
            generation++
            stopRequested = false
            memoryStopped = false
        }
        if (!auto) state.playing = false
        val mine = generation
        renderKey = next
        progress = 0f
        phase = Phase.Rendering
        job = scope.launch {
            var built: FrameStore? = null
            try {
                val started = System.nanoTime()
                val target = live ?: withContext(Dispatchers.IO) { createStore(app, width, height) }
                built = target
                building = target
                val expected = framesThatFit(target.budget, width, height)
                if (live != null && before != null) reconcile(before, next)
                if (seed != null && seedScene != null) {
                    // Keep every frame the edit does not touch; only the affected frames are rendered again.
                    val dirty = withContext(Dispatchers.Default) { previewDirtyRanges(seedScene, scene) }
                    withContext(Dispatchers.IO) {
                        for (frame in maxOf(seed.lowest, 0)..minOf(seed.last, last)) {
                            if (dirty.any { frame in it }) continue
                            val bytes = seed[frame] ?: continue
                            if (!target.put(frame, bytes)) break
                        }
                    }
                }
                revise(force = true)
                var resources = next.resources
                val outcome = try {
                    withContext(Dispatchers.Default) { renderFrames(state.engine, scene, range, at, expected, width, height, cell, next.accurateBlur, target, temporalSpans(scene, temporalTest(state))) { resources = it } }
                } catch (e: CancellationException) {
                    throw e
                } catch (e: OutOfMemoryError) {
                    Outcome.NoMemory
                } catch (e: Exception) {
                    Log.w(TAG, "preview render failed", e)
                    Outcome.Failed
                }
                if (mine != generation) return@launch
                val ms = (System.nanoTime() - started) / 1e6
                val per = target.count.coerceAtLeast(1)
                Log.i(TAG, "render %s frames=%d of %d size=%dx%d bytes=%d avg=%d budget=%d ms=%.0f perFrame=%.1f still=%.1f encode=%.1f warmup=%d".format(
                    outcome, target.count, range.count(), width, height, target.bytes, target.bytes / per, target.budget, ms, ms / per, stillNs / 1e6 / per, encodeNs / 1e6 / per, warmupFrames))
                preparedCell = cell
                finish(app, next.copy(resources = resources), target, width, height, outcome, scene.lastFrame, scene.fps, quiet = auto)
                if (phase == Phase.Ready && store === target) persist(app, state, target, scene.lastFrame, width, height, cell, scope)
                // The render stopped playback only so the engine could be used; it carries on unless the person has done something since.
                if (resume && mine == generation && interactionNs < begun && state.scene.node === scene.node && outcome != Outcome.NoMemory) state.playing = true
            } finally {
                if (building === built) building = null
                seed?.close()
                if (live == null) built?.let { if (store !== it) it.close() }
                if (mine == generation && phase == Phase.Rendering) phase = if (live != null && store === live) Phase.Ready else Phase.Empty
            }
        }
    }

    private fun persist(context: Context, state: EditorState, built: FrameStore, lastFrame: Int, width: Int, height: Int, cell: Float, scope: CoroutineScope) {
        // Renders that are deleted when the app closes are not worth writing out a second time.
        if (!state.settings.persistentCache || state.settings.cleanOnExit) return
        val saved = key ?: return
        val projectId = state.projectId
        val name = saved.scene.node["title"] ?: projectId
        val limit = state.settings.cacheLimitMb * MIB
        val mode = state.settings.cacheCleanup
        val complete = built.lowest == 0 && built.count > lastFrame
        scope.launch(Dispatchers.IO) {
            PersistentCache.save(context, projectId, name, saved, built, width, height, cell, complete, limit, mode)
        }
    }

    /** Brings back a render saved earlier. Frames an edit has not touched are kept; the rest are rendered when you render again. */
    suspend fun restore(state: EditorState, context: Context) {
        if (phase != Phase.Empty || fit <= 0f || !state.settings.persistentCache) return
        val app = context.applicationContext
        val scene = state.scene
        val next = keyOf(state)
        val cell = checkerCell
        val (width, height) = cacheFrameSize(scene.width, scene.height, fit, CACHE_DIVISOR)
        val limit = state.settings.cacheLimitMb * MIB
        val mode = state.settings.cacheCleanup
        val loaded = withContext(Dispatchers.IO) {
            PersistentCache.cleanup(app, limit, mode, state.projectId)
            PersistentCache.load(app, state.projectId, next, cell, width, height)
        } ?: return
        if (phase != Phase.Empty || keyOf(state) != next) {
            loaded.store.close()
            return
        }
        store = loaded.store
        preparedCell = cell
        key = next
        rendered = next
        gaps = loaded.pruned
        player = FramePlayer(loaded.store, width, height)
        phase = Phase.Ready
        progress = 1f
        revise(force = true)
    }

    private class Encoder(private val width: Int, private val height: Int) {
        val bitmap: Bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        private val out = ByteArrayOutputStream(width * height / 4)

        fun encode(pixels: ByteArray, cell: Float, lossless: Boolean = false): ByteArray? {
            flattenOnChecker(pixels, width, height, cell)
            bitmap.copyPixelsFromBuffer(ByteBuffer.wrap(pixels))
            out.reset()
            return if (bitmap.compress(if (lossless) Bitmap.CompressFormat.PNG else Bitmap.CompressFormat.JPEG, QUALITY, out)) out.toByteArray() else null
        }
    }

    @Volatile private var stillNs = 0L
    /** Frames drawn only to rebuild the history of temporal effects in the last render (cost of keeping cached frames identical to a sequential render). */
    @Volatile private var warmupFrames = 0
    @Volatile private var encodeNs = 0L

    private fun temporalTest(state: EditorState): (String) -> Boolean {
        val catalog = state.engine.effects.value
        return { id -> catalog.find(id)?.graph?.temporal == true }
    }

    private suspend fun renderFrames(engine: EngineThread, scene: Scene, range: IntRange, at: Int, expected: Int, width: Int, height: Int, cell: Float, accurateBlur: Boolean,
                                     built: FrameStore, temporal: List<IntRange>, ready: (Long) -> Unit): Outcome =
        engine.exportSession(scene.toXml(), Smoothing(), scene.fps) {
            ready(engine.mediaRevision.value)
            stillNs = 0L
            encodeNs = 0L
            warmupFrames = 0
            val encoders = Array(ENCODERS) { Encoder(width, height) }
            try {
                coroutineScope {
                    // Drawing the next frame overlaps the encoding of the ones before it, on as many encoders as there are lanes.
                    val inflight = ArrayDeque<Pair<Int, Deferred<ByteArray?>>>()
                    var done = 0
                    var turn = 0
                    val todo = range.count { it !in built }.coerceAtLeast(1)
                    val steps = renderPlan(range, at, { it in built }, temporal)
                    val startBytes = built.bytes
                    suspend fun keep(): Outcome? {
                        val (frame, encoded) = inflight.removeFirstOrNull() ?: return null
                        val bytes = encoded.await() ?: return Outcome.Failed
                        while (!built.put(frame, bytes)) if (!built.evictFarther(at, frame)) return Outcome.Full
                        done++
                        revise()
                        val fit = if (built.bytes > startBytes) ((built.budget - startBytes).toDouble() * done / (built.bytes - startBytes)).toInt() else minOf(expected, todo)
                        progress = (done.toFloat() / fit.coerceIn(1, todo)).coerceAtMost(0.99f)
                        return null
                    }
                    suspend fun drain(): Outcome? {
                        while (inflight.isNotEmpty()) keep()?.let { return it }
                        return null
                    }
                    // From the playhead to the end, then the part before it, so what is about to be played is ready first. Frames of effects that keep
                    // history are drawn in unbroken ascending runs from the start of their span (see renderPlan), so a cached frame never depends on
                    // where the playhead was or on which neighbours were already cached.
                    for (step in steps) {
                        val frame = step.frame
                        if (step.store && frame in built) continue
                        if (stopRequested) return@coroutineScope drain() ?: Outcome.Stopped
                        if (!heapRoom(width.toLong() * height * 16)) return@coroutineScope drain() ?: Outcome.Full
                        val started = System.nanoTime()
                        val pixels = previewStill(scene.frameStart(frame), width, height, accurateBlur)
                        stillNs += System.nanoTime() - started
                        if (pixels == null) return@coroutineScope drain() ?: Outcome.Failed
                        if (!step.store) { warmupFrames++; continue }   // drawn only to bring the history up to date
                        if (inflight.size >= ENCODERS) keep()?.let { return@coroutineScope it }
                        val encoder = encoders[turn % ENCODERS]
                        turn++
                        inflight.addLast(frame to async(Dispatchers.Default) {
                            val began = System.nanoTime()
                            encoder.encode(pixels, cell).also { encodeNs += System.nanoTime() - began }
                        })
                    }
                    drain() ?: Outcome.Done
                }
            } finally {
                encoders.forEach { it.bitmap.recycle() }
            }
        }

    private fun heapRoom(needed: Long): Boolean {
        val runtime = Runtime.getRuntime()
        return runtime.maxMemory() - (runtime.totalMemory() - runtime.freeMemory()) > needed + 24 * MIB
    }

    private fun finish(context: Context, next: CacheKey, built: FrameStore, width: Int, height: Int, outcome: Outcome, lastFrame: Int, fps: Int, quiet: Boolean) {
        if (outcome == Outcome.NoMemory) {
            clear()
            if (!quiet) toast(context, context.getString(R.string.preview_cache_no_memory))
            return
        }
        if (built.count == 0 && store !== built) {
            phase = Phase.Empty
            if (quiet) return
            if (outcome == Outcome.Failed) toast(context, context.getString(R.string.preview_cache_failed))
            else if (outcome == Outcome.Full) toast(context, context.getString(R.string.preview_cache_no_memory))
            return
        }
        store = built
        key = next
        rendered = next
        renderKey = null
        validFor = null
        gaps = false
        // A render that went into the store that was already playing keeps its player; the frames it decoded stay valid.
        val kept = player
        if (kept == null || kept.width != width || kept.height != height) {
            kept?.close()
            player = FramePlayer(built, width, height)
        } else kept.drop()
        phase = Phase.Ready
        progress = 1f
        revise(force = true)
        if (quiet) return
        when {
            outcome == Outcome.Failed -> toast(context, context.getString(R.string.preview_cache_failed))
            (outcome != Outcome.Stopped || memoryStopped) && (built.lowest > 0 || built.last < lastFrame) ->
                toast(context, context.getString(R.string.preview_cache_partial, timecode(built.lowest, fps), timecode(built.last + 1, fps)))
        }
    }

    fun rangeLabel(context: Context, fps: Int): String =
        context.getString(R.string.preview_cache_ready_range, timecode(first, fps), timecode(last + 1, fps))

    private fun timecode(frame: Int, fps: Int): String = com.effects.motion.ui.editor.TimelineMath.timecode(frame, fps)

    fun cancel() {
        if (phase == Phase.Rendering) stopRequested = true
    }

    fun remove() {
        clear()
        rendered = null
    }

    fun clear() {
        renderKey = null
        validFor = null
        generation++
        stopRequested = false
        memoryStopped = false
        job?.cancel()
        job = null
        store?.close()
        store = null
        key = null
        gaps = false
        player?.close()
        player = null
        phase = Phase.Empty
        progress = 0f
        revise(force = true)
    }

    /** Deletes every render and prefetched video, when the app is closed for good or starts again after it was removed from the recents. */
    fun sweep(context: Context) {
        val app = context.applicationContext
        app.cacheDir.listFiles { f -> f.name.startsWith(CACHE_PREFIX) }?.forEach { it.delete() }
        PersistentCache.clearAll(app)
        com.effects.motion.media.VideoProxies.clearPrefetch(app)
    }

    fun shutdown(context: Context) {
        clear()
        rendered = null
        sweep(context)
    }

    fun trim(level: Int) {
        if (level == RUNNING_LOW || level == RUNNING_CRITICAL) {
            if (phase == Phase.Rendering && building?.onDisk != true) {
                memoryStopped = true
                cancel()
                Log.i(TAG, "rendering stopped early at trim level $level")
            }
            return
        }
        if (level < BACKGROUND) {
            if (level >= UI_HIDDEN) player?.drop()
            return
        }
        if (phase == Phase.Empty) return
        clear()
        Log.i(TAG, "cache freed at trim level $level")
    }

    private fun toast(context: Context, text: String) = Toast.makeText(context, text, Toast.LENGTH_LONG).show()

    private const val RUNNING_LOW = 10
    private const val RUNNING_CRITICAL = 15
    private const val UI_HIDDEN = 20
    private const val BACKGROUND = 40
}

package com.effects.motion.effects.graph

import com.effects.motion.effects.engine.CapabilityCheck
import com.effects.motion.effects.engine.EffectCapability
import com.effects.motion.effects.engine.ServedCapabilities

/**
 * Native multi-pass effect model (effect schema 2). Pure Kotlin so it can be validated at import time, on the host and in
 * unit tests. The C++ engine (render_graph.h) reads the same model from the runtime XML written by [GraphXml] and applies the
 * same rules again, so an effect that validates here also plans there.
 */
const val GRAPH_SCHEMA = 2

enum class IssueKind(val label: String) {
    MALFORMED("malformed"), UNSUPPORTED("unsupported"), TRANSLATION("translation"), CAPABILITY("capability"), VALIDATION("validation"),
}

/** One problem or note, with enough position to find it: effect, pass, file and line. */
data class Issue(
    val kind: IssueKind,
    val message: String,
    val error: Boolean = true,
    val effect: String = "",
    val pass: String? = null,
    val passIndex: Int = -1,
    val backend: String? = null,
    val file: String? = null,
    val line: Int = 0,
) {
    val text: String
        get() = buildString {
            append(if (error) "error" else "warning").append('[').append(kind.label).append(']')
            if (effect.isNotEmpty()) append(" effect '").append(effect).append('\'')
            if (pass != null) append(" pass '").append(pass).append('\'').also { if (passIndex >= 0) append(" (#").append(passIndex).append(')') }
            if (backend != null) append(" backend ").append(backend)
            if (file != null) append(" (").append(file).also { if (line > 0) append(':').append(line) }.append(')')
            append(": ").append(message)
        }
}

val List<Issue>.hasError: Boolean get() = any { it.error }

object GraphVocabulary {
    val Languages = setOf("sksl", "glsl", "glsl-es", "glsl-vk", "spirv")
    val Blends = setOf("replace", "over", "add", "multiply", "screen")
    val Formats = setOf("inherit", "rgba8", "rgba16f", "rgba32f")
    val Filters = setOf("nearest", "linear")
    val Wraps = setOf("clamp", "repeat", "mirror", "decal")
    val Precisions = setOf("preferred", "required")
    val Seeks = setOf("reset", "replay")
    val TextureSources = setOf("builtin:noise", "builtin:ramp-x", "builtin:ramp-y")
    /** A baked float16 3D LUT file (see engine/LutBake). Only the Skia backend can load it; effects using it must require the skia backend. */
    const val LutPrefix = "lutf16:"
    /** Most frames read on each side of the current one (memory: the window is held as decoded textures). */
    const val MaxFrameWindow = 8
    val Backends = setOf("skia")
    val Features = setOf("float16", "float32", "history")
}

data class PassInput(val name: String, val ref: String)

data class GraphPass(
    val id: String,
    val source: String,
    val name: String = id,
    val lang: String = "sksl",
    val inputs: List<PassInput> = emptyList(),
    val output: String = "",
    val blend: String = "replace",
    val clear: Boolean = true,
    val after: List<String> = emptyList(),
    val constants: Map<String, List<Float>> = emptyMap(),
    val defines: Map<String, String> = emptyMap(),
    val file: String = "",
    val line: Int = 1,
    /** Attributes this build does not know, kept so nothing is silently dropped. */
    val extra: Map<String, String> = emptyMap(),
)

data class GraphBuffer(
    val id: String,
    val scale: Float = 1f,
    val width: Int = 0,
    val height: Int = 0,
    val format: String = "inherit",
    val precision: String = "preferred",
    val filter: String = "linear",
    val wrap: String = "clamp",
    val history: Int = 0,
    val extra: Map<String, String> = emptyMap(),
)

data class GraphTexture(
    val id: String,
    val source: String,
    val width: Int = 256,
    val height: Int = 256,
    val seed: Int = 1,
    val filter: String = "nearest",
    val wrap: String = "repeat",
    val extra: Map<String, String> = emptyMap(),
)

/** Source frames around the current one an effect reads, in project frames (graph inputs "frame:-2" .. "frame:+2"). */
data class FrameWindow(val before: Int = 0, val after: Int = 0) { val any: Boolean get() = before > 0 || after > 0 }

data class GraphRequires(
    val backends: List<String> = emptyList(), val features: List<String> = emptyList(), val minSchema: Int = GRAPH_SCHEMA,
    /** Capability ids from engine/Capabilities.kt (frame_window, previous_frame, ...). */
    val capabilities: List<String> = emptyList(),
)

data class EffectGraph(
    val passes: List<GraphPass>,
    val buffers: List<GraphBuffer> = emptyList(),
    val textures: List<GraphTexture> = emptyList(),
    /** Buffer shown as the effect result. Empty = output of the last pass. */
    val output: String = "",
    val seek: String = "reset",
    val maxReplay: Int = 120,
    val requires: GraphRequires = GraphRequires(),
    /** Unknown top-level metadata (key -> raw JSON text), preserved on save. */
    val extra: Map<String, String> = emptyMap(),
    val frames: FrameWindow = FrameWindow(),
) {
    val temporal: Boolean get() = passes.any { p -> p.inputs.any { (Refs.parse(it.ref)?.back ?: 0) > 0 } }
    val effectiveOutput: String get() = output.ifEmpty { passes.lastOrNull()?.let { it.output.ifEmpty { it.id } } ?: "" }
}

data class Ref(val kind: String, val id: String, val back: Int)

object Refs {
    /** "source", "buffer:id", "buffer:id@1", "texture:id", "pass:id[@n]", "frame:<n>" (source frame n project frames from now, id = n). Null when malformed. */
    fun parse(ref: String): Ref? {
        if (ref == "source") return Ref("source", "", 0)
        val colon = ref.indexOf(':')
        if (colon < 0) return null
        val kind = ref.substring(0, colon)
        if (kind == "frame") {
            val n = ref.substring(colon + 1).removePrefix("+")
            val v = n.toIntOrNull()?.takeIf { it in -99..99 && n == it.toString() } ?: return null
            return Ref("frame", v.toString(), 0)
        }
        if (kind != "buffer" && kind != "texture" && kind != "pass") return null
        var rest = ref.substring(colon + 1)
        var back = 0
        val at = rest.indexOf('@')
        if (at >= 0) {
            back = rest.substring(at + 1).takeIf { it.isNotEmpty() && it.length <= 2 && it.all(Char::isDigit) }?.toInt() ?: return null
            rest = rest.substring(0, at)
        }
        return Ref(kind, rest, back)
    }
}

/**
 * Import-time validation. Mirrors BuildPlan() in render_graph.cpp: ids, references, history depth, read/write hazards,
 * dependency cycles, unreachable passes and unsupported languages.
 */
object GraphValidator {
    private val IdPattern = Regex("[A-Za-z_][A-Za-z0-9_]{0,47}")
    const val MAX_PASSES = 64
    const val MAX_BUFFERS = 32
    const val MAX_INPUTS = 8

    fun validate(effectId: String, graph: EffectGraph, languages: Set<String> = setOf("sksl"), backend: String = "skia", served: Set<EffectCapability> = ServedCapabilities.now): List<Issue> {
        val out = mutableListOf<Issue>()
        fun add(error: Boolean, kind: IssueKind, msg: String, pass: GraphPass? = null, index: Int = -1) {
            out += Issue(kind, msg, error, effectId, pass?.id, index, backend, pass?.file?.takeIf { it.isNotEmpty() }, pass?.line ?: 0)
        }
        fun fail(kind: IssueKind, msg: String, pass: GraphPass? = null, index: Int = -1) = add(true, kind, msg, pass, index)

        val passes = graph.passes
        if (passes.isEmpty()) { fail(IssueKind.MALFORMED, "the effect has no passes"); return out }
        if (passes.size > MAX_PASSES) { fail(IssueKind.UNSUPPORTED, "has ${passes.size} passes; the limit is $MAX_PASSES"); return out }
        if (graph.seek !in GraphVocabulary.Seeks) fail(IssueKind.MALFORMED, "seek must be reset or replay, not '${graph.seek}'")
        if (graph.maxReplay !in 1..1000) fail(IssueKind.MALFORMED, "maxReplay must be 1..1000")
        if (graph.requires.minSchema > GRAPH_SCHEMA) fail(IssueKind.UNSUPPORTED, "needs effect schema ${graph.requires.minSchema}; this build understands $GRAPH_SCHEMA. Update the app.")
        graph.requires.backends.filter { it !in GraphVocabulary.Backends }.forEach {
            fail(IssueKind.CAPABILITY, "requires the '$it' backend, which this build does not have (available: ${GraphVocabulary.Backends.joinToString()})")
        }
        graph.requires.features.filter { it !in GraphVocabulary.Features }.forEach { fail(IssueKind.UNSUPPORTED, "requires the unknown feature '$it'") }
        // Frame access: what the effect declares, what its inputs really use, and what this build can serve.
        run {
            val declared = graph.requires.capabilities.mapNotNull { EffectCapability.parse(it) }.toSet()
            val report = CapabilityCheck.check(graph.requires.capabilities, served)
            report.unknown.forEach { fail(IssueKind.UNSUPPORTED, it.message) }
            report.missing.forEach { fail(IssueKind.CAPABILITY, it.message + " Frames at other times are not available in this build yet, so the effect is not loaded.") }
            val wide = EffectCapability.FrameWindow in declared || EffectCapability.TimeAccess in declared
            val before = if (wide) graph.frames.before else if (EffectCapability.PreviousFrame in declared) 1 else 0
            val after = if (wide) graph.frames.after else if (EffectCapability.NextFrame in declared) 1 else 0
            if (graph.frames.before !in 0..GraphVocabulary.MaxFrameWindow || graph.frames.after !in 0..GraphVocabulary.MaxFrameWindow)
                fail(IssueKind.MALFORMED, "frames.before and frames.after must be 0..${GraphVocabulary.MaxFrameWindow}")
            if (graph.frames.any && !wide) fail(IssueKind.MALFORMED, "frames {before, after} is set but the effect does not declare frame_window")
            val offsets = passes.flatMap { p -> p.inputs.mapNotNull { Refs.parse(it.ref)?.takeIf { r -> r.kind == "frame" }?.id?.toInt() } }.toSet()
            for (k in offsets) if (k < -before || k > after)
                fail(IssueKind.VALIDATION, "reads frame:$k but the declared window is $before before / $after after. Declare frame_window with frames {before, after} that cover it.")
        }

        val passAt = linkedMapOf<String, Int>()
        passes.forEachIndexed { i, p ->
            if (!IdPattern.matches(p.id)) fail(IssueKind.MALFORMED, "pass id '${p.id}' is not a valid name (letters, digits, underscore)", p, i)
            else if (passAt.put(p.id, i) != null) fail(IssueKind.MALFORMED, "pass id '${p.id}' is used twice", p, i)
            if (p.source.isBlank()) fail(IssueKind.MALFORMED, "has no shader source", p, i)
            if (p.lang !in GraphVocabulary.Languages) fail(IssueKind.MALFORMED, "lang '${p.lang}' is not sksl, glsl, glsl-es, glsl-vk or spirv", p, i)
            else if (p.lang !in languages) fail(IssueKind.UNSUPPORTED, "is written in ${p.lang}, which the $backend backend cannot run. Convert the pass to sksl or use a backend that has ${p.lang}.", p, i)
            if (p.blend !in GraphVocabulary.Blends) fail(IssueKind.MALFORMED, "blend '${p.blend}' is not one of ${GraphVocabulary.Blends.joinToString()}", p, i)
            if (p.inputs.size > MAX_INPUTS) fail(IssueKind.UNSUPPORTED, "has ${p.inputs.size} inputs; the limit is $MAX_INPUTS", p, i)
        }
        val texAt = linkedMapOf<String, Int>()
        graph.textures.forEachIndexed { i, t ->
            if (!IdPattern.matches(t.id) || texAt.put(t.id, i) != null) fail(IssueKind.MALFORMED, "texture id '${t.id}' is invalid or used twice")
            if (t.source !in GraphVocabulary.TextureSources && !t.source.startsWith(GraphVocabulary.LutPrefix))
                fail(IssueKind.UNSUPPORTED, "texture '${t.id}' has source '${t.source}'; this build has only ${GraphVocabulary.TextureSources.joinToString()} and ${GraphVocabulary.LutPrefix}<file> (Skia backend)")
            if (t.source.startsWith(GraphVocabulary.LutPrefix) && "skia" !in graph.requires.backends)
                fail(IssueKind.CAPABILITY, "texture '${t.id}' is a LUT file, which only the skia backend can load; the effect must list \"skia\" in requires.backends")
            if (t.width !in 1..2048 || t.height !in 1..2048) fail(IssueKind.MALFORMED, "texture '${t.id}' size must be 1..2048")
            if (t.filter !in GraphVocabulary.Filters || t.wrap !in GraphVocabulary.Wraps) fail(IssueKind.MALFORMED, "texture '${t.id}' has a bad filter or wrap")
        }
        val buffers = graph.buffers.toMutableList()
        val bufAt = linkedMapOf<String, Int>()
        buffers.forEachIndexed { i, b ->
            if (!IdPattern.matches(b.id) || b.id == "source") fail(IssueKind.MALFORMED, "buffer id '${b.id}' is invalid ('source' is reserved)")
            else if (bufAt.put(b.id, i) != null) fail(IssueKind.MALFORMED, "buffer id '${b.id}' is declared twice")
            else if (b.id in texAt) fail(IssueKind.MALFORMED, "'${b.id}' is both a buffer and a texture")
            if (!(b.scale > 0f && b.scale <= 8f)) fail(IssueKind.MALFORMED, "buffer '${b.id}' scale must be in (0, 8]")
            if (b.history !in 0..8) fail(IssueKind.MALFORMED, "buffer '${b.id}' history must be 0..8")
            if (b.format !in GraphVocabulary.Formats) fail(IssueKind.MALFORMED, "buffer '${b.id}' format '${b.format}' is not one of ${GraphVocabulary.Formats.joinToString()}")
            if (b.precision !in GraphVocabulary.Precisions) fail(IssueKind.MALFORMED, "buffer '${b.id}' precision must be preferred or required")
            if (b.filter !in GraphVocabulary.Filters || b.wrap !in GraphVocabulary.Wraps) fail(IssueKind.MALFORMED, "buffer '${b.id}' has a bad filter or wrap")
        }
        if (out.hasError) return out

        passes.forEachIndexed { i, p ->
            val o = p.output.ifEmpty { p.id }
            if (!IdPattern.matches(o)) { fail(IssueKind.MALFORMED, "output '$o' is not a valid name", p, i); return@forEachIndexed }
            if (o in texAt) { fail(IssueKind.VALIDATION, "writes '$o', which is a texture (textures are read-only)", p, i); return@forEachIndexed }
            if (o !in bufAt) { bufAt[o] = buffers.size; buffers += GraphBuffer(o) }
        }
        val output = graph.effectiveOutput
        if (output !in bufAt) fail(IssueKind.VALIDATION, "the effect output '$output' is not a buffer.${suggest(output, bufAt.keys)}")
        if (buffers.size > MAX_BUFFERS) fail(IssueKind.UNSUPPORTED, "has ${buffers.size} buffers; the limit is $MAX_BUFFERS")
        if (out.hasError) return out

        val writers = List(buffers.size) { mutableListOf<Int>() }
        passes.forEachIndexed { i, p -> writers[bufAt.getValue(p.output.ifEmpty { p.id })] += i }
        val preds = List(passes.size) { linkedSetOf<Int>() }
        val readsPrevious = List(passes.size) { mutableListOf<Int>() }   // buffer indices read as @n
        passes.forEachIndexed { i, p ->
            val names = hashSetOf<String>()
            val outBuf = bufAt.getValue(p.output.ifEmpty { p.id })
            for (inp in p.inputs) {
                if (!IdPattern.matches(inp.name)) { fail(IssueKind.MALFORMED, "input name '${inp.name}' is not a valid shader child name", p, i); continue }
                if (!names.add(inp.name)) { fail(IssueKind.MALFORMED, "input '${inp.name}' is declared twice", p, i); continue }
                val ref = Refs.parse(inp.ref)
                if (ref == null) {
                    fail(IssueKind.MALFORMED, "input '${inp.name}' has reference '${inp.ref}'; expected source, buffer:<id>[@n], texture:<id>, pass:<id>[@n] or frame:<n>", p, i)
                    continue
                }
                when (ref.kind) {
                    "source", "frame" -> {}
                    "texture" -> if (ref.id !in texAt) fail(IssueKind.VALIDATION, "input '${inp.name}' reads unknown texture '${ref.id}'.${suggest(ref.id, texAt.keys)}", p, i)
                    else -> {
                        var id = ref.id
                        if (ref.kind == "pass") {
                            val q = passAt[id]
                            if (q == null) { fail(IssueKind.VALIDATION, "input '${inp.name}' reads unknown pass '$id'.${suggest(id, passAt.keys)}", p, i); continue }
                            id = passes[q].output.ifEmpty { passes[q].id }
                        }
                        val b = bufAt[id]
                        if (b == null) { fail(IssueKind.VALIDATION, "input '${inp.name}' reads unknown buffer '$id'.${suggest(id, bufAt.keys)}", p, i); continue }
                        val depth = buffers[b].history
                        if (ref.back > depth) {
                            fail(IssueKind.VALIDATION, "input '${inp.name}' reads '$id@${ref.back}' but the buffer keeps $depth frame(s) of history. Set history >= ${ref.back} on the buffer.", p, i)
                            continue
                        }
                        if (ref.back > 0) { readsPrevious[i] += b; continue }
                        if (b == outBuf) {
                            fail(IssueKind.VALIDATION, "reads and writes buffer '$id' in the same pass (read/write feedback hazard). Read '$id@1' (previous frame) or write to a different buffer.", p, i)
                            continue
                        }
                        if (writers[b].isEmpty()) {
                            fail(IssueKind.VALIDATION, "input '${inp.name}' reads buffer '$id' that no pass writes" + if (depth > 0) ". Use '$id@1' for the previous frame." else ".", p, i)
                            continue
                        }
                        writers[b].forEach { w -> if (w != i) preds[i] += w }
                    }
                }
            }
            for (a in p.after) {
                val q = passAt[a]
                if (q == null) fail(IssueKind.VALIDATION, "after '$a': no such pass.${suggest(a, passAt.keys)}", p, i) else if (q != i) preds[i] += q
            }
        }
        buffers.indices.forEach { b ->
            writers[b].zipWithNext().forEach { (before, later) ->
                preds[later] += before
                val lp = passes[later]
                if (lp.clear && lp.blend == "replace")
                    fail(IssueKind.VALIDATION, "overwrites buffer '${buffers[b].id}' that pass '${passes[before].id}' already wrote. Set clear=false with a blend mode to accumulate, or write to another buffer.", lp, later)
            }
        }
        if (out.hasError) return out

        // cycles (Kahn); report one concrete cycle
        val indeg = IntArray(passes.size) { preds[it].size }
        val succs = List(passes.size) { mutableListOf<Int>() }
        preds.forEachIndexed { to, set -> set.forEach { succs[it] += to } }
        val queue = ArrayDeque<Int>().also { q -> indeg.indices.filter { indeg[it] == 0 }.forEach(q::add) }
        val ordered = BooleanArray(passes.size)
        while (queue.isNotEmpty()) {
            val n = queue.removeFirst()
            ordered[n] = true
            succs[n].forEach { if (--indeg[it] == 0) queue.add(it) }
        }
        if (ordered.any { !it }) {
            val color = IntArray(passes.size)
            val stack = ArrayList<Int>()
            var cycle: List<Int>? = null
            fun dfs(n: Int): Boolean {
                color[n] = 1; stack += n
                for (s in succs[n]) {
                    if (ordered[s]) continue
                    if (color[s] == 1) { cycle = stack.subList(stack.indexOf(s), stack.size) + s; return true }
                    if (color[s] == 0 && dfs(s)) return true
                }
                stack.removeAt(stack.size - 1); color[n] = 2
                return false
            }
            for (i in passes.indices) if (cycle == null && !ordered[i] && color[i] == 0) dfs(i)
            val c = cycle.orEmpty()
            fail(IssueKind.VALIDATION, "dependency cycle: ${c.joinToString(" -> ") { passes[it].id }}. Break it by reading the previous frame ('buffer:<id>@1') on one edge.",
                c.firstOrNull()?.let { passes[it] }, c.firstOrNull() ?: -1)
            return out
        }
        val outBuf = bufAt.getValue(output)
        if (writers[outBuf].isEmpty()) { fail(IssueKind.VALIDATION, "no pass writes the output buffer '$output'"); return out }

        // reachability: unreachable passes are skipped by the engine, say so
        val live = BooleanArray(passes.size)
        val work = ArrayDeque<Int>()
        fun mark(p: Int) { if (!live[p]) { live[p] = true; work.add(p) } }
        writers[outBuf].forEach(::mark)
        while (work.isNotEmpty()) {
            val n = work.removeFirst()
            preds[n].forEach(::mark)
            readsPrevious[n].forEach { b -> writers[b].forEach(::mark) }
        }
        passes.forEachIndexed { i, p -> if (!live[i]) add(false, IssueKind.VALIDATION, "does not contribute to the output and is skipped", p, i) }
        return out
    }

    private fun suggest(wanted: String, known: Collection<String>): String {
        val best = known.minByOrNull { distance(wanted, it) } ?: return ""
        return if (distance(wanted, best) < 3) " Did you mean '$best'?" else ""
    }

    private fun distance(a: String, b: String): Int {
        var prev = IntArray(b.length + 1) { it }
        for (i in 1..a.length) {
            val cur = IntArray(b.length + 1)
            cur[0] = i
            for (j in 1..b.length) cur[j] = minOf(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + if (a[i - 1] == b[j - 1]) 0 else 1)
            prev = cur
        }
        return prev[b.length]
    }
}

package com.effects.motion.effects

import com.effects.motion.effects.engine.CubeLut
import com.effects.motion.effects.engine.LutBake
import org.json.JSONArray
import org.json.JSONObject
import java.security.MessageDigest
import java.util.Locale

/** Builds the schema-2 effect for one imported 3D LUT: one pass reading the baked float16 texture, trilinear in the shader. */
object LutEffect {
    class Built(val key: String, val json: JSONObject)

    fun hash(bytes: ByteArray): String =
        MessageDigest.getInstance("SHA-256").digest(bytes).take(5).joinToString("") { "%02x".format(it) }

    fun slug(name: String): String =
        name.lowercase(Locale.ROOT).replace(Regex("[^a-z0-9]+"), "_").trim('_').take(24).ifBlank { "lut" }

    /** `binPath` is where the baked file is stored (see LutBake). `hash` is the content hash of the .cube text. */
    fun build(displayName: String, lut: CubeLut, hash: String, binPath: String): Built {
        LutBake.problem(lut)?.let { throw IllegalArgumentException(it) }
        val l = LutBake.layout(lut.size)
        val key = "lut_${slug(displayName)}_$hash"
        val tex = "t$hash"
        fun nums(vararg v: Float) = JSONArray(v.map { it.toDouble() })
        val params = JSONArray().put(
            JSONObject().put("id", "amount").put("label", "Amount").put("type", "float").put("default", 1.0)
                .put("min", 0.0).put("max", 1.0).put("step", 0.01).put("percent", true),
        )
        val pass = JSONObject().put("id", "apply").put("lang", "glsl-es").put("source", JSONArray(Shader.lines()))
            .put("inputs", JSONObject().put("image", "source").put("lut", "texture:$tex")).put("output", "out")
            .put("constants", JSONObject().put("n", nums(lut.size.toFloat())).put("cols", nums(l.cols.toFloat()))
                .put("dmin", nums(*lut.domainMin)).put("dmax", nums(*lut.domainMax)))
        val json = JSONObject().put("schema", 2).put("id", key).put("name", displayName).put("category", "color")
            .put("description", "3D LUT (${lut.size} points) from a .cube file, trilinear, float16.")
            .put("requires", JSONObject().put("backends", JSONArray().put("gles")).put("features", JSONArray().put("float16")))
            .put("params", params)
            .put("textures", JSONArray().put(JSONObject().put("id", tex).put("source", "lutf16:$binPath").put("width", l.width).put("height", l.height)
                .put("filter", "nearest").put("wrap", "clamp")))
            .put("buffers", JSONArray().put(JSONObject().put("id", "out").put("scale", 1.0).put("format", "inherit")))
            .put("passes", JSONArray().put(pass)).put("output", "out")
        return Built(key, json)
    }

    /** Texel centres are fetched exactly (texelFetch), so the texture's own filter does not matter; blending is done here. Premultiplied in and out. */
    private val Shader = """
#version 300 es
precision highp float;
precision highp int;
precision highp sampler2D;
out vec4 _frag;
uniform sampler2D image;
uniform sampler2D lut;
uniform vec2 size;
uniform float amount;
uniform float n;
uniform float cols;
uniform vec3 dmin;
uniform vec3 dmax;
vec3 tex(float x, float y) { return texelFetch(lut, ivec2(int(x), int(y)), 0).rgb; }
vec3 slice(float k, vec2 uv) {
  vec2 o = vec2(mod(k, cols) * n, floor(k / cols) * n);
  vec2 f = floor(uv);
  vec2 t = uv - f;
  vec2 g = min(f + 1.0, vec2(n - 1.0));
  vec3 a = tex(o.x + f.x, o.y + f.y);
  vec3 b = tex(o.x + g.x, o.y + f.y);
  vec3 c = tex(o.x + f.x, o.y + g.y);
  vec3 d = tex(o.x + g.x, o.y + g.y);
  return mix(mix(a, b, t.x), mix(c, d, t.x), t.y);
}
void main() {
  vec4 s = texture(image, gl_FragCoord.xy / size);
  vec3 rgb = s.a > 0.0 ? s.rgb / s.a : vec3(0.0);
  vec3 v = clamp((rgb - dmin) / (dmax - dmin), 0.0, 1.0) * (n - 1.0);
  float kz = floor(v.z);
  vec3 mapped = mix(slice(kz, v.xy), slice(min(kz + 1.0, n - 1.0), v.xy), v.z - kz);
  vec3 outc = mix(rgb, mapped, amount);
  _frag = vec4(outc * s.a, s.a);
}
""".trim()

}

// @id cubespin
// @name Cube Spin 3D
// @category depth
// @description 3D: your layer wrapped on a spinning cube, with the original shown behind it.
// @param cubeSize float 1.1 min=0.3 max=2 step=0.01 label="Cube Size"
// @param spin float 40 min=-360 max=360 step=1 label="Spin (deg/s)"
// @param tilt angle 20 label="Tilt"
// @param zoom float 1 min=0.4 max=3 step=0.01 label="Zoom"
// @param bgAmount float 0.35 min=0 max=1 step=0.01 percent=1 label="Background"
uniform sampler2D image;
uniform vec2 size;
uniform float time;
uniform float cubeSize;
uniform float spin;
uniform float tilt;
uniform float zoom;
uniform float bgAmount;

mat3 rotY(float a) { float c = cos(a); float s = sin(a); return mat3(c, 0.0, -s, 0.0, 1.0, 0.0, s, 0.0, c); }
mat3 rotX(float a) { float c = cos(a); float s = sin(a); return mat3(1.0, 0.0, 0.0, 0.0, c, s, 0.0, -s, c); }

vec2 boxHit(vec3 ro, vec3 rd, vec3 h) {
    vec3 inv = 1.0 / (rd + vec3(0.000001));
    vec3 t1 = (-h - ro) * inv;
    vec3 t2 = (h - ro) * inv;
    vec3 tn = min(t1, t2);
    vec3 tf = max(t1, t2);
    return vec2(max(max(tn.x, tn.y), tn.z), min(min(tf.x, tf.y), tf.z));
}

void main() {
    vec2 uv = gl_FragCoord.xy / size;
    vec4 base = texture2D(image, uv);
    vec2 q = (gl_FragCoord.xy - 0.5 * size) / size.y;
    q.y = -q.y;
    vec3 ro = vec3(0.0, 0.0, -3.0 / max(zoom, 0.1));
    vec3 rd = normalize(vec3(q, 1.6));
    float ang = radians(spin) * time;
    float tl = radians(tilt);
    mat3 inv = rotY(-ang) * rotX(-tl);
    mat3 fwd = rotX(tl) * rotY(ang);
    vec3 h = vec3(cubeSize * 0.5);
    vec2 th = boxHit(inv * ro, inv * rd, h);
    if (th.x > th.y || th.y < 0.0) {
        gl_FragColor = base * bgAmount;
        return;
    }
    vec3 p = inv * ro + (inv * rd) * th.x;
    vec3 a = abs(p / h);
    vec3 n;
    vec2 f;
    if (a.x > a.y && a.x > a.z) {
        n = vec3(sign(p.x), 0.0, 0.0);
        f = vec2(p.z * sign(p.x), p.y);
    } else if (a.y > a.z) {
        n = vec3(0.0, sign(p.y), 0.0);
        f = vec2(p.x, p.z * sign(p.y));
    } else {
        n = vec3(0.0, 0.0, sign(p.z));
        f = vec2(-p.x * sign(p.z), p.y);
    }
    vec2 fuv = vec2(f.x / cubeSize + 0.5, 0.5 - f.y / cubeSize);
    vec4 tex = texture2D(image, clamp(fuv, 0.0, 1.0));
    float dif = clamp(dot(normalize(fwd * n), normalize(vec3(-0.4, 0.6, -0.7))), 0.0, 1.0);
    float light = 0.55 + 0.55 * dif;
    vec4 cube = vec4(tex.rgb * light, tex.a);
    gl_FragColor = cube + base * bgAmount * (1.0 - cube.a);
}

package com.effects.motion.ai

import androidx.annotation.StringRes
import com.effects.motion.R
import com.effects.motion.i18n.AppText
import com.effects.motion.i18n.UiText
import com.effects.motion.i18n.txt
import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.FileProvider
import com.effects.motion.editor.EditorPanel
import com.effects.motion.editor.EditorState
import com.effects.motion.export.FrameInterpolation
import com.effects.motion.export.Smoothing
import com.effects.motion.export.holdingVideo
import com.effects.motion.library.CrashLogs
import com.effects.motion.model.Layer
import com.effects.motion.model.MediaDeclaration
import com.effects.motion.model.XmlNode
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.UUID
import kotlin.math.sqrt

enum class AiAction(@StringRes val title: Int) {
    Background(R.string.ai_remove_background), Noise(R.string.ai_reduce_noise), Video(R.string.ai_remove_background_video), Smooth(R.string.smooth_clip),
    Enhance(R.string.ai_enhance), Reverse(R.string.speed_reverse);

    val offered: Boolean get() = when (this) {
        Noise -> true
        Enhance -> false // lives in Tools > Enhancer now, not in the effects library
        Video -> false // lives in the layer toolbar next to Track Motion, not in the effects library
        Background -> false
        Smooth, Reverse -> false
    }

    fun unavailable(layer: Layer?): UiText? = when (this) {
        Background -> if (layer?.mediaFill?.video == false) null else txt(R.string.ai_select_image_layer)
        Noise -> if (layer?.kind == "audio") null else txt(R.string.ai_select_audio_layer)
        Enhance -> com.effects.motion.Tier.reason(com.effects.motion.Feature.AiEnhance) ?: videoReason(layer, AiKind.Enhance)
        Smooth -> videoReason(layer, AiKind.Smooth)
        Reverse -> videoReason(layer, null) ?: if (layer?.aiMarks.orEmpty().any { it.kind == AiKind.Smooth || it.kind == AiKind.Enhance }) txt(R.string.speed_reverse_remove_ai) else null
        Video -> videoReason(layer, null) ?: if (layer?.shape.isNullOrEmpty()) txt(R.string.ai_select_video_layer) else null
    }

    private fun videoReason(layer: Layer?, kind: AiKind?): UiText? = when {
        layer?.mediaFill?.video != true -> txt(R.string.ai_select_video_layer)
        kind != null && layer.aiBuried(kind) -> txt(R.string.ai_undo_newer_first)
        else -> null
    }
}

internal data class AiMedia(val file: File, val declaration: MediaDeclaration)
internal typealias AiProgress = suspend (Float, String) -> Unit

class AiTools(private val context: Context, private val state: EditorState, private val scope: CoroutineScope) {
    var running by mutableStateOf<AiAction?>(null)
        private set
    var last by mutableStateOf<AiAction?>(null)
        private set
    var progress by mutableStateOf(0f)
        private set
    var message by mutableStateOf("")
        private set
    var retry by mutableStateOf<AiAction?>(null)
        private set
    var videoSetup by mutableStateOf<Layer?>(null)
    var noiseSetup by mutableStateOf<Layer?>(null)
    var noiseSource by mutableStateOf(NoiseSource.Voice)
    var smoothSetup by mutableStateOf<Layer?>(null)
    var smoothing by mutableStateOf(Smoothing(FrameInterpolation.Flow))
    var videoSide by mutableIntStateOf(MatteSides[1])
    var enhanceSetup by mutableStateOf<Layer?>(null)
    var enhance by mutableStateOf(EnhanceOptions())
    var cutoutSetup by mutableStateOf<Layer?>(null)
    var cutoutQuality by mutableStateOf(CutoutQuality.Standard)
    var precisePick by mutableStateOf(false)
    internal var avoid by mutableStateOf<List<Tap>>(emptyList())
    internal var subject by mutableStateOf<List<Tap>>(emptyList())
    internal var edge by mutableStateOf(MatteEdge())
    private var job: Job? = null

    private suspend fun <T> holdingPreview(action: AiAction, block: suspend () -> T): T =
        if (action == AiAction.Noise || action == AiAction.Background) block() else holdingVideo(state.engine::holdVideo, state.engine::releaseVideo, block)

    fun cancel() { job?.cancel(); message = AppText.get(R.string.ai_cancelling) }
    fun dismiss() { message = ""; retry = null }

    fun apply(action: AiAction, confirmed: Boolean = false, target: Long? = null) {
        if (running != null) return
        val layer = (target ?: state.selectedId)?.let(state.scene::layer)
        action.unavailable(layer)?.let { message = AppText.get(it); return }
        layer ?: return
        if (action == AiAction.Reverse && layer.reverseMark != null) {
            dismiss()
            state.playing = false
            state.edit { it.unreversed(layer.id) }
            return
        }
        if (action == AiAction.Video && !confirmed) {
            if (retry != action) subject = emptyList()
            dismiss()
            videoSetup = layer
            return
        }
        if (action == AiAction.Noise && !confirmed) {
            dismiss()
            noiseSetup = layer
            return
        }
        if (action == AiAction.Smooth && !confirmed) {
            dismiss()
            smoothSetup = layer
            return
        }
        if (action == AiAction.Enhance && !confirmed) {
            dismiss()
            enhanceSetup = layer
            return
        }
        if (action == AiAction.Background && !confirmed) {
            if (retry != action) Cutout.parse(layer.backgroundMark?.node?.get("option")).let { subject = it.keep; edge = it.edge; avoid = it.avoid }
            dismiss()
            cutoutQuality = CutoutQuality.Standard
            precisePick = false
            cutoutSetup = layer
            return
        }
        if (action == AiAction.Background && cutoutSetup != null && CutoutChoice.of(context).asks(BestCutout.offered)) CutoutChoice.of(context).choose(cutoutQuality)
        cutoutSetup = null
        videoSetup = null
        noiseSetup = null
        smoothSetup = null
        enhanceSetup = null
        state.playing = false
        running = action; last = action; progress = 0f; message = AppText.get(R.string.ai_preparing); retry = null
        job = scope.launch {
            var result: AiMedia? = null
            var committed = false
            var fallback: Int? = null
            try { CrashLogs.during("running AI ${action.name.lowercase()}") { holdingPreview(action) {
                val report: AiProgress = { fraction, text ->
                    withContext(Dispatchers.Main) { progress = fraction.coerceIn(0f, 1f); message = text }
                }
                if (action == AiAction.Enhance) {
                    val options = enhance
                    val media = checkNotNull(state.scene.media(layer.mediaFill!!.uri)) { AppText.get(R.string.ai_video_missing) }
                    for (model in options.models) if (!model.installed(context)) {
                        report(0f, AppText.get(R.string.ai_downloading_model))
                        model.download(context) { fraction -> progress = fraction.coerceIn(0f, 1f) }
                    }
                    val output = withContext(Dispatchers.IO) { AiEnhance.run(context, layer, media, options, report).also { result = it } }
                    ensureActive()
                    check(state.scene.layer(layer.id) == layer) { AppText.get(R.string.ai_layer_changed) }
                    state.edit { scene ->
                        scene.update(layer.id) {
                            it.copy(node = it.node.with(AiKind.Enhance.attribute!!, output.declaration.uri))
                                .withAiMark(AiKind.Enhance, it.node[AiKind.Enhance.attribute], output.declaration.uri, options.xml, media)
                        }.withMedia(output.declaration)
                    }
                } else if (action == AiAction.Video) {
                    val media = checkNotNull(state.scene.media(layer.mediaFill!!.uri)) { AppText.get(R.string.ai_video_missing) }
                    val keep = subject
                    val matte = withContext(Dispatchers.IO) { VideoBackground.run(context, layer, media, videoSide, keep, report).also { result = it.media } }
                    ensureActive()
                    check(state.scene.layer(layer.id) == layer) { AppText.get(R.string.ai_layer_changed) }
                    val groupId = Layer.newId()
                    val next = checkNotNull(state.scene.withVideoMatte(layer, matte.media.declaration, matte.frameWidth, matte.frameHeight, Layer.newId(), groupId)) { AppText.get(R.string.ai_cannot_mask) }
                    state.edit { next.update(groupId) { it.withAiMark(AiKind.Video, null, null) } }
                    state.selectedId = groupId
                } else if (action == AiAction.Smooth) {
                    val previous = layer.aiMarks.firstOrNull { it.kind == AiKind.Smooth }
                    val base = layer.smoothSource(previous)
                    val source = base.mediaFill!!.uri
                    val media = checkNotNull(previous?.media ?: state.scene.media(source)) { AppText.get(R.string.ai_video_missing) }
                    val chosen = smoothing
                    if (chosen.method == FrameInterpolation.Ai && !AiSmooth.installed(context, chosen.level)) {
                        report(0f, AppText.get(R.string.ai_downloading_model))
                        AiSmooth.download(context, chosen.level) { fraction -> progress = fraction.coerceIn(0f, 1f) }
                    }
                    val fps = state.scene.fps
                    val facts = smoothPlan(base, media, fps, chosen)?.let { smoothFacts(base, it, fps) }.orEmpty()
                    val output = withContext(Dispatchers.IO) {
                        ClipSmooth.run(context, state.engine, base, media, fps, chosen, report).also { result = it }
                    }
                    ensureActive()
                    check(state.scene.layer(layer.id) == layer) { AppText.get(R.string.ai_layer_changed) }
                    state.edit { scene ->
                        scene.update(layer.id) { it.withSmoothed(output.declaration.uri, source, chosen.option, media, base, facts) }.withMedia(output.declaration)
                    }
                } else if (action == AiAction.Reverse) {
                    val media = checkNotNull(state.scene.media(layer.mediaFill!!.uri)) { AppText.get(R.string.ai_video_missing) }
                    val output = withContext(Dispatchers.IO) { ClipReverse.run(context, layer, media, report).also { result = it.media } }
                    ensureActive()
                    check(state.scene.layer(layer.id) == layer) { AppText.get(R.string.ai_layer_changed) }
                    state.edit { scene ->
                        scene.update(layer.id) { it.reversedTo(output.media.declaration.uri, output.mirrorUs, media) }.withMedia(output.media.declaration)
                    }
                } else {
                    val mark = layer.backgroundMark?.takeIf { action == AiAction.Background }
                    val source = if (action == AiAction.Noise) layer.node["src"]!! else mark?.original ?: layer.node["fillImage"]!!
                    val original = state.scene.media(source) ?: mark?.media
                    val cutout = Cutout(subject, edge, avoid)
                    var note: Int? = null
                    withContext(Dispatchers.IO) {
                        result = when (action) {
                            AiAction.Background -> {
                                val limit = state.engine.maxPictureSize()
                                val pick = precisePick && cutout.keep.isNotEmpty() && AiNative.loaded && !com.effects.motion.platform.PlatformFeatures.desktop
                                bestOrStandard(if (pick) CutoutQuality.Best else CutoutChoice.of(context).quality(BestCutout.offered),
                                    install = {
                                        if (pick) {
                                            if (!AiModel.EdgeTam.installed(context)) report(0f, AppText.get(R.string.ai_downloading_model))
                                            EdgeCutout.install(context) { fraction -> progress = fraction.coerceIn(0f, 1f) }
                                        } else {
                                            if (!AiModel.Cutout.installed(context)) report(0f, AppText.get(R.string.ai_downloading_model))
                                            BestCutout.install(context) { fraction -> progress = fraction.coerceIn(0f, 1f) }
                                        }
                                    },
                                    best = { if (pick) EdgeCutout.run(context, source, original, limit, cutout, report) else BestCutout.run(context, source, original, limit, cutout, report) },
                                    standard = { BackgroundRemoval.run(context, source, original, limit, cutout, report) },
                                ).also { note = it.note }.value
                            }
                            else -> NoiseReduction.run(context, source, noiseSource, report)
                        }
                    }
                    ensureActive()
                    check(state.scene.layer(layer.id) == layer) { AppText.get(R.string.ai_layer_changed) }
                    val output = result!!
                    val kind = if (action == AiAction.Noise) AiKind.Noise else AiKind.Background
                    val used = noiseSource
                    state.edit { scene ->
                        scene.update(layer.id) { current ->
                            val base = if (kind == AiKind.Background && mark == null) current.withoutAiMark(kind) else current
                            base.copy(node = base.node.with(kind.attribute!!, output.declaration.uri))
                                .withAiMark(kind, base.node[kind.attribute], output.declaration.uri, if (kind == AiKind.Noise) used.xml else cutout.option, original)
                        }.withMedia(output.declaration)
                    }
                    fallback = note
                }
                committed = true
                message = fallback?.let { AppText.get(it) } ?: ""
                if (fallback == null && action != AiAction.Reverse && state.panel != EditorPanel.Speed) {
                    state.panel = EditorPanel.Tools
                    state.effectBrowserOpen = false
                }
            } } } catch (_: CancellationException) {
                message = AppText.get(R.string.ai_cancelled)
            } catch (e: ModelNotReady) {
                message = e.message ?: AppText.get(R.string.ai_model_not_ready_default); retry = action
            } catch (e: Exception) {
                message = com.effects.motion.i18n.failureText(AppText.get(R.string.ai_unable_to_process), e); retry = action
            } catch (_: OutOfMemoryError) {
                message = AppText.get(if (action == AiAction.Background) R.string.ai_out_of_memory_image else R.string.ai_out_of_memory_media); retry = action
            } catch (_: LinkageError) {
                message = AppText.get(when (action) {
                    AiAction.Noise -> R.string.ai_noise_unavailable
                    AiAction.Enhance -> R.string.ai_runtime_unavailable
                    else -> R.string.ai_background_unavailable
                })
            } finally {
                if (!committed) result?.file?.delete()
                running = null
            }
        }
    }
}

internal const val MAX_MATTE_PIXELS = 16_000_000L

internal fun matteLimit(width: Int, height: Int, limit: Int, maxPixels: Long = MAX_MATTE_PIXELS): Int {
    val side = maxOf(width, height)
    val fit = (side * sqrt(maxPixels.toDouble() / (width.toLong() * height))).toLong()
    return minOf(limit.toLong(), fit).toInt().coerceAtLeast(1)
}

internal fun aiFile(context: Context, extension: String): File {
    val directory = File(checkNotNull(context.getExternalFilesDir(null)) { AppText.get(R.string.ai_storage_unavailable) }, "ai")
    check(directory.isDirectory || directory.mkdirs()) { AppText.get(R.string.ai_storage_cannot_create) }
    return File(directory, "${UUID.randomUUID()}.$extension")
}

internal fun aiMedia(context: Context, file: File, type: String, extra: Map<String, String>): AiMedia {
    val uri = FileProvider.getUriForFile(context, "${context.packageName}.files", file).toString()
    return AiMedia(file, MediaDeclaration(XmlNode("media", linkedMapOf(
        "uri" to uri, "filename" to file.name, "title" to file.name, "type" to type,
        "size" to "${file.length()}", "infoUpdated" to "${System.currentTimeMillis()}",
    ) + extra)))
}

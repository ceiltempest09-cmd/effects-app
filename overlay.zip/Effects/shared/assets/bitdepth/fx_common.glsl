// fx_common.glsl — shared header, inserted by ComposeFragment() AFTER these injected defines:
//   FX_PREC (lowp|mediump|highp)   FX_PREC_LOW (only for lowp)
//   FX_FLOAT_BUFFER                (buffers are RGBA16F/32F: linear-light, values may exceed 1.0)
//   FX_MANUAL_BILINEAR             (32F target without OES_texture_float_linear)

// 1) Default precision for per-pixel colour math = the per-effect override.
precision FX_PREC float;
precision FX_PREC int;
// Samplers stay highp: sampler precision is independent of math precision and costs nothing.
precision highp sampler2D;

// 2) Accumulators (blur sums, running totals) are never allowed to be lowp, even when the user
//    picks lowp for colour math: summing many lowp values is the classic source of banding.
#ifdef FX_PREC_LOW
  #define FX_ACC mediump
#else
  #define FX_ACC FX_PREC
#endif

// 3) Colour-space helpers. Convention:
//      RGBA8 buffers   -> sRGB-encoded (display-referred). Linear math here would band in the darks.
//      Float buffers   -> linear-light (scene-referred). Values >1.0 and <0.0 are preserved.
//    fxDecode()/fxEncode() hide that, so effect code always does maths in LINEAR light.
vec3 fxSrgbToLinear(vec3 c) {
    c = max(c, 0.0);
    return mix(c / 12.92, pow((c + 0.055) / 1.055, vec3(2.4)), step(vec3(0.04045), c));
}
vec3 fxLinearToSrgb(vec3 c) {
    c = max(c, 0.0);     // pow() of a negative is NaN, and NaN * 0.0 is still NaN inside mix()
    return mix(c * 12.92, 1.055 * pow(c, vec3(1.0 / 2.4)) - 0.055, step(vec3(0.0031308), c));
}
#ifdef FX_FLOAT_BUFFER
  vec3 fxDecode(vec3 c)    { return c; }                        // already linear
  vec3 fxEncode(vec3 c)    { return c; }
  vec3 fxToDisplay(vec3 c) { return fxLinearToSrgb(c); }        // only the final output pass uses this
#else
  vec3 fxDecode(vec3 c)    { return fxSrgbToLinear(c); }
  vec3 fxEncode(vec3 c)    { return fxLinearToSrgb(c); }
  vec3 fxToDisplay(vec3 c) { return c; }                        // already display-referred
#endif

// 4) Texture fetch. Uses hardware filtering normally; emulates bilinear with texelFetch when the
//    target is RGBA32F and the GPU can't filter it (otherwise the sampler returns black/garbage).
vec4 fxSample(sampler2D t, highp vec2 uv) {
#ifdef FX_MANUAL_BILINEAR
    ivec2 sz = textureSize(t, 0);
    highp vec2 p = uv * vec2(sz) - 0.5;
    highp vec2 i = floor(p);
    highp vec2 f = p - i;
    ivec2 lo = clamp(ivec2(i), ivec2(0), sz - 1);
    ivec2 hi = clamp(ivec2(i) + 1, ivec2(0), sz - 1);
    vec4 s00 = texelFetch(t, ivec2(lo.x, lo.y), 0);
    vec4 s10 = texelFetch(t, ivec2(hi.x, lo.y), 0);
    vec4 s01 = texelFetch(t, ivec2(lo.x, hi.y), 0);
    vec4 s11 = texelFetch(t, ivec2(hi.x, hi.y), 0);
    return mix(mix(s00, s10, f.x), mix(s01, s11, f.x), f.y);
#else
    return texture(t, uv);
#endif
}

// 5) Triangular-PDF dither (+-1 LSB) from interleaved gradient noise. Add it in DISPLAY space,
//    immediately before the value is quantised to 8/10 bits. `levels` = 255.0 or 1023.0.
float fxIGN(highp vec2 p) { return fract(52.9829189 * fract(dot(p, vec2(0.06711056, 0.00583715)))); }
vec3 fxDither(vec3 c, highp vec2 fragCoord, float levels) {
    float n = fxIGN(fragCoord) + fxIGN(fragCoord + 5.588238) - 1.0;   // triangular, range [-1, 1]
    return c + n / levels;
}

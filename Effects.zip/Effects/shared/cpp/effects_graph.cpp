#include "effects_graph.h"
#include "platform_log.h"
#ifndef LOGW
#define LOGW(...) __android_log_print(ANDROID_LOG_WARN, "AMGraph", __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, "AMGraph", __VA_ARGS__)
#endif
#include "render_graph_xml.h"

#include "include/core/SkColorSpace.h"
#include "include/core/SkData.h"
#include "include/core/SkImageInfo.h"
#include "include/core/SkPaint.h"
#include "include/core/SkSurface.h"

#include <algorithm>
#include <cstring>
#include <map>
#include <mutex>

namespace am {
namespace {

uint64_t Fnv(const std::string& s, uint64_t h = 1469598103934665603ull) {
    for (unsigned char c : s) { h ^= c; h *= 1099511628211ull; }
    return h;
}

// Compiled SkSL is device independent; the GPU programs are cached by Skia itself. Key: source + defines + backend + capability set.
std::mutex gCacheLock;
std::map<uint64_t, sk_sp<SkRuntimeEffect>> gCache;

sk_sp<SkRuntimeEffect> Compile(const rg::PassDesc& p, std::string* errorText) {
    std::string key = p.source;
    for (const auto& d : p.defines) key += "\n#" + d.first + "=" + d.second;
    key += "\nbackend=skia;shader";
    const uint64_t h = Fnv(key);
    {
        std::lock_guard<std::mutex> lock(gCacheLock);
        auto it = gCache.find(h);
        if (it != gCache.end()) return it->second;
    }
    auto result = SkRuntimeEffect::MakeForShader(SkString(p.source.c_str()));
    if (!result.effect) { *errorText = result.errorText.c_str(); return nullptr; }
    std::lock_guard<std::mutex> lock(gCacheLock);
    if (gCache.size() > 512) gCache.clear();
    gCache[h] = result.effect;
    return result.effect;
}

// "error: 12: message" -> shifts the SkSL line into the pass' file coordinates.
std::string Located(const rg::PassDesc& p, int index, const std::string& effect, const std::string& skslError) {
    rg::Diag d;
    d.kind = rg::DiagKind::Translation;
    d.effect = effect;
    d.pass = p.id;
    d.passIndex = index;
    d.backend = "skia/sksl";
    d.file = p.file;
    std::string msg = skslError;
    const size_t eol = msg.find('\n');
    std::string first = msg.substr(0, eol);
    const size_t e = first.find("error: ");
    if (e != std::string::npos) {
        first = first.substr(e + 7);
        const size_t colon = first.find(':');
        if (colon != std::string::npos && colon > 0 && std::all_of(first.begin(), first.begin() + colon, [](char c) { return std::isdigit((unsigned char)c); })) {
            d.line = p.line + std::atoi(first.c_str()) - 1;
            first = first.substr(colon + 1);
        }
    }
    while (!first.empty() && first[0] == ' ') first.erase(0, 1);
    d.message = first;
    return d.format();
}

bool EndsWith(const std::string& s, const char* suffix) {
    const size_t n = std::strlen(suffix);
    return s.size() >= n && s.compare(s.size() - n, n, suffix) == 0;
}

}  // namespace

std::string CompileGraph(const XmlNode& root, const std::set<std::string>& controls, std::shared_ptr<const GraphProgram>* out) {
    rg::GraphDesc desc;
    std::vector<rg::Diag> diags;
    const bool readOk = rg::ParseGraphXml(root, &desc, &diags);
    std::string errors;
    auto addAll = [&](const std::vector<rg::Diag>& list) {
        for (const rg::Diag& d : list) if (d.error) errors += (errors.empty() ? "" : "\n") + d.format();
    };
    if (!readOk) { addAll(diags); return "shader error: " + errors; }

    rg::PlanOptions options;
    options.backend = "skia";
    options.languages = {rg::Lang::SkSL};
    auto plan = std::make_shared<rg::Plan>(rg::BuildPlan(desc, options));
    addAll(plan->diags);
    if (!plan->ok()) return "shader error: " + (errors.empty() ? std::string("the render graph is not valid") : errors);
    for (const rg::Diag& d : plan->diags) if (!d.error) LOGW("%s", d.format().c_str());

    if (plan->desc.seek == rg::SeekMode::Replay) {
        return "shader error: " + rg::Diag{true, rg::DiagKind::Capability, plan->desc.effectId, "", "skia", "", "seek=\"replay\" needs the engine to re-render the layer at earlier frames, which this build cannot do. Use seek=\"reset\".", -1, 0}.format();
    }

    auto program = std::make_shared<GraphProgram>();
    program->effects.assign(plan->desc.passes.size(), nullptr);
    program->temporal = plan->temporal;
    program->timed = plan->temporal;
    for (const rg::Step& step : plan->steps) {
        const rg::PassDesc& p = plan->desc.passes[step.pass];
        std::string text;
        sk_sp<SkRuntimeEffect> effect = Compile(p, &text);
        if (!effect) { errors += (errors.empty() ? "" : "\n") + Located(p, step.pass, plan->desc.effectId, text); continue; }
        auto fail = [&](const std::string& msg) {
            rg::Diag d;
            d.kind = rg::DiagKind::Translation; d.effect = plan->desc.effectId; d.pass = p.id; d.passIndex = step.pass; d.backend = "skia/sksl"; d.file = p.file; d.line = p.line;
            d.message = msg;
            errors += (errors.empty() ? "" : "\n") + d.format();
        };
        std::set<std::string> inputs;
        for (const rg::ResolvedInput& in : step.inputs) inputs.insert(in.name);
        for (const auto& c : effect->children()) {
            if (!inputs.count(std::string(c.name))) fail("declares 'uniform shader " + std::string(c.name) + "' but the pass has no input with that name");
        }
        for (const std::string& n : inputs) if (!effect->findChild(n.c_str())) fail("input '" + n + "' is not used: add 'uniform shader " + n + ";' to the shader or remove the input");
        for (const auto& u : effect->uniforms()) {
            const std::string name(u.name);
            const bool constant = std::any_of(p.constants.begin(), p.constants.end(), [&](const rg::Constant& c) { return c.name == name; });
            const bool engine = name == "size" || name == "time" || name == "frame" || name == "out_px";
            const bool texel = EndsWith(name, "_px") && inputs.count(name.substr(0, name.size() - 3));
            if (!constant && !engine && !texel && !controls.count(name))
                fail("uniform '" + name + "' has no control, constant or engine value (engine values: size, time, frame, out_px, <input>_px)");
            if (name == "time" || name == "frame") program->timed = true;
        }
        program->effects[step.pass] = effect;
    }
    if (!errors.empty()) return "shader error: " + errors;
    program->plan = plan;
    *out = program;
    return "ok";
}

// ------------------------------------------------------------------ backend
namespace {
SkColorType ColorTypeOf(rg::Format f) {
    switch (f) {
        case rg::Format::RGBA16F: return kRGBA_F16_SkColorType;
        case rg::Format::RGBA32F: return kRGBA_F32_SkColorType;
        default: return kRGBA_8888_SkColorType;
    }
}
SkTileMode TileOf(rg::Wrap w) {
    switch (w) {
        case rg::Wrap::Repeat: return SkTileMode::kRepeat;
        case rg::Wrap::Mirror: return SkTileMode::kMirror;
        case rg::Wrap::Decal: return SkTileMode::kDecal;
        default: return SkTileMode::kClamp;
    }
}
SkBlendMode BlendOf(rg::Blend b) {
    switch (b) {
        case rg::Blend::SrcOver: return SkBlendMode::kSrcOver;
        case rg::Blend::Add: return SkBlendMode::kPlus;
        case rg::Blend::Multiply: return SkBlendMode::kMultiply;
        case rg::Blend::Screen: return SkBlendMode::kScreen;
        default: return SkBlendMode::kSrc;
    }
}
}  // namespace

class GraphRunner::SkiaBackend : public rg::Backend {
public:
    struct Image : rg::Target {
        sk_sp<SkSurface> surface;       // render target (null for wrapped images)
        sk_sp<SkImage> wrapped;
        sk_sp<SkImage> snapshot;
        sk_sp<SkImage> image() {
            if (wrapped) return wrapped;
            if (!snapshot && surface) snapshot = surface->makeImageSnapshot();   // copy-on-write: later writes do not change what was handed out
            return snapshot;
        }
    };

    explicit SkiaBackend(const GraphProgram& program) : fProgram(program) {}

    void begin(SkCanvas* canvas, const GraphFrame* frame, const std::function<sk_sp<SkImage>(const sk_sp<SkImage>&)>* upload) {
        fCanvas = canvas;
        fFrame = frame;
        fUpload = upload;
        sk_sp<SkColorSpace> space = canvas->imageInfo().refColorSpace();
        if (!space) space = SkColorSpace::MakeSRGB();
        if (fSpace && !SkColorSpace::Equals(fSpace.get(), space.get())) {
            fBlanks.clear();
            fTextures.clear();
            fNeedsDrop = true;                               // targets carry the old colour space: the executor drops them
        }
        fSpace = space;
    }
    bool takeDropRequest() { const bool r = fNeedsDrop; fNeedsDrop = false; return r; }
    void forget() { fBlanks.clear(); fTextures.clear(); fSource.reset(); fF16 = fF32 = -1; fCanvas = nullptr; }

    rg::Target* wrapSource(const sk_sp<SkImage>& image) {
        fSource = std::make_unique<Image>();
        fSource->wrapped = image;
        fSource->width = image->width();
        fSource->height = image->height();
        return fSource.get();
    }

    const char* name() const override { return "skia"; }
    bool supports(rg::Lang l) const override { return l == rg::Lang::SkSL; }
    bool supports(rg::Format f) const override {
        if (f == rg::Format::RGBA8 || f == rg::Format::Inherit) return true;
        int& cached = f == rg::Format::RGBA16F ? fF16 : fF32;
        if (cached < 0) cached = fCanvas && probe(f) ? 1 : 0;           // ask the real GPU: can it create AND render this format?
        return cached == 1;
    }
    // Intermediates are not quantised to 8 bits when the device can hold half floats.
    rg::Format workingFormat() const override { return supports(rg::Format::RGBA16F) ? rg::Format::RGBA16F : rg::Format::RGBA8; }
    int maxTextureSize() const override { return 8192; }

    rg::Target* create(int w, int h, rg::Format f) override {
        auto* t = new Image();
        t->surface = fCanvas ? fCanvas->makeSurface(SkImageInfo::Make(w, h, ColorTypeOf(f), kPremul_SkAlphaType, fSpace)) : nullptr;
        if (!t->surface) { delete t; return nullptr; }
        t->surface->getCanvas()->clear(SK_ColorTRANSPARENT);
        return t;
    }
    void destroy(rg::Target* t) override { delete static_cast<Image*>(t); }

    rg::Target* texture(const rg::TextureDesc& td) override {
        auto it = fTextures.find(td.id);
        if (it != fTextures.end()) return it->second.get();
        auto t = std::make_unique<Image>();
        std::vector<uint8_t> px(td.width * td.height * 4);
        if (td.source == "builtin:noise") px = rg::NoisePixels(td.width, td.height, td.seed);
        else for (int y = 0; y < td.height; y++) for (int x = 0; x < td.width; x++) {
            const uint8_t v = (uint8_t)std::lround(255.0 * (td.source == "builtin:ramp-x" ? (x + 0.5) / td.width : (y + 0.5) / td.height));
            uint8_t* p = &px[((size_t)y * td.width + x) * 4];
            p[0] = p[1] = p[2] = v; p[3] = 255;
        }
        const SkImageInfo info = SkImageInfo::Make(td.width, td.height, kRGBA_8888_SkColorType, kPremul_SkAlphaType, fSpace);
        sk_sp<SkImage> raster = SkImages::RasterFromData(info, SkData::MakeWithCopy(px.data(), px.size()), (size_t)td.width * 4);
        t->wrapped = fUpload && *fUpload ? (*fUpload)(raster) : raster;
        if (!t->wrapped) return nullptr;
        t->width = td.width; t->height = td.height;
        rg::Target* raw = t.get();
        fTextures[td.id] = std::move(t);
        return raw;
    }

    rg::Target* blank(int w, int h, rg::Format f) override {
        const std::string key = std::to_string(w) + "x" + std::to_string(h) + ":" + rg::ToString(f);
        auto it = fBlanks.find(key);
        if (it != fBlanks.end()) return it->second.get();
        std::unique_ptr<rg::Target> t(create(w, h, f));
        if (!t) return nullptr;
        t->width = w; t->height = h; t->format = f;
        rg::Target* raw = t.get();
        fBlanks[key] = std::move(t);
        return raw;
    }

    bool run(const rg::PassRun& run, std::string* error) override {
        const int index = (int)(run.pass - fProgram.plan->desc.passes.data());
        const sk_sp<SkRuntimeEffect>& effect = fProgram.effects[index];
        if (!effect) { *error = "the pass was not compiled"; return false; }
        auto* out = static_cast<Image*>(run.output);
        if (!out->surface) { *error = "the output target has no surface"; return false; }

        SkRuntimeShaderBuilder builder(effect);
        const float areaW = (float)run.areaWidth, areaH = (float)run.areaHeight;
        std::map<std::string, SkISize> pixels;
        for (const rg::BoundInput& in : run.inputs) {
            auto* img = static_cast<Image*>(in.target);
            sk_sp<SkImage> image = img->image();
            if (!image) { *error = "input '" + *in.name + "' has no image"; return false; }
            // All shaders work in effect-area coordinates; each input is mapped onto the area whatever its own resolution.
            const SkMatrix toArea = SkMatrix::Scale(areaW / image->width(), areaH / image->height());
            const SkSamplingOptions sampling(in.filter == rg::Filter::Nearest ? SkFilterMode::kNearest : SkFilterMode::kLinear);
            const SkTileMode tile = TileOf(in.wrap);
            builder.child(in.name->c_str()) = image->makeShader(tile, tile, sampling, &toArea);
            pixels[*in.name] = {image->width(), image->height()};
        }
        for (const SkRuntimeEffect::Uniform& u : effect->uniforms()) {
            const std::string name(u.name);
            const int n = (int)(u.sizeInBytes() / 4);
            std::vector<float> v(n, 0.0f);
            bool known = true;
            const auto constant = std::find_if(run.pass->constants.begin(), run.pass->constants.end(), [&](const rg::Constant& c) { return c.name == name; });
            if (constant != run.pass->constants.end()) { for (int i = 0; i < n && i < (int)constant->value.size(); i++) v[i] = constant->value[i]; }
            else if (name == "size") { v[0] = areaW; if (n > 1) v[1] = areaH; }
            else if (name == "time") v[0] = fFrame->seconds;
            else if (name == "frame") v[0] = (float)run.frame;
            else if (name == "out_px") { v[0] = (float)out->width; if (n > 1) v[1] = (float)out->height; }
            else if (EndsWith(name, "_px") && pixels.count(name.substr(0, name.size() - 3))) {
                const SkISize s = pixels[name.substr(0, name.size() - 3)];
                v[0] = (float)s.width(); if (n > 1) v[1] = (float)s.height();
            } else known = fFrame->control && fFrame->control(u, v.data());
            if (!known) { *error = "uniform '" + name + "' has no value"; return false; }
            if (u.type >= SkRuntimeEffect::Uniform::Type::kInt) {
                std::vector<int> ints(v.begin(), v.end());
                builder.uniform(u.name).set(ints.data(), n);
            } else {
                builder.uniform(u.name).set(v.data(), n);
            }
        }
        sk_sp<SkShader> shader = builder.makeShader();
        if (!shader) { *error = "Skia could not create the shader (inputs/uniforms do not match the SkSL)"; return false; }
        SkCanvas* c = out->surface->getCanvas();
        c->save();
        c->scale((float)out->width / areaW, (float)out->height / areaH);   // buffer pixels <-> area coordinates
        if (run.clear) c->clear(SK_ColorTRANSPARENT);
        SkPaint paint;
        paint.setShader(std::move(shader));
        paint.setBlendMode(BlendOf(run.pass->blend));
        c->drawRect(SkRect::MakeWH(areaW, areaH), paint);
        c->restore();
        out->snapshot.reset();
        return true;
    }

private:
    bool probe(rg::Format f) const {
        sk_sp<SkSurface> s = fCanvas->makeSurface(SkImageInfo::Make(8, 8, ColorTypeOf(f), kPremul_SkAlphaType, fSpace ? fSpace : SkColorSpace::MakeSRGB()));
        if (!s) return false;
        s->getCanvas()->clear(SK_ColorTRANSPARENT);
        return true;
    }

    const GraphProgram& fProgram;
    SkCanvas* fCanvas = nullptr;
    const GraphFrame* fFrame = nullptr;
    const std::function<sk_sp<SkImage>(const sk_sp<SkImage>&)>* fUpload = nullptr;
    sk_sp<SkColorSpace> fSpace;
    mutable int fF16 = -1, fF32 = -1;
    bool fNeedsDrop = false;
    std::unique_ptr<Image> fSource;
    std::map<std::string, std::unique_ptr<rg::Target>> fBlanks;
    std::map<std::string, std::unique_ptr<Image>> fTextures;
};

GraphRunner::GraphRunner(std::shared_ptr<const GraphProgram> program) : fProgram(std::move(program)) {
    fBackend = std::make_unique<SkiaBackend>(*fProgram);
    fExecutor = std::make_unique<rg::Executor>(*fBackend, fProgram->plan);
}

GraphRunner::~GraphRunner() { fExecutor.reset(); }   // returns every target through the backend before it goes away

bool GraphRunner::render(SkCanvas* canvas, const sk_sp<SkImage>& source, const GraphFrame& frame,
                         const std::function<sk_sp<SkImage>(const sk_sp<SkImage>&)>& upload, sk_sp<SkImage>* result, std::string* error) {
    if (!canvas || !source) { *error = "no canvas or source image"; return false; }
    fBackend->begin(canvas, &frame, &upload);
    if (fBackend->takeDropRequest()) fExecutor->dropAll();
    rg::FrameRequest request;
    request.frame = frame.frame;
    request.width = frame.width;
    request.height = frame.height;
    request.signature = frame.signature;
    request.source = fBackend->wrapSource(source);
    sk_sp<SkImage> image;
    fLast = fExecutor->render(request, [&](rg::Target* t) { image = static_cast<SkiaBackend::Image*>(t)->image(); });
    for (const rg::Diag& d : fLast.notes) LOGW("%s", d.format().c_str());
    if (fLast.status != rg::FrameResult::Ok || !image) {
        *error = fLast.error.empty() ? "the graph produced no image" : fLast.error;
        if (*error != fLastError) LOGE("%s", error->c_str());
        fLastError = *error;
        return false;
    }
    fLastError.clear();
    *result = std::move(image);
    return true;
}

void GraphRunner::drop() {
    fExecutor->dropAll();
    fBackend->forget();
}

void GraphRunner::trim() { fExecutor->trimIdle(); }

std::string GraphRunner::report() const {
    const rg::TargetPool::Stats s = fExecutor->poolStats();
    std::string out = "{\"effect\":\"" + fProgram->plan->desc.effectId + "\",\"passes\":[";
    for (size_t i = 0; i < fLast.timings.size(); i++) {
        const rg::PassTiming& t = fLast.timings[i];
        out += (i ? "," : "") + std::string("{\"pass\":\"") + t.pass + "\",\"cpuUs\":" + std::to_string(t.cpuNs / 1000) + ",\"gpuUs\":" + std::to_string(t.gpuNs < 0 ? -1 : t.gpuNs / 1000) + "}";
    }
    out += "],\"pool\":{\"created\":" + std::to_string(s.created) + ",\"reused\":" + std::to_string(s.reused) + ",\"live\":" + std::to_string(s.live) +
           ",\"idle\":" + std::to_string(s.idle) + ",\"bytes\":" + std::to_string(s.bytes) + ",\"peakBytes\":" + std::to_string(s.peakBytes) + "}";
    out += ",\"historyReset\":" + std::string(fLast.historyReset ? "true" : "false") + "}";
    return out;
}

}  // namespace am

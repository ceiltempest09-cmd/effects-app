package com.effects.motion

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.graphics.Typeface
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import com.effects.motion.engine.GpuSelfTest
import java.io.File
import kotlin.concurrent.thread

/** A separate launcher icon ("GPU Test"): runs the native GPU self-test on this phone and shows the report as text. */
class GpuTestActivity : Activity() {
    private lateinit var out: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (16 * resources.displayMetrics.density).toInt()
        val run = Button(this).apply { text = "Run GPU test" }
        val copy = Button(this).apply { text = "Copy report" }
        out = TextView(this).apply { typeface = Typeface.MONOSPACE; textSize = 11f; setTextIsSelectable(true); text = "Tap Run GPU test." }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 2, pad, pad)
            addView(run); addView(copy)
            addView(ScrollView(this@GpuTestActivity).apply { addView(out) })
        }
        setContentView(root)
        run.setOnClickListener {
            out.text = "Running..."
            run.isEnabled = false
            thread {
                val report = try {
                    GpuSelfTest.run(File(cacheDir, "gpu-selftest").absolutePath)
                } catch (t: Throwable) {
                    "The test crashed: $t"
                }
                runOnUiThread { out.text = report; run.isEnabled = true }
            }
        }
        copy.setOnClickListener {
            (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("gpu report", out.text))
            Toast.makeText(this, "Copied", Toast.LENGTH_SHORT).show()
        }
    }
}

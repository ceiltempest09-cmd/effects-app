#include "shader_diag.h"

#include <cctype>
#include <cstdlib>

namespace am::rg {
namespace {

bool AllDigits(const std::string& s) {
    if (s.empty()) return false;
    for (char c : s) if (!std::isdigit((unsigned char)c)) return false;
    return true;
}

std::string Trim(std::string s) {
    while (!s.empty() && std::isspace((unsigned char)s.front())) s.erase(0, 1);
    while (!s.empty() && std::isspace((unsigned char)s.back())) s.pop_back();
    return s;
}

bool Parse(const std::string& raw, LogEntry* e) {
    std::string s = Trim(raw);
    if (s.empty()) return false;
    // Mesa: "0:12(3): error: message"
    {
        const size_t c1 = s.find(':');
        if (c1 != std::string::npos && AllDigits(s.substr(0, c1))) {
            const size_t par = s.find('(', c1);
            const size_t colon2 = s.find(':', c1 + 1);
            if (par != std::string::npos && par < colon2 && AllDigits(s.substr(c1 + 1, par - c1 - 1))) {
                const size_t close = s.find(')', par);
                if (close != std::string::npos) {
                    e->line = std::atoi(s.c_str() + c1 + 1);
                    e->column = std::atoi(s.c_str() + par + 1);
                    std::string rest = Trim(s.substr(close + 1));
                    if (!rest.empty() && rest[0] == ':') rest = Trim(rest.substr(1));
                    e->error = rest.rfind("warning", 0) != 0;
                    const size_t kind = rest.find(':');
                    if (kind != std::string::npos && (rest.rfind("error", 0) == 0 || rest.rfind("warning", 0) == 0)) rest = Trim(rest.substr(kind + 1));
                    e->message = rest;
                    return true;
                }
            }
        }
    }
    // "ERROR: <file-or-index>:<line>[:<col>]: message"   /   "WARNING: ..."
    bool error = true;
    std::string body;
    if (s.rfind("ERROR:", 0) == 0) body = Trim(s.substr(6));
    else if (s.rfind("WARNING:", 0) == 0) { error = false; body = Trim(s.substr(8)); }
    else if (s.rfind("error:", 0) == 0) body = Trim(s.substr(6));       // "error: 12: message" (no file part)
    else if (s.rfind("warning:", 0) == 0) { error = false; body = Trim(s.substr(8)); }
    else {
        // "file.frag:12: error: message"
        const size_t k = s.find(": error:");
        const size_t w = s.find(": warning:");
        const size_t at = k != std::string::npos ? k : w;
        if (at == std::string::npos) return false;
        error = k != std::string::npos;
        const std::string head = s.substr(0, at);
        const size_t colon = head.rfind(':');
        if (colon == std::string::npos || !AllDigits(head.substr(colon + 1))) return false;
        e->error = error;
        e->line = std::atoi(head.c_str() + colon + 1);
        e->message = Trim(s.substr(at + (error ? 8 : 10)));
        return true;
    }
    e->error = error;
    // body: "0:12: message" | "path/x.frag:12: message" | "12: message" | "message"
    std::vector<size_t> colons;
    for (size_t i = 0; i < body.size() && colons.size() < 3; i++) if (body[i] == ':') colons.push_back(i);
    if (colons.size() >= 2 && AllDigits(body.substr(colons[0] + 1, colons[1] - colons[0] - 1))) {      // <file>:<line>:
        e->line = std::atoi(body.c_str() + colons[0] + 1);
        size_t msg = colons[1] + 1;
        if (colons.size() >= 3 && AllDigits(Trim(body.substr(colons[1] + 1, colons[2] - colons[1] - 1)))) {   // <file>:<line>:<col>:
            e->column = std::atoi(body.c_str() + colons[1] + 1);
            msg = colons[2] + 1;
        }
        e->message = Trim(body.substr(msg));
    } else if (!colons.empty() && AllDigits(body.substr(0, colons[0]))) {                              // <line>:
        e->line = std::atoi(body.c_str());
        e->message = Trim(body.substr(colons[0] + 1));
    } else {
        e->message = body;
    }
    return true;
}

}  // namespace

std::vector<LogEntry> ParseCompilerLog(const std::string& log) {
    std::vector<LogEntry> out;
    size_t pos = 0;
    while (pos < log.size()) {
        size_t eol = log.find('\n', pos);
        if (eol == std::string::npos) eol = log.size();
        LogEntry e;
        if (Parse(log.substr(pos, eol - pos), &e)) out.push_back(std::move(e));
        else if (!out.empty()) {                                    // continuation line of the previous message
            const std::string more = Trim(log.substr(pos, eol - pos));
            if (!more.empty() && more.rfind("ERROR:", 0) != 0 && more.rfind("WARNING:", 0) != 0 && more.rfind("N errors", 0) != 0 && more.find(" compilation error") == std::string::npos)
                out.back().message += " " + more;
        }
        pos = eol + 1;
    }
    return out;
}

std::vector<Diag> MapCompilerLog(const PassDesc& pass, int passIndex, const std::string& effect, const std::string& backend,
                                 const std::string& log, int preludeLines) {
    std::vector<Diag> out;
    for (const LogEntry& e : ParseCompilerLog(log)) {
        Diag d;
        d.error = e.error;
        d.kind = DiagKind::Translation;
        d.effect = effect;
        d.pass = pass.id;
        d.passIndex = passIndex;
        d.backend = backend;
        d.file = pass.file;
        d.line = e.line > 0 ? std::max(pass.line, pass.line + (e.line - preludeLines) - 1) : pass.line;
        d.message = e.message.empty() ? "shader compile error" : e.message;
        out.push_back(std::move(d));
    }
    return out;
}

}  // namespace am::rg

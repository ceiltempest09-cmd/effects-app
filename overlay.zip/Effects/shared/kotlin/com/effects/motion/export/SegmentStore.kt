package com.effects.motion.export

import android.content.Context
import android.media.MediaCodec
import android.util.Base64
import android.util.Log
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileOutputStream
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.util.zip.CRC32

/** Thrown when Smart Export cannot guarantee the result. The caller discards the file and renders everything the normal way. */
/** [benign] fallbacks are expected sometimes (another encoder than last time); they never count against Smart Export on this device. */
internal class SmartFallback(message: String, cause: Throwable? = null, val benign: Boolean = false) : Exception(message, cause)

/** What the video stream of an export looks like. Packets are only spliced next to packets of an identical stream. */
internal class StreamFormat(val mime: String, val width: Int, val height: Int, val csd: List<ByteArray>) {
    fun matches(o: StreamFormat): Boolean =
        mime == o.mime && width == o.width && height == o.height && csd.size == o.csd.size && csd.indices.all { csd[it].contentEquals(o.csd[it]) }
}

/** One saved export: its project as it was rendered, the settings key, and the encoded groups of pictures. */
internal class SmartEntry(
    val dir: File, val ctx: String, val scene: String, val frames: Int, val media: Map<String, String>,
    val format: StreamFormat, val path: String, val gops: List<CachedGop>, val blob: File,
)

/**
 * Saved encoded video of earlier exports (app-private storage, one folder per export):
 *   meta.json  written last, by rename, so a crash never leaves a half-valid entry
 *   video.bin  records of [pts: long][flags: int][size: int][payload], grouped per group of pictures; every group has a CRC32
 * Nothing here is ever the user's media or the user's exported file.
 */
internal object SegmentStore {
    private const val VERSION = 1
    private const val TAG = "AMSmart"
    private const val META = "meta.json"
    private const val BLOB = "video.bin"
    const val HEADER = 16
    private const val MAX_ENTRIES = 4
    private const val MAX_ENTRY_BYTES = 1536L * 1024 * 1024
    private const val TOTAL_LIMIT = 3L * 1024 * 1024 * 1024
    private const val FREE_FLOOR = 1024L * 1024 * 1024
    private const val ORPHAN_MS = 10L * 60 * 1000
    internal const val MAX_GOP_BYTES = 96 * 1024 * 1024

    fun root(context: Context): File = File(context.applicationContext.filesDir, "export_cache")

    private fun entries(context: Context): List<File> = root(context).listFiles { f -> f.isDirectory }?.toList().orEmpty()

    private fun dirBytes(dir: File): Long = dir.walkTopDown().filter { it.isFile }.sumOf { it.length() }

    fun total(context: Context): Long = entries(context).sumOf { dirBytes(it) }

    fun clear(context: Context) {
        root(context).deleteRecursively()
    }

    private fun read(dir: File): SmartEntry? = try {
        val meta = JSONObject(File(dir, META).readText())
        if (meta.getInt("version") != VERSION) null else {
            val blob = File(dir, meta.getString("file"))
            if (!blob.isFile || blob.length() != meta.getLong("size")) null else {
                val csd = meta.getJSONArray("csd").let { a -> List(a.length()) { Base64.decode(a.getString(it), Base64.NO_WRAP) } }
                val media = meta.getJSONObject("media").let { m -> m.keys().asSequence().associateWith { m.getString(it) } }
                val g = meta.getJSONArray("g")
                val gops = List(g.length()) { i -> g.getJSONArray(i).let { CachedGop(it.getInt(0), it.getInt(1), it.getLong(2), it.getInt(3), it.getLong(4)) } }
                SmartEntry(dir, meta.getString("ctx"), meta.getString("scene"), meta.getInt("frames"), media,
                    StreamFormat(meta.getString("mime"), meta.getInt("width"), meta.getInt("height"), csd), meta.getString("path"), gops, blob)
            }
        }
    } catch (e: Exception) {
        Log.w(TAG, "unreadable export cache entry ${dir.name}", e)
        null
    }

    /** Entries that were rendered with exactly this settings key and are intact, newest first. Damaged entries are deleted. */
    fun candidates(context: Context, ctx: String): List<SmartEntry> {
        val out = ArrayList<SmartEntry>()
        for (dir in entries(context).sortedByDescending { File(it, META).lastModified() }) {
            if (!File(dir, META).isFile) continue
            val e = read(dir)
            if (e == null) { dir.deleteRecursively(); continue }
            if (e.ctx == ctx) out += e
        }
        return out
    }

    fun touch(entry: SmartEntry) {
        runCatching { File(entry.dir, META).setLastModified(System.currentTimeMillis()) }
    }

    fun drop(entry: SmartEntry) {
        entry.dir.deleteRecursively()
    }

    /** Deletes unfinished entries and the least recently used ones beyond the limits. [keep] is the entry being written. */
    fun sweep(context: Context, keep: File? = null) {
        val now = System.currentTimeMillis()
        val all = entries(context).filter { it != keep }
        for (d in all) if (!File(d, META).isFile && now - d.lastModified() > ORPHAN_MS) d.deleteRecursively()
        val done = entries(context).filter { it != keep && File(it, META).isFile }.sortedBy { File(it, META).lastModified() }.toMutableList()
        var used = done.sumOf { dirBytes(it) } + (keep?.let { dirBytes(it) } ?: 0L)
        while (done.isNotEmpty() && (done.size >= MAX_ENTRIES || used > TOTAL_LIMIT)) {
            val d = done.removeAt(0)
            used -= dirBytes(d)
            d.deleteRecursively()
        }
    }

    /** A recorder for the export that is about to run, or null when there is no room (the export is then simply not saved). */
    fun begin(context: Context, fps: Int, mime: String, estimate: Long): SegmentRecorder? {
        try {
            val app = context.applicationContext
            if (estimate <= 0 || estimate > MAX_ENTRY_BYTES) return null
            if (app.filesDir.usableSpace < estimate * 2 + FREE_FLOOR) return null
            root(app).mkdirs()
            sweep(app)
            val dir = File(root(app), "e" + java.lang.Long.toHexString(System.currentTimeMillis()) + java.lang.Long.toHexString(System.nanoTime()))
            if (!dir.mkdirs()) return null
            return SegmentRecorder(dir, fps, mime)
        } catch (e: Exception) {
            Log.w(TAG, "cannot start saving the export", e)
            return null
        }
    }

    fun commit(
        context: Context, rec: SegmentRecorder, ctx: String, scene: String, frames: Int, media: Map<String, String>,
        format: StreamFormat, path: String, encoder: String,
    ): Boolean {
        val result = rec.finish(frames) ?: return false
        try {
            val blob = File(rec.dir, BLOB)
            if (!result.file.renameTo(blob)) { rec.discard(); return false }
            val meta = JSONObject().put("version", VERSION).put("ctx", ctx).put("scene", scene).put("frames", frames)
                .put("path", path).put("encoder", encoder).put("mime", format.mime).put("width", format.width).put("height", format.height)
                .put("csd", JSONArray(format.csd.map { Base64.encodeToString(it, Base64.NO_WRAP) }))
                .put("media", JSONObject(media)).put("file", BLOB).put("size", blob.length())
                .put("g", JSONArray(result.gops.map { JSONArray(listOf(it.first, it.count, it.offset, it.length, it.crc)) }))
            val tmp = File(rec.dir, "$META.tmp")
            tmp.writeText(meta.toString())
            if (!tmp.renameTo(File(rec.dir, META))) { rec.discard(); return false }
            sweep(context, keep = rec.dir)
            Log.i(TAG, "saved export: ${result.gops.size} groups, ${blob.length()} bytes")
            return true
        } catch (e: Exception) {
            Log.w(TAG, "saving the export failed", e)
            rec.discard()
            return false
        }
    }
}

/** Reads and verifies saved groups. */
internal class SegmentReader(private val entry: SmartEntry) : AutoCloseable {
    private val file = RandomAccessFile(entry.blob, "r")

    /** The records of one group, exactly as recorded. A group whose bytes changed is never used. */
    fun read(g: CachedGop): ByteArray {
        if (g.offset < 0 || g.length <= 0 || g.offset + g.length > entry.blob.length()) throw SmartFallback("saved group outside the file")
        val bytes = ByteArray(g.length)
        file.seek(g.offset)
        file.readFully(bytes)
        if (CRC32().also { it.update(bytes) }.value != g.crc) throw SmartFallback("saved group is damaged")
        return bytes
    }

    override fun close() = file.close()
}

/** Calls [action] for every record of a group's bytes. Throws when the structure is wrong. */
internal inline fun forEachRecord(region: ByteArray, count: Int, action: (ptsUs: Long, flags: Int, offset: Int, size: Int) -> Unit) {
    val buf = ByteBuffer.wrap(region)
    var at = 0
    var n = 0
    while (at < region.size) {
        if (at + SegmentStore.HEADER > region.size) throw SmartFallback("truncated record")
        val pts = buf.getLong(at)
        val flags = buf.getInt(at + 8)
        val size = buf.getInt(at + 12)
        if (size < 0 || at + SegmentStore.HEADER + size > region.size) throw SmartFallback("bad record size")
        action(pts, flags, at + SegmentStore.HEADER, size)
        at += SegmentStore.HEADER + size
        n++
    }
    if (n != count) throw SmartFallback("group has $n packets, expected $count")
}

/** True when the packet holds an IDR picture (Annex B start codes). Only such groups can be copied next to other groups. */
internal fun isIdrPacket(mime: String, d: ByteArray, off: Int, len: Int): Boolean {
    val avc = mime == "video/avc"
    val hevc = mime == "video/hevc"
    if (!avc && !hevc) return false
    var i = off
    val end = off + len
    while (i + 3 < end) {
        if (d[i] == 0.toByte() && d[i + 1] == 0.toByte() && d[i + 2] == 1.toByte()) {
            val h = d[i + 3].toInt() and 0xFF
            if (avc && (h and 0x1F) == 5) return true
            if (hevc && ((h shr 1) and 0x3F) in 19..20) return true
            i += 3
        } else i++
    }
    return false
}

internal class RecordedExport(val file: File, val gops: List<CachedGop>)

/**
 * Records the packets that are written to the exported file, in the order they are written. While recording it checks what Smart Export
 * relies on: frames follow each other without gaps or repeats, the stream starts with a key frame, and groups start with an IDR picture.
 * If anything is off the recording is dropped (the export itself is not affected).
 */
internal class SegmentRecorder(val dir: File, private val fps: Int, private val mime: String) {
    private val tmp = File(dir, "video.bin.tmp")
    private val out = BufferedOutputStream(FileOutputStream(tmp), 1 shl 16)
    private val header = ByteArray(SegmentStore.HEADER)
    private val headerBuf = ByteBuffer.wrap(header)
    private val gops = ArrayList<CachedGop>()
    private var written = 0L
    private var lastFrame = -1
    private var gopFirst = -1
    private var gopOffset = 0L
    private var gopCount = 0
    private var gopOk = false
    private var crc = CRC32()
    @Volatile var problem: String? = null
        private set

    fun add(ptsUs: Long, flags: Int, d: ByteArray, off: Int, len: Int) {
        if (problem != null) return
        try {
            val frame = ((ptsUs * fps + 500_000L) / 1_000_000L).toInt()
            if (frame != lastFrame + 1) { problem = "frame $frame follows $lastFrame"; return }
            val key = flags and MediaCodec.BUFFER_FLAG_KEY_FRAME != 0
            if (key) {
                closeGop()
                gopFirst = frame; gopOffset = written; gopCount = 0; crc = CRC32(); gopOk = isIdrPacket(mime, d, off, len)
            } else if (gopFirst < 0) { problem = "the stream does not start with a key frame"; return }
            lastFrame = frame
            headerBuf.clear()
            headerBuf.putLong(ptsUs).putInt(flags and MediaCodec.BUFFER_FLAG_KEY_FRAME).putInt(len)
            out.write(header)
            out.write(d, off, len)
            crc.update(header, 0, header.size)
            crc.update(d, off, len)
            written += header.size + len
            gopCount++
        } catch (e: Exception) {
            problem = e.message ?: "write failed"
        }
    }

    private fun closeGop() {
        val length = written - gopOffset
        if (gopFirst >= 0 && gopCount > 0 && gopOk && length in 1..SegmentStore.MAX_GOP_BYTES) gops += CachedGop(gopFirst, gopCount, gopOffset, length.toInt(), crc.value)
        gopFirst = -1
    }

    /** Finishes the file. Null when anything was off or the number of frames is not [frames]. */
    fun finish(frames: Int): RecordedExport? {
        try {
            closeGop()
            out.flush()
            out.close()
        } catch (e: Exception) { problem = problem ?: e.message }
        if (problem != null || lastFrame + 1 != frames || gops.isEmpty()) {
            Log.i("AMSmart", "export not saved: ${problem ?: "frames ${lastFrame + 1} of $frames, groups ${gops.size}"}")
            discard()
            return null
        }
        return RecordedExport(tmp, gops)
    }

    fun discard() {
        runCatching { out.close() }
        dir.deleteRecursively()
    }
}

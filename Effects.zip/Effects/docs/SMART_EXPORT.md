# Smart Export

Re-exporting a project after a small edit renders only what changed. The unchanged seconds are copied, byte for byte, from the
encoded video of the previous export. Nothing is ever traded for speed: no lower resolution, bitrate, effects or encoder settings.

## How it works

1. **Every video export is saved** (app-private `files/export_cache/<id>/`) as the encoded packets, split into closed groups of pictures
   (GOPs), each with a CRC32, plus the scene as it was rendered and a fingerprint of every media file. `meta.json` is written last, by rename.
2. **The next export** looks for a saved export with the same *settings key* (`SmartExport.contextKey`: size, fps, codec, container,
   bitrate, precision, turn, device build, app build, imported effects/LUTs/fonts). Different key means no reuse.
3. **What changed** comes from `previewDirtyRanges(old, new, forced)`, the same dependency rules the preview cache uses (references,
   masks, parents, camera/light, layers that read what is below, header, beats). `forced` carries the layers whose media file changed on disk.
4. **Plan** (`planSmartExport`, pure logic, `SmartPlanTest`): a saved GOP is reused only if none of its frames is dirty and it lies
   inside the new video. Frame 0 is always drawn (the first encoder session creates the track and shows the stream format).
5. **Rendering**: each run of changed frames gets its own encoder session, so it starts with an IDR picture and nothing in it refers to a
   frame that is not in the file. Saved GOPs are written between runs. Audio is mixed and encoded again in full (cheap, and it keeps sync exact).
6. **Verification**: every written packet goes through `SmartJob.write`, which requires frame `k` to follow frame `k-1` exactly
   (no gap, no repeat, no black frame). Each run must start with a key frame that contains an IDR NAL. Each session's stream format
   (`csd`, size, mime) must equal the saved one. Saved GOPs are CRC-checked when read. The finished file then goes through the normal
   `verifyExport` check.
7. **Fallback**: any doubt throws `SmartFallback`; the half-written file is discarded and the whole video is rendered the normal way.
   If the final verification of a smart export reports a problem, the file is deleted and everything is rendered again.
   Failures other than an expected encoder/path mismatch count against a per-device guard (3 strikes, reset by an app update).

## History (temporal) effects

A frame inside a history effect's span is only right when every earlier frame of the span was drawn in order
(`render_graph.cpp`: any jump resets the history). So a dirty frame dirties the rest of its span, and a run that starts inside a span
first draws the span from its first frame (*warm-up*: drawn and encoded, packets dropped, cached packets used instead).
`fx.particles*` is treated the same way, to be safe.

**Related fix in the normal export loop:** the 32 px "look" stills and the 320 px live preview stills used a different render size
than the export, which the native executor treats as a jump (`r.width != fW` resets history). Inside a history span they could
corrupt the frames after them. They are now skipped for frames inside such spans (so the live preview pauses there).

## Not reused (full render, same as before)

- Codecs other than H.264/HEVC (AV1, VP9, APV), WebM.
- Frame interpolation or motion blur (frames depend on neighbours in ways the dependency check does not model).
- Settings key mismatch, unreadable media, damaged or incomplete saved export, different encoder or render path than last time,
  too little free space (needs 2x the estimate + 1 GiB), less than 15% of frames skippable, more than 32 separate changed runs.
- Whole-file reuse (`ExportReuse`) still runs first for a completely unchanged project.

## Limits

3 GiB in total, 4 exports, 1.5 GiB per export, least recently used removed first. Orphaned half-written folders are swept after 10 minutes.
Turn Smart Export off per export in the export screen (Video > Smart export).

## Known boundaries

- Granularity is the layer's span (+-1 frame), the same as the preview cache: editing one keyframe of a long layer re-renders that layer's whole span.
- Spliced GOPs come from separate rate-control sessions, so bitrate can differ slightly at the joins. Quality targets are unchanged.
- Effects that keep hidden state without declaring a history pass would need adding to `SmartExport.statefulBuiltin`.

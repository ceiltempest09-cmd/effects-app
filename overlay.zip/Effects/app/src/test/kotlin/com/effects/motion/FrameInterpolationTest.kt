package com.effects.motion

import com.effects.motion.export.ExportKind
import com.effects.motion.export.FrameInterpolation
import com.effects.motion.export.defaultSettings
import com.effects.motion.export.frameTimeMs
import com.effects.motion.model.FramePair
import com.effects.motion.model.Layer
import com.effects.motion.model.Scene
import com.effects.motion.model.VideoTiming
import com.effects.motion.model.XmlNode
import com.effects.motion.model.exportFrame
import com.effects.motion.model.exportFrameMs
import com.effects.motion.model.framePair
import com.effects.motion.model.needsFrameInterpolation
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.abs
import kotlin.math.roundToLong

class FrameInterpolationTest {
    private fun rounded(fps: Double, count: Int, first: Long = 0) = LongArray(count) { first + (it * 1e6 / fps).roundToLong() }
    private fun truncated(fps: Double, count: Int) = LongArray(count) { (it * 1e6 / fps).toLong() }

    private fun scene(fps: Int) = Scene.create("t", 1920, 1080, fps, 0)

    private fun clip(
        start: Int = 0, end: Int = 59_999, inTime: Int = 0, outTime: Int = 60_000, speed: String? = null, loop: Boolean = false,
        speedMap: XmlNode? = null,
    ): Layer {
        val attrs = linkedMapOf("id" to "1", "startTime" to "$start", "endTime" to "$end", "fillType" to "media",
            "fillVideo" to "content://clip", "inTime" to "$inTime", "outTime" to "$outTime", "s" to ".rect")
        speed?.let { attrs["speed"] = it }
        if (loop) attrs["loop"] = "true"
        return Layer(XmlNode("shape", attrs, listOfNotNull(speedMap)))
    }

    private fun Scene.at(frame: Int, fps: Int = this.fps) = exportFrameMs(frameTimeMs(this, fps, frame), fps)

    private fun Layer.pairAt(scene: Scene, frame: Int, stamps: LongArray, fps: Int = scene.fps) = framePair(scene.at(frame, fps), scene, stamps)

    private fun Layer.needsAt(scene: Scene, frame: Int, stamps: LongArray, fps: Int) = needsFrameInterpolation(scene.at(frame, fps), scene, stamps, fps)

    private fun assertPair(a: Long, b: Long, t: Float, actual: FramePair) {
        assertEquals(a, actual.a)
        assertEquals(b, actual.b)
        assertEquals(t, actual.t, 1e-3f)
    }

    @Test fun exportFrameTimesAreRecoveredExactlyAndInterpolationStartsOff() {
        val thirty = scene(30)
        for (fps in listOf(10, 24, 25, 30, 48, 50, 60)) for (k in 0 until 600) assertEquals(k * 1000.0 / fps, thirty.at(k, fps), 1e-9)
        for (kind in ExportKind.entries) assertEquals(FrameInterpolation.Off, defaultSettings(kind, thirty).interpolation)
    }

    @Test fun thirtyFramesIntoASixtyFrameExportGetHalfwayFrames() {
        val project = scene(30)
        for (stamps in listOf(rounded(30.0, 400), truncated(30.0, 400))) {
            for (k in 0 until 400) {
                assertTrue(clip().needsAt(project, k, stamps, 60))
                val pair = clip().pairAt(project, k, stamps, 60)
                if (k % 2 == 0) assertPair(stamps[k / 2], stamps[k / 2], 0f, pair) else assertPair(stamps[k / 2], stamps[k / 2 + 1], 0.5f, pair)
            }
        }
        val forty = rounded(40.0, 400)
        assertTrue(clip().needsAt(project, 1, forty, 60))
        assertPair(forty[0], forty[1], 2 / 3f, clip().pairAt(project, 1, forty, 60))
        assertPair(forty[2], forty[2], 0f, clip().pairAt(project, 3, forty, 60))
    }

    @Test fun clipsAtOrAboveTheExportRateAreLeftAlone() {
        val project = scene(30)
        assertFalse(clip().needsAt(project, 5, rounded(60.0, 400), 60))
        assertFalse(clip().needsAt(project, 5, rounded(30.0, 400), 30))
        assertFalse(clip().needsAt(scene(60), 5, rounded(59.94, 400), 60))
        assertFalse(clip().needsAt(project, 5, rounded(29.97, 400), 30))
        assertFalse(clip(speed = "2").needsAt(project, 5, rounded(30.0, 400), 60))
        assertTrue(clip(speed = "1.5").needsAt(project, 5, rounded(30.0, 400), 60))
        assertTrue(clip(speed = "0.5").needsAt(project, 5, rounded(60.0, 400), 60))
        assertTrue(clip().needsAt(project, 5, rounded(24.0, 400), 30))
        assertTrue(clip().needsAt(project, 5, rounded(25.0, 400), 30))
        assertFalse(clip().needsAt(project, 5, longArrayOf(0), 60))
    }

    @Test fun constantRateClipsAreDecidedByTheirFrameRateTimesSpeed() {
        val project = scene(30)
        for (rate in listOf(24.0, 25.0, 29.97, 30.0, 50.0, 59.94, 60.0)) for (stamps in listOf(rounded(rate, 400), truncated(rate, 400))) {
            for (speed in listOf(0.25, 0.5, 1.0, 1.5, 2.0)) for (fps in listOf(24, 25, 30, 50, 60)) {
                val layer = clip(speed = "$speed")
                for (k in 0 until 120) assertEquals("$rate fps x $speed at $fps fps, frame $k", speed * rate < fps * 0.99, layer.needsAt(project, k, stamps, fps))
            }
        }
    }

    @Test fun aSixtyFrameClipInAThirtyFrameProjectShowsEverySourceFrameInASixtyFrameExport() {
        val project = scene(30)
        for (stamps in listOf(rounded(60.0, 400), truncated(60.0, 400))) {
            val picked = (0 until 300).map { clip().exportFrame(project.at(it, 60), project, stamps, 60) }
            for ((k, pair) in picked.withIndex()) assertEquals(FramePair(stamps[k], stamps[k], 0f), pair)
            assertEquals(300, picked.toSet().size)
            for (k in 0 until 100) assertNull(clip().exportFrame(project.at(k, 30), project, stamps, 30))
        }
        val fast = rounded(120.0, 600)
        for (k in 0 until 200) assertEquals(FramePair(fast[2 * k], fast[2 * k], 0f), clip().exportFrame(project.at(k, 60), project, fast, 60))
        val thirty = rounded(30.0, 400)
        assertPair(thirty[0], thirty[1], 0.5f, clip().exportFrame(project.at(1, 60), project, thirty, 60)!!)
    }

    @Test fun theExactExportTimePicksTheSourceFrameAtOrJustBeforeIt() {
        val project = scene(30)
        val stamps = rounded(60.0, 400)
        val late = clip(start = 7)
        for (k in 1 until 200) assertEquals(FramePair(stamps[k - 1], stamps[k - 1], 0f), late.exportFrame(project.at(k, 60), project, stamps, 60))
        val mixed = listOf(rounded(30.0, 400), stamps)
        val shown = (0 until 120).map { k -> mixed.map { clip().exportFrame(project.at(k, 60), project, it, 60)!! } }
        assertEquals(120, shown.map { it[1] }.toSet().size)
        assertTrue(shown.withIndex().all { (k, frames) -> (frames[0].t > 0f) == (k % 2 == 1) })
    }

    @Test fun aNormalSpeedClipAtTheProjectRateLandsOnWholeFrames() {
        val project = scene(30)
        for (stamps in listOf(rounded(30.0, 400), truncated(30.0, 400))) {
            for (frame in 0 until 300) assertPair(stamps[frame], stamps[frame], 0f, clip().pairAt(project, frame, stamps))
            val late = clip(start = project.frameStart(7))
            for (frame in 7 until 300) assertPair(stamps[frame - 7], stamps[frame - 7], 0f, late.pairAt(project, frame, stamps))
        }
    }

    @Test fun quarterSpeedStepsThroughQuarterFractions() {
        val project = scene(10)
        val stamps = rounded(10.0, 12)
        val layer = clip(end = 4499, outTime = 1200, speed = "0.25")
        for (frame in 0..44) {
            assertTrue(layer.needsAt(project, frame, stamps, 10))
            val k = frame / 4
            val step = frame % 4
            if (step == 0) assertPair(stamps[k], stamps[k], 0f, layer.pairAt(project, frame, stamps))
            else assertPair(stamps[k], stamps[k + 1], step / 4f, layer.pairAt(project, frame, stamps))
        }
    }

    @Test fun halfSpeedFromALaterStartAlternatesWholeAndHalfFrames() {
        val project = scene(30)
        val stamps = rounded(30.0, 200)
        val layer = clip(start = project.frameStart(1), speed = "0.5")
        assertEquals(33, layer.startTime)
        for (j in 0 until 120) {
            val m = j / 2
            if (j % 2 == 0) assertPair(stamps[m], stamps[m], 0f, layer.pairAt(project, 1 + j, stamps))
            else assertPair(stamps[m], stamps[m + 1], 0.5f, layer.pairAt(project, 1 + j, stamps))
        }
    }

    @Test fun aLowerSourceRateFallsBetweenFrames() {
        val project = scene(30)
        val film = rounded(24.0, 200)
        assertPair(film[0], film[1], 0.8f, clip().pairAt(project, 1, film))
        assertPair(film[1], film[2], 0.6f, clip().pairAt(project, 2, film))
        assertPair(film[4], film[4], 0f, clip().pairAt(project, 5, film))
    }

    @Test fun fasterThanNormalSpeedLandsOnWholeOrHalfFrames() {
        val project = scene(30)
        val stamps = rounded(30.0, 400)
        for (frame in 0 until 150) assertPair(stamps[2 * frame], stamps[2 * frame], 0f, clip(speed = "2").pairAt(project, frame, stamps))
        val faster = clip(speed = "1.5")
        for (frame in 0 until 150 step 2) assertPair(stamps[3 * frame / 2], stamps[3 * frame / 2], 0f, faster.pairAt(project, frame, stamps))
        for (frame in 1 until 150 step 2) assertPair(stamps[3 * frame / 2], stamps[3 * frame / 2 + 1], 0.5f, faster.pairAt(project, frame, stamps))
    }

    @Test fun theSlowestSpeedBarelyMovesAndSnapsNearWholeFrames() {
        val project = scene(30)
        val stamps = rounded(30.0, 10)
        val layer = clip(speed = "0.001")
        assertTrue(layer.needsAt(project, 0, stamps, 30))
        assertPair(stamps[0], stamps[0], 0f, layer.pairAt(project, 0, stamps))
        assertPair(stamps[0], stamps[1], 0.5f, layer.pairAt(project, 10, stamps))
        assertPair(stamps[1], stamps[1], 0f, layer.pairAt(project, 20, stamps))
        assertPair(stamps[1], stamps[2], 0.25f, layer.pairAt(project, 25, stamps))
    }

    @Test fun aSpeedRampIsInterpolatedOnlyWhereItSlowsBelowTheExportRate() {
        val ramp = XmlNode("speedMap", children = listOf(
            XmlNode("kf", mapOf("t" to "0", "v" to "2")), XmlNode("kf", mapOf("t" to "1000000000", "v" to "0.25"))))
        val project = scene(30)
        val stamps = rounded(30.0, 200)
        val layer = clip(end = 9999, speedMap = ramp)
        assertFalse(layer.needsAt(project, 0, stamps, 30))
        assertTrue(layer.needsAt(project, 200, stamps, 30))
        val timing = VideoTiming(layer)
        var previous = -1.0
        for (frame in 0 until 240) {
            val pair = layer.pairAt(project, frame, stamps)
            val us = timing.mediaMs(frame * 1000.0 / 30) * 1000
            val shown = pair.a + pair.t.toDouble() * (pair.b - pair.a)
            assertTrue(pair.a <= pair.b && pair.t >= 0f && pair.t < 1f)
            assertTrue(pair.b - pair.a <= 33_334)
            assertTrue("frame $frame shows $shown for $us", abs(shown - us) <= 0.005 * 33_334 + 1)
            assertTrue(shown >= previous)
            previous = shown
        }
    }

    @Test fun aLoopingClipWrapsToItsStartAndNeverBlendsPastItsEnd() {
        val project = scene(10)
        val stamps = rounded(10.0, 20)
        val layer = clip(outTime = 500, speed = "0.5", loop = true)
        assertPair(stamps[3], stamps[4], 0.5f, layer.pairAt(project, 7, stamps))
        assertPair(stamps[4], stamps[4], 0f, layer.pairAt(project, 9, stamps))
        assertPair(stamps[0], stamps[0], 0f, layer.pairAt(project, 10, stamps))
        assertPair(stamps[0], stamps[1], 0.5f, layer.pairAt(project, 11, stamps))
        assertPair(stamps[2], stamps[2], 0f, layer.pairAt(project, 24, stamps))
    }

    @Test fun aLoopTrimmedToOneSecondHoldsItsLastFrameInsteadOfBlendingTheFrameAtOneSecond() {
        val project = scene(30)
        val stamps = rounded(30.0, 60)
        val layer = clip(outTime = 1000, loop = true)
        assertEquals(983.333, project.at(59, 60), 1e-3)
        assertEquals(966_667L, stamps[29])
        assertEquals(1_000_000L, stamps[30])
        assertTrue(layer.needsAt(project, 59, stamps, 60))
        assertPair(stamps[29], stamps[29], 0f, layer.pairAt(project, 59, stamps, 60))
        assertPair(stamps[28], stamps[29], 0.5f, layer.pairAt(project, 57, stamps, 60))
        assertPair(stamps[0], stamps[0], 0f, layer.pairAt(project, 60, stamps, 60))
        assertPair(stamps[0], stamps[1], 0.5f, layer.pairAt(project, 61, stamps, 60))
    }

    @Test fun aTrimBetweenSourceFramesNeverBlendsInAFrameOutsideIt() {
        val project = scene(30)
        val stamps = rounded(30.0, 60)
        val end = clip(outTime = 990)
        assertPair(stamps[29], stamps[29], 0f, end.pairAt(project, 59, stamps, 60))
        for (frame in 60..70) assertPair(stamps[29], stamps[29], 0f, end.pairAt(project, frame, stamps, 60))
        assertPair(stamps[28], stamps[29], 0.5f, end.pairAt(project, 57, stamps, 60))
        val start = clip(inTime = 10)
        assertPair(stamps[1], stamps[1], 0f, start.pairAt(project, 0, stamps, 60))
        assertPair(stamps[1], stamps[1], 0f, start.pairAt(project, 1, stamps, 60))
        assertPair(stamps[1], stamps[2], 0.3f, start.pairAt(project, 2, stamps, 60))
    }

    @Test fun aSlowSectionOfAVariableRateClipIsInterpolatedOnItsOwn() {
        val project = scene(60)
        val stamps = longArrayOf(0, 100_000) + (200_000L..1_000_000L step 10_000).toList()
        assertEquals(83, stamps.size)
        assertTrue(clip().needsAt(project, 3, stamps, 60))
        assertPair(0, 100_000, 0.5f, clip().pairAt(project, 3, stamps, 60))
        assertTrue(clip().needsAt(project, 9, stamps, 60))
        assertPair(100_000, 200_000, 0.5f, clip().pairAt(project, 9, stamps, 60))
        for (frame in 12..59) assertFalse("frame $frame", clip().needsAt(project, frame, stamps, 60))
        assertPair(500_000, 500_000, 0f, clip().pairAt(project, 30, stamps, 60))
    }

    @Test fun pastTheTrimEndTheLastFrameBeforeItIsHeld() {
        val project = scene(10)
        val stamps = rounded(10.0, 20)
        val layer = clip(end = 9999, outTime = 300, speed = "0.5")
        assertPair(stamps[1], stamps[2], 0.5f, layer.pairAt(project, 3, stamps))
        for (frame in 4..30) assertPair(stamps[2], stamps[2], 0f, layer.pairAt(project, frame, stamps))
    }

    @Test fun aClipWithNoIndexedFramesIsLeftToTheNormalSampling() {
        val project = scene(30)
        val layer = clip()
        for (fps in listOf(30, 60)) {
            assertFalse(layer.needsAt(project, 7, LongArray(0), fps))
            assertNull(layer.exportFrame(project.at(7, fps), project, LongArray(0), fps))
        }
    }

    @Test fun theFirstAndLastSourceFramesAreHeld() {
        val project = scene(30)
        val late = rounded(30.0, 10, first = 40_000)
        val layer = clip(speed = "0.5")
        assertPair(late[0], late[0], 0f, layer.pairAt(project, 0, late))
        assertPair(late[0], late[0], 0f, layer.pairAt(project, 2, late))
        assertPair(late[9], late[9], 0f, layer.pairAt(project, 40, late))
        assertPair(late[9], late[9], 0f, clip(speed = "0.5", inTime = 290).pairAt(project, 3, late))
        assertPair(0, 0, 0f, layer.pairAt(project, 7, longArrayOf(0)))
    }

    @Test fun aNegativeSpeedIsNotPlayedBackwards() {
        val project = scene(30)
        val stamps = rounded(30.0, 50)
        val layer = clip(speed = "-2")
        val shown = (0 until 60).map { layer.pairAt(project, it, stamps).let { p -> p.a + p.t * (p.b - p.a) } }
        assertEquals(shown.sorted(), shown)
    }
}

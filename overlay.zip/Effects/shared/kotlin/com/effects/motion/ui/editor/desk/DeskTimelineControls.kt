package com.effects.motion.ui.editor

object DeskTimelineControls {
    var zoom: ((Float) -> Unit)? = null
    var fit: (() -> Unit)? = null
    var headerDp = 180f
}

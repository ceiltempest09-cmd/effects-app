package com.effects.motion.engine

import android.hardware.HardwareBuffer
import android.graphics.Rect
import android.graphics.Bitmap
import android.view.Surface
import com.effects.motion.model.ColorSupport

class NativeEngine(backend: Backend) : AutoCloseable {
    enum class Backend { GRAPHITE, GANESH, GL }

    private var handle = nativeCreate(backend.ordinal)
    val failed: Boolean get() = nativeFailed(handle)

    val info: String get() = nativeInfo(handle)

    fun attach(surface: Surface, forEncoder: Boolean): Long =
        nativeAttach(handle, surface, forEncoder).also { check(it != 0L) { "attach failed" } }

    fun detach(target: Long) = nativeDetach(handle, target)

    fun timing(target: Long): String = nativeTiming(handle, target)

    fun setScene(xml: String) {
        nativeSetScene(handle, xml.toByteArray())?.let { throw IllegalArgumentException(it) }
    }

    fun loadEffect(xml: String): String = nativeLoadEffect(handle, xml.toByteArray())

    val maxPictureSize: Int get() = nativeMaxPictureSize(handle)

    /** What the GPU really does for the colour settings of the scene last set. Call on the engine thread. */
    fun colorStatus(): ColorSupport? = nativeColorStatus(handle)?.takeIf { it.size >= 5 }?.let {
        ColorSupport(
            effective = com.effects.motion.engine.bitdepth.BitDepth.entries.firstOrNull { d -> d.bits == it[0] } ?: com.effects.motion.engine.bitdepth.BitDepth.BIT8,
            hdrPreserved = it[1] != 0, hdrOutput = it[2] != 0, float16 = it[3] != 0, float32 = it[4] != 0,
        )
    }

    fun setPicture(uri: String, bitmap: Bitmap?, layerId: Long = 0): Boolean =
        nativeSetPicture(handle, uri.toByteArray(), layerId, bitmap, null, bitmap?.hasAlpha() == false, 0, 0, 0, 0, 0, 0)

    fun setPicture(uri: String, buffer: HardwareBuffer, layerId: Long = 0, opaque: Boolean = true, standard: Int = 0, range: Int = 0, crop: Rect? = null): Boolean =
        nativeSetPicture(handle, uri.toByteArray(), layerId, null, buffer, opaque, standard, range, crop?.left ?: 0, crop?.top ?: 0, crop?.right ?: 0, crop?.bottom ?: 0)

    fun setVideoFrame(uri: String, layerId: Long, pts: Long, buffer: HardwareBuffer, standard: Int = 0, range: Int = 0, crop: Rect? = null): Boolean =
        nativeSetVideoFrame(handle, uri.toByteArray(), layerId, pts, buffer, standard, range, crop?.left ?: 0, crop?.top ?: 0, crop?.right ?: 0, crop?.bottom ?: 0)

    fun interpolateVideo(uri: String, layerId: Long, frames: LongArray, t: Float, mode: Int, soft: Boolean, blur: Float, params: FloatArray, made: Bitmap? = null): Boolean =
        nativeInterpolateVideo(handle, uri.toByteArray(), layerId, frames, t, mode, soft, blur, params, made)

    fun moshStart(uri: String, layerId: Long, pts: LongArray, mosh: FloatArray, flow: FloatArray): Int =
        nativeMoshStart(handle, uri.toByteArray(), layerId, pts, mosh, flow)

    fun moshFrame(uri: String, layerId: Long, step: Int, buffer: HardwareBuffer, standard: Int = 0, range: Int = 0, crop: Rect? = null): Boolean =
        nativeMoshFrame(handle, uri.toByteArray(), layerId, step, buffer, standard, range, crop?.left ?: 0, crop?.top ?: 0, crop?.right ?: 0, crop?.bottom ?: 0)

    fun renderScene(
        target: Long, timeMs: Double, scale: Float, dx: Float, dy: Float, background: Int, selectedId: Long, handles: Int,
        view: PreviewView,
    ): Int = nativeRenderScene(
        handle, target, timeMs, scale, dx, dy, background, selectedId, handles,
        view.pixels, view.divisor, view.gridSpacing, view.solo, view.soloIds.takeIf { it.isNotEmpty() }?.toLongArray(),
        view.guides.flatMap { listOf(if (it.vertical) 1f else 0f, it.at, if (it.wide) 1f else 0f) }.toFloatArray(), view.refPx,
    )

    fun setCameraView(on: Boolean) = nativeSetCameraView(handle, on)

    fun setSceneView(on: Boolean, yaw: Float, pitch: Float, dist: Float) = nativeSetSceneView(handle, on, yaw, pitch, dist)

    fun setAccurateBlur(on: Boolean) = nativeSetAccurateBlur(handle, on)

    fun renderFrame(target: Long, timeMs: Double, background: Int, presentTimeNs: Long): Int =
        nativeRenderFrame(handle, target, timeMs, background, presentTimeNs)

    fun renderBuffer(buffer: HardwareBuffer, timeMs: Double, background: Int): Int = nativeRenderBuffer(handle, buffer, timeMs, background)

    fun releaseBuffers() = nativeReleaseBuffers(handle)

    fun trim() = nativeTrim(handle)

    val displayTiming: Boolean get() = org.json.JSONObject(info).optBoolean("displayTiming")
    val openGl: Boolean get() = org.json.JSONObject(info).optString("backend") == "gl"

    fun layerQuad(layerId: Long, timeMs: Double): FloatArray? = nativeLayerQuad(handle, layerId, timeMs)

    fun propertyNumbers(layerId: Long, effect: Int, name: String, timeMs: Double): FloatArray? = nativePropertyNumbers(handle, layerId, effect, name, timeMs)

    fun layerMatrix(layerId: Long, timeMs: Double): FloatArray? = nativeLayerMatrix(handle, layerId, timeMs)

    fun layerBounds(layerId: Long, timeMs: Double): FloatArray? = nativeLayerBounds(handle, layerId, timeMs)

    fun layerOutline(layerId: Long, timeMs: Double): String? = nativeLayerOutline(handle, layerId, timeMs)

    fun hitTest(x: Float, y: Float, timeMs: Double): Long = nativeHitTest(handle, x, y, timeMs)

    fun still(timeMs: Double, width: Int, height: Int): ByteArray? = nativeStill(handle, timeMs, width, height)

    fun previewStill(timeMs: Double, width: Int, height: Int, accurateBlur: Boolean): ByteArray? = nativePreviewStill(handle, timeMs, width, height, accurateBlur)

    fun shapeIcon(xml: String, size: Int, color: Int): ByteArray? = nativeShapeIcon(handle, xml.toByteArray(), size, color)

    fun setModel(uri: String, mesh: com.effects.motion.media.Mesh?): Boolean =
        nativeSetModel(uri.toByteArray(), mesh?.positions, mesh?.normals, mesh?.uvs, mesh?.colors, mesh?.triangles, mesh?.slots, mesh?.twoSided == true)

    override fun close() {
        nativeDestroy(handle)
        handle = 0
    }

    companion object {
        init {
            System.loadLibrary("amengine")
        }

        fun ease(easing: String, us: FloatArray): FloatArray = nativeEase(easing, us)

        fun blipTimes(text: String, speed: Float, pause: Float, every: Int): FloatArray = nativeBlipTimes(text.toByteArray(), speed, pause, every)

        fun ease(easing: String, u: Float): Float = if (easing.isEmpty()) u else nativeEase(easing, floatArrayOf(u))[0]

        fun fastCaptionCpu(): Boolean = nativeFastCaptionCpu()

        fun shapeOutline(scene: String, t: Float, rounded: Boolean): String? = nativeShapeOutline(scene.toByteArray(), t, rounded)

        fun vulkanDevice(): String? = nativeVulkanDevice()

        fun usePipelineCache(cacheDir: java.io.File, version: Int) {
            val dir = java.io.File(cacheDir, "gpu-$version")
            cacheDir.listFiles { f -> f.isDirectory && f.name.startsWith("gpu-") && f != dir }?.forEach { it.deleteRecursively() }
            val files = dir.listFiles().orEmpty()
            files.filter { ".tmp" in it.name }.forEach { it.delete() }
            val programs = files.filter { it.name.startsWith("p") && ".tmp" !in it.name }.sortedByDescending { it.lastModified() }
            var kept = 0L
            for (file in programs) { kept += file.length(); if (kept > 32L shl 20) file.delete() }
            if (dir.isDirectory || dir.mkdirs()) nativeSetPipelineDir(dir.absolutePath)
            nativeSetNativeFences(nativeFencesRequested(cacheDir))
        }

        /**
         * XML effect-library passes are native GLSL ES. Enable that path by default on Graphite;
         * users can explicitly disable it in Settings. The legacy Ganesh/OpenGL engine cannot
         * share its render targets with the native graph backend, so it must keep this disabled.
         */
        private const val NATIVE_SHADERS_OFF_FLAG = "native-shaders.off"
        /** Native GLSL is always on now: a stale "off" flag from an older build is deleted and never read. */
        @Suppress("UNUSED_PARAMETER")
        fun nativeShadersRequested(cacheDir: java.io.File): Boolean {
            java.io.File(cacheDir, NATIVE_SHADERS_OFF_FLAG).delete()
            return true
        }

        @Suppress("UNUSED_PARAMETER")
        fun requestNativeShaders(cacheDir: java.io.File, on: Boolean) {
            java.io.File(cacheDir, NATIVE_SHADERS_OFF_FLAG).delete()
        }

        /** Call after GPU fallback selection, before any effects are loaded into the engine. */
        @Suppress("UNUSED_PARAMETER")
        fun configureNativeShaders(cacheDir: java.io.File?, supportsNativeGraph: Boolean) {
            // Always native GLSL. If this engine cannot share buffers with the native GL backend (the OpenGL/Ganesh engine), the pass
            // reports a Capability error when it draws, instead of the effect being rejected up front as "skia cannot run glsl-es".
            if (cacheDir != null) nativeShadersRequested(cacheDir)
            nativeSetNativeShaders(true)
        }

        /** Experimental: hand Skia's work to the native GL passes through a GPU fence instead of a CPU wait (falls back to the CPU wait when the device cannot). Off by default. */
        const val NATIVE_FENCES_FLAG = "native-fences.on"
        fun nativeFencesRequested(cacheDir: java.io.File): Boolean = java.io.File(cacheDir, NATIVE_FENCES_FLAG).exists()
        fun requestNativeFences(cacheDir: java.io.File, on: Boolean) {
            val flag = java.io.File(cacheDir, NATIVE_FENCES_FLAG)
            if (on) flag.writeText("1") else flag.delete()
        }

        @JvmStatic private external fun nativeCreate(backend: Int): Long
        @JvmStatic private external fun nativeShapeOutline(scene: ByteArray, t: Float, rounded: Boolean): String?
        @JvmStatic private external fun nativeSetPipelineDir(dir: String)
        @JvmStatic private external fun nativeSetNativeShaders(on: Boolean)
        @JvmStatic private external fun nativeSetNativeFences(on: Boolean)
        @JvmStatic private external fun nativeDestroy(engine: Long)
        @JvmStatic private external fun nativeInfo(engine: Long): String
        @JvmStatic private external fun nativeFailed(engine: Long): Boolean
        @JvmStatic private external fun nativeAttach(engine: Long, surface: Surface, forEncoder: Boolean): Long
        @JvmStatic private external fun nativeDetach(engine: Long, target: Long)
        @JvmStatic private external fun nativeTiming(engine: Long, target: Long): String
        @JvmStatic private external fun nativeSetScene(engine: Long, xml: ByteArray): String?
        @JvmStatic private external fun nativeLoadEffect(engine: Long, xml: ByteArray): String
        @JvmStatic private external fun nativeMaxPictureSize(engine: Long): Int
        @JvmStatic private external fun nativeColorStatus(engine: Long): IntArray?
        @JvmStatic private external fun nativeSetPicture(engine: Long, uri: ByteArray, layerId: Long,
                                                        bitmap: Bitmap?, buffer: HardwareBuffer?, opaque: Boolean, standard: Int, range: Int, left: Int, top: Int, right: Int, bottom: Int): Boolean
        @JvmStatic private external fun nativeSetVideoFrame(engine: Long, uri: ByteArray, layerId: Long, pts: Long, buffer: HardwareBuffer, standard: Int, range: Int, left: Int, top: Int, right: Int, bottom: Int): Boolean
        @JvmStatic private external fun nativeInterpolateVideo(engine: Long, uri: ByteArray, layerId: Long, frames: LongArray, t: Float,
                                                               mode: Int, soft: Boolean, blur: Float, params: FloatArray, made: Bitmap?): Boolean
        @JvmStatic private external fun nativeMoshStart(engine: Long, uri: ByteArray, layerId: Long, pts: LongArray, mosh: FloatArray, flow: FloatArray): Int
        @JvmStatic private external fun nativeMoshFrame(engine: Long, uri: ByteArray, layerId: Long, step: Int, buffer: HardwareBuffer, standard: Int, range: Int, left: Int, top: Int, right: Int, bottom: Int): Boolean
        @JvmStatic private external fun nativeRenderScene(
            engine: Long, target: Long, timeMs: Double, scale: Float, dx: Float, dy: Float, background: Int,
            selectedId: Long, handles: Int, pixels: Boolean, pixelDivisor: Int, gridSpacing: Float, solo: Int, soloIds: LongArray?,
            guides: FloatArray, refPx: Float,
        ): Int
        @JvmStatic private external fun nativeSetCameraView(engine: Long, on: Boolean)
        @JvmStatic private external fun nativeSetSceneView(engine: Long, on: Boolean, yaw: Float, pitch: Float, dist: Float)
        @JvmStatic private external fun nativeSetAccurateBlur(engine: Long, on: Boolean)
        @JvmStatic private external fun nativeRenderFrame(
            engine: Long, target: Long, timeMs: Double, background: Int, presentTimeNs: Long,
        ): Int
        @JvmStatic private external fun nativeRenderBuffer(engine: Long, buffer: HardwareBuffer, timeMs: Double, background: Int): Int
        @JvmStatic private external fun nativeReleaseBuffers(engine: Long)
        @JvmStatic private external fun nativeTrim(engine: Long)
        @JvmStatic private external fun nativeEase(easing: String, us: FloatArray): FloatArray
        @JvmStatic private external fun nativeBlipTimes(text: ByteArray, speed: Float, pause: Float, every: Int): FloatArray
        @JvmStatic private external fun nativeFastCaptionCpu(): Boolean
        @JvmStatic private external fun nativeVulkanDevice(): String?
        @JvmStatic private external fun nativeLayerBounds(engine: Long, layerId: Long, timeMs: Double): FloatArray?
        @JvmStatic private external fun nativeLayerQuad(engine: Long, layerId: Long, timeMs: Double): FloatArray?
        @JvmStatic private external fun nativePropertyNumbers(engine: Long, layerId: Long, effect: Int, name: String, timeMs: Double): FloatArray?
        @JvmStatic private external fun nativeLayerMatrix(engine: Long, layerId: Long, timeMs: Double): FloatArray?
        @JvmStatic private external fun nativeLayerOutline(engine: Long, layerId: Long, timeMs: Double): String?
        @JvmStatic private external fun nativeHitTest(engine: Long, x: Float, y: Float, timeMs: Double): Long
        @JvmStatic private external fun nativeStill(engine: Long, timeMs: Double, width: Int, height: Int): ByteArray?
        @JvmStatic private external fun nativePreviewStill(engine: Long, timeMs: Double, width: Int, height: Int, accurateBlur: Boolean): ByteArray?
        @JvmStatic private external fun nativeShapeIcon(engine: Long, xml: ByteArray, size: Int, color: Int): ByteArray?
        @JvmStatic private external fun nativeSetModel(uri: ByteArray, positions: FloatArray?, normals: FloatArray?, uvs: FloatArray?,
                                                      colors: IntArray?, triangles: IntArray?, slots: IntArray?, twoSided: Boolean): Boolean
    }
}
